# move-old-files.ps1
# Run this ONCE, from the project root, after the reorganised files have been copied in:
#
#     powershell -ExecutionPolicy Bypass -File .\move-old-files.ps1
#
# The reorganisation replaced 86 files with TypeScript versions in new folders. The old versions are still on your disk,
# next to the new ones, and they would confuse the TypeScript compiler and Next.js (two copies of the same module).
# This script MOVES each old file into  _legacy\before-reorganize\  keeping its folder structure. NOTHING IS DELETED:
# to bring a file back, move it out of that folder again. If the project is a git repository the moves are done with
# `git mv`, so git records them as renames and keeps the history.
#
# It is safe to run twice: files that were already moved are skipped.

$ErrorActionPreference = 'Stop'

$files = @(

    'components\AdminPanel.tsx',
    'components\LicensePanel.tsx',
    'components\NetworkBanner.tsx',
    'components\NotifyPanel.tsx',
    'components\ReceiptCard.tsx',
    'components\RevocationPanel.tsx',
    'components\TxLink.tsx',
    'components\VehicleHistory.tsx',
    'components\VehicleRegistryPanel.tsx',
    'components\WalletBar.tsx',
    'components\admin\IdReviewQueue.tsx',
    'components\admin\UsersTable.tsx',
    'components\auth\AccountBar.tsx',
    'components\auth\AuthProvider.tsx',
    'components\auth\CapabilityGate.tsx',
    'components\auth\IdStep.tsx',
    'components\auth\ui.tsx',
    'components\dashboard\Dashboard.tsx',
    'components\layout\Layout.tsx',
    'components\layout\NavBar.tsx',
    'components\wallet\WalletProvider.tsx',
    'e2e\accounts.e2e.js',
    'e2e\flow.e2e.js',
    'e2e\multichain.e2e.js',
    'e2e\navigation.e2e.js',
    'e2e\notify-ui.e2e.js',
    'e2e\notify.e2e.js',
    'migrations\2_deploy_vehicle_registration.js',
    'migrations\3_deploy_vehicle_manager.js',
    'notifier\deployments.js',
    'notifier\index.js',
    'notifier\mailer.js',
    'notifier\resolve.js',
    'notifier\state.js',
    'notifier\templates.js',
    'notifier\watcher.js',
    'scripts\check-consistency.js',
    'scripts\gen-real-structure.js',
    'scripts\id-maintenance.js',
    'scripts\record-deployment.js',
    'scripts\review-id.js',
    'scripts\set-role.js',
    'scripts\sync-contracts.js',
    'server\apiHelpers.js',
    'server\audit.js',
    'server\auth.js',
    'server\challenge.js',
    'server\config.js',
    'server\crypto.js',
    'server\env.js',
    'server\firebaseAdmin.js',
    'server\httpError.js',
    'server\identity\checkers.js',
    'server\identity\index.js',
    'server\identity\worker.js',
    'server\links.js',
    'server\locations.js',
    'server\otp.js',
    'server\phone.js',
    'server\rateLimit.js',
    'server\roles.js',
    'server\session.js',
    'server\sms\arkesel.js',
    'server\sms\consoleProvider.js',
    'server\sms\http.js',
    'server\sms\hubtel.js',
    'server\sms\index.js',
    'server\sms\mock.js',
    'server\store.js',
    'server\users.js',
    'shared\journey.js',
    'shared\navigation.js',
    'shared\rpc.js',
    'test\accounts\accounts.test.js',
    'test\accounts\helpers.js',
    'test\accounts\journey.test.js',
    'test\e2e.js',
    'utils\accountTypes.ts',
    'utils\api.ts',
    'utils\auth.ts',
    'utils\contracts.ts',
    'utils\errors.ts',
    'utils\firebaseClient.ts',
    'utils\networks.ts',
    'utils\receipts.ts',
    'utils\walletLink.ts'
)

$archive = '_legacy\before-reorganize'
$isGit = (Test-Path '.git') -and (Get-Command git -ErrorAction SilentlyContinue)
$moved = 0
$skipped = 0

function Test-Tracked($path) {
    if (-not $isGit) { return $false }
    git ls-files --error-unmatch -- $path 2>$null | Out-Null
    return ($LASTEXITCODE -eq 0)
}

foreach ($file in $files) {
    if (-not (Test-Path -LiteralPath $file)) { $skipped++; continue }

    $target = Join-Path $archive $file
    New-Item -ItemType Directory -Force -Path (Split-Path $target) | Out-Null

    if (Test-Path -LiteralPath $target) {
        # The archive already holds a copy of this file (the zip includes one). If it is identical, the copy in the
        # live tree is just a duplicate and can go; if it differs, keep both by giving the moved file a new name.
        $same = (Get-FileHash -LiteralPath $file).Hash -eq (Get-FileHash -LiteralPath $target).Hash
        if ($same) {
            if (Test-Tracked $file) { git rm -q -- $file } else { Remove-Item -LiteralPath $file }
            $moved++
            continue
        }
        $target = $target + '.from-project'
    }

    if (Test-Tracked $file) { git mv -- $file $target } else { Move-Item -LiteralPath $file -Destination $target }
    $moved++
}

# Remove folders that are now empty (the old lower-case component folders, for example).
$skip = [regex]'\\(node_modules|_legacy|\.git|\.next)(\\|$)'
Get-ChildItem -Directory -Recurse |
    Where-Object { $_.FullName -notmatch $skip } |
    Sort-Object { $_.FullName.Length } -Descending |
    ForEach-Object { if (-not (Get-ChildItem -Force -LiteralPath $_.FullName)) { Remove-Item -LiteralPath $_.FullName } }

Write-Host ''
Write-Host "Moved $moved old file(s) into $archive  ($skipped were already gone)."
Write-Host 'Next:  yarn install   then   yarn check   then   yarn dev'
