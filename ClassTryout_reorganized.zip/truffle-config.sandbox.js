// TEST-ONLY (not shipped): same config, but solc from node_modules (the sandbox cannot download compilers)
// and two extra local chains for the multi-chain test.
const cfg = require("./truffle-config.js");
cfg.compilers.solc.version = require.resolve("solc/soljson.js");
cfg.networks.local1 = { host: "127.0.0.1", port: 7545, network_id: 5777 };
cfg.networks.local2 = { host: "127.0.0.1", port: 7546, network_id: 8453 };
module.exports = cfg;
