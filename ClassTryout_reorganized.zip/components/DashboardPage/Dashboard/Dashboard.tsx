// components/Dashboard/Dashboard/Dashboard.tsx
// The page people land on after signing in. It answers one question: "what do I do now?"
// The answer comes from shared/journey.ts (unit-tested). This file only gathers the facts and draws the pieces.

import React, { useEffect, useState } from 'react';
import styles from '@/styles/Layout.module.css';
import nav from '@/shared/nav.json';
import { buildJourney } from '@/shared/journey';
import { visibleItems } from '@/shared/navigation';
import type { JourneyStep } from '@/shared/journey';
import type { NavItem } from '@/shared/navigation';
import { listLinkedWallets } from '@/blockchain/wallets';
import { REQUIRE_ACCOUNT, useAccount } from '@/components/Authentication';
import { useWallet } from '@/components/WalletConnection';
import { NextStepHero } from '../NextStepHero';
import { JourneyChecklist } from '../JourneyChecklist';
import { AccountSummary } from '../AccountSummary';
import { ActionTiles } from '../ActionTiles';

export const Dashboard: React.FC = () => {
  const { me, firebaseUser, refresh } = useAccount();
  const wallet = useWallet();
  const [walletIsLinked, setWalletIsLinked] = useState<boolean | null>(null);

  // Has this person linked a wallet for email notices? (null means we could not find out.)
  useEffect(() => {
    let stillMounted = true;

    listLinkedWallets()
      .then((wallets) => stillMounted && setWalletIsLinked(wallets.length > 0))
      .catch(() => stillMounted && setWalletIsLinked(null));

    return () => {
      stillMounted = false;
    };
  }, []);

  // After using the email link, or after a reviewer decides, pick up the change without a manual reload.
  async function recheck() {
    try {
      if (firebaseUser && me && me.email && !me.emailVerified) {
        await firebaseUser.reload();
        await firebaseUser.getIdToken(true);
      }

      await refresh();
    } catch {
      // Offline: leave the screen as it is.
    }
  }

  // Check again whenever the person comes back to this browser tab.
  useEffect(() => {
    const onReturn = () => {
      if (document.visibilityState !== 'hidden') recheck();
    };

    window.addEventListener('focus', onReturn);
    document.addEventListener('visibilitychange', onReturn);

    return () => {
      window.removeEventListener('focus', onReturn);
      document.removeEventListener('visibilitychange', onReturn);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [firebaseUser, me && me.emailVerified, me && me.email]);

  if (!me) return null;

  const journey = buildJourney({
    me,
    wallet: { connected: !!wallet.account, deployed: wallet.deployed, networkName: wallet.networkName },
    linked: walletIsLinked,
  });

  const name = me.profile.givenName || me.profile.displayName || me.email || 'there';

  const tiles = visibleItems(nav.items as NavItem[], me, { requireAccount: REQUIRE_ACCOUNT }).filter(
    (item) => item.href !== '/dashboard'
  );

  // The "Connect wallet" step has no page. Its button connects the wallet, or points at the network picker.
  function handleStepAction(step: JourneyStep) {
    if (step.action !== 'connect') return;

    if (!wallet.account) {
      wallet.connect();
      return;
    }

    (document.querySelector('select[aria-label=Network]') as HTMLElement | null)?.focus();
  }

  return (
    <div className={styles.stack}>
      <NextStepHero name={name} next={journey.next} onAction={handleStepAction} onRecheck={recheck} />

      <div className={styles.twoCol}>
        <JourneyChecklist steps={journey.steps} onAction={handleStepAction} />

        <AccountSummary me={me} walletAccount={wallet.account} networkName={wallet.networkName} />
      </div>

      <ActionTiles me={me} items={tiles} />
    </div>
  );
};

export default Dashboard;
