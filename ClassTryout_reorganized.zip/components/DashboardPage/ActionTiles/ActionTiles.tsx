// components/Dashboard/ActionTiles/ActionTiles.tsx
// "What you can do": one tile per page this person can open. A tile is greyed out when the account is not allowed yet.

import React from 'react';
import Link from 'next/link';
import styles from '@/styles/Layout.module.css';
import { LOCKED_REASON_SHORT } from '@/constants';
import type { NavItem } from '@/shared/navigation';
import type { Me } from '@/types';

export interface ActionTilesProps {
  me: Me;
  items: NavItem[];
}

export const ActionTiles: React.FC<ActionTilesProps> = ({ me, items }) => {
  return (
    <section>
      <h3 style={{ margin: '6px 0 12px', fontSize: 16 }}>What you can do</h3>

      <div className={styles.cards} data-testid="tiles">
        {items.map((item) => {
          const capability = item.capability ? me.capabilities[item.capability] : null;
          const locked = !!capability && !capability.allowed;
          const reason = (capability && capability.reason) || 'role';

          return (
            <Link
              key={item.href}
              href={item.href}
              className={`${styles.tile} ${locked ? styles.tileLocked : ''}`}
              data-testid={`tile-${item.href.slice(1).replace('/', '-')}`}
            >
              <span className={styles.tileTitle}>{item.label}</span>
              <span className={styles.tileText}>{item.blurb}</span>

              {locked ? (
                <span className={styles.tileState}>{LOCKED_REASON_SHORT[reason] || 'Locked'}</span>
              ) : (
                <span className={styles.tileOpen}>Open →</span>
              )}
            </Link>
          );
        })}
      </div>
    </section>
  );
};

export default ActionTiles;
