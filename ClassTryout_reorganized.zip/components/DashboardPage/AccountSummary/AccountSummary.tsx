// components/Dashboard/AccountSummary/AccountSummary.tsx
// "Your account": role, ID level, phone and wallet in four short lines.

import React from 'react';
import Link from 'next/link';
import styles from '@/styles/Layout.module.css';
import { shortAddress } from '@/utils/shortAddress';
import type { Me } from '@/types';

const ID_LEVEL_TEXT = ['No ID yet', 'Added, awaiting review', 'Confirmed'];

const LABEL_STYLE = { color: '#6a7385' };
const VALUE_STYLE = { margin: 0 };

export interface AccountSummaryProps {
  me: Me;
  walletAccount: string | null;
  networkName: string;
}

export const AccountSummary: React.FC<AccountSummaryProps> = ({ me, walletAccount, networkName }) => {
  const walletText = walletAccount ? `${shortAddress(walletAccount)} on ${networkName}` : 'Not connected';

  return (
    <section className={styles.panel}>
      <h3>Your account</h3>

      <dl style={{ display: 'grid', gridTemplateColumns: '110px 1fr', gap: '6px 10px', fontSize: 14, margin: 0 }}>
        <dt style={LABEL_STYLE}>Role</dt>
        <dd style={{ ...VALUE_STYLE, textTransform: 'capitalize' }}>{me.role.replace('_', ' ')}</dd>

        <dt style={LABEL_STYLE}>ID</dt>
        <dd style={VALUE_STYLE}>{ID_LEVEL_TEXT[me.identity.level]}</dd>

        <dt style={LABEL_STYLE}>Phone</dt>
        <dd style={VALUE_STYLE}>{me.phone.verified ? me.phone.masked : 'Not verified'}</dd>

        <dt style={LABEL_STYLE}>Wallet</dt>
        <dd style={VALUE_STYLE}>{walletText}</dd>
      </dl>

      <p style={{ marginTop: 14 }}>
        <Link href="/account" className={styles.ctaGhost}>
          Manage my account
        </Link>
      </p>
    </section>
  );
};

export default AccountSummary;
