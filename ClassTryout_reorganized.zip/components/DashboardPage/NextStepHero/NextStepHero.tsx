// components/Dashboard/NextStepHero/NextStepHero.tsx
// The big box at the top of the dashboard: "Next: <the one thing to do now>".

import React from 'react';
import styles from '@/styles/Layout.module.css';
import type { JourneyStep } from '@/shared/journey';
import { StepButton } from '../StepButton';

export interface NextStepHeroProps {
  name: string;
  next: JourneyStep | null;
  onAction: (step: JourneyStep) => void;
  onRecheck: () => void;
}

export const NextStepHero: React.FC<NextStepHeroProps> = ({ name, next, onAction, onRecheck }) => {
  return (
    <section className={`${styles.hero} ${next ? styles.heroNext : ''}`} data-testid="next-step">
      <p className={styles.eyebrow}>Welcome, {name}</p>

      {next ? (
        <>
          <h2 data-testid="next-title">
            {next.status === 'waiting' ? 'Waiting: ' : 'Next: '}
            {next.title}
          </h2>

          <p>{next.detail}</p>

          <StepButton step={next} big onAction={onAction} />

          {next.id === 'email' && (
            <>
              {' '}
              <button type="button" className={styles.ctaGhost} onClick={onRecheck} data-testid="recheck">
                I have verified it
              </button>
            </>
          )}

          {next.status === 'waiting' && (
            <>
              {' '}
              <button type="button" className={styles.ctaGhost} onClick={onRecheck} data-testid="recheck">
                Check again
              </button>
            </>
          )}
        </>
      ) : (
        <>
          <h2 data-testid="next-title">You are all set</h2>
          <p>Your account is complete and your wallet is connected. Pick what you want to do below.</p>
        </>
      )}
    </section>
  );
};

export default NextStepHero;
