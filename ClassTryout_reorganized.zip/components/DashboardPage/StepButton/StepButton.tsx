// components/Dashboard/StepButton/StepButton.tsx
// The button for one step of the journey. It is a link when the step has a page, or a button when it has an action.

import React from 'react';
import Link from 'next/link';
import styles from '@/styles/Layout.module.css';
import type { JourneyStep } from '@/shared/journey';

export interface StepButtonProps {
  step: JourneyStep;
  big?: boolean;
  onAction: (step: JourneyStep) => void;
}

export const StepButton: React.FC<StepButtonProps> = ({ step, big = false, onAction }) => {
  const className = big ? styles.cta : `${styles.ctaGhost} ${styles.small}`;

  if (step.href) {
    return (
      <Link href={step.href} className={className}>
        {step.cta}
      </Link>
    );
  }

  return (
    <button type="button" className={className} onClick={() => onAction(step)}>
      {step.cta}
    </button>
  );
};

export default StepButton;
