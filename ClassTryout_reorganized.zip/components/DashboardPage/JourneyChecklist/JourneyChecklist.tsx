// components/Dashboard/JourneyChecklist/JourneyChecklist.tsx
// "Your checklist": every step of the journey, with a tick for each one that is done.

import React from 'react';
import styles from '@/styles/Layout.module.css';
import type { JourneyStep, StepStatus } from '@/shared/journey';
import { StepButton } from '../StepButton';

export interface JourneyChecklistProps {
  steps: JourneyStep[];
  onAction: (step: JourneyStep) => void;
}

function dotClass(status: StepStatus): string {
  if (status === 'done') return styles.dotDone;
  if (status === 'current') return styles.dotCurrent;
  if (status === 'waiting') return styles.dotWaiting;

  return '';
}

export const JourneyChecklist: React.FC<JourneyChecklistProps> = ({ steps, onAction }) => {
  return (
    <section className={styles.panel}>
      <h3>Your checklist</h3>

      <ol className={styles.steps} data-testid="checklist">
        {steps.map((step) => (
          <li key={step.id} className={styles.stepRow} data-testid={`step-${step.id}`} data-status={step.status}>
            <span className={`${styles.dot} ${dotClass(step.status)}`} aria-hidden="true">
              {step.status === 'done' ? '✓' : ''}
            </span>

            <div className={styles.stepBody}>
              <div className={styles.stepTitle}>
                {step.title}
                {step.optional && <span className={styles.optionalTag}>optional</span>}
              </div>

              <div className={styles.stepDetail}>{step.detail}</div>
            </div>

            {step.status !== 'done' && step.status !== 'waiting' && (
              <div className={styles.stepAct}>
                <StepButton step={step} onAction={onAction} />
              </div>
            )}
          </li>
        ))}
      </ol>
    </section>
  );
};

export default JourneyChecklist;
