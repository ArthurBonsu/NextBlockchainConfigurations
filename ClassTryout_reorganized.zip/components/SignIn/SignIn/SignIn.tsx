// components/SignIn/SignIn/SignIn.tsx
// The sign-in and create-account screen: email + password, or Google, GitHub and X.
// The logic is in hooks/useSignIn.ts. The Firebase calls are in services/auth/.

import React, { useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import styles from '@/styles/Account.module.css';
import { firebaseConfigured, firebaseMissing } from '@/services/firebase';
import { useSignIn } from '@/hooks';
import { safeNext } from '@/utils';
import { useAccount, AccountProblem, SignInForm, SocialSignInButtons } from '@/components/Authentication';
import { Notice } from '@/components/Common';
import { NavBar } from '@/components/AppLayout';

// Once the account is loaded, leave this page: to the set-up screen if it is not finished, otherwise onward.
function useLeaveWhenSignedIn(nextPage: string) {
  const router = useRouter();
  const { state, me } = useAccount();

  useEffect(() => {
    if (state !== 'ready' || !me) return;

    if (me.onboarding.complete) {
      router.replace(nextPage || '/dashboard');
    } else {
      const query = nextPage ? `?next=${encodeURIComponent(nextPage)}` : '';

      router.replace(`/onboarding${query}`);
    }
  }, [state, me, nextPage, router]);
}

const NotSetUp: React.FC = () => (
  <main className={styles.page}>
    <div className={styles.narrow}>
      <Notice kind="info">Sign-in is not set up on this site yet. Set the NEXT_PUBLIC_FIREBASE_* values in .env.local.</Notice>
    </div>
  </main>
);

export const SignIn: React.FC = () => {
  const router = useRouter();
  const { state } = useAccount();
  const signIn = useSignIn();

  const nextPage = safeNext(router.query.next, '');

  useLeaveWhenSignedIn(nextPage);

  if (!firebaseConfigured) return <NotSetUp />;

  const isSignIn = signIn.mode === 'in';

  return (
    <main className={styles.page}>
      <NavBar variant="minimal" />

      <div className={styles.narrow}>
        <div className={styles.card}>
          <h1>{isSignIn ? 'Sign in' : 'Create your account'}</h1>

          <p className={styles.muted}>One account for vehicles, licences and notifications.</p>

          <div className={styles.tabs} role="tablist">
            <button
              type="button"
              role="tab"
              aria-selected={isSignIn}
              className={`${styles.tab} ${isSignIn ? styles.tabOn : ''}`}
              onClick={() => signIn.changeMode('in')}
              data-testid="tab-in"
            >
              Sign in
            </button>

            <button
              type="button"
              role="tab"
              aria-selected={!isSignIn}
              className={`${styles.tab} ${!isSignIn ? styles.tabOn : ''}`}
              onClick={() => signIn.changeMode('up')}
              data-testid="tab-up"
            >
              Create account
            </button>
          </div>

          {signIn.error && (
            <Notice kind="err" testid="auth-error">
              {signIn.error}
            </Notice>
          )}

          {signIn.info && (
            <Notice kind="ok" testid="auth-info">
              {signIn.info}
            </Notice>
          )}

          {state === 'error' && <AccountProblem />}

          {firebaseMissing.length > 0 && (
            <Notice kind="info">
              Some Firebase settings are empty ({firebaseMissing.join(', ')}). Email sign-in may still work; Google, GitHub and X sign-in
              need all of them. See <Link href="/setup-check">the set-up check</Link>.
            </Notice>
          )}

          <SignInForm
            mode={signIn.mode}
            email={signIn.email}
            password={signIn.password}
            repeatedPassword={signIn.repeatedPassword}
            busy={signIn.busy}
            onEmailChange={signIn.setEmail}
            onPasswordChange={signIn.setPassword}
            onRepeatedPasswordChange={signIn.setRepeatedPassword}
            onSubmit={signIn.submitEmailForm}
            onForgotPassword={signIn.resetPassword}
          />

          <div className={styles.divider}>or</div>

          <SocialSignInButtons busy={signIn.busy} onSignIn={signIn.signInWithSocial} />

          <p className={styles.muted} style={{ marginTop: 16 }}>
            Creating an account means you will add your phone number and details next. <Link href="/">Back to the home page</Link>
          </p>
        </div>
      </div>
    </main>
  );
};

export default SignIn;
