// components/Revocations/RevocationAdminActions/RevocationAdminActions.tsx
// Process a report (which revokes the vehicle) and reinstate a vehicle.
// Only the wallet that owns the RevocationManager can do these. Anyone else is told they are not the admin.

import React, { useState } from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { processReport, reinstateVehicle } from '@/blockchain/contracts/RevocationManager';
import { useActionStatus } from '@/hooks/useActionStatus';
import { StatusMessage } from '@/components/Common';
import { ReceiptCard } from '@/components/Receipts';
import type { Receipt } from '@/blockchain/types';

const ADMIN_PENDING = 'Confirm the transaction in your wallet... (admin only)';

export const RevocationAdminActions: React.FC = () => {
  const [reportId, setReportId] = useState('');
  const [processReceipt, setProcessReceipt] = useState<Receipt | null>(null);
  const processStatus = useActionStatus();

  const [pseudonym, setPseudonym] = useState('');
  const reinstateStatus = useActionStatus();

  async function handleProcess() {
    const id = reportId.trim();

    if (!id) return;

    processStatus.showPending(ADMIN_PENDING);
    setProcessReceipt(null);

    try {
      setProcessReceipt(await processReport(id));
      processStatus.showSuccess(`Report ${id} processed — vehicle revoked.`);
      setReportId('');
    } catch (err) {
      processStatus.showError(err);
    }
  }

  async function handleReinstate() {
    const name = pseudonym.trim();

    if (!name) return;

    reinstateStatus.showPending(ADMIN_PENDING);

    try {
      await reinstateVehicle(name);
      reinstateStatus.showSuccess(`"${name}" reinstated.`);
      setPseudonym('');
    } catch (err) {
      reinstateStatus.showError(err);
    }
  }

  return (
    <div className={styles.adminSection}>
      <div className={styles.adminLabel}>Admin actions</div>

      <div className={styles.subtle}>
        Only the admin wallet (the RevocationManager owner) can complete these. Anyone else is told they are not the admin.
      </div>

      <div className={styles.section}>
        <label className={styles.label}>Process a report (revokes the offender)</label>

        <div className={styles.inputRow}>
          <input
            className={styles.input}
            placeholder="Report ID"
            value={reportId}
            onChange={(e) => setReportId(e.target.value)}
          />

          <button className={styles.buttonAdmin} onClick={handleProcess} disabled={processStatus.isPending}>
            Process
          </button>
        </div>

        <StatusMessage status={processStatus.status} />

        {processReceipt && <ReceiptCard receipt={processReceipt} />}
      </div>

      <div className={styles.section}>
        <label className={styles.label}>Reinstate a vehicle</label>

        <div className={styles.inputRow}>
          <input
            className={styles.input}
            placeholder="Vehicle pseudonym"
            value={pseudonym}
            onChange={(e) => setPseudonym(e.target.value)}
          />

          <button className={styles.buttonAdmin} onClick={handleReinstate} disabled={reinstateStatus.isPending}>
            Reinstate
          </button>
        </div>

        <StatusMessage status={reinstateStatus.status} />
      </div>
    </div>
  );
};

export default RevocationAdminActions;
