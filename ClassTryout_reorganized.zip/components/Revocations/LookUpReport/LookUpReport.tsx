// components/Revocations/LookUpReport/LookUpReport.tsx
// "Look up a report": reads a report from the RevocationManager. Free, no wallet confirmation.

import React, { useState } from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { getReport } from '@/blockchain/contracts/RevocationManager';
import { useActionStatus } from '@/hooks/useActionStatus';
import { StatusMessage } from '@/components/Common';
import type { ReportInfo } from '@/blockchain/types';

const ReportResult: React.FC<{ report: ReportInfo }> = ({ report }) => {
  return (
    <div className={styles.resultBox}>
      <div>
        <span className={styles.resultLabel}>Offender:</span> {report.offender}
      </div>

      <div>
        <span className={styles.resultLabel}>Reporter:</span> {report.reporter}
      </div>

      <div>
        <span className={styles.resultLabel}>Reason:</span> {report.reason}
      </div>

      <div>
        <span className={styles.resultLabel}>Submitted:</span> {report.timestamp}
      </div>

      <div>
        <span className={styles.resultLabel}>Processed:</span>{' '}
        {report.processed ? (
          <span className={styles.badgeRevoked}>Yes</span>
        ) : (
          <span className={styles.badgeActive}>Not yet</span>
        )}
      </div>
    </div>
  );
};

export const LookUpReport: React.FC = () => {
  const [reportId, setReportId] = useState('');
  const [report, setReport] = useState<ReportInfo | null>(null);
  const lookupStatus = useActionStatus();

  async function handleLookUp() {
    const id = reportId.trim();

    if (!id) return;

    lookupStatus.showPending('Reading from chain...');
    setReport(null);

    try {
      setReport(await getReport(id));
      lookupStatus.clear();
    } catch (err) {
      lookupStatus.showError(err);
    }
  }

  return (
    <div className={styles.section}>
      <label className={styles.label}>Look up a report</label>

      <div className={styles.inputRow}>
        <input
          className={styles.input}
          placeholder="Report ID"
          value={reportId}
          onChange={(e) => setReportId(e.target.value)}
        />

        <button className={styles.buttonSecondary} onClick={handleLookUp}>
          Get Report
        </button>
      </div>

      <StatusMessage status={lookupStatus.status} />

      {report && <ReportResult report={report} />}
    </div>
  );
};

export default LookUpReport;
