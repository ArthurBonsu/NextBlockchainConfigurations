// components/Revocations/RevocationPanel/RevocationPanel.tsx
// The Revocations page card: report a vehicle, look up a report, and the admin actions.
// The contract work is in blockchain/contracts/RevocationManager/RevocationManagerActions.ts

import React from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { ReportVehicleForm } from '../ReportVehicleForm';
import { LookUpReport } from '../LookUpReport';
import { RevocationAdminActions } from '../RevocationAdminActions';

export const RevocationPanel: React.FC = () => {
  return (
    <div className={styles.card}>
      <h2>Revocation</h2>

      <ReportVehicleForm />

      <LookUpReport />

      <RevocationAdminActions />
    </div>
  );
};

export default RevocationPanel;
