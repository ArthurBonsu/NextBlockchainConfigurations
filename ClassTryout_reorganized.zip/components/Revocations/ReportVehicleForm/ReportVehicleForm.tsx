// components/Revocations/ReportVehicleForm/ReportVehicleForm.tsx
// "Report a vehicle": writes to the RevocationManager contract. Anyone can report.

import React, { useState } from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { submitReport } from '@/blockchain/contracts/RevocationManager';
import { useActionStatus } from '@/hooks/useActionStatus';
import { StatusMessage } from '@/components/Common';
import { ReceiptCard } from '@/components/Receipts';
import type { Receipt } from '@/blockchain/types';

export const ReportVehicleForm: React.FC = () => {
  const [offender, setOffender] = useState('');
  const [reporter, setReporter] = useState('');
  const [reason, setReason] = useState('');
  const [receipt, setReceipt] = useState<Receipt | null>(null);
  const reportStatus = useActionStatus();

  async function handleSubmit() {
    const input = {
      offender: offender.trim(),
      reporter: reporter.trim(),
      reason: reason.trim(),
    };

    if (!input.offender || !input.reporter || !input.reason) return;

    reportStatus.showPending('Confirm the transaction in your wallet...');
    setReceipt(null);

    try {
      const result = await submitReport(input);

      setReceipt(result.receipt);
      reportStatus.showSuccess(result.reportId ? `Report submitted — ID ${result.reportId}` : 'Report submitted.');

      setOffender('');
      setReporter('');
      setReason('');
    } catch (err) {
      reportStatus.showError(err);
    }
  }

  return (
    <div className={styles.section}>
      <label className={styles.label}>Report a vehicle</label>

      <div className={styles.stackedInputs}>
        <input
          className={styles.input}
          placeholder="Offender pseudonym"
          value={offender}
          onChange={(e) => setOffender(e.target.value)}
        />

        <input
          className={styles.input}
          placeholder="Reporter pseudonym"
          value={reporter}
          onChange={(e) => setReporter(e.target.value)}
        />

        <input className={styles.input} placeholder="Reason" value={reason} onChange={(e) => setReason(e.target.value)} />

        <button className={styles.button} onClick={handleSubmit} disabled={reportStatus.isPending}>
          Submit Report
        </button>
      </div>

      <StatusMessage status={reportStatus.status} />

      {receipt && <ReceiptCard receipt={receipt} />}
    </div>
  );
};

export default ReportVehicleForm;
