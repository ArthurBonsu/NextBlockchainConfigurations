// components/Home/Home/Home.tsx
// The front door. Signed-in people go straight to their dashboard.
// Everyone else sees what the system does and how to start.

import React, { useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import styles from '@/styles/Layout.module.css';
import { useAccount } from '@/components/Authentication';
import { Layout } from '@/components/AppLayout';
import { HowItWorks } from '../HowItWorks';

const DEMO_MODE_NOTE =
  'Sign-in is not set up on this site yet, so you are in demo mode: every page is open and nothing is tied to an account.';

export const Home: React.FC = () => {
  const router = useRouter();
  const { state } = useAccount();

  const demoMode = state === 'unavailable';

  useEffect(() => {
    if (state === 'ready') router.replace('/dashboard');
  }, [state, router]);

  return (
    <Layout title="Vehicle and licence registry" width="normal" chain>
      <section className={`${styles.hero} ${styles.stack}`}>
        <div>
          <p className={styles.eyebrow}>ClassTryout</p>

          <h2>Register vehicles and issue licences on the blockchain</h2>

          <p>
            Every registration, licence and revocation leaves a permanent, publicly checkable receipt on the chain. Your account decides
            who may do what; the blockchain keeps the record.
          </p>
        </div>

        {demoMode && <div className={`${styles.notice} ${styles.noticeInfo}`}>{DEMO_MODE_NOTE}</div>}

        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          {!demoMode && (
            <Link href="/signin" className={styles.cta}>
              Sign in or create an account
            </Link>
          )}

          <Link href="/history" className={styles.ctaGhost}>
            Look up a vehicle&apos;s history
          </Link>

          {demoMode && (
            <Link href="/vehicles" className={styles.cta}>
              Open the registry
            </Link>
          )}
        </div>
      </section>

      <HowItWorks />
    </Layout>
  );
};

export default Home;
