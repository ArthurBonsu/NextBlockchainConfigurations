// components/Home/HowItWorks/HowItWorks.tsx
// The four numbered steps on the front page.

import React from 'react';
import styles from '@/styles/Layout.module.css';

interface HowItWorksStep {
  title: string;
  detail: string;
}

const STEPS: HowItWorksStep[] = [
  {
    title: 'Create an account',
    detail: 'Sign up with email, Google, GitHub or X, then verify your email and your phone number.',
  },
  {
    title: 'Confirm your ID',
    detail: 'Add your Ghana Card, passport or other ID. A reviewer confirms it. This unlocks registration and licensing.',
  },
  {
    title: 'Register a vehicle',
    detail: 'Connect your wallet on a test network and register a vehicle under a pseudonym.',
  },
  {
    title: 'Licences and revocations',
    detail: 'Officers issue licences. Reports can lead to a revocation, and every step is recorded on the chain.',
  },
];

export const HowItWorks: React.FC = () => {
  return (
    <section className={styles.panel} style={{ marginTop: 18 }}>
      <h3>How it works</h3>

      <ol className={styles.steps}>
        {STEPS.map((step, index) => (
          <li key={step.title} className={styles.stepRow}>
            <span className={`${styles.dot} ${styles.dotCurrent}`} style={{ color: '#2457d6', fontWeight: 700 }}>
              {index + 1}
            </span>

            <div className={styles.stepBody}>
              <div className={styles.stepTitle}>{step.title}</div>
              <div className={styles.stepDetail}>{step.detail}</div>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
};

export default HowItWorks;
