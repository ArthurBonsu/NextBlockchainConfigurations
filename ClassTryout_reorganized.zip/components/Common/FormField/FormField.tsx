// components/Common/FormField/FormField.tsx
// A label, an input (passed as children), and an optional hint or error message.

import React, { ReactNode } from 'react';
import styles from '@/styles/Account.module.css';

export interface FormFieldProps {
  id: string;
  label: string;
  error?: string;
  hint?: string;
  children: ReactNode;
}

export const FormField: React.FC<FormFieldProps> = ({ id, label, error, hint, children }) => {
  return (
    <div className={styles.field}>
      <label htmlFor={id}>{label}</label>

      {children}

      {hint && !error && <span className={styles.hint}>{hint}</span>}

      {error && (
        <span className={styles.err} data-testid={`err-${id}`}>
          {error}
        </span>
      )}
    </div>
  );
};

export default FormField;
