// components/Common/StatusMessage/StatusMessage.tsx
// Shows an ActionStatus: red for an error, green for success, grey while waiting.

import React from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import type { ActionStatus } from '@/blockchain/types';

export interface StatusMessageProps {
  status: ActionStatus;
}

function classFor(type: ActionStatus['type']): string {
  if (type === 'error') return styles.errorText;
  if (type === 'success') return styles.successText;

  return styles.subtle;
}

export const StatusMessage: React.FC<StatusMessageProps> = ({ status }) => {
  if (!status.message) return null;

  return <div className={classFor(status.type)}>{status.message}</div>;
};

export default StatusMessage;
