export { Notice } from './Notice';
export type { NoticeProps, NoticeKind } from './Notice';
