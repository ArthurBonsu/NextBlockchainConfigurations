// components/Common/Notice/Notice.tsx
// A coloured box with a message: "err" (red), "ok" (green) or "info" (blue).

import React, { ReactNode } from 'react';
import styles from '@/styles/Account.module.css';

export type NoticeKind = 'err' | 'ok' | 'info';

export interface NoticeProps {
  kind: NoticeKind;
  children: ReactNode;
  testid?: string;
}

function classFor(kind: NoticeKind): string {
  if (kind === 'err') return styles.noticeErr;
  if (kind === 'ok') return styles.noticeOk;

  return styles.noticeInfo;
}

export const Notice: React.FC<NoticeProps> = ({ kind, children, testid }) => {
  return (
    <div
      className={`${styles.notice} ${classFor(kind)}`}
      role={kind === 'err' ? 'alert' : 'status'}
      data-testid={testid}
    >
      {children}
    </div>
  );
};

export default Notice;
