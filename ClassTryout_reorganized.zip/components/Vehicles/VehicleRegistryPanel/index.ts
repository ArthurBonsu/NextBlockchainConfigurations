export { VehicleRegistryPanel } from './VehicleRegistryPanel';
