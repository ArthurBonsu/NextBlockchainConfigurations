// components/Vehicles/VehicleRegistryPanel/VehicleRegistryPanel.tsx
// The Vehicles page card: register a vehicle, and look one up.
// The contract work is in blockchain/contracts/VehicleRegistry/VehicleRegistryActions.ts

import React from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { RegisterVehicleForm } from '../RegisterVehicleForm';
import { LookUpVehicle } from '../LookUpVehicle';

export const VehicleRegistryPanel: React.FC = () => {
  return (
    <div className={styles.card}>
      <h2>Vehicle Registry</h2>

      <RegisterVehicleForm />

      <LookUpVehicle />
    </div>
  );
};

export default VehicleRegistryPanel;
