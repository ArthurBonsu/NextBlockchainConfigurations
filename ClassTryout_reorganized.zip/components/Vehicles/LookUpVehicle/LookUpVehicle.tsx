// components/Vehicles/LookUpVehicle/LookUpVehicle.tsx
// "Look up a vehicle": reads the VehicleRegistry and RevocationManager. Free, no wallet confirmation.

import React, { useState } from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { lookUpVehicle } from '@/blockchain/contracts/VehicleRegistry';
import { useActionStatus } from '@/hooks/useActionStatus';
import { StatusMessage } from '@/components/Common';
import type { VehicleInfo } from '@/blockchain/types';

// The answer box under the search field.
const VehicleResult: React.FC<{ vehicle: VehicleInfo }> = ({ vehicle }) => {
  if (!vehicle.isRegistered) {
    return <div className={styles.errorText}>Not registered.</div>;
  }

  return (
    <>
      <div>
        <span className={styles.resultLabel}>Owner:</span> <code>{vehicle.owner}</code>
      </div>

      <div>
        <span className={styles.resultLabel}>Registered:</span> {vehicle.registrationTime}
      </div>

      <div>
        <span className={styles.resultLabel}>Status:</span>{' '}
        {vehicle.isRevoked ? (
          <span className={styles.badgeRevoked}>
            Revoked{vehicle.revokedReason ? ` — ${vehicle.revokedReason}` : ''}
          </span>
        ) : (
          <span className={styles.badgeActive}>Active</span>
        )}
      </div>
    </>
  );
};

export const LookUpVehicle: React.FC = () => {
  const [pseudonym, setPseudonym] = useState('');
  const [vehicle, setVehicle] = useState<VehicleInfo | null>(null);
  const lookupStatus = useActionStatus();

  async function handleLookUp() {
    const name = pseudonym.trim();

    if (!name) return;

    lookupStatus.showPending('Reading from chain...');
    setVehicle(null);

    try {
      setVehicle(await lookUpVehicle(name));
      lookupStatus.clear();
    } catch (err) {
      lookupStatus.showError(err);
    }
  }

  return (
    <div className={styles.section}>
      <label className={styles.label}>Look up a vehicle</label>

      <div className={styles.inputRow}>
        <input
          className={styles.input}
          placeholder="Vehicle pseudonym to check"
          value={pseudonym}
          onChange={(e) => setPseudonym(e.target.value)}
        />

        <button className={styles.buttonSecondary} onClick={handleLookUp}>
          Look Up
        </button>
      </div>

      <StatusMessage status={lookupStatus.status} />

      {vehicle && (
        <div className={styles.resultBox}>
          <VehicleResult vehicle={vehicle} />
        </div>
      )}
    </div>
  );
};

export default LookUpVehicle;
