// components/Vehicles/RegisterVehicleForm/RegisterVehicleForm.tsx
// "Register a vehicle": one input, one button. Writes to the VehicleRegistry contract.

import React, { useState } from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { registerVehicle } from '@/blockchain/contracts/VehicleRegistry';
import { useActionStatus } from '@/hooks/useActionStatus';
import { StatusMessage } from '@/components/Common';
import { ReceiptCard } from '@/components/Receipts';
import type { Receipt } from '@/blockchain/types';

export const RegisterVehicleForm: React.FC = () => {
  const [pseudonym, setPseudonym] = useState('');
  const [receipt, setReceipt] = useState<Receipt | null>(null);
  const registerStatus = useActionStatus();

  async function handleRegister() {
    const name = pseudonym.trim();

    if (!name) return;

    registerStatus.showPending('Confirm the transaction in your wallet...');
    setReceipt(null);

    try {
      const newReceipt = await registerVehicle(name);

      setReceipt(newReceipt);
      registerStatus.showSuccess(`"${name}" registered on-chain.`);
      setPseudonym('');
    } catch (err) {
      registerStatus.showError(err);
    }
  }

  return (
    <div className={styles.section}>
      <label className={styles.label}>Register a vehicle</label>

      <div className={styles.inputRow}>
        <input
          className={styles.input}
          placeholder="Vehicle pseudonym, e.g. car-001"
          value={pseudonym}
          onChange={(e) => setPseudonym(e.target.value)}
        />

        <button className={styles.button} onClick={handleRegister} disabled={registerStatus.isPending}>
          Register
        </button>
      </div>

      <StatusMessage status={registerStatus.status} />

      {receipt && <ReceiptCard receipt={receipt} />}
    </div>
  );
};

export default RegisterVehicleForm;
