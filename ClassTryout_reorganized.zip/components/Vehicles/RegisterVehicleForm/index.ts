export { RegisterVehicleForm } from './RegisterVehicleForm';
