// components/Vehicles/VehicleHistory/VehicleHistory.tsx
// The full history of one vehicle, read straight from the blockchain's event logs.
// There is no database. Reload the page, or open it on another computer, and you get the same history.

import React, { useState } from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { getContracts } from '@/blockchain/contracts';
import { getVehicleTimeline } from '@/blockchain/history';
import { useActionStatus } from '@/hooks/useActionStatus';
import { StatusMessage } from '@/components/Common';
import { TxLink } from '@/components/Receipts';
import type { TimelineEntry } from '@/blockchain/types';

const TimelineRow: React.FC<{ entry: TimelineEntry }> = ({ entry }) => {
  const details = Object.entries(entry.details);

  return (
    <div className={styles.timelineEntry}>
      <div className={styles.timelineDot} />

      <div className={styles.timelineContent}>
        <div className={styles.timelineType}>{entry.type}</div>

        <div className={styles.subtle}>
          {entry.timestamp} · block #{entry.blockNumber}
        </div>

        {details.map(([key, value]) => (
          <div key={key} className={styles.timelineDetail}>
            <span className={styles.receiptLabel}>{key}</span> {value}
          </div>
        ))}

        <TxLink hash={entry.txHash} className={styles.timelineTx} />
      </div>
    </div>
  );
};

export const VehicleHistory: React.FC = () => {
  const [pseudonym, setPseudonym] = useState('');
  const [timeline, setTimeline] = useState<TimelineEntry[] | null>(null);
  const loadStatus = useActionStatus();

  async function handleLoad() {
    const name = pseudonym.trim();

    if (!name) return;

    loadStatus.showPending('Scanning chain history...');
    setTimeline(null);

    try {
      const { web3, registry, revocation, license, deployment } = await getContracts();

      // Scan only from the block the contracts were deployed in, never from block 0.
      const startBlock = Math.min(
        deployment.VehicleRegistry.startBlock,
        deployment.RevocationManager.startBlock,
        deployment.LicenseRegistry.startBlock
      );

      const result = await getVehicleTimeline({ web3, registry, revocation, license }, name, startBlock);

      setTimeline(result);
      loadStatus.clear();
    } catch (err) {
      loadStatus.showError(err);
    }
  }

  return (
    <div className={styles.card}>
      <h2>On-Chain History</h2>

      <div className={styles.subtle}>
        No database — every entry below is read live from this vehicle&apos;s event logs across all three contracts.
      </div>

      <div className={styles.section} style={{ marginTop: 16 }}>
        <div className={styles.inputRow}>
          <input
            className={styles.input}
            placeholder="Vehicle pseudonym"
            value={pseudonym}
            onChange={(e) => setPseudonym(e.target.value)}
          />

          <button className={styles.buttonSecondary} onClick={handleLoad}>
            Load Timeline
          </button>
        </div>

        <StatusMessage status={loadStatus.status} />

        {timeline && (
          <div className={styles.timeline}>
            {timeline.length === 0 && <div className={styles.subtle}>No events found for that pseudonym.</div>}

            {timeline.map((entry, index) => (
              <TimelineRow key={index} entry={entry} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default VehicleHistory;
