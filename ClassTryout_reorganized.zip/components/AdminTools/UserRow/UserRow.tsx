// components/Admin/UserRow/UserRow.tsx
// One person in the users table, with the buttons to suspend, restore or change their role.

import React from 'react';
import styles from '@/styles/Layout.module.css';
import rolesPolicy from '@/shared/roles.json';
import { ID_LEVEL_LABELS, roleName } from '../UsersFilters';
import type { PendingUserChange, UserRowData } from '@/types';

export interface UserRowProps {
  user: UserRowData;
  isMe: boolean;
  canChangeStatus: boolean;
  canChangeRole: boolean;
  pending: PendingUserChange | null;
  note: string;
  newRole: string;
  busy: boolean;
  onStartChange: (change: PendingUserChange) => void;
  onNoteChange: (note: string) => void;
  onNewRoleChange: (role: string) => void;
  onConfirm: () => void;
  onCancel: () => void;
}

function idBadgeClass(level: number): string {
  if (level === 2) return styles.badgeOk;
  if (level === 1) return styles.badgeWarn;

  return '';
}

export const UserRow: React.FC<UserRowProps> = (props) => {
  const { user } = props;
  const roleList: string[] = (rolesPolicy as any).roles;
  const isOpen = props.pending !== null && props.pending.uid === user.uid;
  const where = [user.suburb, user.district, user.region].filter(Boolean).join(', ') || '—';

  return (
    <tr data-testid={`user-${user.uid}`}>
      <td>
        <div className={styles.cellMain}>{user.name || '(no name yet)'}</div>
        <div className={styles.cellSub}>
          {user.email || 'no email'}
          {user.phone ? ` · ${user.phone}` : ''}
        </div>
        {!user.onboardingComplete && <div className={styles.cellSub}>Set-up not finished</div>}
      </td>

      <td>{roleName(user.role)}</td>

      <td>
        <span className={`${styles.badge} ${user.status === 'active' ? styles.badgeOk : styles.badgeBad}`}>
          {user.status === 'active' ? 'Active' : 'Suspended'}
        </span>
      </td>

      <td>
        <span className={`${styles.badge} ${idBadgeClass(user.level)}`}>{ID_LEVEL_LABELS[user.level]}</span>
      </td>

      <td>{where}</td>

      <td>{user.createdAt.slice(0, 10)}</td>

      <td>
        {props.isMe ? (
          <span className={styles.cellSub}>This is you</span>
        ) : (
          <>
            <div className={styles.rowActions}>
              {props.canChangeStatus && user.status === 'active' && (
                <button
                  className={`${styles.mini} ${styles.miniDanger}`}
                  onClick={() => props.onStartChange({ uid: user.uid, kind: 'suspend' })}
                >
                  Suspend
                </button>
              )}

              {props.canChangeStatus && user.status !== 'active' && (
                <button className={styles.mini} onClick={() => props.onStartChange({ uid: user.uid, kind: 'restore' })}>
                  Restore
                </button>
              )}

              {props.canChangeRole && (
                <button
                  className={styles.mini}
                  onClick={() => props.onStartChange({ uid: user.uid, kind: 'role', role: user.role })}
                >
                  Change role
                </button>
              )}

              {!props.canChangeStatus && !props.canChangeRole && <span className={styles.cellSub}>View only</span>}
            </div>

            {isOpen && props.pending && (
              <div className={styles.inlineConfirm} data-testid="inline-confirm">
                {props.pending.kind === 'role' ? (
                  <>
                    <select aria-label="New role" value={props.newRole} onChange={(e) => props.onNewRoleChange(e.target.value)}>
                      {roleList.map((role) => (
                        <option key={role} value={role}>
                          {roleName(role)}
                        </option>
                      ))}
                    </select>

                    <button
                      className={`${styles.mini} ${styles.miniPrimary}`}
                      disabled={props.busy || props.newRole === user.role}
                      onClick={props.onConfirm}
                    >
                      Save role
                    </button>
                  </>
                ) : (
                  <>
                    <span>
                      {props.pending.kind === 'suspend'
                        ? 'Suspend this account? They are signed out of everything.'
                        : 'Restore this account?'}
                    </span>

                    <input
                      aria-label="Note (optional)"
                      placeholder="Note (optional)"
                      value={props.note}
                      onChange={(e) => props.onNoteChange(e.target.value)}
                      maxLength={200}
                    />

                    <button
                      className={`${styles.mini} ${props.pending.kind === 'suspend' ? styles.miniDanger : styles.miniPrimary}`}
                      disabled={props.busy}
                      onClick={props.onConfirm}
                    >
                      {props.pending.kind === 'suspend' ? 'Yes, suspend' : 'Yes, restore'}
                    </button>
                  </>
                )}

                <button className={styles.mini} disabled={props.busy} onClick={props.onCancel}>
                  Cancel
                </button>
              </div>
            )}
          </>
        )}
      </td>
    </tr>
  );
};

export default UserRow;
