// components/Admin/AdminPanel/AdminPanel.tsx
// "Contract Control": who owns each contract, and is it paused?
// The owner wallet can pause or resume each contract. Everyone else sees the status read-only.
// The blockchain work is in blockchain/contracts/ContractControl/ContractControlActions.ts

import React, { useCallback, useEffect, useState } from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { getContractStatuses, togglePause } from '@/blockchain/contracts/ContractControl';
import { useActionStatus } from '@/hooks/useActionStatus';
import { StatusMessage } from '@/components/Common';
import { shortAddress } from '@/utils/shortAddress';
import type { ContractStatus } from '@/blockchain/types';

interface ControlData {
  account: string;
  isAdmin: boolean;
  statuses: ContractStatus[];
}

export const AdminPanel: React.FC = () => {
  const [data, setData] = useState<ControlData | null>(null);
  const message = useActionStatus();

  const refresh = useCallback(async () => {
    try {
      const report = await getContractStatuses();

      setData({ account: report.account, isAdmin: report.isAdmin, statuses: report.statuses });
      message.clearError();
    } catch (err) {
      setData(null);
      message.showError(err);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Load once, and again whenever the user switches account in the wallet.
  useEffect(() => {
    refresh();

    const ethereum = typeof window !== 'undefined' ? window.ethereum : undefined;

    ethereum?.on?.('accountsChanged', refresh);

    return () => ethereum?.removeListener?.('accountsChanged', refresh);
  }, [refresh]);

  async function handleToggle(contract: ContractStatus) {
    const action = contract.paused ? 'unpause' : 'pause';

    message.showPending(`Confirm in your wallet: ${action} ${contract.name}...`);

    try {
      await togglePause(contract.name, contract.paused);
      message.showSuccess(`${contract.name} ${contract.paused ? 'resumed' : 'paused'}.`);

      await refresh();
    } catch (err) {
      message.showError(err);
    }
  }

  return (
    <div className={styles.card} style={{ gridColumn: '1 / -1' }}>
      <h2>
        Contract Control {data?.isAdmin && <span className={styles.badgeActive}>You are the admin</span>}
      </h2>

      <div className={styles.subtle}>
        Ownership and pausing come from OpenZeppelin&apos;s Ownable and Pausable. Pausing stops new registrations, reports and
        licenses; the admin can still process, revoke and reinstate.
      </div>

      {data && (
        <div className={styles.controlTable}>
          {data.statuses.map((contract) => (
            <div key={contract.name} className={styles.controlRow}>
              <div>
                <strong>{contract.name}</strong>

                <div className={styles.subtle}>
                  {shortAddress(contract.address)} · admin {shortAddress(contract.owner)}
                </div>
              </div>

              <div className={styles.controlActions}>
                {contract.paused ? (
                  <span className={styles.badgeRevoked}>Paused</span>
                ) : (
                  <span className={styles.badgeActive}>Running</span>
                )}

                <button
                  className={styles.buttonAdmin}
                  disabled={!data.isAdmin || message.isPending}
                  title={data.isAdmin ? '' : 'Only the admin wallet can do this'}
                  onClick={() => handleToggle(contract)}
                >
                  {contract.paused ? 'Resume' : 'Pause'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <StatusMessage status={message.status} />
    </div>
  );
};

export default AdminPanel;
