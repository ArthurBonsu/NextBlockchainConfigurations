// components/Admin/IdReviewRow/IdReviewRow.tsx
// One ID document in the review queue, with the buttons to show the number, confirm it, or reject it.

import React from 'react';
import styles from '@/styles/Layout.module.css';
import { SHOW_SECONDS } from '@/hooks/useIdReviewQueue';
import type { IdReviewDocument, PendingReview, RevealedId } from '@/types';

export const REVIEW_STATUSES = [
  { value: 'pending_review', label: 'Waiting for a reviewer' },
  { value: 'pending_check', label: 'Being checked automatically' },
  { value: 'verified', label: 'Confirmed' },
  { value: 'rejected', label: 'Rejected' },
];

export interface IdReviewRowProps {
  doc: IdReviewDocument;
  canReview: boolean;
  revealed: RevealedId | null;
  deciding: PendingReview | null;
  note: string;
  busy: boolean;
  onShowNumber: () => void;
  onHideNumber: () => void;
  onStartDecision: (decision: 'verified' | 'rejected') => void;
  onNoteChange: (note: string) => void;
  onConfirmDecision: () => void;
  onCancelDecision: () => void;
}

function statusBadgeClass(status: string): string {
  if (status === 'verified') return styles.badgeOk;
  if (status === 'rejected') return styles.badgeBad;

  return '';
}

export const IdReviewRow: React.FC<IdReviewRowProps> = (props) => {
  const { doc, revealed, deciding } = props;
  const statusLabel = REVIEW_STATUSES.find((s) => s.value === doc.status)?.label || doc.status;

  return (
    <tr data-testid={`doc-${doc.id}`}>
      <td>
        <div className={styles.cellMain}>{doc.label}</div>
        <div className={styles.cellSub}>ending {doc.last4}</div>
      </td>

      <td>
        <div className={styles.cellSub}>Account</div>
        <code>{doc.uid.slice(0, 10)}…</code>
      </td>

      <td>
        <div className={styles.cellSub}>{doc.country ? `Country ${doc.country}` : 'Country not given'}</div>
        <div className={styles.cellSub}>{doc.expiry ? `Expires ${doc.expiry}` : 'No expiry date'}</div>

        {doc.attempts ? (
          <div className={styles.cellSub}>
            {doc.attempts} automatic check{doc.attempts === 1 ? '' : 's'}
          </div>
        ) : null}

        {doc.note && <div className={styles.cellSub}>Note: {doc.note}</div>}

        {revealed && (
          <div className={styles.revealBox} data-testid="reveal-box">
            <div>Number: {revealed.number}</div>

            <div>
              Name: {revealed.holder.name || '—'} · Born: {revealed.holder.dob || '—'}
            </div>

            <div style={{ opacity: 0.7, fontSize: 12 }}>
              Hides itself after {SHOW_SECONDS} seconds. This look-up is recorded.
            </div>
          </div>
        )}
      </td>

      <td>{doc.createdAt.slice(0, 16).replace('T', ' ')}</td>

      <td>
        {props.canReview ? (
          <>
            <div className={styles.rowActions}>
              <button className={styles.mini} onClick={revealed ? props.onHideNumber : props.onShowNumber}>
                {revealed ? 'Hide number' : 'Show number'}
              </button>

              <button className={`${styles.mini} ${styles.miniPrimary}`} onClick={() => props.onStartDecision('verified')}>
                Confirm
              </button>

              <button className={`${styles.mini} ${styles.miniDanger}`} onClick={() => props.onStartDecision('rejected')}>
                Reject
              </button>
            </div>

            {deciding && (
              <div className={styles.inlineConfirm} data-testid="inline-confirm">
                <span>
                  {deciding.decision === 'verified'
                    ? 'Confirm that the number matches the card and holder?'
                    : 'Reject this ID?'}
                </span>

                <input
                  aria-label="Note (optional)"
                  placeholder={deciding.decision === 'rejected' ? 'Reason (the person sees it)' : 'Note (optional)'}
                  value={props.note}
                  onChange={(e) => props.onNoteChange(e.target.value)}
                  maxLength={200}
                />

                <button
                  className={`${styles.mini} ${deciding.decision === 'verified' ? styles.miniPrimary : styles.miniDanger}`}
                  disabled={props.busy}
                  onClick={props.onConfirmDecision}
                >
                  {deciding.decision === 'verified' ? 'Yes, confirm' : 'Yes, reject'}
                </button>

                <button className={styles.mini} disabled={props.busy} onClick={props.onCancelDecision}>
                  Cancel
                </button>
              </div>
            )}
          </>
        ) : (
          <span className={`${styles.badge} ${statusBadgeClass(doc.status)}`}>{statusLabel}</span>
        )}
      </td>
    </tr>
  );
};

export default IdReviewRow;
