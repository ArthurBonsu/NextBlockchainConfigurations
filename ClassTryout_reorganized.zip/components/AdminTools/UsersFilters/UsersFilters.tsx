// components/Admin/UsersFilters/UsersFilters.tsx
// The filter bar above the users table. One group of filters at a time (the server only allows one).

import React from 'react';
import styles from '@/styles/Layout.module.css';
import regions from '@/shared/locations/regions.json';
import rolesPolicy from '@/shared/roles.json';
import type { UserFilterGroup } from '@/types';

export const ID_LEVEL_LABELS = ['No ID', 'ID given', 'ID confirmed'];

export function roleName(role: string): string {
  const labels = (rolesPolicy as any).labels || {};

  return labels[role] || role;
}

export interface UsersFiltersProps {
  group: UserFilterGroup;
  role: string;
  status: string;
  email: string;
  level: string;
  region: string;
  onGroupChange: (group: UserFilterGroup) => void;
  onRoleChange: (role: string) => void;
  onStatusChange: (status: string) => void;
  onEmailChange: (email: string) => void;
  onLevelChange: (level: string) => void;
  onRegionChange: (region: string) => void;
  onSearch: () => void;
}

export const UsersFilters: React.FC<UsersFiltersProps> = (props) => {
  const roleList: string[] = (rolesPolicy as any).roles;

  function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    props.onSearch();
  }

  return (
    <form className={styles.filters} onSubmit={handleSubmit}>
      <label>
        Filter by
        <select aria-label="Filter by" value={props.group} onChange={(e) => props.onGroupChange(e.target.value as UserFilterGroup)}>
          <option value="role">Role and status</option>
          <option value="email">Email</option>
          <option value="level">ID level</option>
          <option value="region">Region</option>
        </select>
      </label>

      {props.group === 'role' && (
        <>
          <label>
            Role
            <select aria-label="Role" value={props.role} onChange={(e) => props.onRoleChange(e.target.value)}>
              <option value="">Any</option>
              {roleList.map((role) => (
                <option key={role} value={role}>
                  {roleName(role)}
                </option>
              ))}
            </select>
          </label>

          <label>
            Status
            <select aria-label="Status" value={props.status} onChange={(e) => props.onStatusChange(e.target.value)}>
              <option value="">Any</option>
              <option value="active">Active</option>
              <option value="suspended">Suspended</option>
            </select>
          </label>
        </>
      )}

      {props.group === 'email' && (
        <label>
          Exact email
          <input
            aria-label="Email"
            type="email"
            value={props.email}
            onChange={(e) => props.onEmailChange(e.target.value)}
            placeholder="name@example.com"
          />
        </label>
      )}

      {props.group === 'level' && (
        <label>
          ID level
          <select aria-label="ID level" value={props.level} onChange={(e) => props.onLevelChange(e.target.value)}>
            <option value="">Choose…</option>
            {ID_LEVEL_LABELS.map((label, index) => (
              <option key={label} value={index}>
                {label}
              </option>
            ))}
          </select>
        </label>
      )}

      {props.group === 'region' && (
        <label>
          Region
          <select aria-label="Region" value={props.region} onChange={(e) => props.onRegionChange(e.target.value)}>
            <option value="">Choose…</option>
            {(regions as { code: string; name: string }[]).map((region) => (
              <option key={region.code} value={region.code}>
                {region.name}
              </option>
            ))}
          </select>
        </label>
      )}

      {props.group === 'email' && (
        <button type="submit" className={`${styles.mini} ${styles.miniPrimary}`}>
          Search
        </button>
      )}
    </form>
  );
};

export default UsersFilters;
