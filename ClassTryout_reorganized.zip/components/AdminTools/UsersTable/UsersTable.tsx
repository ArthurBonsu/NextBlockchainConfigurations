// components/Admin/UsersTable/UsersTable.tsx
// The admin list of users. The data and the server calls live in hooks/useUsersTable.ts.

import React from 'react';
import styles from '@/styles/Layout.module.css';
import { useUsersTable } from '@/hooks/useUsersTable';
import { UsersFilters } from '../UsersFilters';
import { UserRow } from '../UserRow';

export const UsersTable: React.FC = () => {
  const table = useUsersTable();
  const { filters } = table;

  // What to say when the table is empty.
  function emptyMessage(): string {
    if (filters.group === 'level' && filters.level === '') return 'Choose an ID level.';
    if (filters.group === 'region' && !filters.region) return 'Choose a region.';
    if (filters.group === 'email' && !filters.email.trim()) return 'Type an email and press Search.';

    return 'No users match.';
  }

  return (
    <section data-testid="users-table">
      <UsersFilters
        group={filters.group}
        role={filters.role}
        status={filters.status}
        email={filters.email}
        level={filters.level}
        region={filters.region}
        onGroupChange={table.setGroup}
        onRoleChange={table.setRole}
        onStatusChange={table.setStatus}
        onEmailChange={table.setEmail}
        onLevelChange={table.setLevel}
        onRegionChange={table.setRegion}
        onSearch={() => table.load(false)}
      />

      {table.flash && (
        <div className={`${styles.notice} ${styles.noticeOk}`} role="status">
          {table.flash}
        </div>
      )}

      {table.error && (
        <div className={`${styles.notice} ${styles.noticeErr}`} role="alert">
          {table.error}
        </div>
      )}

      <div className={styles.tableWrap}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Person</th>
              <th>Role</th>
              <th>Status</th>
              <th>ID</th>
              <th>Where</th>
              <th>Joined</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {table.rows.map((user) => (
              <UserRow
                key={user.uid}
                user={user}
                isMe={!!table.me && table.me.uid === user.uid}
                canChangeStatus={table.canChangeStatus}
                canChangeRole={table.canChangeRole}
                pending={table.pending}
                note={table.note}
                newRole={table.newRole}
                busy={table.busy}
                onStartChange={table.startChange}
                onNoteChange={table.setNote}
                onNewRoleChange={table.chooseNewRole}
                onConfirm={table.confirmChange}
                onCancel={() => table.setPending(null)}
              />
            ))}

            {!table.rows.length && !table.loading && (
              <tr>
                <td colSpan={7} className={styles.empty}>
                  {emptyMessage()}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {table.loading && <p className={styles.muted}>Loading…</p>}

      {table.hasMore && !table.loading && (
        <p>
          <button className={styles.mini} onClick={() => table.load(true)}>
            Load more
          </button>
        </p>
      )}
    </section>
  );
};

export default UsersTable;
