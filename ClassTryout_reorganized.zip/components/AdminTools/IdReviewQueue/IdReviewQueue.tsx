// components/Admin/IdReviewQueue/IdReviewQueue.tsx
// The reviewer's list of ID documents. The data and the server calls live in hooks/useIdReviewQueue.ts.

import React from 'react';
import styles from '@/styles/Layout.module.css';
import { useIdReviewQueue } from '@/hooks/useIdReviewQueue';
import { IdReviewRow, REVIEW_STATUSES } from '../IdReviewRow';

export const IdReviewQueue: React.FC = () => {
  const queue = useIdReviewQueue();

  // Only IDs that are waiting for a reviewer can be confirmed or rejected.
  const canReview = queue.status === 'pending_review';

  return (
    <section data-testid="id-queue">
      <div className={styles.filters}>
        <label>
          Show IDs that are
          <select aria-label="Status" value={queue.status} onChange={(e) => queue.setStatus(e.target.value)}>
            {REVIEW_STATUSES.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </select>
        </label>

        <button className={styles.mini} onClick={() => queue.load(false, [], queue.status)} disabled={queue.loading}>
          Refresh
        </button>
      </div>

      {queue.flash && (
        <div className={`${styles.notice} ${styles.noticeOk}`} role="status">
          {queue.flash}
        </div>
      )}

      {queue.error && (
        <div className={`${styles.notice} ${styles.noticeErr}`} role="alert">
          {queue.error}
        </div>
      )}

      <div className={styles.tableWrap}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>ID</th>
              <th>Person</th>
              <th>Details</th>
              <th>Submitted</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {queue.docs.map((doc) => (
              <IdReviewRow
                key={doc.id}
                doc={doc}
                canReview={canReview}
                revealed={queue.shown && queue.shown.id === doc.id ? queue.shown.data : null}
                deciding={queue.deciding && queue.deciding.id === doc.id ? queue.deciding : null}
                note={queue.note}
                busy={queue.busy}
                onShowNumber={() => queue.revealNumber(doc.id)}
                onHideNumber={queue.hideNumber}
                onStartDecision={(decision) => queue.startDecision(doc.id, decision)}
                onNoteChange={queue.setNote}
                onConfirmDecision={queue.confirmDecision}
                onCancelDecision={() => queue.setDeciding(null)}
              />
            ))}

            {!queue.docs.length && !queue.loading && (
              <tr>
                <td colSpan={5} className={styles.empty}>
                  {canReview ? 'Nothing is waiting for review.' : 'Nothing here.'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {queue.loading && <p className={styles.muted}>Loading…</p>}

      {queue.hasMore && !queue.loading && (
        <p>
          <button className={styles.mini} onClick={() => queue.load(true, queue.docs, queue.status)}>
            Load more
          </button>
        </p>
      )}
    </section>
  );
};

export default IdReviewQueue;
