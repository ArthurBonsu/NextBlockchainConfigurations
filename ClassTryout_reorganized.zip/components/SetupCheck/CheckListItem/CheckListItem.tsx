// components/SetupCheck/CheckListItem/CheckListItem.tsx
// One line of the set-up check: a badge (OK / Fix this), what was checked, and how to fix it.

import React from 'react';
import styles from '@/styles/Account.module.css';
import type { SetupCheckItem } from '@/services/auth';

const BADGE_CLASS: Record<string, string> = {
  ok: styles.badgeOk,
  fail: styles.badgeBad,
  warn: styles.badgeWarn,
  skip: '',
};

const BADGE_WORD: Record<string, string> = {
  ok: 'OK',
  fail: 'Fix this',
  warn: 'Check',
  skip: 'Skipped',
};

export const CheckListItem: React.FC<{ check: SetupCheckItem }> = ({ check }) => {
  return (
    <li data-check={check.id} data-status={check.status} style={{ alignItems: 'flex-start', flexDirection: 'column' }}>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <span className={`${styles.badge} ${BADGE_CLASS[check.status]}`}>{BADGE_WORD[check.status]}</span>

        <strong>{check.label}</strong>
      </div>

      {check.detail && <div className={styles.muted}>{check.detail}</div>}

      {check.fix && check.status !== 'ok' && (
        <div className={styles.muted}>
          <em>How to fix:</em> {check.fix}
        </div>
      )}
    </li>
  );
};

export default CheckListItem;
