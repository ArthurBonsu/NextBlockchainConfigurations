// components/SetupCheck/SetupCheck/SetupCheck.tsx
// A checklist for whoever sets the site up: what is switched on, what is missing, and the exact console step to fix it.
// It shows no secret. The server only answers yes or no, and the public project id.

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import styles from '@/styles/Account.module.css';
import { firebaseConfigured, firebaseMissing, firebaseProjectId } from '@/services/firebase';
import { browserCheck } from '@/services/auth';
import type { SetupCheckItem } from '@/services/auth';
import { NavBar } from '@/components/AppLayout';
import { CheckListItem } from '../CheckListItem';

// Check 1: what this page was built with.
function pageSettingsCheck(): SetupCheckItem {
  const label = 'Sign-in page has all four Firebase settings';

  if (firebaseMissing.length === 0) {
    return { id: 'page-config', label, status: 'ok', detail: `Project "${firebaseProjectId}".`, fix: '' };
  }

  return {
    id: 'page-config',
    label,
    status: firebaseConfigured ? 'warn' : 'fail',
    detail: 'Empty: ' + firebaseMissing.join(', '),
    fix: 'Firebase console > Project settings > General > Your apps > Web app. Put the values in .env.local and RESTART the site (a running site does not read .env.local again).',
  };
}

// Check 2: the server's own checks (/api/auth-check).
async function serverChecks(): Promise<{ checks: SetupCheckItem[]; projectId: string | null }> {
  const response = await fetch('/api/auth-check');

  if (response.status === 404) throw new Error('The check is switched off on a live site. Set SETUP_CHECK=on to allow it.');

  const body = await response.json();
  const checks: SetupCheckItem[] = [...body.checks];

  // The page and the server must have been started with the same .env.local.
  if (body.projectId && firebaseProjectId && body.projectId !== firebaseProjectId) {
    checks.push({
      id: 'restart',
      label: 'Page and server were started with the same settings',
      status: 'fail',
      detail: `The page has "${firebaseProjectId}", the server has "${body.projectId}".`,
      fix: 'Stop the site and start it again so both read the same .env.local.',
    });
  }

  return { checks, projectId: body.projectId };
}

export const SetupCheck: React.FC = () => {
  const [checks, setChecks] = useState<SetupCheckItem[] | null>(null);
  const [problem, setProblem] = useState('');
  const [busy, setBusy] = useState(false);
  const [projectId, setProjectId] = useState<string | null>(null);

  const runChecks = useCallback(async () => {
    setBusy(true);
    setProblem('');

    const list: SetupCheckItem[] = [pageSettingsCheck()];

    try {
      const fromServer = await serverChecks();

      list.push(...fromServer.checks);
      setProjectId(fromServer.projectId);
    } catch (error: any) {
      setProblem(error && error.message ? error.message : 'The server did not answer.');
    }

    // Check 3: the browser itself.
    list.push(await browserCheck());

    setChecks(list);
    setBusy(false);
  }, []);

  useEffect(() => {
    runChecks();
  }, [runChecks]);

  const failedCount = checks ? checks.filter((check) => check.status === 'fail').length : 0;
  const allGood = failedCount === 0 && !problem;

  return (
    <main className={styles.page}>
      <NavBar variant="minimal" />

      <div className={styles.wide}>
        <div className={styles.card}>
          <h1>Set-up check</h1>

          <p className={styles.muted}>
            What is working for sign-in, and the exact step to fix what is not. It never shows a secret.
            {projectId ? ` Firebase project: ${projectId}.` : ''}
          </p>

          {problem && (
            <div className={`${styles.notice} ${styles.noticeErr}`} role="alert">
              {problem}
            </div>
          )}

          {checks && (
            <div className={`${styles.notice} ${allGood ? styles.noticeOk : styles.noticeErr}`} data-testid="check-summary">
              {allGood ? 'Everything needed for sign-in looks right.' : `${failedCount} thing${failedCount === 1 ? '' : 's'} to fix.`}
            </div>
          )}

          <ul className={styles.list} data-testid="check-list">
            {(checks || []).map((check) => (
              <CheckListItem key={check.id} check={check} />
            ))}
          </ul>

          <div className={styles.actions}>
            <button type="button" className={styles.btn} onClick={runChecks} disabled={busy} data-testid="check-again">
              {busy ? 'Checking…' : 'Check again'}
            </button>

            <Link href="/signin">Go to sign in</Link>
          </div>
        </div>
      </div>
    </main>
  );
};

export default SetupCheck;
