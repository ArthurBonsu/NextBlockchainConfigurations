// components/Auth/AccountProblem/AccountProblem.tsx
// Shown when Firebase accepted the sign-in but our server could not finish loading the account.
// It says what happened (the server's own sentence), and offers the useful next steps.

import React from 'react';
import Link from 'next/link';
import styles from '@/styles/Account.module.css';
import { Notice } from '@/components/Common';
import { useAccount } from '../AuthProvider';

// Problems that are fixed in the site's set-up, not by the person signing in.
const SETUP_CODES = [
  'project_mismatch',
  'admin_credentials',
  'admin_missing',
  'firestore_missing',
  'firestore_denied',
  'server_setup',
  'server_offline',
];

const CONNECTION_CODES = ['network', 'timeout'];

export interface AccountProblemProps {
  lead?: string;
}

export const AccountProblem: React.FC<AccountProblemProps> = ({
  lead = 'You are signed in, but we could not load your account.',
}) => {
  const { error, errorCode, refresh, signOut } = useAccount();

  const isSetupProblem = SETUP_CODES.includes(errorCode);
  const isConnectionProblem = CONNECTION_CODES.includes(errorCode);

  return (
    <Notice kind="err" testid="account-problem">
      <strong>{lead}</strong>

      <div style={{ margin: '6px 0' }} data-testid="account-problem-text">
        {error || 'Unknown problem.'}
      </div>

      <div className={styles.actions} style={{ marginTop: 6 }}>
        <button type="button" className={styles.btnGhost} onClick={() => refresh()} data-testid="account-retry">
          Try again
        </button>

        <button type="button" className={styles.btnGhost} onClick={() => signOut()} data-testid="account-signout">
          Sign out
        </button>

        {(isSetupProblem || isConnectionProblem) && (
          <Link href="/setup-check" data-testid="account-setupcheck">
            Check the set-up
          </Link>
        )}
      </div>
    </Notice>
  );
};

export default AccountProblem;
