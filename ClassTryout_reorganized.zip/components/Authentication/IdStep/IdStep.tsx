// components/Auth/IdStep/IdStep.tsx
// Adding an identity document (Ghana Card, passport, ...).
// Adding an ID never waits for an outside service: the person is at "ID given" straight away.
// "Confirmed" follows when an automatic check answers, or when a reviewer looks at it.

import React, { FormEvent, useState } from 'react';
import styles from '@/styles/Account.module.css';
import idTypes from '@/shared/id-types.json';
import { api, ApiError } from '@/services/api';
import { FormField, Notice } from '@/components/Common';
import type { IdDocument, Me } from '@/types';

const STATUS_LABELS: Record<string, { text: string; className: string }> = {
  pending_check: { text: 'Being checked', className: styles.badgeWarn },
  pending_review: { text: 'Waiting for review', className: styles.badgeWarn },
  submitted: { text: 'Received', className: styles.badgeWarn },
  verified: { text: 'Confirmed', className: styles.badgeOk },
  rejected: { text: 'Not accepted', className: styles.badgeBad },
  expired: { text: 'Expired: add it again', className: styles.badgeBad },
};

export interface IdStepProps {
  me: Me;
  onChanged: (me: Me) => void;
}

// One ID in the list, with its status and a Remove button.
const IdListItem: React.FC<{ doc: IdDocument; busy: boolean; onRemove: (id: string) => void }> = ({ doc, busy, onRemove }) => {
  const status = STATUS_LABELS[doc.status] || { text: doc.status, className: '' };

  return (
    <li>
      <span>
        {doc.label} <span className={styles.mono}>•••• {doc.last4}</span>
        {doc.note && doc.status === 'rejected' ? <em className={styles.hint}> {doc.note}</em> : null}
      </span>

      <span style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <span className={`${styles.badge} ${status.className}`} data-testid={`id-status-${doc.id}`}>
          {status.text}
        </span>

        {doc.status !== 'verified' && (
          <button type="button" className={styles.linkBtn} onClick={() => onRemove(doc.id)} disabled={busy}>
            Remove
          </button>
        )}
      </span>
    </li>
  );
};

export const IdStep: React.FC<IdStepProps> = ({ me, onChanged }) => {
  const [type, setType] = useState('ghana_card');
  const [number, setNumber] = useState('');
  const [country, setCountry] = useState('');
  const [expiry, setExpiry] = useState('');

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  const selectedType = idTypes.types.find((item) => item.code === type)!;
  const documents: IdDocument[] = me.documents || [];

  async function handleAdd(event: FormEvent) {
    event.preventDefault();

    setBusy(true);
    setError('');
    setFieldErrors({});

    try {
      const answer = await api<{ me: Me }>('/api/identity', {
        body: {
          type,
          number,
          country: selectedType.country ? undefined : country,
          expiry: expiry || undefined,
        },
      });

      onChanged(answer.me);
      setNumber('');
      setExpiry('');
    } catch (err: any) {
      setError(err.message || 'Could not add the ID.');

      if (err instanceof ApiError) setFieldErrors(err.fields);
    }

    setBusy(false);
  }

  async function handleRemove(id: string) {
    setBusy(true);
    setError('');

    try {
      const answer = await api<{ me: Me }>(`/api/identity?id=${encodeURIComponent(id)}`, { method: 'DELETE' });

      onChanged(answer.me);
    } catch (err: any) {
      setError(err.message);
    }

    setBusy(false);
  }

  const showExpiry = selectedType.needsExpiry || type !== 'ghana_card';

  return (
    <div data-testid="step-id">
      <h2>Identity document</h2>

      <p className={styles.muted}>
        Add a Ghana Card, passport, NHIS card or another government ID. You can finish setting up without it, but registering a
        vehicle or issuing a licence needs a confirmed ID. A reviewer confirms it; this never blocks you from using the rest of
        the app.
      </p>

      {documents.length > 0 && (
        <ul className={styles.list} data-testid="id-list" style={{ marginBottom: 16 }}>
          {documents.map((doc) => (
            <IdListItem key={doc.id} doc={doc} busy={busy} onRemove={handleRemove} />
          ))}
        </ul>
      )}

      {error && (
        <Notice kind="err" testid="id-error">
          {error}
        </Notice>
      )}

      <form onSubmit={handleAdd}>
        <FormField id="idType" label="ID type" error={fieldErrors.type}>
          <select id="idType" value={type} onChange={(e) => setType(e.target.value)}>
            {idTypes.types.map((item) => (
              <option key={item.code} value={item.code}>
                {item.label}
              </option>
            ))}
          </select>
        </FormField>

        <FormField
          id="idNumber"
          label="ID number"
          error={fieldErrors.number}
          hint={selectedType.example ? `For example ${selectedType.example}` : undefined}
        >
          <input id="idNumber" value={number} onChange={(e) => setNumber(e.target.value)} autoComplete="off" spellCheck={false} />
        </FormField>

        {!selectedType.country && (
          <FormField id="idCountry" label="Issuing country (two-letter code)" error={fieldErrors.country}>
            <input
              id="idCountry"
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              maxLength={2}
              style={{ textTransform: 'uppercase', width: 80 }}
            />
          </FormField>
        )}

        {showExpiry && (
          <FormField
            id="idExpiry"
            label={selectedType.needsExpiry ? 'Expiry date' : 'Expiry date (optional)'}
            error={fieldErrors.expiry}
          >
            <input id="idExpiry" type="date" value={expiry} onChange={(e) => setExpiry(e.target.value)} />
          </FormField>
        )}

        <button className={styles.btn} disabled={busy || !number} data-testid="add-id">
          {busy ? 'Adding…' : 'Add ID'}
        </button>
      </form>
    </div>
  );
};

export default IdStep;
