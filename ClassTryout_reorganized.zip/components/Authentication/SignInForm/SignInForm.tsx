// components/Auth/SignInForm/SignInForm.tsx
// The email and password form. In "Create account" mode it also asks for the password twice.

import React, { FormEvent } from 'react';
import styles from '@/styles/Account.module.css';
import { PASSWORD_MIN } from '@/services/auth';
import { FormField } from '@/components/Common';
import type { SignInMode } from '@/hooks/useSignIn';

export interface SignInFormProps {
  mode: SignInMode;
  email: string;
  password: string;
  repeatedPassword: string;
  busy: boolean;
  onEmailChange: (value: string) => void;
  onPasswordChange: (value: string) => void;
  onRepeatedPasswordChange: (value: string) => void;
  onSubmit: (event: FormEvent) => void;
  onForgotPassword: () => void;
}

export const SignInForm: React.FC<SignInFormProps> = (props) => {
  const isSignUp = props.mode === 'up';

  return (
    <>
      <form onSubmit={props.onSubmit} noValidate>
        <FormField id="email" label="Email">
          <input
            id="email"
            type="email"
            autoComplete="email"
            value={props.email}
            onChange={(e) => props.onEmailChange(e.target.value)}
            required
          />
        </FormField>

        <FormField id="password" label="Password" hint={isSignUp ? `At least ${PASSWORD_MIN} characters.` : undefined}>
          <input
            id="password"
            type="password"
            autoComplete={isSignUp ? 'new-password' : 'current-password'}
            value={props.password}
            onChange={(e) => props.onPasswordChange(e.target.value)}
            required
          />
        </FormField>

        {isSignUp && (
          <FormField id="confirm" label="Repeat password">
            <input
              id="confirm"
              type="password"
              autoComplete="new-password"
              value={props.repeatedPassword}
              onChange={(e) => props.onRepeatedPasswordChange(e.target.value)}
              required
            />
          </FormField>
        )}

        <button
          className={`${styles.btn} ${styles.btnWide}`}
          disabled={props.busy || !props.email || !props.password}
          type="submit"
          data-testid="submit"
        >
          {props.busy ? 'Please wait…' : isSignUp ? 'Create account' : 'Sign in'}
        </button>
      </form>

      {!isSignUp && (
        <p className={styles.muted} style={{ marginTop: 12 }}>
          <button type="button" className={styles.linkBtn} onClick={props.onForgotPassword} data-testid="forgot">
            Forgot your password?
          </button>
        </p>
      )}
    </>
  );
};

export default SignInForm;
