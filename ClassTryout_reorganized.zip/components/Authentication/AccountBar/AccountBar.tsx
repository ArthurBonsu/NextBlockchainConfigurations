// components/Auth/AccountBar/AccountBar.tsx
// A slim bar at the top of a page: who is signed in, and the way to the account page or the sign-in page.

import React from 'react';
import Link from 'next/link';
import styles from '@/styles/Account.module.css';
import { useAccount } from '../AuthProvider';

export const AccountBar: React.FC = () => {
  const { state, me, signOut } = useAccount();

  if (state === 'unavailable') return null;

  return (
    <div className={styles.bar}>
      <span className={styles.brand}>ClassTryout</span>

      <span className={styles.barRight}>
        {state === 'loading' && <span>…</span>}

        {state === 'signedOut' && <Link href="/signin">Sign in</Link>}

        {state === 'ready' && me && (
          <>
            <span data-testid="bar-name">{me.profile.displayName || me.email || 'Account'}</span>

            <span className={styles.roleTag}>{me.role.replace('_', ' ')}</span>

            {!me.onboarding.complete && <Link href="/onboarding">Finish setup</Link>}

            <Link href="/account">Account</Link>

            <button type="button" className={styles.linkBtn} onClick={() => signOut()}>
              Sign out
            </button>
          </>
        )}
      </span>
    </div>
  );
};

export default AccountBar;
