export { CapabilityGate, REQUIRE_ACCOUNT } from './CapabilityGate';
export type { CapabilityGateProps } from './CapabilityGate';
