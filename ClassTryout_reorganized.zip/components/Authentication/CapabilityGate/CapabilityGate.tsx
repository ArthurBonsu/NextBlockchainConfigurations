// components/Auth/CapabilityGate/CapabilityGate.tsx
// Hides an action unless the signed-in account may do it.
//
// This is a CONVENIENCE. The server checks again (/api/capability/<name>), and the smart contract itself is open,
// so anything important must call the server check first.
//
// It is switched on with NEXT_PUBLIC_REQUIRE_ACCOUNT=true. Otherwise the demo works as before and children always show.

import React, { ReactNode } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import styles from '@/styles/Account.module.css';
import { LOCKED_REASON_MESSAGES } from '@/constants';
import { useAccount } from '../AuthProvider';

export const REQUIRE_ACCOUNT = process.env.NEXT_PUBLIC_REQUIRE_ACCOUNT === 'true';

export interface CapabilityGateProps {
  capability: string;
  title?: string;
  children: ReactNode;
}

// Where the "Open" link goes, depending on why the section is locked.
function fixLinkFor(reason: string): string | null {
  if (reason === 'onboarding') return '/onboarding';
  if (reason === 'level' || reason === 'email_unverified') return '/account';

  return null;
}

export const CapabilityGate: React.FC<CapabilityGateProps> = ({ capability, title, children }) => {
  const { state, me } = useAccount();
  const router = useRouter();

  if (!REQUIRE_ACCOUNT) return <>{children}</>;

  const label = title || 'This section';

  if (state === 'loading') return <div className={styles.gate}>Checking your account…</div>;

  if (state !== 'ready' || !me) {
    return (
      <div className={styles.gate}>
        <strong>{label}</strong> needs an account.{' '}
        <Link href={`/signin?next=${encodeURIComponent(router.asPath)}`}>Sign in or create one</Link>.
      </div>
    );
  }

  const found = me.capabilities[capability];

  if (found && found.allowed) return <>{children}</>;

  const reason = (found && found.reason) || 'role';
  const fixLink = fixLinkFor(reason);

  return (
    <div className={styles.gate}>
      <strong>{label}</strong> is locked. {LOCKED_REASON_MESSAGES[reason] || 'Not allowed.'}{' '}
      {fixLink && <Link href={fixLink}>Open</Link>}
    </div>
  );
};

export default CapabilityGate;
