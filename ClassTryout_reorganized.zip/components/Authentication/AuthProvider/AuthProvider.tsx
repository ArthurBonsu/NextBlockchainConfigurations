// components/Auth/AuthProvider/AuthProvider.tsx
// One place that knows who is signed in (Firebase) and what the server says about them (/api/me).
//
//   loading      checking Firebase, or fetching the profile
//   signedOut    nobody is signed in
//   ready        signed in, and the profile is loaded
//   error        signed in, but the server could not load the profile (the message says why)
//   unavailable  this site has no Firebase sign-in configured (demo mode)
//
// Any component can read this with useAccount().

import React, { ReactNode, createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import type { User } from 'firebase/auth';
import { firebaseConfigured, getFirebaseAuth } from '@/services/firebase';
import { signOutUser } from '@/services/auth';
import { api, ApiError } from '@/services/api';
import type { Me } from '@/types';

export type AuthState = 'loading' | 'signedOut' | 'ready' | 'error' | 'unavailable';

export interface AccountContextValue {
  state: AuthState;
  firebaseUser: User | null;
  me: Me | null;
  error: string;
  errorCode: string; // a machine word from the server, for example "project_mismatch" ("" when there is none)
  refresh: () => Promise<Me | null>;
  setMe: (me: Me) => void;
  signOut: () => Promise<void>;
}

const AccountContext = createContext<AccountContextValue>({
  state: 'loading',
  firebaseUser: null,
  me: null,
  error: '',
  errorCode: '',
  refresh: async () => null,
  setMe: () => {},
  signOut: async () => {},
});

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AuthState>(firebaseConfigured ? 'loading' : 'unavailable');
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [error, setError] = useState('');
  const [errorCode, setErrorCode] = useState('');

  // An answer that arrives after the person signed out (or in as someone else) is ignored.
  const currentTurn = useRef(0);

  const clearProblem = useCallback(() => {
    setError('');
    setErrorCode('');
  }, []);

  const loadAccount = useCallback(async (): Promise<Me | null> => {
    const myTurn = ++currentTurn.current;

    try {
      const answer = await api<{ me: Me }>('/api/me');

      if (myTurn !== currentTurn.current) return null;

      setMe(answer.me);
      clearProblem();
      setState('ready');

      return answer.me;
    } catch (err: any) {
      if (myTurn !== currentTurn.current) return null;

      // Firebase said "signed in", but our server refused the token or could not load the profile.
      // This must be SHOWN. Showing "signed out" here would make sign-in look like it silently did nothing.
      const stillSignedIn = !!getFirebaseAuth().currentUser;
      const nobodyIsSignedIn = err instanceof ApiError && err.status === 401 && !stillSignedIn;

      setMe(null);
      setError(err && err.message ? err.message : 'Could not load your account.');
      setErrorCode(err instanceof ApiError ? err.code : 'error');
      setState(nobodyIsSignedIn ? 'signedOut' : 'error');

      return null;
    }
  }, [clearProblem]);

  // Watch Firebase. Every sign-in and sign-out arrives here.
  useEffect(() => {
    if (!firebaseConfigured) return;

    return onAuthStateChanged(getFirebaseAuth(), (user) => {
      setFirebaseUser(user);

      if (!user) {
        currentTurn.current++;
        setMe(null);
        clearProblem();
        setState('signedOut');
        return;
      }

      setState((previous) => (previous === 'ready' ? previous : 'loading'));
      loadAccount();
    });
  }, [loadAccount, clearProblem]);

  const signOut = useCallback(async () => {
    if (firebaseConfigured) await signOutUser();

    currentTurn.current++;
    setMe(null);
    clearProblem();
    setState(firebaseConfigured ? 'signedOut' : 'unavailable');
  }, [clearProblem]);

  const value = useMemo(
    () => ({ state, firebaseUser, me, error, errorCode, refresh: loadAccount, setMe, signOut }),
    [state, firebaseUser, me, error, errorCode, loadAccount, signOut]
  );

  return <AccountContext.Provider value={value}>{children}</AccountContext.Provider>;
};

export const useAccount = () => useContext(AccountContext);
