// components/Auth/SocialSignInButtons/SocialSignInButtons.tsx
// "Continue with Google / GitHub / X". The same buttons sign in a returning person and create a new account.

import React from 'react';
import styles from '@/styles/Account.module.css';
import type { SocialProviderKind } from '@/services/auth';

interface SocialButton {
  kind: SocialProviderKind;
  label: string;
}

const BUTTONS: SocialButton[] = [
  { kind: 'google', label: 'Continue with Google' },
  { kind: 'github', label: 'Continue with GitHub' },
  { kind: 'twitter', label: 'Continue with X' },
];

export interface SocialSignInButtonsProps {
  busy: boolean;
  onSignIn: (kind: SocialProviderKind) => void;
}

export const SocialSignInButtons: React.FC<SocialSignInButtonsProps> = ({ busy, onSignIn }) => {
  return (
    <div className={styles.actions} style={{ flexDirection: 'column', alignItems: 'stretch' }}>
      {BUTTONS.map((button) => (
        <button
          key={button.kind}
          type="button"
          className={styles.btnGhost}
          disabled={busy}
          onClick={() => onSignIn(button.kind)}
          data-testid={button.kind}
        >
          {button.label}
        </button>
      ))}
    </div>
  );
};

export default SocialSignInButtons;
