// components/Layout/NetworkBanner/NetworkBanner.tsx
// The two warnings that matter before anyone sends a transaction:
// you are on a live (real-money) network, or the network has no contracts yet.

import React from 'react';
import styles from '@/styles/Layout.module.css';
import { useWallet } from '@/components/WalletConnection';

export const NetworkBanner: React.FC = () => {
  const { account, chainId, networkName, realMoney, deployed } = useWallet();

  if (!account || !chainId) return null;

  return (
    <>
      {realMoney && (
        <div className={styles.bannerDanger}>
          You are on <strong>{networkName}</strong>, a live network. Transactions here spend real money and cannot be undone.
          Use a testnet for class demos.
        </div>
      )}

      {!deployed && (
        <div className={styles.bannerWarn}>
          The registry contracts are not deployed on <strong>{networkName}</strong> yet. Switch to a network marked as deployed,
          or run <code>truffle migrate --network &lt;name&gt;</code> first.
        </div>
      )}
    </>
  );
};

export default NetworkBanner;
