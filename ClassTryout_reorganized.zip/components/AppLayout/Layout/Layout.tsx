// components/Layout/Layout/Layout.tsx
// Every page uses this. The top bar, the page container, the sign-in redirect and the
// "you may not use this page" message all live here, so no page repeats them.

import React, { ReactNode, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import styles from '@/styles/Layout.module.css';
import { LOCKED_REASON_MESSAGES } from '@/constants';
import { AccountProblem, useAccount } from '@/components/Authentication';
import { NavBar } from '../NavBar';
import { NetworkBanner } from '../NetworkBanner';

export interface LayoutProps {
  title: string; // the browser tab title, and (with `intro`) the page heading
  intro?: string; // one line under the heading. The heading only shows when this is given.
  children: ReactNode;
  variant?: 'app' | 'minimal'; // minimal: brand and account only (sign-in, set-up)
  width?: 'narrow' | 'normal' | 'full';
  chain?: boolean; // show the live-network and not-deployed warnings (pages that touch the blockchain)
  requireAccount?: boolean; // signed-out people are sent to sign in, then back here
  capability?: string; // the page itself needs this capability (admin pages)
}

function widthClass(width: LayoutProps['width']): string {
  if (width === 'narrow') return styles.narrow;
  if (width === 'normal') return styles.normal;

  return '';
}

export const Layout: React.FC<LayoutProps> = ({
  title,
  intro,
  children,
  variant = 'app',
  width = 'full',
  chain = false,
  requireAccount = false,
  capability,
}) => {
  const router = useRouter();
  const { state, me } = useAccount();
  const onboardingDone = !me || me.onboarding.complete;

  // Signed-out people go to the sign-in page, and come back here afterwards.
  useEffect(() => {
    if (requireAccount && state === 'signedOut') {
      router.replace(`/signin?next=${encodeURIComponent(router.asPath)}`);
    }
  }, [requireAccount, state, router]);

  // People who have not finished set-up go to the set-up page first.
  useEffect(() => {
    if (requireAccount && state === 'ready' && me && !me.onboarding.complete) {
      router.replace(`/onboarding?next=${encodeURIComponent(router.asPath)}`);
    }
  }, [requireAccount, state, me, router]);

  // What to show instead of the page, when the person cannot use it yet.
  function renderBody(): ReactNode {
    if (!requireAccount) return children;

    if (state === 'unavailable') {
      return (
        <div className={`${styles.notice} ${styles.noticeInfo}`}>
          Sign-in is not set up on this site yet. Set the NEXT_PUBLIC_FIREBASE_* values in .env.local.
        </div>
      );
    }

    if (state === 'error') return <AccountProblem />;

    if (state === 'loading' || state === 'signedOut' || !onboardingDone) {
      return <p className={styles.muted}>Loading…</p>;
    }

    if (capability && me) {
      const found = me.capabilities[capability];

      if (!found || !found.allowed) {
        const reason = (found && found.reason) || 'role';
        const needsAccountPage = reason === 'level' || reason === 'email_unverified';

        return (
          <div className={`${styles.notice} ${styles.noticeWarn}`} data-testid="page-locked">
            <strong>{title}</strong> is locked. {LOCKED_REASON_MESSAGES[reason] || 'Not allowed.'}{' '}
            {needsAccountPage && <Link href="/account">Open my account</Link>}
          </div>
        );
      }
    }

    return children;
  }

  return (
    <>
      <Head>
        <title>{`${title} · ClassTryout`}</title>
      </Head>

      <div className={styles.shell}>
        <NavBar variant={variant} />

        <main className={`${styles.main} ${widthClass(width)}`}>
          {chain && <NetworkBanner />}

          {intro && (
            <div className={styles.pageHead}>
              <h1>{title}</h1>
              <p>{intro}</p>
            </div>
          )}

          {renderBody()}
        </main>
      </div>
    </>
  );
};

export default Layout;
