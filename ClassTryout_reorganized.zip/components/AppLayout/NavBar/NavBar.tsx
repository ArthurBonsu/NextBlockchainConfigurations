// components/Layout/NavBar/NavBar.tsx
// The top bar on every page.
// Which links show depends on the signed-in role. shared/nav.json decides, and the server still enforces everything.
// The "minimal" bar is for sign-in and set-up: just the brand and the account, nothing to distract.

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import styles from '@/styles/Layout.module.css';
import nav from '@/shared/nav.json';
import { visibleItems } from '@/shared/navigation';
import type { NavItem } from '@/shared/navigation';
import { REQUIRE_ACCOUNT, useAccount } from '@/components/Authentication';
import { WalletBar } from '@/components/WalletConnection';

export interface NavBarProps {
  variant?: 'app' | 'minimal';
}

export const NavBar: React.FC<NavBarProps> = ({ variant = 'app' }) => {
  const router = useRouter();
  const { state, me, signOut } = useAccount();
  const [menuOpen, setMenuOpen] = useState(false);

  // Close the mobile menu after moving to another page.
  useEffect(() => setMenuOpen(false), [router.asPath]);

  const showNav = variant === 'app';

  const items = visibleItems(nav.items as NavItem[], state === 'ready' ? me : null, { requireAccount: REQUIRE_ACCOUNT });
  const mainItems = items.filter((item) => !item.group);
  const adminItems = items.filter((item) => item.group === 'admin');

  const isActive = (href: string) => router.pathname === href || router.pathname.startsWith(href + '/');

  function linkClass(href: string): string {
    return `${styles.link} ${isActive(href) ? styles.active : ''}`;
  }

  async function handleSignOut() {
    await signOut();
    router.push('/');
  }

  const signInHref = `/signin?next=${encodeURIComponent(router.asPath === '/signin' ? '/dashboard' : router.asPath)}`;

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link href={me ? '/dashboard' : '/'} className={styles.brand}>
          <span className={styles.brandMark} aria-hidden="true">
            C
          </span>
          ClassTryout
        </Link>

        {showNav && (
          <button
            type="button"
            className={styles.burger}
            aria-expanded={menuOpen}
            aria-controls="main-nav"
            onClick={() => setMenuOpen((open) => !open)}
          >
            {menuOpen ? 'Close' : 'Menu'}
          </button>
        )}

        {showNav && (
          <nav id="main-nav" aria-label="Main" className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}>
            {mainItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={linkClass(item.href)}
                aria-current={isActive(item.href) ? 'page' : undefined}
              >
                {item.label}
              </Link>
            ))}

            {adminItems.length > 0 && (
              <details
                key={router.asPath}
                className={`${styles.menu} ${adminItems.some((item) => isActive(item.href)) ? styles.menuActive : ''}`}
              >
                <summary>Admin</summary>

                <div className={styles.menuList}>
                  {adminItems.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={linkClass(item.href)}
                      aria-current={isActive(item.href) ? 'page' : undefined}
                    >
                      {item.label}
                    </Link>
                  ))}
                </div>
              </details>
            )}
          </nav>
        )}

        <div className={styles.tools}>
          {showNav && <WalletBar />}

          {state !== 'unavailable' && (
            <div className={styles.account}>
              {state === 'loading' && <span aria-label="Loading account">…</span>}

              {state === 'signedOut' && (
                <Link href={signInHref} className={styles.link}>
                  Sign in
                </Link>
              )}

              {state === 'ready' && me && (
                <>
                  <span className={styles.who} data-testid="bar-name">
                    {me.profile.displayName || me.email || 'Account'}
                  </span>

                  <span className={styles.roleTag}>{me.role.replace('_', ' ')}</span>

                  {!me.onboarding.complete && router.pathname !== '/onboarding' && (
                    <Link href="/onboarding" className={styles.setupLink}>
                      Finish setup
                    </Link>
                  )}

                  <Link href="/account" className={styles.link}>
                    Account
                  </Link>

                  <button type="button" className={styles.linkBtn} onClick={handleSignOut}>
                    Sign out
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default NavBar;
