// components/Wallet/WalletBar/WalletBar.tsx
// The wallet control in the navigation bar: a connect button, or the network picker + address + Admin badge.
// All the state lives in WalletProvider. This file only draws it.

import React, { useMemo } from 'react';
import styles from '@/styles/Layout.module.css';
import { enabledNetworks, networkLabel } from '@/blockchain/wallets';
import { isDeployedOnChain } from '@/blockchain/contracts/deployments';
import { shortAddress } from '@/utils/shortAddress';
import { useWallet } from '../WalletProvider';
import type { AppNetwork } from '@/blockchain/types';

interface NetworkGroup {
  label: string;
  items: AppNetwork[];
}

// The picker groups networks so people choose a free testnet first.
function groupNetworks(networks: AppNetwork[]): NetworkGroup[] {
  const groups: NetworkGroup[] = [
    { label: 'Testnets (free test ETH)', items: networks.filter((n) => n.testnet && n.kind !== 'Local') },
    { label: 'Layer 2 (low fees)', items: networks.filter((n) => !n.testnet && n.kind === 'L2') },
    { label: 'Ethereum mainnet (real ETH)', items: networks.filter((n) => !n.testnet && n.kind === 'L1') },
    { label: 'Other chains', items: networks.filter((n) => !n.testnet && n.kind === 'Sidechain') },
    { label: 'Local', items: networks.filter((n) => n.kind === 'Local') },
  ];

  return groups.filter((group) => group.items.length > 0);
}

export const WalletBar: React.FC = () => {
  const { account, chainId, isAdmin, error, switching, connect, switchTo } = useWallet();

  const networks = useMemo(() => enabledNetworks(), []);
  const groups = groupNetworks(networks);
  const currentNetworkIsListed = networks.some((n) => String(n.chainId) === chainId);

  function handleNetworkChange(event: React.ChangeEvent<HTMLSelectElement>) {
    const chosen = event.target.value;

    if (chosen && chosen !== chainId) switchTo(Number(chosen));
  }

  return (
    <div className={styles.walletBar}>
      {account ? (
        <>
          <select
            className={styles.networkSelect}
            aria-label="Network"
            value={currentNetworkIsListed ? chainId : ''}
            disabled={switching}
            onChange={handleNetworkChange}
          >
            {!currentNetworkIsListed && (
              <option value="">
                {networkLabel(chainId)} ({chainId})
              </option>
            )}

            {groups.map((group) => (
              <optgroup key={group.label} label={group.label}>
                {group.items.map((network) => (
                  <option key={network.chainId} value={network.chainId}>
                    {network.name}
                    {isDeployedOnChain(network.chainId) ? '' : ' — not deployed yet'}
                  </option>
                ))}
              </optgroup>
            ))}
          </select>

          <span className={styles.pill} title={account}>
            {shortAddress(account)}
          </span>

          {isAdmin && <span className={styles.adminBadge}>Admin</span>}
        </>
      ) : (
        <button type="button" className={styles.walletBtn} onClick={connect}>
          Connect Wallet
        </button>
      )}

      {error && (
        <span className={styles.walletErr} role="alert">
          {error}
        </span>
      )}
    </div>
  );
};

export default WalletBar;
