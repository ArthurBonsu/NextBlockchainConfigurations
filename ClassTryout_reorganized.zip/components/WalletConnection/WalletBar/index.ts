export { WalletBar } from './WalletBar';
