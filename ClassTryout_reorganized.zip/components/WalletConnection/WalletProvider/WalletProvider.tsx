// components/Wallet/WalletProvider/WalletProvider.tsx
// One place that knows about the connected wallet: which account, which network, and whether it is the contracts' admin.
// The navigation bar, the network banners and the dashboard all read it from here, so they never disagree.
// (Each panel still calls getContracts() itself when it sends a transaction.)

import React, { ReactNode, createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { connectWallet, isRealMoney, networkLabel, switchWalletNetwork } from '@/blockchain/wallets';
import { isDeployedOnChain } from '@/blockchain/contracts/deployments';
import { getContractStatuses } from '@/blockchain/contracts/ContractControl';
import { friendlyError } from '@/utils/friendlyError';

export interface WalletContextValue {
  account: string | null;
  chainId: string;
  networkName: string;
  isAdmin: boolean;
  deployed: boolean;
  realMoney: boolean;
  error: string;
  switching: boolean;
  connect: () => Promise<void>;
  switchTo: (chainId: number) => Promise<void>;
}

const WalletContext = createContext<WalletContextValue>({
  account: null,
  chainId: '',
  networkName: '',
  isAdmin: false,
  deployed: true,
  realMoney: false,
  error: '',
  switching: false,
  connect: async () => {},
  switchTo: async () => {},
});

export const WalletProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [account, setAccount] = useState<string | null>(null);
  const [chainId, setChainId] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);
  const [error, setError] = useState('');
  const [switching, setSwitching] = useState(false);

  // Is this wallet the admin (the OpenZeppelin owner)? If nothing is deployed on this chain, quietly say no.
  const readAdmin = useCallback(() => {
    getContractStatuses()
      .then((report) => setIsAdmin(report.isAdmin))
      .catch(() => setIsAdmin(false));
  }, []);

  const connect = useCallback(async () => {
    setError('');

    try {
      const connection = await connectWallet();

      setAccount(connection.account);
      setChainId(connection.chainId);
      readAdmin();
    } catch (err) {
      setError(friendlyError(err));
    }
  }, [readAdmin]);

  const switchTo = useCallback(async (targetChainId: number) => {
    if (!targetChainId) return;

    setError('');
    setSwitching(true);

    try {
      await switchWalletNetwork(targetChainId);
      // The wallet fires "chainChanged", which reloads the page (see below).
    } catch (err) {
      setError(friendlyError(err));
    } finally {
      setSwitching(false);
    }
  }, []);

  // If the wallet already trusted this site on an earlier visit, connect without a pop-up.
  // (eth_accounts never opens a pop-up.)
  useEffect(() => {
    if (typeof window === 'undefined' || !window.ethereum) return;

    window.ethereum
      .request({ method: 'eth_accounts' })
      .then((accounts: string[]) => {
        if (accounts && accounts.length > 0) connect();
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Stay in sync with the wallet. If the user switches network or account in MetaMask, update or reload the page.
  useEffect(() => {
    if (typeof window === 'undefined' || !window.ethereum) return;

    // Contract addresses and anything already fetched belong to the old chain.
    // Reloading is the simplest clean reset, and what MetaMask recommends.
    const onChainChanged = () => window.location.reload();

    const onAccountsChanged = (accounts: string[]) => {
      if (accounts.length === 0) {
        setAccount(null);
        setChainId('');
        setIsAdmin(false);
        return;
      }

      setAccount(accounts[0]);
      readAdmin();
    };

    window.ethereum.on?.('chainChanged', onChainChanged);
    window.ethereum.on?.('accountsChanged', onAccountsChanged);

    return () => {
      window.ethereum?.removeListener?.('chainChanged', onChainChanged);
      window.ethereum?.removeListener?.('accountsChanged', onAccountsChanged);
    };
  }, [readAdmin]);

  const value = useMemo<WalletContextValue>(
    () => ({
      account,
      chainId,
      isAdmin,
      error,
      switching,
      connect,
      switchTo,
      networkName: chainId ? networkLabel(chainId) : '',
      deployed: chainId ? isDeployedOnChain(chainId) : true,
      realMoney: chainId ? isRealMoney(chainId) : false,
    }),
    [account, chainId, isAdmin, error, switching, connect, switchTo]
  );

  return <WalletContext.Provider value={value}>{children}</WalletContext.Provider>;
};

export const useWallet = () => useContext(WalletContext);
