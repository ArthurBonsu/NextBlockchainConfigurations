// components/Account/AccountDetails/AccountDetails.tsx
// The summary card at the top of the account page: name, email, role, phone, address and ID level.

import React from 'react';
import Link from 'next/link';
import styles from '@/styles/Account.module.css';
import rolesPolicy from '@/shared/roles.json';
import type { Address, Me } from '@/types';

const ID_LEVEL_TEXT = ['No ID yet', 'ID added, waiting to be confirmed', 'ID confirmed'];

const ROLE_LABELS = rolesPolicy.labels as Record<string, string>;

function addressText(address: Address | null): string {
  if (!address) return 'Not set';

  const parts = [address.suburb, address.city, address.districtName, `${address.regionName} Region`];
  const text = parts.filter(Boolean).join(', ');

  return address.gpsAddress ? `${text} (${address.gpsAddress})` : text;
}

export const AccountDetails: React.FC<{ me: Me }> = ({ me }) => {
  const signedInWith = me.provider.replace('.com', '');

  return (
    <div className={styles.card} data-testid="account-summary">
      <h1>{me.profile.displayName || 'Your account'}</h1>

      <p className={styles.muted}>
        {me.email || 'No email on this sign-in'} · signed in with {signedInWith}
      </p>

      <dl className={styles.kv}>
        <dt>Role</dt>
        <dd data-testid="role">{ROLE_LABELS[me.role] || me.role}</dd>

        <dt>Status</dt>
        <dd>{me.status}</dd>

        <dt>Phone</dt>
        <dd>{me.phone.verified ? me.phone.masked : 'Not verified'}</dd>

        <dt>Address</dt>
        <dd data-testid="address">{addressText(me.address)}</dd>

        <dt>Identity</dt>
        <dd data-testid="id-level">
          Level {me.identity.level}: {ID_LEVEL_TEXT[me.identity.level]}
        </dd>
      </dl>

      <div className={styles.actions}>
        <Link href="/onboarding" className={styles.btnGhost}>
          Edit details
        </Link>

        <Link href="/dashboard" className={styles.btnGhost}>
          Go to my dashboard
        </Link>
      </div>
    </div>
  );
};

export default AccountDetails;
