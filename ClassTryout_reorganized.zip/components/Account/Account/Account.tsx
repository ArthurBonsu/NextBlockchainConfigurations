// components/Account/Account/Account.tsx
// The account page: who you are, what you may do, your ID, and your notification choices.

import React, { useEffect } from 'react';
import { useRouter } from 'next/router';
import styles from '@/styles/Account.module.css';
import { useAccount, IdStep } from '@/components/Authentication';
import { Notice } from '@/components/Common';
import { NavBar } from '@/components/AppLayout';
import { VerifyEmailNotice } from '@/components/Onboarding';
import { AccountDetails } from '../AccountDetails';
import { CapabilityList } from '../CapabilityList';
import { NotificationSettings } from '../NotificationSettings';

export const Account: React.FC = () => {
  const router = useRouter();
  const { state, me, setMe } = useAccount();

  useEffect(() => {
    if (state === 'signedOut') router.replace(`/signin?next=${encodeURIComponent('/account')}`);
  }, [state, router]);

  // People who have not finished setting up go there first, then come back.
  useEffect(() => {
    if (state === 'ready' && me && !me.onboarding.complete) router.replace('/onboarding?next=/account');
  }, [state, me, router]);

  if (state === 'unavailable') {
    return (
      <main className={styles.page}>
        <div className={styles.narrow}>
          <Notice kind="info">Sign-in is not set up on this site yet.</Notice>
        </div>
      </main>
    );
  }

  if (state === 'error') {
    return (
      <main className={styles.page}>
        <div className={styles.narrow}>
          <Notice kind="err">We could not load your account. Reload the page.</Notice>
        </div>
      </main>
    );
  }

  if (!me) {
    return (
      <main className={styles.page}>
        <NavBar />

        <div className={styles.narrow}>
          <p className={styles.muted}>Loading…</p>
        </div>
      </main>
    );
  }

  return (
    <main className={styles.page}>
      <NavBar />

      <div className={styles.wide}>
        <VerifyEmailNotice message="Verify your email to unlock vehicle and licence actions." />

        <AccountDetails me={me} />

        <CapabilityList capabilities={me.capabilities} />

        <div className={styles.card} id="id">
          <IdStep me={me} onChanged={(updated) => setMe({ ...updated })} />
        </div>

        <NotificationSettings me={me} />
      </div>
    </main>
  );
};

export default Account;
