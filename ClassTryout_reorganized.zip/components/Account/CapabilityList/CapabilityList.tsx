// components/Account/CapabilityList/CapabilityList.tsx
// "What you can do": each action the app has, with Allowed or the reason it is not allowed yet.

import React from 'react';
import styles from '@/styles/Account.module.css';
import rolesPolicy from '@/shared/roles.json';
import type { Capability } from '@/types';

const CAPABILITY_LABELS = rolesPolicy.capabilities as Record<string, { label: string }>;

const REASON_TEXT: Record<string, string> = {
  level: 'Needs a confirmed ID',
  role: 'Not for your role',
  onboarding: 'Finish setup',
  email_unverified: 'Verify email',
};

function badgeText(capability: Capability): string {
  if (capability.allowed) return 'Allowed';

  return REASON_TEXT[capability.reason || ''] || 'Not available';
}

export const CapabilityList: React.FC<{ capabilities: Record<string, Capability> }> = ({ capabilities }) => {
  return (
    <div className={styles.card}>
      <h2>What you can do</h2>

      <ul className={styles.list} data-testid="capabilities">
        {Object.entries(capabilities).map(([name, capability]) => (
          <li key={name}>
            <span>{CAPABILITY_LABELS[name]?.label || name}</span>

            <span className={`${styles.badge} ${capability.allowed ? styles.badgeOk : styles.badgeWarn}`} data-testid={`cap-${name}`}>
              {badgeText(capability)}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CapabilityList;
