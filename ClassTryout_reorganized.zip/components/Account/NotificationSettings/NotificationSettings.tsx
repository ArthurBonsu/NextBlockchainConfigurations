// components/Account/NotificationSettings/NotificationSettings.tsx
// Two tick boxes: email me / text me about my vehicles and licences.
// A tick shows at once. If saving fails, the box is put back and a message appears.

import React, { useState } from 'react';
import styles from '@/styles/Account.module.css';
import { api } from '@/services/api';
import { useAccount } from '@/components/Authentication';
import type { Me } from '@/types';

type Channel = 'email' | 'sms';

export const NotificationSettings: React.FC<{ me: Me }> = ({ me }) => {
  const { setMe } = useAccount();
  const [message, setMessage] = useState('');

  async function change(channel: Channel, value: boolean) {
    const before = me;

    // Show the new value straight away, then save it.
    setMe({ ...before, notifications: { ...before.notifications, [channel]: value } });

    try {
      const answer = await api<{ me: Me }>('/api/me/notifications', { body: { [channel]: value } });

      setMe({ ...answer.me, documents: before.documents });
    } catch {
      setMe(before);
      setMessage('Could not save that change. Try again.');
    }
  }

  return (
    <div className={styles.card}>
      <h2>Notifications</h2>

      <label className={styles.check}>
        <input type="checkbox" checked={me.notifications.email} onChange={(e) => change('email', e.target.checked)} data-testid="pref-email" />
        Email me about my vehicles and licences
      </label>

      <label className={styles.check}>
        <input type="checkbox" checked={me.notifications.sms} onChange={(e) => change('sms', e.target.checked)} data-testid="pref-sms" />
        Text me about my vehicles and licences
      </label>

      {message && <p className={styles.hint}>{message}</p>}

      <p className={styles.hint}>Security codes are always sent by SMS. Link a wallet on the vehicles page so notices reach you.</p>
    </div>
  );
};

export default NotificationSettings;
