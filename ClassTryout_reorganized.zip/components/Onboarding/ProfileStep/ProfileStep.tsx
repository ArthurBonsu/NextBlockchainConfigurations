// components/Onboarding/ProfileStep/ProfileStep.tsx
// Step 2: name, date of birth, gender and nationality (as they appear on the person's ID).

import React, { ChangeEvent, useState } from 'react';
import styles from '@/styles/Account.module.css';
import onboardingConfig from '@/shared/onboarding.json';
import { api } from '@/services/api';
import { useFormSubmit } from '@/hooks';
import { FormField, Notice } from '@/components/Common';
import type { Me } from '@/types';
import type { StepProps } from '../StepProps';

type ProfileFields = {
  givenName: string;
  familyName: string;
  otherNames: string;
  dob: string;
  gender: string;
  nationality: string;
};

// Sign-in with Google or GitHub gives us a full name. Use it to pre-fill the two name boxes.
function splitSuggestedName(fullName: string | null | undefined) {
  if (!fullName) return { first: '', rest: '' };

  const parts = fullName.split(' ');

  return { first: parts[0], rest: parts.slice(1).join(' ') };
}

function startingFields(me: Me): ProfileFields {
  const saved = me.profile;
  const suggested = splitSuggestedName(me.suggestedName);

  return {
    givenName: saved.givenName || suggested.first,
    familyName: saved.familyName || suggested.rest,
    otherNames: saved.otherNames || '',
    dob: saved.dob || '',
    gender: saved.gender || '',
    nationality: saved.nationality || 'GH',
  };
}

export const ProfileStep: React.FC<StepProps> = ({ me, onSaved }) => {
  const [values, setValues] = useState<ProfileFields>(startingFields(me));

  // Once the ID is confirmed, the name and date of birth can only be changed by support.
  const locked = me.identity.level >= 2;

  const form = useFormSubmit(async () => {
    const answer = await api<{ me: Me }>('/api/onboarding/profile', { body: values });

    onSaved(answer.me);
  });

  function update(name: keyof ProfileFields) {
    return (event: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      setValues({ ...values, [name]: event.target.value });
    };
  }

  const today = new Date().toISOString().slice(0, 10);

  return (
    <form onSubmit={form.run} data-testid="step-profile">
      <h2>About you</h2>

      <p className={styles.muted}>Use your name as it appears on your ID.</p>

      {locked && <Notice kind="info">Your ID is confirmed, so these details are locked. Contact support to correct them.</Notice>}

      {form.error && <Notice kind="err">{form.error}</Notice>}

      <div className={styles.row2}>
        <FormField id="givenName" label="First name" error={form.fields.givenName}>
          <input id="givenName" value={values.givenName} onChange={update('givenName')} autoComplete="given-name" disabled={locked} />
        </FormField>

        <FormField id="familyName" label="Surname" error={form.fields.familyName}>
          <input id="familyName" value={values.familyName} onChange={update('familyName')} autoComplete="family-name" disabled={locked} />
        </FormField>
      </div>

      <FormField id="otherNames" label="Other names (optional)" error={form.fields.otherNames}>
        <input id="otherNames" value={values.otherNames} onChange={update('otherNames')} disabled={locked} />
      </FormField>

      <div className={styles.row2}>
        <FormField id="dob" label="Date of birth" error={form.fields.dob} hint={`You must be at least ${onboardingConfig.minAge}.`}>
          <input id="dob" type="date" value={values.dob} onChange={update('dob')} max={today} disabled={locked} />
        </FormField>

        <FormField id="gender" label="Gender" error={form.fields.gender}>
          <select id="gender" value={values.gender} onChange={update('gender')} disabled={locked}>
            <option value="">Choose…</option>

            {onboardingConfig.genders.map((gender) => (
              <option key={gender} value={gender}>
                {gender.replace(/_/g, ' ')}
              </option>
            ))}
          </select>
        </FormField>
      </div>

      <FormField id="nationality" label="Nationality (two-letter code)" error={form.fields.nationality} hint="GH for Ghana.">
        <input
          id="nationality"
          value={values.nationality}
          onChange={update('nationality')}
          maxLength={2}
          disabled={locked}
          style={{ textTransform: 'uppercase', width: 80 }}
        />
      </FormField>

      <button className={styles.btn} disabled={form.busy || locked} data-testid="save-profile">
        {form.busy ? 'Saving…' : 'Save and continue'}
      </button>
    </form>
  );
};

export default ProfileStep;
