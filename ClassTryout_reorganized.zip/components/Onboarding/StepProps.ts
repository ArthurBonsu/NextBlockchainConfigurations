// components/Onboarding/StepProps.ts
// Every onboarding step receives the signed-in person and tells the page when it saved.

import type { Me } from '@/types';

export interface StepProps {
  me: Me;
  onSaved: (me: Me) => void;
}
