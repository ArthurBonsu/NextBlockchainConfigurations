// components/Onboarding/Onboarding/Onboarding.tsx
// The "Set up your account" screen: consent, about you, phone, address, then an optional ID.
// It opens on the first unfinished step and moves on by itself each time a step is saved.

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import styles from '@/styles/Account.module.css';
import { safeNext } from '@/utils';
import { useAccount, IdStep } from '@/components/Authentication';
import { Notice } from '@/components/Common';
import { NavBar } from '@/components/AppLayout';
import type { Me } from '@/types';
import { ConsentStep } from '../ConsentStep';
import { ProfileStep } from '../ProfileStep';
import { PhoneStep } from '../PhoneStep';
import { AddressStep } from '../AddressStep';
import { StepPills } from '../StepPills';
import { VerifyEmailNotice } from '../VerifyEmailNotice';

// A small page frame, so the loading and error screens look like the real one.
const Frame: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <main className={styles.page}>
    <NavBar variant="minimal" />

    <div className={styles.narrow}>{children}</div>
  </main>
);

export const Onboarding: React.FC = () => {
  const router = useRouter();
  const { state, me, setMe } = useAccount();

  const [step, setStep] = useState<string | null>(null);

  const nextPage = safeNext(router.query.next, '/dashboard');

  useEffect(() => {
    if (state === 'signedOut') router.replace(`/signin?next=${encodeURIComponent('/onboarding')}`);
  }, [state, router]);

  // Open on the first unfinished step. After the person clicks a step, stay where they chose.
  useEffect(() => {
    if (me && step === null) setStep(me.onboarding.next || me.onboarding.steps[0]);
  }, [me, step]);

  if (state === 'unavailable') {
    return (
      <Frame>
        <Notice kind="info">Sign-in is not set up on this site yet.</Notice>
      </Frame>
    );
  }

  if (state === 'error') {
    return (
      <Frame>
        <Notice kind="err">We could not load your account. Reload the page.</Notice>
      </Frame>
    );
  }

  if (!me || !step) {
    return (
      <Frame>
        <p className={styles.muted}>Loading…</p>
      </Frame>
    );
  }

  // After a step is saved, go to the next one. The ID step is optional and shows its own list, so it stays.
  function handleSaved(updated: Me) {
    setMe({ ...updated, documents: updated.documents ?? me?.documents });

    const position = updated.onboarding.steps.indexOf(step as string);
    const hasNextStep = position < updated.onboarding.steps.length - 1;

    if (step !== 'id' && hasNextStep) setStep(updated.onboarding.steps[position + 1]);
  }

  const stepProps = { me, onSaved: handleSaved };

  return (
    <main className={styles.page}>
      <NavBar variant="minimal" />

      <div className={styles.narrow}>
        <VerifyEmailNotice />

        <div className={styles.card}>
          <h1>Set up your account</h1>

          <StepPills onboarding={me.onboarding} currentStep={step} onChoose={setStep} />

          {step === 'consent' && <ConsentStep {...stepProps} />}
          {step === 'profile' && <ProfileStep {...stepProps} />}
          {step === 'phone' && <PhoneStep {...stepProps} />}
          {step === 'address' && <AddressStep {...stepProps} />}
          {step === 'id' && <IdStep me={me} onChanged={(updated) => setMe({ ...updated })} />}

          {me.onboarding.complete && (
            <div className={`${styles.notice} ${styles.noticeOk}`} style={{ marginTop: 20 }} data-testid="onboarding-complete">
              Your account is set up.{' '}
              {me.identity.level < 2 && 'Registering vehicles and licences needs a confirmed ID: add yours when you are ready.'}{' '}
              <button type="button" className={styles.btn} onClick={() => router.push(nextPage)} data-testid="finish">
                Continue
              </button>
            </div>
          )}
        </div>
      </div>
    </main>
  );
};

export default Onboarding;
