// components/Onboarding/VerifyEmailNotice/VerifyEmailNotice.tsx
// Shown while the person's email address is not yet verified.
// "Send again" mails a new link. "I have verified" reloads the account after they clicked it.

import React, { useState } from 'react';
import styles from '@/styles/Account.module.css';
import { sendVerificationEmail } from '@/services/auth';
import { Notice } from '@/components/Common';
import { useAccount } from '@/components/Authentication';

export interface VerifyEmailNoticeProps {
  message?: string; // the first sentence. The default is for the set-up screen.
}

export const VerifyEmailNotice: React.FC<VerifyEmailNoticeProps> = ({ message: lead }) => {
  const { me, firebaseUser, refresh } = useAccount();
  const [feedback, setFeedback] = useState('');

  if (!me || !me.email || me.emailVerified) return null;

  async function sendAgain() {
    try {
      if (firebaseUser) await sendVerificationEmail(firebaseUser);
      setFeedback('Verification email sent. Check your inbox.');
    } catch {
      setFeedback('Could not send it just now. Try again in a minute.');
    }
  }

  async function checkNow() {
    await firebaseUser?.reload();
    await firebaseUser?.getIdToken(true);
    await refresh();
  }

  return (
    <Notice kind="info" testid="verify-email">
      {lead || 'Verify your email:'} We sent a link to {me.email}.{' '}
      <button type="button" className={styles.linkBtn} onClick={sendAgain}>
        Send again
      </button>{' '}
      <button type="button" className={styles.linkBtn} onClick={checkNow}>
        I have verified
      </button>
      {feedback && <div>{feedback}</div>}
    </Notice>
  );
};

export default VerifyEmailNotice;
