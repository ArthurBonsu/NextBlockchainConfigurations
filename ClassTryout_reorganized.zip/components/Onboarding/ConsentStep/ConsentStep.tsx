// components/Onboarding/ConsentStep/ConsentStep.tsx
// Step 1: the person agrees to the terms, the privacy notice and SMS messages.

import React, { useState } from 'react';
import styles from '@/styles/Account.module.css';
import onboardingConfig from '@/shared/onboarding.json';
import { api } from '@/services/api';
import { useFormSubmit } from '@/hooks';
import { Notice } from '@/components/Common';
import type { Me } from '@/types';
import type { StepProps } from '../StepProps';

type ConsentKey = keyof typeof onboardingConfig.consents;

const CONSENT_KEYS = Object.keys(onboardingConfig.consents) as ConsentKey[];

export const ConsentStep: React.FC<StepProps> = ({ me, onSaved }) => {
  const alreadyAgreed = !!me.onboarding.done.consent;

  const [agreed, setAgreed] = useState({
    terms: alreadyAgreed,
    privacy: alreadyAgreed,
    sms: alreadyAgreed,
  });

  const form = useFormSubmit(async () => {
    const answer = await api<{ me: Me }>('/api/onboarding/consent', { body: agreed });

    onSaved(answer.me);
  });

  const everythingTicked = agreed.terms && agreed.privacy && agreed.sms;

  return (
    <form onSubmit={form.run} data-testid="step-consent">
      <h2>Agreements</h2>

      <p className={styles.muted}>We need your agreement before we store your details or text you a code.</p>

      {form.error && <Notice kind="err">{form.error}</Notice>}

      {CONSENT_KEYS.map((key) => (
        <label className={styles.check} key={key}>
          <input
            type="checkbox"
            checked={agreed[key]}
            onChange={(event) => setAgreed({ ...agreed, [key]: event.target.checked })}
            data-testid={`consent-${key}`}
          />

          <span>{onboardingConfig.consents[key].label}</span>
        </label>
      ))}

      <button className={styles.btn} disabled={form.busy || !everythingTicked} data-testid="save-consent">
        {form.busy ? 'Saving…' : 'Agree and continue'}
      </button>
    </form>
  );
};

export default ConsentStep;
