// components/Onboarding/PhoneStep/PhoneStep.tsx
// Step 3: confirm a mobile number. We text a 6-digit code, the person types it back.

import React, { useEffect, useState } from 'react';
import styles from '@/styles/Account.module.css';
import onboardingConfig from '@/shared/onboarding.json';
import { api } from '@/services/api';
import { useFormSubmit } from '@/hooks';
import { FormField, Notice } from '@/components/Common';
import type { Me } from '@/types';
import type { StepProps } from '../StepProps';

interface CodeSent {
  maskedPhone: string;
  resendAt: number; // a time in milliseconds
}

// If the person left this page after asking for a code, pick up where they were.
function codeAlreadySent(me: Me): CodeSent | null {
  if (!me.pendingPhone) return null;

  return {
    maskedPhone: me.pendingPhone.masked,
    resendAt: Date.parse(me.pendingPhone.resendAfter),
  };
}

// Counts down once a second, so the "Send again in 20s" label stays right.
function useNow(): number {
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);

    return () => clearInterval(timer);
  }, []);

  return now;
}

function sendButtonLabel(busy: boolean, sent: CodeSent | null, secondsToWait: number): string {
  if (busy) return 'Sending…';
  if (!sent) return 'Send code';
  if (secondsToWait > 0) return `Send again in ${secondsToWait}s`;

  return 'Send a new code';
}

export const PhoneStep: React.FC<StepProps> = ({ me, onSaved }) => {
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [sent, setSent] = useState<CodeSent | null>(codeAlreadySent(me));

  const now = useNow();
  const secondsToWait = sent ? Math.max(0, Math.ceil((sent.resendAt - now) / 1000)) : 0;

  const sendForm = useFormSubmit(async () => {
    const answer = await api<{ sentTo: string; resendInSeconds: number }>('/api/onboarding/phone/start', {
      body: { phone },
    });

    setSent({ maskedPhone: answer.sentTo, resendAt: Date.now() + answer.resendInSeconds * 1000 });
    setCode('');
  });

  const confirmForm = useFormSubmit(async () => {
    const answer = await api<{ me: Me }>('/api/onboarding/phone/confirm', { body: { code } });

    setSent(null);
    onSaved(answer.me);
  });

  const cannotSendYet = !phone || (!!sent && secondsToWait > 0);
  const minutesValid = Math.round(onboardingConfig.otp.ttlSeconds / 60);

  return (
    <div data-testid="step-phone">
      <h2>Phone number</h2>

      <p className={styles.muted}>We text a 6-digit code to confirm the number is yours. Standard SMS rates may apply.</p>

      {me.phone.verified && (
        <Notice kind="ok" testid="phone-verified">
          Verified: {me.phone.masked}. You can change it below.
        </Notice>
      )}

      {sendForm.error && (
        <Notice kind="err" testid="phone-error">
          {sendForm.error}
        </Notice>
      )}

      <form onSubmit={sendForm.run}>
        <FormField id="phone" label="Mobile number" error={sendForm.fields.phone} hint="For example 024 123 4567">
          <input
            id="phone"
            inputMode="tel"
            autoComplete="tel"
            value={phone}
            onChange={(event) => setPhone(event.target.value)}
            placeholder="024 123 4567"
          />
        </FormField>

        <button className={styles.btn} disabled={sendForm.busy || cannotSendYet} data-testid="send-code">
          {sendButtonLabel(sendForm.busy, sent, secondsToWait)}
        </button>
      </form>

      {sent && (
        <form onSubmit={confirmForm.run} style={{ marginTop: 20 }}>
          <Notice kind="info" testid="code-sent">
            Code sent to {sent.maskedPhone}. It expires in {minutesValid} minutes.
          </Notice>

          {confirmForm.error && (
            <Notice kind="err" testid="code-error">
              {confirmForm.error}
            </Notice>
          )}

          <FormField id="code" label="6-digit code" error={confirmForm.fields.code}>
            <input
              id="code"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              value={code}
              onChange={(event) => setCode(event.target.value.replace(/\D/g, ''))}
            />
          </FormField>

          <button className={styles.btn} disabled={confirmForm.busy || code.length !== 6} data-testid="confirm-code">
            {confirmForm.busy ? 'Checking…' : 'Verify'}
          </button>
        </form>
      )}
    </div>
  );
};

export default PhoneStep;
