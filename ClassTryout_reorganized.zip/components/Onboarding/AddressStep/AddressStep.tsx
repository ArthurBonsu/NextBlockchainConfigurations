// components/Onboarding/AddressStep/AddressStep.tsx
// Step 4: region, district, town and suburb (and optionally street, GPS address and map position).

import React, { ChangeEvent, useEffect, useMemo, useState } from 'react';
import styles from '@/styles/Account.module.css';
import regions from '@/shared/locations/regions.json';
import districts from '@/shared/locations/districts.json';
import { api } from '@/services/api';
import { useFormSubmit } from '@/hooks';
import { FormField, Notice } from '@/components/Common';
import type { Me } from '@/types';
import type { StepProps } from '../StepProps';

type AddressFields = Record<string, string>;

function startingFields(me: Me): AddressFields {
  const saved = me.address;

  return {
    regionCode: saved?.regionCode || '',
    districtId: saved?.districtId || '',
    city: saved?.city || '',
    suburb: saved?.suburb || '',
    subarea: saved?.subarea || '',
    street: saved?.street || '',
    gpsAddress: saved?.gpsAddress || '',
    lat: saved?.lat != null ? String(saved.lat) : '',
    lng: saved?.lng != null ? String(saved.lng) : '',
  };
}

// When a district is picked, ask the server which suburbs people have used there.
function useSuburbSuggestions(districtId: string): string[] {
  const [suburbs, setSuburbs] = useState<string[]>([]);

  useEffect(() => {
    let stillMounted = true;

    if (!districtId) {
      setSuburbs([]);
      return;
    }

    api<{ suburbs: { suburb: string }[] }>(`/api/locations/suburbs?districtId=${encodeURIComponent(districtId)}`)
      .then((answer) => stillMounted && setSuburbs(answer.suburbs.map((item) => item.suburb)))
      .catch(() => stillMounted && setSuburbs([]));

    return () => {
      stillMounted = false;
    };
  }, [districtId]);

  return suburbs;
}

export const AddressStep: React.FC<StepProps> = ({ me, onSaved }) => {
  const [values, setValues] = useState<AddressFields>(startingFields(me));
  const [locationMessage, setLocationMessage] = useState('');

  const suburbSuggestions = useSuburbSuggestions(values.districtId);

  const districtsInRegion = useMemo(() => districts.filter((item) => item.region === values.regionCode), [values.regionCode]);
  const chosenDistrict = districts.find((item) => item.id === values.districtId);

  const form = useFormSubmit(async () => {
    const answer = await api<{ me: Me }>('/api/onboarding/address', { body: values });

    onSaved(answer.me);
  });

  function update(name: string) {
    return (event: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      setValues({ ...values, [name]: event.target.value });
    };
  }

  // Changing the region clears everything below it, because the old choices no longer fit.
  function chooseRegion(event: ChangeEvent<HTMLSelectElement>) {
    setValues({ ...values, regionCode: event.target.value, districtId: '', city: '', suburb: '' });
  }

  function chooseDistrict(event: ChangeEvent<HTMLSelectElement>) {
    setValues({ ...values, districtId: event.target.value, city: '', suburb: '' });
  }

  function useMyLocation() {
    setLocationMessage('');

    if (!navigator.geolocation) {
      setLocationMessage('Your browser cannot share its location.');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setValues((current) => ({
          ...current,
          lat: position.coords.latitude.toFixed(6),
          lng: position.coords.longitude.toFixed(6),
        }));
      },
      () => setLocationMessage('We could not get your location. You can skip this.'),
      { timeout: 8000 }
    );
  }

  return (
    <form onSubmit={form.run} data-testid="step-address">
      <h2>Where you live</h2>

      <p className={styles.muted}>Pick your region and district, then type your town and suburb.</p>

      {form.error && <Notice kind="err">{form.error}</Notice>}

      <div className={styles.row2}>
        <FormField id="regionCode" label="Region" error={form.fields.regionCode}>
          <select id="regionCode" value={values.regionCode} onChange={chooseRegion}>
            <option value="">Choose a region…</option>

            {regions.map((region) => (
              <option key={region.code} value={region.code}>
                {region.name}
              </option>
            ))}
          </select>
        </FormField>

        <FormField id="districtId" label="District (MMDA)" error={form.fields.districtId}>
          <select id="districtId" value={values.districtId} onChange={chooseDistrict} disabled={!values.regionCode}>
            <option value="">{values.regionCode ? 'Choose a district…' : 'Choose a region first'}</option>

            {districtsInRegion.map((district) => (
              <option key={district.id} value={district.id}>
                {district.name}
              </option>
            ))}
          </select>
        </FormField>
      </div>

      <div className={styles.row2}>
        <FormField id="city" label="City or town" error={form.fields.city}>
          <input id="city" list="cities" value={values.city} onChange={update('city')} autoComplete="address-level2" />

          <datalist id="cities">
            {(chosenDistrict?.cities || []).map((city) => (
              <option key={city} value={city} />
            ))}
          </datalist>
        </FormField>

        <FormField id="suburb" label="Suburb / neighbourhood" error={form.fields.suburb} hint="Type it if you do not see it.">
          <input id="suburb" list="suburbs" value={values.suburb} onChange={update('suburb')} />

          <datalist id="suburbs">
            {suburbSuggestions.map((suburb) => (
              <option key={suburb} value={suburb} />
            ))}
          </datalist>
        </FormField>
      </div>

      <div className={styles.row2}>
        <FormField id="subarea" label="Area, estate or landmark (optional)" error={form.fields.subarea}>
          <input id="subarea" value={values.subarea} onChange={update('subarea')} />
        </FormField>

        <FormField id="street" label="Street or house (optional)" error={form.fields.street}>
          <input id="street" value={values.street} onChange={update('street')} />
        </FormField>
      </div>

      <FormField id="gpsAddress" label="GhanaPostGPS address (optional)" error={form.fields.gpsAddress} hint="For example GA-543-1234.">
        <input id="gpsAddress" value={values.gpsAddress} onChange={update('gpsAddress')} style={{ textTransform: 'uppercase' }} />
      </FormField>

      <div className={styles.actions} style={{ marginBottom: 12 }}>
        <button type="button" className={styles.btnGhost} onClick={useMyLocation}>
          Use my current location (optional)
        </button>

        {values.lat && values.lng && (
          <span className={`${styles.hint} ${styles.mono}`}>
            {values.lat}, {values.lng}
          </span>
        )}

        {locationMessage && <span className={styles.hint}>{locationMessage}</span>}
      </div>

      <button className={styles.btn} disabled={form.busy} data-testid="save-address">
        {form.busy ? 'Saving…' : 'Save and continue'}
      </button>
    </form>
  );
};

export default AddressStep;
