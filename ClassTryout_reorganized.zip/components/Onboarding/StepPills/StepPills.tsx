// components/Onboarding/StepPills/StepPills.tsx
// The row of small buttons at the top: one per step, with a tick when it is done.

import React from 'react';
import styles from '@/styles/Account.module.css';
import onboardingConfig from '@/shared/onboarding.json';
import type { Onboarding } from '@/types';

export interface StepPillsProps {
  onboarding: Onboarding;
  currentStep: string;
  onChoose: (step: string) => void;
}

const STEP_LABELS = onboardingConfig.stepLabels as Record<string, string>;

function pillClass(isDone: boolean, isCurrent: boolean): string {
  const done = isDone ? styles.stepDone : '';
  const now = isCurrent ? styles.stepNow : '';

  return `${styles.step} ${done} ${now}`;
}

export const StepPills: React.FC<StepPillsProps> = ({ onboarding, currentStep, onChoose }) => {
  return (
    <ol className={styles.steps}>
      {onboarding.steps.map((step) => {
        const isDone = !!onboarding.done[step];
        const isOptional = onboarding.optional.includes(step);

        return (
          <li key={step}>
            <button
              type="button"
              onClick={() => onChoose(step)}
              data-testid={`pill-${step}`}
              className={pillClass(isDone, step === currentStep)}
              style={{ border: 0, cursor: 'pointer' }}
            >
              {isDone ? '✓ ' : ''}
              {STEP_LABELS[step]}
              {isOptional ? ' (later is fine)' : ''}
            </button>
          </li>
        );
      })}
    </ol>
  );
};

export default StepPills;
