// components/Licences/IssueLicenseForm/IssueLicenseForm.tsx
// "Issue a license": writes to the LicenseRegistry contract.

import React, { useState } from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { issueLicense } from '@/blockchain/contracts/LicenseRegistry';
import { useActionStatus } from '@/hooks/useActionStatus';
import { StatusMessage } from '@/components/Common';
import { ReceiptCard } from '@/components/Receipts';
import type { Receipt } from '@/blockchain/types';

const DEFAULT_VALID_DAYS = 365;

export const IssueLicenseForm: React.FC = () => {
  const [licenseId, setLicenseId] = useState('');
  const [vehiclePseudonym, setVehiclePseudonym] = useState('');
  const [licenseType, setLicenseType] = useState('Standard');
  const [validityDays, setValidityDays] = useState(String(DEFAULT_VALID_DAYS));
  const [receipt, setReceipt] = useState<Receipt | null>(null);
  const issueStatus = useActionStatus();

  async function handleIssue() {
    const id = licenseId.trim();
    const vehicle = vehiclePseudonym.trim();
    const type = licenseType.trim();

    if (!id || !vehicle || !type) return;

    issueStatus.showPending('Confirm the transaction in your wallet...');
    setReceipt(null);

    try {
      const newReceipt = await issueLicense({
        licenseId: id,
        vehiclePseudonym: vehicle,
        licenseType: type,
        validityDays: Number(validityDays) || DEFAULT_VALID_DAYS,
      });

      setReceipt(newReceipt);
      issueStatus.showSuccess(`License "${id}" issued.`);
      setLicenseId('');
      setVehiclePseudonym('');
    } catch (err) {
      issueStatus.showError(err);
    }
  }

  return (
    <div className={styles.section}>
      <label className={styles.label}>Issue a license</label>

      <div className={styles.stackedInputs}>
        <input
          className={styles.input}
          placeholder="License ID, e.g. lic-001"
          value={licenseId}
          onChange={(e) => setLicenseId(e.target.value)}
        />

        <input
          className={styles.input}
          placeholder="Vehicle pseudonym (must already be registered)"
          value={vehiclePseudonym}
          onChange={(e) => setVehiclePseudonym(e.target.value)}
        />

        <div className={styles.inputRow}>
          <input
            className={styles.input}
            placeholder="License type, e.g. Standard"
            value={licenseType}
            onChange={(e) => setLicenseType(e.target.value)}
          />

          <input
            className={styles.input}
            style={{ maxWidth: 110 }}
            type="number"
            placeholder="Days valid"
            value={validityDays}
            onChange={(e) => setValidityDays(e.target.value)}
          />
        </div>

        <button className={styles.button} onClick={handleIssue} disabled={issueStatus.isPending}>
          Issue License
        </button>
      </div>

      <StatusMessage status={issueStatus.status} />

      {receipt && <ReceiptCard receipt={receipt} />}
    </div>
  );
};

export default IssueLicenseForm;
