// components/Licences/LicenseAdminActions/LicenseAdminActions.tsx
// Revoke or reinstate a licence. Only the wallet that owns the LicenseRegistry can do this.

import React, { useState } from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { reinstateLicense, revokeLicense } from '@/blockchain/contracts/LicenseRegistry';
import { useActionStatus } from '@/hooks/useActionStatus';
import { StatusMessage } from '@/components/Common';

export interface LicenseAdminActionsProps {
  // Called after a successful change, so the page can refresh the licence it is showing.
  onChanged: (licenseId: string) => void;
}

export const LicenseAdminActions: React.FC<LicenseAdminActionsProps> = ({ onChanged }) => {
  const [licenseId, setLicenseId] = useState('');
  const adminStatus = useActionStatus();

  async function runAdminAction(action: 'revoke' | 'reinstate') {
    const id = licenseId.trim();

    if (!id) return;

    adminStatus.showPending('Confirm the transaction in your wallet... (admin only)');

    try {
      if (action === 'revoke') {
        await revokeLicense(id);
        adminStatus.showSuccess(`License "${id}" revoked.`);
      } else {
        await reinstateLicense(id);
        adminStatus.showSuccess(`License "${id}" reinstated.`);
      }

      onChanged(id);
    } catch (err) {
      adminStatus.showError(err);
    }
  }

  return (
    <div className={styles.adminSection}>
      <div className={styles.adminLabel}>Admin actions</div>

      <div className={styles.subtle}>
        Only the admin wallet (the LicenseRegistry owner) can revoke or reinstate a license.
      </div>

      <div className={styles.section}>
        <label className={styles.label}>Revoke / reinstate a license</label>

        <input
          className={styles.input}
          style={{ width: '100%', boxSizing: 'border-box', marginBottom: 8 }}
          placeholder="License ID to revoke or reinstate"
          value={licenseId}
          onChange={(e) => setLicenseId(e.target.value)}
        />

        <div className={styles.inputRow}>
          <button className={styles.buttonAdmin} onClick={() => runAdminAction('revoke')} disabled={adminStatus.isPending}>
            Revoke License
          </button>

          <button className={styles.buttonAdmin} onClick={() => runAdminAction('reinstate')} disabled={adminStatus.isPending}>
            Reinstate License
          </button>
        </div>

        <StatusMessage status={adminStatus.status} />
      </div>
    </div>
  );
};

export default LicenseAdminActions;
