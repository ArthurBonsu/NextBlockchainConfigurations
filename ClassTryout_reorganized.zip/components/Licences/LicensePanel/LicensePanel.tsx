// components/Licences/LicensePanel/LicensePanel.tsx
// The Licences page card: issue a licence, look one up, and the admin buttons.
// The contract work is in blockchain/contracts/LicenseRegistry/LicenseRegistryActions.ts

import React from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { useLicenseLookup } from '@/hooks/useLicenseLookup';
import { StatusMessage } from '@/components/Common';
import { IssueLicenseForm } from '../IssueLicenseForm';
import { LicenseResult } from '../LicenseResult';
import { LicenseAdminActions } from '../LicenseAdminActions';

export const LicensePanel: React.FC = () => {
  const lookup = useLicenseLookup();

  // After an admin revokes or reinstates a licence, refresh it if it is the one on screen.
  function handleAdminChanged(changedId: string) {
    if (lookup.licenseId.trim() === changedId) lookup.lookUpById(changedId);
  }

  return (
    <div className={styles.card}>
      <h2>License</h2>

      <IssueLicenseForm />

      <div className={styles.section}>
        <label className={styles.label}>Look up a license</label>

        <div className={styles.inputRow}>
          <input
            className={styles.input}
            placeholder="License ID"
            value={lookup.licenseId}
            onChange={(e) => lookup.setLicenseId(e.target.value)}
          />

          <button className={styles.buttonSecondary} onClick={() => lookup.lookUpById()}>
            Look Up
          </button>
        </div>

        <div className={styles.inputRow} style={{ marginTop: 8 }}>
          <input
            className={styles.input}
            placeholder="...or find by vehicle pseudonym"
            value={lookup.vehicleToFind}
            onChange={(e) => lookup.setVehicleToFind(e.target.value)}
          />

          <button className={styles.buttonSecondary} onClick={lookup.findByVehicle}>
            Find
          </button>
        </div>

        <StatusMessage status={lookup.vehicleStatus} />
        <StatusMessage status={lookup.idStatus} />

        {lookup.licenseInfo && <LicenseResult license={lookup.licenseInfo} licenseId={lookup.foundId} />}
      </div>

      <LicenseAdminActions onChanged={handleAdminChanged} />
    </div>
  );
};

export default LicensePanel;
