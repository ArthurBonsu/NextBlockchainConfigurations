export { LicenseResult } from './LicenseResult';
export type { LicenseResultProps } from './LicenseResult';
