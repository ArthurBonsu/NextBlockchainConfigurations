// components/Licences/LicenseResult/LicenseResult.tsx
// The answer box shown after looking up a licence.

import React from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import type { LicenseInfo } from '@/blockchain/types';

export interface LicenseResultProps {
  license: LicenseInfo;
  licenseId: string;
}

export const LicenseResult: React.FC<LicenseResultProps> = ({ license, licenseId }) => {
  if (!license.issued) {
    return (
      <div className={styles.resultBox}>
        <div className={styles.errorText}>No license with that ID.</div>
      </div>
    );
  }

  return (
    <div className={styles.resultBox}>
      <div>
        <span className={styles.resultLabel}>License ID:</span> {licenseId}
      </div>

      <div>
        <span className={styles.resultLabel}>Vehicle:</span> {license.vehiclePseudonym}
      </div>

      <div>
        <span className={styles.resultLabel}>Type:</span> {license.licenseType}
      </div>

      <div>
        <span className={styles.resultLabel}>Issued:</span> {license.issueTime}
      </div>

      <div>
        <span className={styles.resultLabel}>Expires:</span> {license.expiryTime}
      </div>

      <div>
        <span className={styles.resultLabel}>Status:</span>{' '}
        {license.isValid ? (
          <span className={styles.badgeActive}>Valid</span>
        ) : (
          <span className={styles.badgeRevoked}>{license.isActive ? 'Expired or vehicle revoked' : 'Revoked'}</span>
        )}
      </div>
    </div>
  );
};

export default LicenseResult;
