// components/Notifications/NotifyPanel/NotifyPanel.tsx
// Lets a signed-in user link their wallet to their account, so the email watcher knows where to send
// registration, revocation, reinstatement and licence notices.
// Linking means signing one free message with the wallet. No transaction, no gas.

import React, { useCallback, useEffect, useState } from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { connectWallet, linkWallet, listLinkedWallets, unlinkWallet } from '@/blockchain/wallets';
import type { LinkedWallet } from '@/blockchain/wallets';
import { AUTH_IS_DEV, NotSignedInError, getDevIdentity, setDevIdentity } from '@/services/auth';
import type { DevIdentity } from '@/services/auth';
import { friendlyError } from '@/utils/friendlyError';
import { shortAddress } from '@/utils/shortAddress';
import type { ActionStatus } from '@/blockchain/types';

const IDLE: ActionStatus = { type: 'idle', message: '' };

export const NotifyPanel: React.FC = () => {
  const [wallets, setWallets] = useState<LinkedWallet[]>([]);
  const [account, setAccount] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<ActionStatus>(IDLE);
  const [devIdentity, setDevIdentityDraft] = useState<DevIdentity>(getDevIdentity() || { uid: '', email: '', verified: true });

  const refresh = useCallback(async () => {
    try {
      const connection = await connectWallet();

      setAccount(connection.account);
      setWallets(await listLinkedWallets());
      setMessage((current) => (current.type === 'error' ? IDLE : current));
    } catch (err: any) {
      setWallets([]);

      // "Not signed in" is a normal state, not an error to shout about.
      if (err instanceof NotSignedInError) {
        setMessage({ type: 'idle', message: err.message });
      } else {
        setMessage({ type: 'error', message: friendlyError(err) });
      }
    }
  }, []);

  // Load once, and again whenever the user switches account in the wallet.
  useEffect(() => {
    if (!AUTH_IS_DEV) refresh();

    const ethereum = typeof window !== 'undefined' ? window.ethereum : undefined;

    ethereum?.on?.('accountsChanged', refresh);

    return () => ethereum?.removeListener?.('accountsChanged', refresh);
  }, [refresh]);

  async function handleLink() {
    setBusy(true);
    setMessage({ type: 'pending', message: 'Sign the message in your wallet (free, no transaction)...' });

    try {
      const connection = await connectWallet();

      await linkWallet(connection.web3, connection.account);

      setMessage({
        type: 'success',
        message: "Wallet linked. You will get emails for this wallet's registrations, revocations and licenses.",
      });

      await refresh();
    } catch (err) {
      setMessage({ type: 'error', message: friendlyError(err) });
    }

    setBusy(false);
  }

  async function handleUnlink(address: string) {
    setBusy(true);

    try {
      await unlinkWallet(address);
      setMessage({ type: 'success', message: 'Wallet unlinked. No more emails for it.' });

      await refresh();
    } catch (err) {
      setMessage({ type: 'error', message: friendlyError(err) });
    }

    setBusy(false);
  }

  function handleUseDevAccount() {
    setDevIdentity(devIdentity);
    refresh();
  }

  const thisWalletIsLinked = wallets.some((wallet) => wallet.address.toLowerCase() === account.toLowerCase());

  function messageClass(): string {
    if (message.type === 'error') return styles.errorText;
    if (message.type === 'success') return styles.successText;

    return styles.subtle;
  }

  return (
    <div className={styles.card} style={{ gridColumn: '1 / -1' }}>
      <h2>Email notifications</h2>

      <div className={styles.subtle}>
        Link your wallet to your account and you get an email when you register, when your registration is revoked or
        reinstated, and when a license for your vehicle is issued, revoked or reinstated. Your email address is never
        written to the blockchain; only your account knows it, and only a verified email is used.
      </div>

      {AUTH_IS_DEV && (
        <div className={styles.subtle} style={{ marginTop: 12 }}>
          <strong>Test sign-in (local only).</strong> Real sign-in uses Firebase Authentication.

          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 6 }}>
            <input
              className={styles.input}
              placeholder="test user id"
              value={devIdentity.uid}
              onChange={(e) => setDevIdentityDraft({ ...devIdentity, uid: e.target.value })}
            />

            <input
              className={styles.input}
              placeholder="test email"
              value={devIdentity.email}
              onChange={(e) => setDevIdentityDraft({ ...devIdentity, email: e.target.value })}
            />

            <label>
              <input
                type="checkbox"
                checked={devIdentity.verified}
                onChange={(e) => setDevIdentityDraft({ ...devIdentity, verified: e.target.checked })}
              />{' '}
              email verified
            </label>

            <button className={styles.buttonAdmin} onClick={handleUseDevAccount}>
              Use this account
            </button>
          </div>
        </div>
      )}

      <div style={{ marginTop: 12 }}>
        {wallets.length === 0 && <div className={styles.subtle}>No wallet linked to this account yet.</div>}

        {wallets.map((wallet) => (
          <div key={wallet.address} className={styles.controlRow}>
            <div>
              <strong>{shortAddress(wallet.address)}</strong>
              <div className={styles.subtle}>linked {new Date(wallet.linkedAt).toLocaleString()}</div>
            </div>

            <button className={styles.buttonAdmin} disabled={busy} onClick={() => handleUnlink(wallet.address)}>
              Unlink
            </button>
          </div>
        ))}
      </div>

      <button className={styles.button} style={{ marginTop: 12 }} disabled={busy || thisWalletIsLinked || !account} onClick={handleLink}>
        {thisWalletIsLinked ? 'This wallet is linked' : 'Link this wallet'}
      </button>

      {message.message && <div className={messageClass()}>{message.message}</div>}
    </div>
  );
};

export default NotifyPanel;
