// components/Receipts/ReceiptCard/ReceiptCard.tsx
// The on-chain receipt the user sees right after registering a vehicle, issuing a licence or processing a revocation.
// It is built from the transaction itself (hash, block, event). Nothing comes from a database.

import React from 'react';
import styles from '@/styles/VehicleDemo.module.css';
import { TxLink } from '../TxLink';
import type { Receipt } from '@/blockchain/types';

export interface ReceiptCardProps {
  receipt: Receipt;
}

export const ReceiptCard: React.FC<ReceiptCardProps> = ({ receipt }) => {
  const details = Object.entries(receipt.details);

  return (
    <div className={styles.receipt}>
      <div className={styles.receiptHeader}>
        <span className={styles.receiptAction}>{receipt.action}</span>
        <span className={styles.receiptSubject}>{receipt.subject}</span>
      </div>

      <div className={styles.receiptBody}>
        {details.map(([key, value]) => (
          <div key={key} className={styles.receiptRow}>
            <span className={styles.receiptLabel}>{key}</span>
            <span>{value}</span>
          </div>
        ))}

        <div className={styles.receiptRow}>
          <span className={styles.receiptLabel}>block</span>
          <span>#{receipt.blockNumber}</span>
        </div>

        <div className={styles.receiptRow}>
          <span className={styles.receiptLabel}>time</span>
          <span>{receipt.timestamp}</span>
        </div>

        <div className={styles.receiptRow}>
          <span className={styles.receiptLabel}>tx</span>
          <TxLink hash={receipt.txHash} className={styles.receiptTx} />
        </div>
      </div>
    </div>
  );
};

export default ReceiptCard;
