// components/Receipts/TxLink/TxLink.tsx
// Shows a transaction hash.
// On a network with a block explorer (mainnet, layer 2s, testnets) the hash is a link to it.
// On a local chain it is plain text. The network is read from the wallet, so this works wherever it is used.

import React, { useEffect, useState } from 'react';
import { explorerTxUrl } from '@/blockchain/wallets';

export interface TxLinkProps {
  hash: string;
  className?: string;
}

export const TxLink: React.FC<TxLinkProps> = ({ hash, className }) => {
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    const ethereum = typeof window !== 'undefined' ? window.ethereum : undefined;

    if (!ethereum) return;

    let cancelled = false;

    Promise.resolve(ethereum.request({ method: 'eth_chainId' }))
      .then((chainIdHex: string) => {
        if (cancelled) return;

        setUrl(explorerTxUrl(parseInt(chainIdHex, 16), hash));
      })
      .catch(() => {});

    return () => {
      cancelled = true;
    };
  }, [hash]);

  return (
    <code className={className}>
      {url ? (
        <a href={url} target="_blank" rel="noopener noreferrer">
          {hash}
        </a>
      ) : (
        hash
      )}
    </code>
  );
};

export default TxLink;
