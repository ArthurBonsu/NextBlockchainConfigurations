// notifier/templates.ts
// The wording of each email. One function per template id in shared/notifications.json.
// Each returns { subject, text, html }.
//
// `d` always has: network (name), explorerUrl (may be ""), appUrl (may be ""), wallet, plus the fields used below.

type TemplateData = Record<string, any>;

// A line is either a plain sentence, or a [label, value] pair shown in a small table.
type Line = string | [string, string];

export interface EmailContent {
  subject: string;
  text: string;
  html: string;
}

const HTML_ESCAPES: Record<string, string> = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

function esc(value: unknown): string {
  return String(value).replace(/[&<>"']/g, (character) => HTML_ESCAPES[character]);
}

// A unix time in seconds as a readable date. Empty when there is no time.
function when(unixSeconds: unknown): string {
  return unixSeconds ? new Date(Number(unixSeconds) * 1000).toUTCString() : '';
}

const DEFAULT_FOOTER = 'You get this email because your wallet is linked to your ClassTryout account. You can unlink it any time in the app.';

// Builds the plain-text and the HTML version of an email from the same lines.
function layout(d: TemplateData, title: string, lines: Line[], footerNote?: string): { text: string; html: string } {
  const textLines: string[] = lines.map((line) => (Array.isArray(line) ? `${line[0]}: ${line[1]}` : line));

  if (d.explorerUrl) textLines.push('', `Transaction: ${d.explorerUrl}`);
  if (d.appUrl) textLines.push(`Open ClassTryout: ${d.appUrl}`);

  textLines.push('', footerNote || DEFAULT_FOOTER);

  const tableRows = lines
    .map((line) =>
      Array.isArray(line)
        ? `<tr><td style="padding:4px 12px 4px 0;color:#555">${esc(line[0])}</td><td style="padding:4px 0"><strong>${esc(line[1])}</strong></td></tr>`
        : ''
    )
    .join('');

  const introParagraphs = lines
    .filter((line) => !Array.isArray(line) && line !== '')
    .map((line) => `<p style="margin:0 0 12px">${esc(line)}</p>`)
    .join('');

  const html =
    `<div style="font-family:Arial,Helvetica,sans-serif;font-size:15px;color:#111;max-width:560px">` +
    `<h2 style="margin:0 0 16px">${esc(title)}</h2>${introParagraphs}<table style="border-collapse:collapse;margin:8px 0 16px">${tableRows}</table>` +
    (d.explorerUrl ? `<p style="margin:0 0 8px"><a href="${esc(d.explorerUrl)}">View the transaction</a></p>` : '') +
    (d.appUrl ? `<p style="margin:0 0 16px"><a href="${esc(d.appUrl)}">Open ClassTryout</a></p>` : '') +
    `<p style="margin:16px 0 0;color:#666;font-size:12px">${esc(footerNote || DEFAULT_FOOTER)}</p></div>`;

  return { text: textLines.join('\n'), html };
}

export const templates: Record<string, (d: TemplateData) => EmailContent> = {
  registration: (d) => ({
    subject: `Registration confirmed: ${d.pseudonym}`,
    ...layout(d, 'Your vehicle registration is confirmed', [
      'Your registration was recorded on the blockchain.',
      '',
      ['Pseudonym', d.pseudonym],
      ['Wallet', d.wallet],
      ['Network', d.network],
      ['Registered', when(d.timestamp)],
    ]),
  }),

  revocation: (d) => ({
    subject: `Notice: your registration ${d.pseudonym} has been revoked`,
    ...layout(
      d,
      'Your registration has been revoked',
      [
        'The administrator has revoked this registration. Licenses tied to it are no longer valid while it is revoked.',
        '',
        ['Pseudonym', d.pseudonym],
        ['Reason', d.reason || '(none given)'],
        ['Network', d.network],
        ['Revoked', when(d.timestamp)],
      ],
      'If you think this is a mistake, contact the administrator. Records on the blockchain are public and permanent. You get this email because your wallet is linked to your ClassTryout account.'
    ),
  }),

  reinstatement: (d) => ({
    subject: `Good news: your registration ${d.pseudonym} has been reinstated`,
    ...layout(d, 'Your registration has been reinstated', [
      'The administrator has lifted the revocation on this registration.',
      '',
      ['Pseudonym', d.pseudonym],
      ['Network', d.network],
      ['Reinstated', when(d.timestamp)],
    ]),
  }),

  licenseIssued: (d) => ({
    subject: `A license was issued for ${d.pseudonym}`,
    ...layout(
      d,
      'A license was issued for your vehicle',
      [
        'A license was recorded on the blockchain for your registration.',
        '',
        ['License', d.licenseId || '(see the transaction)'],
        ['Type', d.licenseType],
        ['Vehicle', d.pseudonym],
        ['Valid until', when(d.expiryTime)],
        ['Issued by wallet', d.issuer],
        ['Network', d.network],
      ],
      'If you did not expect this license, contact the administrator. You get this email because your wallet is linked to your ClassTryout account.'
    ),
  }),

  licenseRevoked: (d) => ({
    subject: `License ${d.licenseId || ''} has been revoked`.replace('  ', ' '),
    ...layout(d, 'Your license has been revoked', [
      'The administrator has revoked this license. It is not valid until it is reinstated.',
      '',
      ['License', d.licenseId || '(see the transaction)'],
      ['Vehicle', d.pseudonym],
      ['Network', d.network],
      ['Revoked', when(d.timestamp)],
    ]),
  }),

  licenseReinstated: (d) => ({
    subject: `License ${d.licenseId || ''} has been reinstated`.replace('  ', ' '),
    ...layout(d, 'Your license has been reinstated', [
      'The administrator has reinstated this license.',
      '',
      ['License', d.licenseId || '(see the transaction)'],
      ['Vehicle', d.pseudonym],
      ['Network', d.network],
      ['Reinstated', when(d.timestamp)],
    ]),
  }),
};
