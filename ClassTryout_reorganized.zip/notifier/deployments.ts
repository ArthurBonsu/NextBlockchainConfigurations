// notifier/deployments.ts
// Finds the contract addresses (and the block to start scanning from) for a chain.
// It reads the same two files as the front end: shared/deployments.json (public chains, keyed by chain id)
// and shared/deployments.local.json (local chains).

import fs from 'fs';
import path from 'path';
import { root } from '../server/config';
import { contracts } from '../shared/contracts.json';
import type { Deployment } from '../blockchain/types';

function readJson(relativePath: string): Record<string, any> {
  try {
    return JSON.parse(fs.readFileSync(path.join(root, relativePath), 'utf8'));
  } catch {
    return {};
  }
}

// A deployment is only usable when every contract has an address.
function completeOrNothing(deployment: any): Deployment | undefined {
  const hasEveryContract = deployment && contracts.every((name) => deployment[name] && deployment[name].address);

  return hasEveryContract ? deployment : undefined;
}

export function deploymentFor(chain: { chainId: number }): Deployment | undefined {
  const publicDeployment = completeOrNothing(readJson('shared/deployments.json')[String(chain.chainId)]);

  if (publicDeployment) return publicDeployment;

  const local = readJson('shared/deployments.local.json');
  const forThisChain = Object.values(local).find((entry: any) => entry && typeof entry === 'object' && entry.chainId === chain.chainId);

  return completeOrNothing(forThisChain);
}
