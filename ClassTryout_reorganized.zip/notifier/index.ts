// notifier/index.ts
// The email watcher. Run:
//
//   yarn notify           keep running, and check every NOTIFY_POLL_SECONDS (default 20)
//   yarn notify:once      one pass, then stop (for a scheduled job)
//   yarn notify:status    show what the watcher knows, then stop

import '../server/config';
import { chains } from '../shared/chains.json';
import type { AppNetwork } from '../blockchain/types';
import { deploymentFor } from './deployments';
import * as state from './state';
import { tick } from './watcher';

const args = new Set(process.argv.slice(2));

function log(message: string): void {
  console.log(`${new Date().toISOString()} ${message}`);
}

// Which chains to watch: the ones in NOTIFY_CHAINS, or else every chain where the contracts are deployed.
function watchedChains(): AppNetwork[] {
  const wanted = (process.env.NOTIFY_CHAINS || '')
    .split(',')
    .map((text) => text.trim())
    .filter(Boolean)
    .map(Number);

  return (chains as AppNetwork[]).filter((chain) => {
    if (wanted.length) return wanted.includes(chain.chainId);
    if (chain.kind === 'Local') return process.env.NOTIFY_LOCAL === 'true';

    return !!deploymentFor(chain);
  });
}

function showStatus(): void {
  const saved = state.load();
  const counts: Record<string, number> = {};

  for (const event of Object.values(saved.events)) counts[event.status] = (counts[event.status] || 0) + 1;

  console.log('State file:', state.stateFile());
  console.log('Backend:', process.env.NOTIFY_BACKEND || 'firebase', '| transport:', process.env.NOTIFY_TRANSPORT || 'smtp');
  console.log('Chains watched:', watchedChains().map((chain) => `${chain.name} (${chain.chainId})`).join(', ') || 'none');
  console.log('Cursors:', JSON.stringify(saved.cursors));
  console.log('Events handled by outcome:', JSON.stringify(counts));
  console.log('Waiting to retry:', Object.keys(saved.pending).length);
}

async function runOnce(): Promise<void> {
  const saved = state.load();

  // A dry run must leave no trace. Otherwise it would mark events "handled" and a real run would skip them.
  const save = process.env.NOTIFY_DRY_RUN === 'true' ? () => {} : () => state.save(saved);

  for (const chain of watchedChains()) {
    try {
      const result = await tick(chain, saved, save, log);

      if (result.skipped) log(`${chain.key}: ${result.skipped}`);
    } catch (error: any) {
      log(`${chain.key}: ${error.message}`); // one bad RPC server must not stop the other chains
    }
  }
}

async function main(): Promise<void> {
  if (args.has('--status')) return showStatus();

  if (!watchedChains().length) {
    log('No chain to watch. Deploy the contracts first, or set NOTIFY_CHAINS (and NOTIFY_LOCAL=true for Ganache).');

    if (args.has('--once')) return;
  }

  if (args.has('--once')) return runOnce();

  log(`Watching: ${watchedChains().map((chain) => chain.name).join(', ')}`);

  const everyMilliseconds = Number(process.env.NOTIFY_POLL_SECONDS || 20) * 1000;

  for (;;) {
    await runOnce();
    await new Promise((resolveWait) => setTimeout(resolveWait, everyMilliseconds));
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
