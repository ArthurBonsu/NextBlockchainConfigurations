// notifier/types.ts
// The shapes the email watcher passes around.

import type { Web3 } from 'web3';
import type { AppNetwork } from '../blockchain/types';
import type { createVehicleRegistryContract } from '../blockchain/contracts/VehicleRegistry/VehicleRegistryContract';
import type { createRevocationManagerContract } from '../blockchain/contracts/RevocationManager/RevocationManagerContract';
import type { createLicenseRegistryContract } from '../blockchain/contracts/LicenseRegistry/LicenseRegistryContract';

export type RegistryContract = ReturnType<typeof createVehicleRegistryContract>;
export type RevocationContract = ReturnType<typeof createRevocationManagerContract>;
export type LicenseContract = ReturnType<typeof createLicenseRegistryContract>;

// One line of shared/notifications.json: which on-chain event sends which email.
export interface NotificationRule {
  id: string;
  contract: string;
  event: string;
  timestampArg: string;
}

// An event read from the chain, with its numbers turned into plain strings.
export interface ChainEvent {
  event: string;
  args: Record<string, any>;
  txHash: string;
  blockNumber: number;
  logIndex: number;
}

// What to send and to whom. `data` fills the email template.
export interface EmailPayload {
  id: string;
  wallet: string;
  template: string;
  data: Record<string, any>;
}

export interface PendingSend {
  payload: EmailPayload;
  attempts: number;
  nextAt: number;
  error: string;
}

// The watcher's memory. It is saved in one JSON file (see state.ts).
export interface NotifierState {
  cursors: Record<string, number>; // last block fully processed, per chain
  events: Record<string, { status: string; id?: string; wallet?: string; error?: string }>; // events already handled
  pending: Record<string, PendingSend>; // sends that failed and will be retried
  owners: Record<string, string>; // "chainId:pseudonym" -> owner wallet
  licenses: Record<string, { id: string; vehicle: string }>; // "chainId:hash" -> licence id and vehicle
  deployed?: Record<string, string>; // which deployment each cursor belongs to
}

// Everything the watcher needs while it handles one chain.
export interface WatchContext {
  web3: Web3;
  chain: AppNetwork;
  state: NotifierState;
  save: () => void;
  log: (message: string) => void;
  contracts: Record<string, any>;
  c: {
    registry: RegistryContract;
    revocation: RevocationContract;
    license: LicenseContract;
  };
}

export type ResolveResult =
  | { skip: string }
  | { wallet: string; template: string; data: Record<string, any> };
