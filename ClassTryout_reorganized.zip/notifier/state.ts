// notifier/state.ts
// The watcher's memory, kept in one JSON file (NOTIFY_STATE_FILE, by default notifier/data/state.json). It holds:
//
//   cursors    the last block fully processed, per chain
//   events     one entry per event already handled (so nothing is sent twice), WITHOUT any email address
//   pending    sends that failed and will be tried again
//   owners     pseudonym -> owner wallet, learnt from VehicleRegistered events
//   licenses   hash of the licence id -> { id, vehicle }, learnt from LicenseIssued events
//
// It must survive restarts (put it on a disk that stays). Delete it to scan again from the deployment block.
// Emails would then be sent again, except those older than NOTIFY_MAX_AGE_HOURS.

import fs from 'fs';
import path from 'path';
import { root } from '../server/config';
import type { NotifierState } from './types';

export function stateFile(): string {
  return process.env.NOTIFY_STATE_FILE || path.join(root, 'notifier', 'data', 'state.json');
}

function emptyState(): NotifierState {
  return { cursors: {}, events: {}, pending: {}, owners: {}, licenses: {} };
}

export function load(): NotifierState {
  try {
    const saved = JSON.parse(fs.readFileSync(stateFile(), 'utf8'));

    return { ...emptyState(), ...saved };
  } catch {
    return emptyState();
  }
}

// Write to a temporary file, then rename it, so a crash in the middle can never leave a half-written state file.
export function save(state: NotifierState): void {
  const file = stateFile();

  fs.mkdirSync(path.dirname(file), { recursive: true });

  const temporaryFile = file + '.tmp';

  fs.writeFileSync(temporaryFile, JSON.stringify(state, null, 2));
  fs.renameSync(temporaryFile, file);
}
