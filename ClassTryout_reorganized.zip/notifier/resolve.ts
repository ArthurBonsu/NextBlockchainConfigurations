// notifier/resolve.ts
// Turns one decoded blockchain event into "who gets which email, with what details".
//
// Why this is not trivial: an event carries only what the contract chose to log.
//   - VehicleRegistered and LicenseIssued log `string indexed` fields, so the log holds only a HASH of the pseudonym or
//     licence id. We recover the readable text from the transaction input (which holds the real arguments) and check it
//     against the hash. If that fails, we read the contract.
//   - LicenseIssued's `owner` is the wallet that SENT the issue transaction, not the vehicle's owner. The email goes to
//     the owner of the vehicle (looked up from the registry), and names the issuing wallet.

import { VehicleRegistryAbi } from '../shared/abi/VehicleRegistry';
import { LicenseRegistryAbi } from '../shared/abi/LicenseRegistry';
import type { ChainEvent, NotificationRule, ResolveResult, WatchContext } from './types';

const ABIS: Record<string, readonly any[]> = {
  VehicleRegistry: VehicleRegistryAbi,
  LicenseRegistry: LicenseRegistryAbi,
};

const ZERO = '0x0000000000000000000000000000000000000000';

// Decodes the arguments of a transaction that was sent straight to one of our contracts.
// Returns null if it was not (for example it went through a multisig wallet), so callers can try other sources.
async function txArgs(ctx: WatchContext, txHash: string, contractName: string, functionName: string): Promise<Record<string, any> | null> {
  try {
    const tx = await ctx.web3.eth.getTransaction(txHash);
    const fn: any = ABIS[contractName].find((item) => item.type === 'function' && item.name === functionName);
    const selector = ctx.web3.eth.abi.encodeFunctionSignature(fn);
    const input = String(tx.input || (tx as any).data || '');

    if (!input.startsWith(selector)) return null;

    return ctx.web3.eth.abi.decodeParameters(fn.inputs, '0x' + input.slice(10)) as Record<string, any>;
  } catch {
    return null;
  }
}

function hashOf(ctx: WatchContext, text: string): string {
  return ctx.web3.utils.keccak256(text);
}

function matches(ctx: WatchContext, text: unknown, hash: unknown): boolean {
  return typeof text === 'string' && text.length > 0 && hashOf(ctx, text) === String(hash).toLowerCase();
}

async function ownerOfVehicle(ctx: WatchContext, pseudonym: string): Promise<string | null> {
  const known = ctx.state.owners[`${ctx.chain.chainId}:${pseudonym}`];

  if (known) return known;

  try {
    const vehicle: any = await ctx.c.registry.methods.getVehicle(pseudonym).call();

    if (vehicle.owner && vehicle.owner !== ZERO) return vehicle.owner;
  } catch {
    // The vehicle is not on this chain.
  }

  return null;
}

async function readPseudonym(ctx: WatchContext, event: ChainEvent): Promise<string | null> {
  const hash = event.args.pseudonym;

  const fromTransaction = await txArgs(ctx, event.txHash, 'VehicleRegistry', 'registerVehicle');

  if (fromTransaction && matches(ctx, fromTransaction._pseudonym, hash)) return fromTransaction._pseudonym;

  try {
    const current: any = await ctx.c.registry.methods.getPseudonymByOwner(event.args.owner).call();

    if (matches(ctx, current, hash)) return current;
  } catch {
    // Not found: give up on this source.
  }

  return null;
}

async function readLicenseId(ctx: WatchContext, event: ChainEvent): Promise<string | null> {
  const hash = event.args.licenseId;
  const functionName = { LicenseIssued: 'issueLicense', LicenseRevoked: 'revokeLicense', LicenseReinstated: 'reinstateLicense' }[event.event] as string;

  const fromTransaction = await txArgs(ctx, event.txHash, 'LicenseRegistry', functionName);

  if (fromTransaction && matches(ctx, fromTransaction._licenseId, hash)) return fromTransaction._licenseId;

  if (event.args.vehiclePseudonym) {
    try {
      const latest: any = await ctx.c.license.methods.getLicenseByVehicle(event.args.vehiclePseudonym).call();

      if (matches(ctx, latest, hash)) return latest;
    } catch {
      // Not found: give up on this source.
    }
  }

  return null;
}

// Learn readable names from events that carry them.
// It is called for EVERY event, even ones we will not email about, so later events that carry only a hash can still be understood.
export async function learn(ctx: WatchContext, event: ChainEvent): Promise<void> {
  const chainId = ctx.chain.chainId;

  if (event.event === 'VehicleRegistered') {
    const pseudonym = await readPseudonym(ctx, event);

    if (pseudonym) ctx.state.owners[`${chainId}:${pseudonym}`] = event.args.owner;
  }

  if (event.event === 'LicenseIssued') {
    const id = await readLicenseId(ctx, event);

    if (id) ctx.state.licenses[`${chainId}:${String(event.args.licenseId).toLowerCase()}`] = { id, vehicle: event.args.vehiclePseudonym };
  }
}

// Decides who gets which email for one event: { skip: 'reason' } or { wallet, template, data }.
export async function resolve(ctx: WatchContext, rule: NotificationRule, event: ChainEvent): Promise<ResolveResult> {
  const a = event.args;

  const base = {
    network: ctx.chain.name,
    explorerUrl: ctx.chain.explorer ? `${ctx.chain.explorer}/tx/${event.txHash}` : '',
    appUrl: process.env.APP_URL || '',
  };

  switch (rule.id) {
    case 'registration': {
      const pseudonym = (await readPseudonym(ctx, event)) || '(see the transaction)';

      return { wallet: a.owner, template: 'registration', data: { ...base, wallet: a.owner, pseudonym, timestamp: a.timestamp } };
    }

    case 'revocation':
    case 'reinstatement': {
      const wallet = await ownerOfVehicle(ctx, a.pseudonym);

      if (!wallet) return { skip: 'owner-unknown' };

      return { wallet, template: rule.id, data: { ...base, wallet, pseudonym: a.pseudonym, reason: a.reason, timestamp: a.timestamp } };
    }

    case 'licenseIssued': {
      const wallet = await ownerOfVehicle(ctx, a.vehiclePseudonym);

      if (!wallet) return { skip: 'owner-unknown' };

      const licenseId = (await readLicenseId(ctx, event)) || '';

      return {
        wallet,
        template: 'licenseIssued',
        data: {
          ...base,
          wallet,
          pseudonym: a.vehiclePseudonym,
          licenseId,
          licenseType: a.licenseType,
          expiryTime: a.expiryTime,
          issuer: a.owner,
        },
      };
    }

    case 'licenseRevoked':
    case 'licenseReinstated': {
      const cached = ctx.state.licenses[`${ctx.chain.chainId}:${String(a.licenseId).toLowerCase()}`];
      const licenseId = cached ? cached.id : await readLicenseId(ctx, event);

      let vehicle: string | undefined = a.vehiclePseudonym || (cached && cached.vehicle);

      if (!vehicle && licenseId) {
        try {
          const found: any = await ctx.c.license.methods.getLicense(licenseId).call();

          vehicle = found.vehiclePseudonym;
        } catch {
          // Not found: we cannot tell whose licence this is.
        }
      }

      if (!vehicle) return { skip: 'license-unknown' };

      const wallet = await ownerOfVehicle(ctx, vehicle);

      if (!wallet) return { skip: 'owner-unknown' };

      return { wallet, template: rule.id, data: { ...base, wallet, pseudonym: vehicle, licenseId: licenseId || '', timestamp: a.timestamp } };
    }

    default:
      return { skip: 'no-handler' };
  }
}
