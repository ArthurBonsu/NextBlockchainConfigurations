// notifier/watcher.ts
// Reads new contract events from one chain and sends the emails listed in shared/notifications.json.
//
// What it promises (and what it does not), so nobody is surprised:
//   - Each event is handled once. Its key is chainId:txHash:logIndex, recorded in the state file.
//   - Delivery is "at least once": if the process dies between sending and recording, that one email may repeat.
//   - Events are read only when they are NOTIFY_CONFIRMATIONS blocks deep, so a chain reorganisation cannot cause
//     a notification about something that then vanishes.
//   - A failed send is tried again with growing waits (up to 8 attempts), without blocking newer events.
//   - Events older than NOTIFY_MAX_AGE_HOURS (default 72) are recorded but not emailed, so starting the watcher on an
//     old deployment does not mail people about last month. 0 means no limit.

import { Web3 } from 'web3';
import { rpcUrl } from '../shared/rpc';
import { notifications } from '../shared/notifications.json';
import { createLicenseRegistryContract } from '../blockchain/contracts/LicenseRegistry/LicenseRegistryContract';
import { createRevocationManagerContract } from '../blockchain/contracts/RevocationManager/RevocationManagerContract';
import { createVehicleRegistryContract } from '../blockchain/contracts/VehicleRegistry/VehicleRegistryContract';
import { emailForWallet } from '../server/walletLinks';
import type { AppNetwork } from '../blockchain/types';
import { deploymentFor } from './deployments';
import { resolve, learn } from './resolve';
import { templates } from './templates';
import * as mailer from './mailer';
import type { ChainEvent, EmailPayload, NotificationRule, NotifierState, WatchContext } from './types';

const MAX_ATTEMPTS = 8;
const CONTRACT_NAMES = ['VehicleRegistry', 'RevocationManager', 'LicenseRegistry'] as const;

const rules = notifications as NotificationRule[];

function short(value: unknown): string {
  return `${String(value).slice(0, 6)}…${String(value).slice(-4)}`;
}

// web3 returns BigInt for numbers. We turn everything into plain strings so the state file and the templates stay simple.
function plainArgs(returnValues: Record<string, any>): Record<string, any> {
  const out: Record<string, any> = {};

  for (const [key, value] of Object.entries(returnValues)) {
    const isNumberedCopy = /^\d+$/.test(key) || key === '__length__';

    if (!isNumberedCopy) out[key] = typeof value === 'bigint' ? value.toString() : value;
  }

  return out;
}

// ---------------------------------------------------------------- sending one email
async function deliver(payload: EmailPayload, key: string, log: (message: string) => void): Promise<{ status: string }> {
  const recipient = await emailForWallet(payload.wallet);

  if (!('email' in recipient)) return { status: `skipped:${recipient.reason}` };

  const message = templates[payload.template](payload.data);

  if (process.env.NOTIFY_DRY_RUN === 'true') {
    log(`[dry-run] would send "${message.subject}" for wallet ${short(payload.wallet)}`);
    return { status: 'dry-run' };
  }

  await mailer.send({ to: recipient.email, ...message, key });

  return { status: 'sent' };
}

async function attempt(ctx: WatchContext, key: string, payload: EmailPayload, attempts: number): Promise<void> {
  const { state, log } = ctx;

  try {
    const outcome = await deliver(payload, key, log);

    state.events[key] = { status: outcome.status, id: payload.id, wallet: payload.wallet };
    delete state.pending[key];

    log(`${payload.id} -> wallet ${short(payload.wallet)}: ${outcome.status}`);
  } catch (error: any) {
    const attemptNumber = attempts + 1;

    if (attemptNumber >= MAX_ATTEMPTS) {
      state.events[key] = { status: 'failed', id: payload.id, wallet: payload.wallet, error: String(error.message).slice(0, 200) };
      delete state.pending[key];

      log(`${payload.id} -> wallet ${short(payload.wallet)}: GAVE UP after ${attemptNumber} attempts (${error.message})`);
    } else {
      const waitSeconds = Math.min(30 * 2 ** attemptNumber, 3600);

      state.pending[key] = { payload, attempts: attemptNumber, nextAt: Date.now() + waitSeconds * 1000, error: String(error.message).slice(0, 200) };

      log(`${payload.id} -> wallet ${short(payload.wallet)}: send failed (${error.message}); retry in ${waitSeconds}s`);
    }
  }
}

async function retryPending(ctx: WatchContext): Promise<void> {
  for (const [key, pending] of Object.entries(ctx.state.pending)) {
    const belongsToOtherChain = !key.startsWith(`${ctx.chain.chainId}:`);

    if (belongsToOtherChain || pending.nextAt > Date.now()) continue;

    await attempt(ctx, key, pending.payload, pending.attempts);
    ctx.save();
  }
}

// ---------------------------------------------------------------- handling one event
async function handleEvent(ctx: WatchContext, event: ChainEvent, rule: NotificationRule): Promise<void> {
  const { state, log } = ctx;
  const key = `${ctx.chain.chainId}:${event.txHash}:${event.logIndex}`;

  if (state.events[key]) return;

  await learn(ctx, event);

  const maxAgeHours = Number(process.env.NOTIFY_MAX_AGE_HOURS ?? 72);
  const happenedAt = Number(event.args[rule.timestampArg]);
  const isTooOld = maxAgeHours > 0 && happenedAt && Date.now() / 1000 - happenedAt > maxAgeHours * 3600;

  if (isTooOld) {
    state.events[key] = { status: 'skipped:too-old', id: rule.id };
    return;
  }

  const result = await resolve(ctx, rule, event);

  if ('skip' in result) {
    state.events[key] = { status: `skipped:${result.skip}`, id: rule.id };
    log(`${rule.id} ${short(event.txHash)} skipped (${result.skip})`);
    return;
  }

  await attempt(ctx, key, { id: rule.id, wallet: result.wallet, template: result.template, data: result.data }, 0);
}

// ---------------------------------------------------------------- reading events
// Reads the events in [from, to]. If the RPC server says the range is too big, the range is halved.
async function readRange(ctx: WatchContext, from: number, to: number): Promise<ChainEvent[]> {
  try {
    const found: ChainEvent[] = [];

    for (const [name, contract] of Object.entries(ctx.contracts)) {
      const wanted = new Set(rules.filter((rule) => rule.contract === name).map((rule) => rule.event));
      const events = await contract.getPastEvents('allEvents', { fromBlock: from, toBlock: to });

      for (const event of events) {
        if (!wanted.has(event.event)) continue;

        found.push({
          event: event.event,
          args: plainArgs(event.returnValues),
          txHash: event.transactionHash,
          blockNumber: Number(event.blockNumber),
          logIndex: Number(event.logIndex),
        });
      }
    }

    return found.sort((x, y) => x.blockNumber - y.blockNumber || x.logIndex - y.logIndex);
  } catch (error) {
    if (to > from) {
      const middle = from + Math.floor((to - from) / 2);

      return [...(await readRange(ctx, from, middle)), ...(await readRange(ctx, middle + 1, to))];
    }

    throw error;
  }
}

function openContracts(web3: Web3, deployment: Record<string, { address: string }>) {
  const registry = createVehicleRegistryContract(web3, deployment.VehicleRegistry.address);
  const revocation = createRevocationManagerContract(web3, deployment.RevocationManager.address);
  const license = createLicenseRegistryContract(web3, deployment.LicenseRegistry.address);

  return {
    byName: { VehicleRegistry: registry, RevocationManager: revocation, LicenseRegistry: license },
    c: { registry, revocation, license },
  };
}

// ---------------------------------------------------------------- one pass over one chain. Safe to call again and again.
export async function tick(chain: AppNetwork, state: NotifierState, save: () => void, log: (message: string) => void) {
  const deployment = deploymentFor(chain);

  if (!deployment) return { skipped: 'not deployed' };

  const web3 = new Web3(rpcUrl(chain));
  const actualChainId = Number(await web3.eth.getChainId());

  if (actualChainId !== chain.chainId) {
    throw new Error(`RPC for ${chain.key} reports chain ${actualChainId}, expected ${chain.chainId}. Check RPC_URL_${chain.key.toUpperCase()}.`);
  }

  const opened = openContracts(web3, deployment);
  const ctx: WatchContext = { web3, chain, state, save, log, contracts: opened.byName, c: opened.c };

  const startBlock = Math.min(...CONTRACT_NAMES.map((name) => Number(deployment[name].startBlock || 0)));
  const deploymentKey = CONTRACT_NAMES.map((name) => deployment[name].address.toLowerCase()).join(',');
  const chainKey = String(chain.chainId);

  state.deployed = state.deployed || {};

  let cursor: number | undefined = state.cursors[chainKey];
  const head = Number(await web3.eth.getBlockNumber());

  // A new deployment on this chain (or a local chain that was reset): start again from its first block.
  if (cursor === undefined || state.deployed[chainKey] !== deploymentKey || cursor > head) {
    if (cursor !== undefined) log(`chain ${chain.key}: deployment changed or chain was reset, rescanning from block ${startBlock}`);

    cursor = Math.max(startBlock - 1, -1);
    state.deployed[chainKey] = deploymentKey;
    state.cursors[chainKey] = cursor;
  }

  const confirmations = chain.kind === 'Local' ? 0 : Number(process.env.NOTIFY_CONFIRMATIONS ?? 5);
  const safeHead = head - confirmations;
  const maxRange = Number(process.env.NOTIFY_MAX_BLOCK_RANGE || 1000);

  let handled = 0;

  while (cursor < safeHead) {
    const from = cursor + 1;
    const to = Math.min(safeHead, from + maxRange - 1);

    for (const event of await readRange(ctx, from, to)) {
      const rule = rules.find((item) => item.event === event.event) as NotificationRule;

      await handleEvent(ctx, event, rule);
      handled++;
    }

    cursor = to;
    state.cursors[chainKey] = cursor;
    save();
  }

  await retryPending(ctx);
  save();

  return { head, cursor, handled };
}
