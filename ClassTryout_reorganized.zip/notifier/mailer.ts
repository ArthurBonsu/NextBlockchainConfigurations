// notifier/mailer.ts
// Sends one email. NOTIFY_TRANSPORT picks how:
//
//   smtp    (the default) real delivery through EMAIL_SERVER_* (Gmail app password, SendGrid, Mailgun, Amazon SES, ...)
//   outbox  writes each email as a JSON file in notifier/data/outbox/ (local testing, nothing leaves the computer)
//   log     prints a one-line note only

import fs from 'fs';
import path from 'path';
import nodemailer from 'nodemailer';
import type { Transporter } from 'nodemailer';
import { root } from '../server/config';

let transporter: Transporter | undefined;

function smtp(): Transporter {
  if (transporter) return transporter;

  const { EMAIL_SERVER_HOST, EMAIL_SERVER_PORT, EMAIL_SERVER_USER, EMAIL_SERVER_PASSWORD, EMAIL_SERVER_SECURE } = process.env;

  if (!EMAIL_SERVER_HOST) {
    throw new Error('EMAIL_SERVER_HOST is not set. See .env.local.example (or use NOTIFY_TRANSPORT=outbox to test locally).');
  }

  const port = Number(EMAIL_SERVER_PORT || 587);

  transporter = nodemailer.createTransport({
    host: EMAIL_SERVER_HOST,
    port,
    secure: EMAIL_SERVER_SECURE ? EMAIL_SERVER_SECURE === 'true' : port === 465,
    auth: EMAIL_SERVER_USER ? { user: EMAIL_SERVER_USER, pass: EMAIL_SERVER_PASSWORD } : undefined,
    tls: process.env.EMAIL_SERVER_INSECURE_TLS === 'true' ? { rejectUnauthorized: false } : undefined,
  });

  return transporter;
}

export interface Email {
  to: string;
  subject: string;
  text: string;
  html: string;
  key: string; // identifies the event, so a repeated email can be told apart
}

export async function send({ to, subject, text, html, key }: Email): Promise<void> {
  const from = process.env.EMAIL_FROM || 'ClassTryout <no-reply@localhost>';
  const mode = (process.env.NOTIFY_TRANSPORT || 'smtp').toLowerCase();

  if (mode === 'log') {
    console.log(`[mail:log] to=<hidden> subject="${subject}"`);
    return;
  }

  if (mode === 'outbox') {
    const folder = path.join(root, 'notifier', 'data', 'outbox');

    fs.mkdirSync(folder, { recursive: true });

    const file = path.join(folder, key.replace(/[^a-zA-Z0-9._-]/g, '_') + '.json');

    fs.writeFileSync(file, JSON.stringify({ from, to, subject, text, html }, null, 2));
    return;
  }

  await smtp().sendMail({ from, to, subject, text, html, headers: { 'X-ClassTryout-Event': key } });
}
