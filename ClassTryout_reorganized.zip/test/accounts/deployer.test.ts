// Which wallet signs which kind of network (scripts/deployerWallet.ts). Pure: no network, and no keys of any value.
import test from 'node:test';
import assert from 'node:assert/strict';
import { walletFor } from '../../scripts/deployerWallet';
import type { ChainInfo } from '../../scripts/deployerWallet';

const TEST_CHAIN: ChainInfo = { key: 'sepolia', name: 'Sepolia', chainId: 11155111, testnet: true };
const MAIN_CHAIN: ChainInfo = { key: 'mainnet', name: 'Ethereum Mainnet', chainId: 1, testnet: false };

const KEY_ONE = '11'.repeat(32);
const KEY_TWO = '22'.repeat(32);
const WORDS = 'test test test test test test test test test test test junk';

// The signing options are either { privateKeys } or { mnemonic }; these read them without casts in every test.
const privateKeysOf = (options: object) => ('privateKeys' in options ? (options as { privateKeys: string[] }).privateKeys : []);
const hasMnemonic = (options: object) => 'mnemonic' in options;

test('a test network uses TESTNET_PRIVATE_KEY', () => {
  const wallet = walletFor(TEST_CHAIN, { TESTNET_PRIVATE_KEY: '0x' + KEY_ONE });

  assert.deepEqual(wallet.options, { privateKeys: [KEY_ONE] });
  assert.equal(wallet.scope, 'testnet');
  assert.equal(wallet.source, 'TESTNET_PRIVATE_KEY');
});

test('the older PRIVATE_KEY / MNEMONIC names still work for test networks', () => {
  assert.equal(walletFor(TEST_CHAIN, { PRIVATE_KEY: KEY_ONE }).source, 'PRIVATE_KEY');
  assert.equal(walletFor(TEST_CHAIN, { MNEMONIC: WORDS }).source, 'MNEMONIC');
});

test('TESTNET_ wins over the older names', () => {
  const wallet = walletFor(TEST_CHAIN, { TESTNET_PRIVATE_KEY: KEY_ONE, PRIVATE_KEY: KEY_TWO });

  assert.equal(privateKeysOf(wallet.options)[0], KEY_ONE);
});

test('both a mnemonic and a key for test networks: the mnemonic is used, with a warning', () => {
  const wallet = walletFor(TEST_CHAIN, { MNEMONIC: WORDS, PRIVATE_KEY: KEY_ONE });

  assert.ok(hasMnemonic(wallet.options));
  assert.equal(privateKeysOf(wallet.options).length, 0);
  assert.match(wallet.warning || '', /using the mnemonic/);
});

test('no wallet at all gives a clear message', () => {
  assert.throws(() => walletFor(TEST_CHAIN, {}), /TESTNET_PRIVATE_KEY/);
});

test('empty values (as in the .env.local template) count as not set', () => {
  assert.throws(() => walletFor(TEST_CHAIN, { TESTNET_PRIVATE_KEY: '', MAINNET_PRIVATE_KEY: '' }), /TESTNET_PRIVATE_KEY/);
  assert.throws(() => walletFor(MAIN_CHAIN, { TESTNET_PRIVATE_KEY: KEY_ONE, MAINNET_PRIVATE_KEY: '' }), /real-money network/);
});

test('real money needs MAINNET_*: the test wallet is never a fall-back', () => {
  assert.throws(() => walletFor(MAIN_CHAIN, { TESTNET_PRIVATE_KEY: KEY_ONE, PRIVATE_KEY: KEY_ONE }), /real-money network/);

  const wallet = walletFor(MAIN_CHAIN, { MAINNET_PRIVATE_KEY: KEY_TWO, TESTNET_PRIVATE_KEY: KEY_ONE });

  assert.equal(wallet.scope, 'mainnet');
  assert.equal(privateKeysOf(wallet.options)[0], KEY_TWO);
});

test('the mainnet wallet may not be the test wallet (same key, with or without 0x, any case)', () => {
  assert.throws(() => walletFor(MAIN_CHAIN, { MAINNET_PRIVATE_KEY: KEY_ONE, TESTNET_PRIVATE_KEY: '0x' + KEY_ONE.toUpperCase() }), /same secret/);
  assert.throws(() => walletFor(MAIN_CHAIN, { MAINNET_MNEMONIC: WORDS, MNEMONIC: WORDS.toUpperCase() }), /same secret/);
});

test('mainnet: both a mnemonic and a key is refused', () => {
  assert.throws(() => walletFor(MAIN_CHAIN, { MAINNET_MNEMONIC: WORDS, MAINNET_PRIVATE_KEY: KEY_ONE }), /only one/);
});

test('malformed secrets are caught before anything is sent', () => {
  assert.throws(() => walletFor(TEST_CHAIN, { TESTNET_PRIVATE_KEY: 'abc' }), /64 hex/);
  assert.throws(() => walletFor(MAIN_CHAIN, { MAINNET_MNEMONIC: 'one two three' }), /12, 15/);
});

test('error messages never contain the secret', () => {
  assert.throws(
    () => walletFor(MAIN_CHAIN, { MAINNET_PRIVATE_KEY: KEY_ONE, TESTNET_PRIVATE_KEY: KEY_ONE }),
    (error: Error) => !error.message.includes(KEY_ONE)
  );
  assert.throws(
    () => walletFor(TEST_CHAIN, { TESTNET_PRIVATE_KEY: KEY_TWO + 'zz' }),
    (error: Error) => !error.message.includes(KEY_TWO)
  );
});
