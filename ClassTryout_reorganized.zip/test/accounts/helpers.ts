// Shared set-up for the account tests: a throwaway file store, the mock SMS outbox, dev (fake-token) sign-in.
import fs from 'fs';
import os from 'os';
import path from 'path';
import type { AuthenticatedUser } from '@/server/auth';
import { lastTo } from '@/server/sms';
import { ensureUser, saveConsents, saveProfile, saveAddress } from '@/server/users';
import { startPhoneVerification, confirmPhoneVerification } from '@/server/phone';

export function setup(name: string): string {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), `ct-${name}-`));

  Object.assign(process.env, {
    NODE_ENV: 'test',
    STORE_BACKEND: 'file',
    STORE_FILE: path.join(dir, 'store.json'),
    SMS_PROVIDER: 'mock',
    SMS_OUTBOX_FILE: path.join(dir, 'sms.jsonl'),
    NOTIFY_BACKEND: 'dev',
  });

  return dir;
}

// A user as the server sees them after verifying a token.
export const auth = (uid: string, email = `${uid}@example.com`, emailVerified = true): AuthenticatedUser => ({
  uid,
  email,
  emailVerified,
  provider: 'password',
});

// Reads the code out of the mock SMS outbox (the API never returns it).
export function lastCode(phone: string): string {
  const message = lastTo(phone);
  const match = message && /(\d{6}) is your/.exec(message.text);

  return match ? match[1] : '';
}

export const ADDRESS = { regionCode: 'GAR', districtId: 'GAR-accra', city: 'Accra', suburb: 'East Legon' };
export const PROFILE = { givenName: 'Ama', familyName: 'Mensah', dob: '1995-04-12', gender: 'female', nationality: 'GH' };

export async function complete(uid: string, phone = '0241234567'): Promise<void> {
  await ensureUser(auth(uid));
  await saveConsents(uid, { terms: true, privacy: true, sms: true }, '1.2.3.4');
  await saveProfile(uid, PROFILE);
  await startPhoneVerification(uid, phone, '1.2.3.4');
  await confirmPhoneVerification(uid, lastCode('+233' + phone.replace(/^0/, '')), '1.2.3.4');
  await saveAddress(uid, ADDRESS);
}
