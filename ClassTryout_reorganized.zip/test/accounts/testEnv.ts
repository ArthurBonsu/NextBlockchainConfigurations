// Imported FIRST by a test file: it points the server code at a throwaway file store, the mock SMS outbox and dev
// (fake-token) sign-in before any server module reads its settings.
import { setup } from './helpers';

setup('unit');
