// Unit tests for sign-in/onboarding logic. No network, no Firebase: a file store, the mock SMS outbox, fake accounts.
//   yarn test:accounts
import './testEnv'; // must stay first: it sets up the throwaway store before the server code loads
import test from 'node:test';
import assert from 'node:assert/strict';
import * as h from './helpers';
import * as users from '@/server/users';
import * as otp from '@/server/phone';
import * as identity from '@/server/identity';
import type { CheckOutcome } from '@/server/identity';
import { roles } from '@/server/auth';
import { normaliseGhPhone } from '@/server/phone';
import { validateAddress, normKey } from '@/server/locations';
import { store, requiredIndex } from '@/server/database';
import { redact } from '@/server/security';

const rejects = (promise: Promise<unknown>, code?: string) =>
  assert.rejects(promise, (error: { code?: string }) => (code ? error.code === code : true));

test("phone numbers: Ghana mobile formats normalise to +233", () => {
  for (const s of ["0241234567", "024 123 4567", "+233241234567", "233241234567", "00233 24 123 4567", "(024) 123-4567"]) assert.equal(normaliseGhPhone(s), "+233241234567");
  assert.equal(normaliseGhPhone("0551234567"), "+233551234567");
  for (const s of ["", "12345", "0301234567", "+441234567890", "02412345678", "abc"]) assert.throws(() => normaliseGhPhone(s), /Ghana mobile|Enter your/);
});

test("locations: region/district hierarchy is enforced and text is normalised", () => {
  const ok = validateAddress({ regionCode: "GAR", districtId: "GAR-accra", city: "Accra", suburb: "  East   Legon ", gpsAddress: "ga-543-1234" });
  assert.equal(ok.suburbKey, "east legon");
  assert.equal(ok.gpsAddress, "GA-543-1234");
  assert.equal(normKey("East Legon (Ext.)"), "east legon ext");
  assert.throws(() => validateAddress({ regionCode: "ASH", districtId: "GAR-accra", city: "x1", suburb: "y1" }), /not in the region/);
  assert.throws(() => validateAddress({ regionCode: "XXX", districtId: "GAR-accra", city: "Accra", suburb: "Osu" }), /region/);
  assert.throws(() => validateAddress({ regionCode: "GAR", districtId: "GAR-accra", city: "Accra", suburb: "Osu", gpsAddress: "nonsense" }), /GhanaPostGPS/);
  assert.throws(() => validateAddress({ regionCode: "GAR", districtId: "GAR-accra", city: "Accra", suburb: "<script>" }), /characters/);
  assert.throws(() => validateAddress({ regionCode: "GAR", districtId: "GAR-accra", city: "Accra", suburb: "Osu", lat: 51, lng: 0 }), /outside Ghana/);
});

test("new account starts as a citizen at level 0, onboarding incomplete, nothing but account:use allowed", async () => {
  const u = await users.ensureUser(h.auth("u1"));
  assert.equal(u.role, "citizen");
  assert.equal(u.identity.level, 0);
  const v = users.view(u);
  assert.equal(v.onboarding.complete, false);
  assert.equal(v.onboarding.next, "consent");
  assert.equal(v.capabilities["account:use"].allowed, true);
  assert.equal(v.capabilities["vehicle:register"].allowed, false);
  assert.equal(v.capabilities["vehicle:register"].reason, "onboarding");
});

test("role is never settable through onboarding input", async () => {
  await users.ensureUser(h.auth("u2"));
  await users.saveConsents("u2", { terms: true, privacy: true, sms: true }, "1.1.1.1");
  await users.saveProfile("u2", { ...h.PROFILE, role: "super_admin", status: "active", identity: { level: 2 } });
  const u = await users.requireUser("u2");
  assert.equal(u.role, "citizen");
  assert.equal(u.identity.level, 0);
});

test("consent needs all three agreements", async () => {
  await users.ensureUser(h.auth("u3"));
  await rejects(users.saveConsents("u3", { terms: true, privacy: true }, null), "invalid");
  await users.saveConsents("u3", { terms: true, privacy: true, sms: true }, null);
});

test("profile validation: names, date of birth, age", async () => {
  await users.ensureUser(h.auth("u4"));
  await rejects(users.saveProfile("u4", { ...h.PROFILE, givenName: "<b>" }), "invalid");
  await rejects(users.saveProfile("u4", { ...h.PROFILE, dob: "2999-01-01" }), "invalid");
  await rejects(users.saveProfile("u4", { ...h.PROFILE, dob: "2015-01-01" }), "invalid");
  await rejects(users.saveProfile("u4", { ...h.PROFILE, dob: "1995-02-30" }), "invalid");
  await rejects(users.saveProfile("u4", { ...h.PROFILE, gender: "robot" }), "invalid");
  await users.saveProfile("u4", { ...h.PROFILE, givenName: "Kofi", familyName: "O'Brien-Mensah" });
});

test("phone code: needs SMS consent, then verifies; code is stored hashed; wrong codes lock", async () => {
  await users.ensureUser(h.auth("p1"));
  await users.saveConsents("p1", { terms: true, privacy: true, sms: true }, null);
  const r = await otp.startPhoneVerification("p1", "0241110001", "9.9.9.1");
  assert.match(r.sentTo, /^\+233•+0001$/);
  const ch = await store().get("phoneChallenges", "p1");
  assert.ok(ch && ch.codeHmac && !JSON.stringify(ch).match(/"\d{6}"/), "code is not stored in clear");
  const code = h.lastCode("+233241110001");
  assert.match(code, /^\d{6}$/);
  const wrong = code === "000000" ? "111111" : "000000";
  await rejects(otp.confirmPhoneVerification("p1", wrong, null), "wrong_code");
  const u = await otp.confirmPhoneVerification("p1", code, null);
  assert.equal(u.phone.verified, true);
  assert.equal(u.phone.last4, "0001");
  assert.equal(await store().get("phoneChallenges", "p1"), null, "challenge consumed");
  await rejects(otp.confirmPhoneVerification("p1", code, null), "no_challenge");
});

test("phone code: no consent -> refused; resend too soon -> 429; 5 wrong guesses lock", async () => {
  await users.ensureUser(h.auth("p2"));
  await rejects(otp.startPhoneVerification("p2", "0241110002", null), "consent_required");
  await users.saveConsents("p2", { terms: true, privacy: true, sms: true }, null);
  await otp.startPhoneVerification("p2", "0241110002", null);
  await rejects(otp.startPhoneVerification("p2", "0241110002", null), "rate_limited");
  const real = h.lastCode("+233241110002");
  const bad = real === "123456" ? "654321" : "123456";
  for (let i = 0; i < 4; i++) await rejects(otp.confirmPhoneVerification("p2", bad, null), "wrong_code");
  await rejects(otp.confirmPhoneVerification("p2", bad, null), "locked");
  await rejects(otp.confirmPhoneVerification("p2", real, null), "locked"); // even the right code is refused once locked
});

test("phone code: expiry", async () => {
  await users.ensureUser(h.auth("p3"));
  await users.saveConsents("p3", { terms: true, privacy: true, sms: true }, null);
  await otp.startPhoneVerification("p3", "0241110003", null);
  await store().update("phoneChallenges", "p3", { expireAt: new Date(Date.now() - 1000).toISOString() });
  await rejects(otp.confirmPhoneVerification("p3", h.lastCode("+233241110003"), null), "expired");
});

test("phone: one verified number per account", async () => {
  for (const id of ["p4", "p5"]) {
    await users.ensureUser(h.auth(id));
    await users.saveConsents(id, { terms: true, privacy: true, sms: true }, null);
  }
  await otp.startPhoneVerification("p4", "0241110004", null);
  await otp.confirmPhoneVerification("p4", h.lastCode("+233241110004"), null);
  await rejects(otp.startPhoneVerification("p5", "0241110004", null), "phone_in_use");
});

test("phone: SMS provider failure -> 502, nothing left behind, code never leaks", async () => {
  await users.ensureUser(h.auth("p6"));
  await users.saveConsents("p6", { terms: true, privacy: true, sms: true }, null);
  process.env.SMS_MOCK_FAIL = "1";
  try {
    await rejects(otp.startPhoneVerification("p6", "0241110006", null), "sms_failed");
  } finally {
    delete process.env.SMS_MOCK_FAIL;
  }
  assert.equal(await store().get("phoneChallenges", "p6"), null);
});

test("full onboarding completes and unlocks level-0 capabilities only", async () => {
  await h.complete("c1", "0241110011");
  const u = await users.requireUser("c1");
  const v = users.view(u);
  assert.equal(v.onboarding.complete, true);
  assert.ok(u.onboarding.completedAt);
  assert.equal(v.capabilities["wallet:link"].allowed, true);
  assert.equal(v.capabilities["vehicle:register"].reason, "level");
  assert.equal(v.capabilities["license:issue"].reason, "role");
});

test("address suggestions: counted once per person and offered back by district", async () => {
  await h.complete("s1", "0241110021");
  await h.complete("s2", "0241110022");
  await users.saveAddress("s2", h.ADDRESS); // saving the same place again does not inflate the count
  const sub = await users.suburbSuggestions("GAR-accra");
  const el = sub.find((s) => s.suburb === "East Legon");
  assert.ok(el && el.count >= 2);
});

test("ID: Ghana Card format, same ID cannot belong to two accounts, hashed at rest", async () => {
  await h.complete("i1", "0241110031");
  await h.complete("i2", "0241110032");
  await rejects(identity.submitDocument("i1", { type: "ghana_card", number: "GHA-12345-0" }), "invalid");
  const d = await identity.submitDocument("i1", { type: "ghana_card", number: "gha123456789-0" }, null);
  assert.equal(d.last4, "7890");
  assert.equal(d.status, "pending_review", "no NIA connection: goes to a human, onboarding unaffected");
  assert.equal((await users.requireUser("i1")).identity.level, 1);
  const raw = JSON.stringify(await store().query("identityDocuments", { where: [["uid", "==", "i1"]], orderBy: [["createdAt", "desc"]] }));
  assert.ok(!raw.includes("123456789"), "full number not in plain text");
  await rejects(identity.submitDocument("i2", { type: "ghana_card", number: "GHA-123456789-0" }), "id_in_use");
  await rejects(identity.submitDocument("i1", { type: "ghana_card", number: "GHA-123456789-0" }), "already_added");
});

test("ID: passport needs country and expiry; NHIS and 'other' are accepted", async () => {
  await h.complete("i3", "0241110033");
  await rejects(identity.submitDocument("i3", { type: "passport", number: "G1234567" }), "invalid");
  await rejects(identity.submitDocument("i3", { type: "passport", number: "G1234567", country: "GH", expiry: "2001-01-01" }), "invalid");
  const exp = new Date(Date.now() + 5 * 365 * 864e5).toISOString().slice(0, 10);
  await identity.submitDocument("i3", { type: "passport", number: "G1234567", country: "gh", expiry: exp });
  await identity.submitDocument("i3", { type: "nhis", number: "12345678", expiry: exp });
  await identity.submitDocument("i3", { type: "other", number: "DL-2020/ABC123", country: "GH" });
  assert.equal((await identity.listMyDocuments("i3")).length, 3);
});

test("ID: human review confirms (level 2), number deleted, reviewer cannot review own ID, rejection frees the ID", async () => {
  await h.complete("r1", "0241110041");
  await h.complete("rv", "0241110042");
  const d = await identity.submitDocument("r1", { type: "ghana_card", number: "GHA-222222222-2" });
  const reviewer = { uid: "rv", role: "admin" };
  // Reviewer reveals the number (audit-logged), then decides.
  const rev = await identity.revealNumber(reviewer, d.id, null);
  assert.equal(rev.number, "GHA-222222222-2");
  assert.equal(rev.holder.name, "Ama Mensah");
  await rejects(identity.decide({ docId: d.id, decision: "verified", by: { uid: "r1", role: "admin" } }), "self");
  await identity.decide({ docId: d.id, decision: "verified", by: reviewer, note: "Matches card" });
  const u = await users.requireUser("r1");
  assert.equal(u.identity.level, 2);
  const stored = await store().get("identityDocuments", d.id);
  assert.equal(stored?.encNumber, undefined, "encrypted number deleted after decision");
  await rejects(identity.decide({ docId: d.id, decision: "rejected", by: reviewer }), "decided");
  await rejects(identity.revealNumber(reviewer, d.id, null), "removed");
  // locked profile after level 2
  await rejects(users.saveProfile("r1", { ...h.PROFILE, givenName: "Other" }), "locked");
  const caps = users.view(u).capabilities;
  assert.equal(caps["vehicle:register"].allowed, true, "citizen at level 2 may register a vehicle");
  assert.equal(caps["license:issue"].allowed, false, "but a citizen may not issue licences (role)");

  await h.complete("r2", "0241110043");
  const d2 = await identity.submitDocument("r2", { type: "ghana_card", number: "GHA-333333333-3" });
  await identity.decide({ docId: d2.id, decision: "rejected", by: reviewer, note: "Blurry" });
  assert.equal((await users.requireUser("r2")).identity.level, 0);
  await identity.submitDocument("r2", { type: "ghana_card", number: "GHA-333333333-3" }); // typo fixed, resubmitted
  assert.equal((await users.requireUser("r2")).identity.level, 1);
});

test("ID worker: checker outage never blocks anyone; verified result gives level 2; mismatch goes to a human", async () => {
  process.env.ID_CHECK_NIA = "true";
  try {
    await h.complete("w1", "0241110051");
    await h.complete("w2", "0241110052");
    await h.complete("w3", "0241110053");
    const a = await identity.submitDocument("w1", { type: "ghana_card", number: "GHA-444444444-4" });
    const b = await identity.submitDocument("w2", { type: "ghana_card", number: "GHA-555555555-5" });
    const c = await identity.submitDocument("w3", { type: "ghana_card", number: "GHA-666666666-6" });
    assert.equal(a.status, "pending_check");
    for (const id of ["w1", "w2", "w3"]) assert.equal((await users.requireUser(id)).identity.level, 1, "level 1 immediately, before any check");

    // 1) NIA down
    const down = { nia: { name: "nia", enabled: () => true, check: async (): Promise<CheckOutcome> => ({ outcome: "unavailable" }) } };
    let r = await identity.processDue({ registry: down, now: new Date(Date.now() + 1000) });
    assert.equal(r.retry, 3);
    assert.equal((await users.requireUser("w1")).identity.level, 1);

    // 2) NIA answers: w1 verified, w2 mismatch, w3 throws
    const answers = {
      nia: {
        name: "nia",
        enabled: () => true,
        check: async ({ number }: { number: string }): Promise<CheckOutcome> => {
          if (number.includes("444444444")) return { outcome: "verified" };
          if (number.includes("555555555")) return { outcome: "rejected", reason: "name differs" };
          throw new Error("boom");
        },
      },
    };
    r = await identity.processDue({ registry: answers, now: new Date(Date.now() + 3 * 3600_000) });
    assert.deepEqual([r.verified, r.toReview, r.retry], [1, 1, 1]);
    assert.equal((await users.requireUser("w1")).identity.level, 2);
    assert.equal((await store().get("identityDocuments", b.id))?.status, "pending_review");
    assert.equal((await store().get("identityDocuments", c.id))?.status, "pending_check");
  } finally {
    delete process.env.ID_CHECK_NIA;
  }
});

test("ID: numbers not decided within the window are purged and the account drops back, never locked out", async () => {
  await h.complete("x1", "0241110061");
  const d = await identity.submitDocument("x1", { type: "nhis", number: "87654321", expiry: new Date(Date.now() + 3e10).toISOString().slice(0, 10) });
  const n = await identity.purgeExpired(new Date(Date.now() + 15 * 864e5));
  assert.ok(n >= 1);
  assert.equal((await store().get("identityDocuments", d.id))?.status, "expired");
  assert.equal((await users.requireUser("x1")).identity.level, 0);
  assert.equal((await users.requireUser("x1")).onboarding.completedAt !== null, true, "still onboarded");
});

test("withdraw: unconfirmed ID can be removed and re-added, confirmed one cannot", async () => {
  await h.complete("d1", "0241110071");
  const d = await identity.submitDocument("d1", { type: "voter_id", number: "1234567890" });
  await identity.withdrawDocument("d1", d.id);
  assert.equal((await users.requireUser("d1")).identity.level, 0);
  await identity.submitDocument("d1", { type: "voter_id", number: "1234567890" });
});

test("roles: assign, cannot self-assign, last super admin protected, revocation + audit", async () => {
  await h.complete("sa", "0241110081");
  await h.complete("sb", "0241110082");
  await h.complete("tg", "0241110083");
  const SYSTEM = { uid: "system", role: "system" };
  await users.assignRole(SYSTEM, "sa", "super_admin", null);
  const sa = await users.requireUser("sa");
  await rejects(users.assignRole(sa, "sa", "citizen", null), "self");
  await rejects(users.assignRole(sa, "tg", "emperor", null), "invalid");
  await users.assignRole(sa, "tg", "officer", null);
  assert.equal((await users.requireUser("tg")).role, "officer");
  await rejects(users.assignRole(SYSTEM, "sa", "citizen", null), "last_super_admin");
  const logs = await store().query("auditLogs", { where: [["target.id", "==", "tg"]], orderBy: [["at", "desc"]] });
  assert.equal(logs[0].action, "user.role");
  assert.equal(logs[0].after.role, "officer");
});

test("roles: the last ACTIVE super admin cannot be demoted (a suspended one does not count)", async () => {
  await users.ensureUser(h.auth("ga")); // profile only: this test is about roles, not onboarding
  await users.ensureUser(h.auth("gb"));
  const SYSTEM = { uid: "system", role: "system" };
  await users.assignRole(SYSTEM, "ga", "super_admin", null);
  await users.assignRole(SYSTEM, "gb", "super_admin", null);
  for (const o of await store().query("users", { where: [["role", "==", "super_admin"]], limit: 50 })) {
    if (o.uid !== "ga" && o.uid !== "gb") await users.assignRole(SYSTEM, o.uid, "citizen", null); // leftovers from earlier tests share this store
  }
  const ga = await users.requireUser("ga");
  await users.setStatus(ga, "gb", "suspended", "test", null);
  await rejects(users.assignRole(SYSTEM, "ga", "citizen", null), "last_super_admin"); // gb is suspended, so ga is the last active one
  await users.setStatus(ga, "gb", "active", "test", null);
  await users.assignRole(SYSTEM, "ga", "citizen", null); // now gb can take over, so this is allowed
  assert.equal((await users.requireUser("ga")).role, "citizen");
  await rejects(users.assignRole(SYSTEM, "gb", "admin", null), "last_super_admin");
});

test("roles: officer needs level 2 to issue a licence; suspension blocks everything", async () => {
  await h.complete("o1", "0241110091");
  await h.complete("o2", "0241110092");
  const SYSTEM = { uid: "system", role: "system" };
  await users.assignRole(SYSTEM, "o1", "officer", null);
  let u = await users.requireUser("o1");
  assert.equal(roles.check(u, "license:issue", { onboardingComplete: true }).reason, "level");
  const d = await identity.submitDocument("o1", { type: "ghana_card", number: "GHA-777777777-7" });
  await identity.decide({ docId: d.id, decision: "verified", by: { uid: "o2", role: "admin" } });
  u = await users.requireUser("o1");
  assert.equal(roles.check(u, "license:issue", { onboardingComplete: true }).allowed, true);
  await users.assignRole(SYSTEM, "o2", "admin", null);
  const admin = await users.requireUser("o2");
  await users.setStatus(admin, "o1", "suspended", "test", null);
  u = await users.requireUser("o1");
  assert.equal(roles.check(u, "license:issue", { onboardingComplete: true }).reason, "suspended");
  await rejects(users.setStatus(admin, "o2", "suspended", "", null), "self");
});

test("unverified email blocks capabilities (but a no-email account, e.g. X without email, is not blocked by this rule)", async () => {
  await h.complete("e1", "0241110101");
  await store().update("users", "e1", { emailVerified: false });
  let u = await users.requireUser("e1");
  assert.equal(roles.check(u, "wallet:link", { onboardingComplete: true }).reason, "email_unverified");
  await store().update("users", "e1", { email: null });
  u = await users.requireUser("e1");
  assert.equal(roles.check(u, "wallet:link", { onboardingComplete: true }).allowed, true);
});

test("admin user list: one filter group, indexed shapes only", async () => {
  const all = await users.listUsers({});
  assert.ok(all.length > 5);
  const officers = await users.listUsers({ role: "officer", status: "active" });
  assert.ok(officers.every((x) => x.role === "officer"));
  await rejects(users.listUsers({ role: "officer", regionCode: "GAR" }), "invalid");
  assert.ok((await users.listUsers({ regionCode: "GAR" })).length > 3);
  assert.ok(Array.isArray(await users.listUsers({ level: "2" })));
});

test("store: queries that would need an unlisted composite index fail loudly (as Firestore would)", async () => {
  await assert.rejects(store().query("users", { where: [["role", "==", "citizen"], ["identity.level", "==", 2]], orderBy: [["profile.dob", "asc"]] }), /composite index/);
  assert.equal(requiredIndex("users", { where: [["role", "==", "a"], ["status", "==", "b"]] }), null, "equality-only needs no index");
});

test("audit: secrets and numbers are redacted", () => {
  const r = redact({ role: "x", numberHmac: "abc", encNumber: "zzz", phone: { e164: "+233" }, codeHmac: "q", nested: { token: "t", ok: 1 } });
  assert.equal(r.role, "x");
  assert.equal(r.numberHmac, "[removed]");
  assert.equal(r.encNumber, "[removed]");
  assert.equal(r.phone, "[removed]");
  assert.equal(r.nested.token, "[removed]");
  assert.equal(r.nested.ok, 1);
});

test("rate limit: IP limit on code sends", async () => {
  let blocked = 0;
  for (let i = 0; i < 24; i++) {
    const id = `ip${i}`;
    await users.ensureUser(h.auth(id));
    await users.saveConsents(id, { terms: true, privacy: true, sms: true }, null);
    try {
      await otp.startPhoneVerification(id, `024222${String(1000 + i)}`, "8.8.8.8");
    } catch (e) {
      if ((e as { code?: string }).code === "rate_limited") blocked++;
    }
  }
  assert.ok(blocked >= 4, `expected the 21st+ request from one IP to be blocked, got ${blocked}`);
});
