// Tests for the sign-in problem messages: every kind of "the site is set up wrongly" must be recognised and explained,
// and a plain bad token must still just mean "sign in again".
import './testEnv'; // must stay first: it sets up the throwaway store before the server code loads
import test from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync } from 'crypto';
import { classify, explainVerifyError, AuthError, SetupError, runSetupCheck } from '@/server/auth';
import type { SetupCheckReport } from '@/server/auth';

const withCode = (message: string, code: string | number) => Object.assign(new Error(message), { code });

// classify() returns null for an error it does not recognise; these tests always expect a match.
function mustClassify(error: Error) {
  const problem = classify(error);
  assert.ok(problem, 'expected the error to be recognised');

  return problem;
}

test("classify: Firestore database missing (and says Realtime Database is the wrong product)", () => {
  const e = withCode("5 NOT_FOUND: The database (default) does not exist for project my-app", 5);
  const r = mustClassify(e);
  assert.equal(r.code, "firestore_missing");
  assert.match(r.message, /Firestore Database > Create database/);
  assert.match(r.message, /NOT the same product as Realtime Database/);
});

test("classify: Firestore refused / API off", () => {
  assert.equal(mustClassify(withCode("7 PERMISSION_DENIED: Cloud Firestore API has not been used in project 1 before", 7)).code, "firestore_denied");
});

test("classify: bad private key and bad credentials", () => {
  assert.equal(mustClassify(new Error("Failed to parse private key: Error: Invalid PEM formatted message.")).code, "admin_credentials");
  assert.equal(mustClassify(withCode("16 UNAUTHENTICATED: Request had invalid authentication credentials", 16)).code, "admin_credentials");
  assert.equal(mustClassify(new Error("error:1E08010C:DECODER routines::unsupported")).code, "admin_credentials");
});

test("classify: offline server, admin missing, unrelated error", () => {
  assert.equal(mustClassify(new Error("getaddrinfo ENOTFOUND firestore.googleapis.com")).code, "server_offline");
  assert.equal(mustClassify(new Error("Firebase Admin is not configured. Set FIREBASE_PROJECT_ID...")).code, "admin_missing");
  assert.equal(classify(new Error("Cannot read properties of undefined (reading 'x')")), null);
  assert.equal(classify(new Error("temperature template")), null); // the word-boundary on PEM: no false match
});

test("classify: never copies a long message through", () => {
  const r = mustClassify(new Error("7 PERMISSION_DENIED: " + "x".repeat(2000)));
  assert.ok(r.message.length < 600);
});

test("verify errors: expired, revoked, disabled, deleted", () => {
  for (const [code, want] of [["auth/id-token-expired", "token_expired"], ["auth/id-token-revoked", "token_revoked"], ["auth/user-disabled", "user_disabled"], ["auth/user-not-found", "user_missing"]]) {
    const r = explainVerifyError(Object.assign(new Error("x"), { code }));
    assert.ok(r instanceof AuthError);
    assert.equal(r.code, want);
  }
});

test("verify errors: wrong Firebase project names both projects and is a SET-UP error", () => {
  const e = Object.assign(new Error('Firebase ID token has incorrect "aud" (audience) claim. Expected "server-proj" but got "page-proj". Make sure the ID token comes from the same Firebase project as the service account used to authenticate this SDK.'), { code: "auth/argument-error" });
  const r = explainVerifyError(e);
  assert.ok(r instanceof SetupError);
  assert.equal(r.code, "project_mismatch");
  assert.match(r.message, /"server-proj"/);
  assert.match(r.message, /"page-proj"/);
  assert.match(r.message, /FIREBASE_PROJECT_ID/);
});

test("verify errors: clock skew is explained", () => {
  const r = explainVerifyError(Object.assign(new Error("Token used too early, 100 < 120. Check that your computer's clock is set correctly."), { code: "auth/argument-error" }));
  assert.equal(r.code, "clock_skew");
  assert.match(r.message, /clock/);
});

test("verify errors: credentials trouble is a set-up error, garbage token is just 'sign in again'", () => {
  assert.ok(explainVerifyError(new Error("Credential implementation provided to initializeApp() via the 'credential' property failed to fetch a valid Google OAuth2 access token")) instanceof SetupError);
  const r = explainVerifyError(Object.assign(new Error("Decoding Firebase ID token failed. Make sure you passed the entire string JWT"), { code: "auth/argument-error" }));
  assert.ok(r instanceof AuthError);
  assert.equal(r.code, "invalid_token");
});

// ---- the set-up check ----------------------------------------------------------------------------------------
// Runs `run` with ONLY the given Firebase settings in the environment, then puts everything back.
async function withEnv<T>(vars: Record<string, string>, run: () => Promise<T>): Promise<T> {
  const keep = { ...process.env };

  for (const key of Object.keys(process.env)) {
    if (/^(NEXT_PUBLIC_FIREBASE|FIREBASE_|GOOGLE_APPLICATION|STORE_BACKEND)/.test(key)) delete process.env[key];
  }

  Object.assign(process.env, vars);

  try {
    return await run();
  } finally {
    for (const key of Object.keys(process.env)) delete process.env[key];
    Object.assign(process.env, keep);
  }
}

const find = (report: SetupCheckReport, id: string) => {
  const item = report.checks.find((check) => check.id === id);
  assert.ok(item, `no check called ${id}`);

  return item;
};

test("set-up check: nothing configured lists what is missing, skips the network, and shows no secret", async () => {
  const r = await withEnv({}, () => runSetupCheck());
  assert.equal(r.ok, false);
  assert.equal(find(r, "client-config").status, "fail");
  assert.match(find(r, "client-config").detail, /NEXT_PUBLIC_FIREBASE_API_KEY/);
  assert.equal(find(r, "admin-config").status, "fail");
  assert.equal(find(r, "auth-reach").status, "skip");
});

test("set-up check: different projects are flagged, same project is OK", async () => {
  const base = { NEXT_PUBLIC_FIREBASE_API_KEY: "k", NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN: "d", NEXT_PUBLIC_FIREBASE_APP_ID: "a", FIREBASE_CLIENT_EMAIL: "x@a.iam.gserviceaccount.com", FIREBASE_PRIVATE_KEY: "nope" };
  const bad = await withEnv({ ...base, NEXT_PUBLIC_FIREBASE_PROJECT_ID: "page", FIREBASE_PROJECT_ID: "server" }, () => runSetupCheck());
  assert.equal(find(bad, "same-project").status, "fail");
  const good = await withEnv({ ...base, NEXT_PUBLIC_FIREBASE_PROJECT_ID: "same", FIREBASE_PROJECT_ID: "same" }, () => runSetupCheck());
  assert.equal(find(good, "same-project").status, "ok");
});

test("set-up check: an unreadable private key is flagged and never echoed", async () => {
  const secret = "-----BEGIN PRIVATE KEY-----\\nTOP-SECRET-MATERIAL\\n-----END PRIVATE KEY-----\\n";
  const r = await withEnv({ NEXT_PUBLIC_FIREBASE_PROJECT_ID: "p", FIREBASE_PROJECT_ID: "p", FIREBASE_CLIENT_EMAIL: "x@p.iam.gserviceaccount.com", FIREBASE_PRIVATE_KEY: secret }, () => runSetupCheck());
  assert.equal(find(r, "private-key").status, "fail");
  assert.ok(!JSON.stringify(r).includes("TOP-SECRET-MATERIAL"));
  assert.equal(find(r, "auth-reach").status, "skip");
});

test("set-up check: a real-looking key that parses is accepted", async () => {
  const pem = generateKeyPairSync("rsa", { modulusLength: 2048, privateKeyEncoding: { type: "pkcs8", format: "pem" }, publicKeyEncoding: { type: "spki", format: "pem" } }).privateKey;
  const r = await withEnv({ NEXT_PUBLIC_FIREBASE_PROJECT_ID: "p", FIREBASE_PROJECT_ID: "p", FIREBASE_CLIENT_EMAIL: "x@p.iam.gserviceaccount.com", FIREBASE_PRIVATE_KEY: pem.replace(/\n/g, "\\n"), STORE_BACKEND: "file" }, async () => {
    // do not call Google from a unit test: stop before the network step by pointing admin at an unreachable emulator
    process.env.FIREBASE_AUTH_EMULATOR_HOST = "127.0.0.1:1";
    return runSetupCheck();
  });
  assert.equal(find(r, "admin-config").status, "ok");
});
