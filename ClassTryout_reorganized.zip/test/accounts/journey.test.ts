// Unit tests for the two pure functions behind the new navigation and the guided dashboard.
//   yarn test:accounts
import test from 'node:test';
import assert from 'node:assert/strict';
import { buildJourney } from '@/shared/journey';
import type { Journey, WalletState } from '@/shared/journey';
import { visibleItems } from '@/shared/navigation';
import type { NavItem } from '@/shared/navigation';
import type { Me } from '@/types';
import navJson from '@/shared/nav.json';

const nav = navJson as { items: NavItem[] };

// Only the fields the journey and the navigation read; the rest of `Me` is not needed here.
const me = (over: Record<string, unknown> = {}) =>
  ({
    email: 'a@example.test',
    emailVerified: true,
    role: 'citizen',
    status: 'active',
    onboarding: { complete: true },
    identity: { level: 2 },
    ...over,
  }) as unknown as Me;

const W: WalletState = { connected: true, deployed: true, networkName: 'Sepolia' };
const NO_WALLET: WalletState = { connected: false, deployed: false, networkName: '' };

const ids = (journey: Journey) => journey.steps.map((step) => step.id);

// The first step that is not done; the tests below always expect one.
const next = (journey: Journey) => {
  assert.ok(journey.next, 'expected a next step');

  return journey.next;
};

test("journey: a brand-new account is sent to verify its email first", () => {
  const r = buildJourney({ me: me({ emailVerified: false, onboarding: { complete: false }, identity: { level: 0 } }), wallet: NO_WALLET, linked: null });
  assert.deepEqual(ids(r), ["email", "setup", "id", "wallet", "link"]);
  assert.equal(next(r).id, "email");
  assert.equal(next(r).status, "current");
});

test("journey: an account without an email (X sign-in) has no email step", () => {
  const r = buildJourney({ me: me({ email: null, onboarding: { complete: false } }), wallet: W, linked: false });
  assert.ok(!ids(r).includes("email"));
  assert.equal(next(r).id, "setup");
});

test("journey: order is email -> set-up -> ID -> wallet", () => {
  let r = buildJourney({ me: me({ onboarding: { complete: false } }), wallet: W, linked: true });
  assert.equal(next(r).id, "setup");
  r = buildJourney({ me: me({ identity: { level: 0 } }), wallet: W, linked: true });
  assert.equal(next(r).id, "id");
  r = buildJourney({ me: me(), wallet: NO_WALLET, linked: true });
  assert.equal(next(r).id, "wallet");
});

test("journey: an ID waiting for review shows 'waiting', still the next step", () => {
  const r = buildJourney({ me: me({ identity: { level: 1 } }), wallet: W, linked: true });
  assert.equal(next(r).id, "id");
  assert.equal(next(r).status, "waiting");
});

test("journey: connected to a network with no contracts is not 'done'", () => {
  const r = buildJourney({ me: me(), wallet: { connected: true, deployed: false, networkName: "Base" }, linked: true });
  assert.equal(next(r).id, "wallet");
  assert.match(next(r).detail, /no ClassTryout contracts/);
});

test("journey: the optional wallet-link step only becomes 'next' when everything else is done", () => {
  let r = buildJourney({ me: me(), wallet: W, linked: false });
  assert.equal(next(r).id, "link");
  r = buildJourney({ me: me(), wallet: W, linked: true });
  assert.equal(r.next, null);
  r = buildJourney({ me: me({ identity: { level: 0 } }), wallet: W, linked: false });
  assert.equal(next(r).id, "id", "a required step comes before the optional one");
});

test("journey: unknown link state (null) behaves like 'not linked'", () => {
  const r = buildJourney({ me: me(), wallet: W, linked: null });
  assert.equal(next(r).id, "link");
});

const hrefs = (items: NavItem[]) => items.map((item) => item.href);

test("nav: a citizen sees vehicles, history and notifications but no officer or admin pages", () => {
  const h = hrefs(visibleItems(nav.items, me({ role: "citizen" }), { requireAccount: true }));
  assert.deepEqual(h, ["/dashboard", "/vehicles", "/history", "/notifications"]);
});

test("nav: an officer also sees licences and revocations, still no admin pages", () => {
  const h = hrefs(visibleItems(nav.items, me({ role: "officer" })));
  assert.ok(h.includes("/licences") && h.includes("/revocations"));
  assert.ok(!h.some((href) => href.startsWith("/admin")));
});

test("nav: an admin sees the admin pages; a super admin sees the same", () => {
  for (const role of ["admin", "super_admin"]) {
    const h = hrefs(visibleItems(nav.items, me({ role })));
    assert.ok(["/admin/users", "/admin/ids", "/admin/contracts"].every((href) => h.includes(href)), role);
  }
});

test("nav: signed out with accounts required sees only public pages", () => {
  assert.deepEqual(hrefs(visibleItems(nav.items, null, { requireAccount: true })), ["/history"]);
});

test("nav: signed out in demo mode sees the chain pages but never account or admin pages", () => {
  const h = hrefs(visibleItems(nav.items, null, { requireAccount: false }));
  assert.ok(h.includes("/vehicles") && h.includes("/history"));
  assert.ok(!h.includes("/dashboard") && !h.some((href) => href.startsWith("/admin")));
});

test("nav: a suspended account sees only public pages", () => {
  assert.deepEqual(hrefs(visibleItems(nav.items, me({ status: "suspended", role: "admin" }))), ["/history"]);
});
