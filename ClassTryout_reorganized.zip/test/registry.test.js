// Run with:  npx truffle test        (uses Truffle's built-in throwaway chain; nothing is deployed anywhere)
const VehicleRegistry = artifacts.require("VehicleRegistry");
const RevocationManager = artifacts.require("RevocationManager");
const LicenseRegistry = artifacts.require("LicenseRegistry");

// OpenZeppelin 5 reports failures as custom errors, which Truffle's test runner cannot print by name,
// so they are matched by their 4-byte selector: first 4 bytes of keccak256("Name(argTypes)").
const CUSTOM_ERRORS = {
  OwnableUnauthorizedAccount: "OwnableUnauthorizedAccount(address)",
  EnforcedPause: "EnforcedPause()",
  ExpectedPause: "ExpectedPause()",
};
const selector = (name) => web3.utils.keccak256(CUSTOM_ERRORS[name]).slice(0, 10);

// Passes only if `promise` reverts with the expected custom error (by name) or require() message (by substring).
async function reverts(promise, expected) {
  try {
    await promise;
  } catch (err) {
    const raw = JSON.stringify(err.data || {}) + " " + (err.message || "");
    if (CUSTOM_ERRORS[expected]) {
      assert(raw.toLowerCase().includes(selector(expected).toLowerCase()), `reverted, but not with ${expected}: ${raw.slice(0, 250)}`);
    } else {
      assert(raw.includes(expected), `reverted, but with "${raw.slice(0, 250)}" instead of "${expected}"`);
    }
    return;
  }
  assert.fail(`expected a revert with "${expected}", but the call succeeded`);
}

contract("ClassTryout contracts", (accounts) => {
  const [admin, alice, bob, carol] = accounts;
  let registry, revocation, license;

  beforeEach(async () => {
    registry = await VehicleRegistry.new({ from: admin });
    revocation = await RevocationManager.new(registry.address, { from: admin });
    await registry.setRevocationManager(revocation.address, { from: admin });
    license = await LicenseRegistry.new(registry.address, revocation.address, { from: admin });
  });

  describe("ownership (OpenZeppelin Ownable)", () => {
    it("deployer is owner, and admin() is an alias of owner() on all three contracts", async () => {
      for (const c of [registry, revocation, license]) {
        assert.equal(await c.owner(), admin);
        assert.equal(await c.admin(), admin);
      }
    });

    it("only the owner can use admin functions", async () => {
      await registry.registerVehicle("car-a", { from: alice });
      await registry.registerVehicle("car-b", { from: bob });
      await revocation.submitRevocationReport("car-a", "car-b", "speeding", { from: bob });
      await reverts(revocation.processRevocation(1, { from: bob }), "OwnableUnauthorizedAccount");
      await reverts(revocation.reinstateVehicle("car-a", { from: bob }), "OwnableUnauthorizedAccount");
      await reverts(license.revokeLicense("x", { from: bob }), "OwnableUnauthorizedAccount");
      await reverts(license.reinstateLicense("x", { from: bob }), "OwnableUnauthorizedAccount");
      await reverts(registry.pause({ from: bob }), "OwnableUnauthorizedAccount");
      await reverts(revocation.pause({ from: bob }), "OwnableUnauthorizedAccount");
      await reverts(license.pause({ from: bob }), "OwnableUnauthorizedAccount");
    });

    it("renouncing ownership is disabled", async () => {
      await reverts(registry.renounceOwnership({ from: admin }), "Renouncing ownership is disabled");
      assert.equal(await registry.owner(), admin);
    });

    it("ownership can be transferred, and the old owner loses its rights", async () => {
      await license.transferOwnership(alice, { from: admin });
      assert.equal(await license.admin(), alice);
      await reverts(license.pause({ from: admin }), "OwnableUnauthorizedAccount");
      await license.pause({ from: alice });
      assert.equal(await license.paused(), true);
    });

    it("setRevocationManager works once only", async () => {
      await reverts(registry.setRevocationManager(carol, { from: admin }), "RevocationManager already set");
    });
  });

  describe("pausing (OpenZeppelin Pausable)", () => {
    it("pausing stops new registrations, reports and licenses; unpausing restores them", async () => {
      await registry.registerVehicle("car-a", { from: alice });
      await registry.registerVehicle("car-b", { from: bob });

      await registry.pause({ from: admin });
      await revocation.pause({ from: admin });
      await license.pause({ from: admin });
      assert.equal(await registry.paused(), true);

      await reverts(registry.registerVehicle("car-c", { from: carol }), "EnforcedPause");
      await reverts(revocation.submitRevocationReport("car-a", "car-b", "x", { from: bob }), "EnforcedPause");
      await reverts(license.issueLicense("L1", "car-a", "Standard", 30, { from: alice }), "EnforcedPause");

      await registry.unpause({ from: admin });
      await revocation.unpause({ from: admin });
      await license.unpause({ from: admin });
      await registry.registerVehicle("car-c", { from: carol });
      await license.issueLicense("L1", "car-a", "Standard", 30, { from: alice });
      assert.equal(await license.isLicenseValid("L1"), true);
    });

    it("admin actions still work while paused", async () => {
      await registry.registerVehicle("car-a", { from: alice });
      await registry.registerVehicle("car-b", { from: bob });
      await revocation.submitRevocationReport("car-a", "car-b", "speeding", { from: bob });
      await license.issueLicense("L1", "car-a", "Standard", 30, { from: alice });

      await revocation.pause({ from: admin });
      await license.pause({ from: admin });
      await revocation.processRevocation(1, { from: admin });
      assert.equal(await revocation.isRevoked("car-a"), true);
      await license.revokeLicense("L1", { from: admin });
      await license.reinstateLicense("L1", { from: admin });
      await revocation.reinstateVehicle("car-a", { from: admin });
      assert.equal(await revocation.isRevoked("car-a"), false);
    });

    it("pausing twice, or unpausing when not paused, reverts", async () => {
      await reverts(registry.unpause({ from: admin }), "ExpectedPause");
      await registry.pause({ from: admin });
      await reverts(registry.pause({ from: admin }), "EnforcedPause");
    });
  });

  describe("VehicleRegistry rules", () => {
    it("rejects empty and duplicate pseudonyms", async () => {
      await reverts(registry.registerVehicle("", { from: alice }), "Pseudonym cannot be empty");
      await registry.registerVehicle("car-a", { from: alice });
      await reverts(registry.registerVehicle("car-a", { from: bob }), "Pseudonym already registered");
    });

    it("stores owner and lets the owner look it up", async () => {
      await registry.registerVehicle("car-a", { from: alice });
      const v = await registry.getVehicle("car-a");
      assert.equal(v.owner, alice);
      assert.equal(v.isRegistered, true);
      assert.equal(await registry.getPseudonymByOwner(alice), "car-a");
    });

    it("only the owner or admin can remove a registration", async () => {
      await registry.registerVehicle("car-a", { from: alice });
      await reverts(registry.removeVehicle("car-a", { from: bob }), "Only the owner or admin can remove this registration");
      await registry.removeVehicle("car-a", { from: alice });
      assert.equal(await registry.isVehicleRegistered("car-a"), false);
      await registry.registerVehicle("car-b", { from: bob });
      await registry.removeVehicle("car-b", { from: admin });
      assert.equal(await registry.isVehicleRegistered("car-b"), false);
    });
  });

  describe("revocation cannot be dodged", () => {
    beforeEach(async () => {
      await registry.registerVehicle("car-a", { from: alice });
      await registry.registerVehicle("car-b", { from: bob });
      await revocation.submitRevocationReport("car-a", "car-b", "speeding", { from: bob });
      await revocation.processRevocation(1, { from: admin });
    });

    it("a revoked wallet cannot register a fresh pseudonym", async () => {
      await reverts(registry.registerVehicle("car-clean", { from: alice }), "current identity is revoked");
    });

    it("a revoked wallet cannot delete its own record to escape (hardening)", async () => {
      await reverts(registry.removeVehicle("car-a", { from: alice }), "A revoked identity can only be removed by the admin");
      assert.equal(await registry.isVehicleRegistered("car-a"), true);
    });

    it("the admin can still remove a revoked identity, and reinstated owners can remove their own", async () => {
      await revocation.reinstateVehicle("car-a", { from: admin });
      await registry.removeVehicle("car-a", { from: alice });
      assert.equal(await registry.isVehicleRegistered("car-a"), false);
    });
  });

  describe("RevocationManager reports", () => {
    beforeEach(async () => {
      await registry.registerVehicle("car-a", { from: alice });
      await registry.registerVehicle("car-b", { from: bob });
    });

    it("validates reports", async () => {
      await reverts(revocation.submitRevocationReport("ghost", "car-b", "x", { from: bob }), "Offender is not a registered identity");
      await reverts(revocation.submitRevocationReport("car-a", "ghost", "x", { from: bob }), "Reporter is not a registered identity");
      await reverts(revocation.submitRevocationReport("car-a", "car-a", "x", { from: bob }), "An identity cannot report itself");
      await reverts(revocation.submitRevocationReport("car-a", "car-b", "", { from: bob }), "Reason cannot be empty");
    });

    it("report ids start at 1; unknown ids and double-processing revert", async () => {
      await revocation.submitRevocationReport("car-a", "car-b", "speeding", { from: bob });
      assert.equal((await revocation.reportCount()).toString(), "1");
      await reverts(revocation.processRevocation(0, { from: admin }), "Report does not exist");
      await reverts(revocation.processRevocation(2, { from: admin }), "Report does not exist");
      await revocation.processRevocation(1, { from: admin });
      await reverts(revocation.processRevocation(1, { from: admin }), "Report already processed");
    });
  });

  describe("LicenseRegistry", () => {
    beforeEach(async () => {
      await registry.registerVehicle("car-a", { from: alice });
      await registry.registerVehicle("car-b", { from: bob });
    });

    it("issues, reads and finds a license by vehicle", async () => {
      await license.issueLicense("L1", "car-a", "Standard", 365, { from: alice });
      const lic = await license.getLicense("L1");
      assert.equal(lic.vehiclePseudonym, "car-a");
      assert.equal(lic.licenseType, "Standard");
      assert.equal(lic.issued, true);
      assert.equal(await license.getLicenseByVehicle("car-a"), "L1");
      assert.equal(await license.isLicenseValid("L1"), true);
    });

    it("rejects unregistered vehicles and reused ids", async () => {
      await reverts(license.issueLicense("L1", "ghost", "Standard", 30, { from: alice }), "Vehicle not registered");
      await license.issueLicense("L1", "car-a", "Standard", 30, { from: alice });
      await reverts(license.issueLicense("L1", "car-b", "Standard", 30, { from: bob }), "License ID already used");
    });

    it("revoking a vehicle invalidates its license instantly, reinstating restores it", async () => {
      await license.issueLicense("L1", "car-a", "Standard", 365, { from: alice });
      await revocation.submitRevocationReport("car-a", "car-b", "speeding", { from: bob });
      await revocation.processRevocation(1, { from: admin });
      assert.equal(await license.isLicenseValid("L1"), false);
      await reverts(license.issueLicense("L2", "car-a", "Standard", 30, { from: alice }), "Vehicle is revoked");
      await revocation.reinstateVehicle("car-a", { from: admin });
      assert.equal(await license.isLicenseValid("L1"), true);
    });

    it("admin can revoke and reinstate a single license", async () => {
      await license.issueLicense("L1", "car-a", "Standard", 365, { from: alice });
      await license.revokeLicense("L1", { from: admin });
      assert.equal(await license.isLicenseValid("L1"), false);
      await reverts(license.revokeLicense("L1", { from: admin }), "License already inactive");
      await license.reinstateLicense("L1", { from: admin });
      await reverts(license.reinstateLicense("L1", { from: admin }), "License already active");
      assert.equal(await license.isLicenseValid("L1"), true);
      await reverts(license.revokeLicense("nope", { from: admin }), "License does not exist");
    });

    it("an expired license is not valid", async () => {
      await license.issueLicense("L1", "car-a", "Standard", 1, { from: alice });
      await new Promise((res, rej) =>
        web3.currentProvider.send({ jsonrpc: "2.0", id: 1, method: "evm_increaseTime", params: [2 * 86400] }, (e) => (e ? rej(e) : res()))
      );
      await new Promise((res, rej) =>
        web3.currentProvider.send({ jsonrpc: "2.0", id: 2, method: "evm_mine", params: [] }, (e) => (e ? rej(e) : res()))
      );
      assert.equal(await license.isLicenseValid("L1"), false);
    });
  });
});
