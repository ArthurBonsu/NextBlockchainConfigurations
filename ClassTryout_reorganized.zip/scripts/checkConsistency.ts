// scripts/checkConsistency.ts
// "Does everything pull the same thing?"   Run it with:  yarn check
//
// It fails (exit code 1) when the contracts, ABIs, migrations, deployments, chains and the front end have drifted apart.
// Each numbered section below is one kind of check, written as one small function.

import fs from 'fs';
import path from 'path';
import { abiFiles, normalizeAbi } from './syncContracts';

const root = path.resolve(__dirname, '..');

// ---------------------------------------------------------------- tools used by all the checks
const errors: string[] = [];
const warnings: string[] = [];

const fail = (message: string) => errors.push(message);
const warn = (message: string) => warnings.push(message);

const relative = (file: string) => path.relative(root, file).split(path.sep).join('/');
const read = (file: string) => fs.readFileSync(file, 'utf8');
const exists = (file: string) => fs.existsSync(file);
const readJson = (file: string) => JSON.parse(read(file));
const inRoot = (...parts: string[]) => path.join(root, ...parts);

// All files under a folder whose names end with one of the extensions.
function walk(dir: string, extensions: string[], found: string[] = []): string[] {
  if (!exists(dir)) return found;

  for (const name of fs.readdirSync(dir)) {
    if (name === 'node_modules' || name === '.next' || name === 'build') continue;

    const fullPath = path.join(dir, name);

    if (fs.statSync(fullPath).isDirectory()) {
      walk(fullPath, extensions, found);
    } else if (extensions.some((extension) => name.endsWith(extension))) {
      found.push(fullPath);
    }
  }

  return found;
}

const { contracts } = readJson(inRoot('shared/contracts.json')) as { contracts: string[] };
const { chains } = readJson(inRoot('shared/chains.json')) as { chains: any[] };

type Abi = any[];
const abis: Record<string, Abi> = {};

const methodsOf = (name: string) => new Set((abis[name] || []).filter((item) => item.type === 'function').map((item) => item.name));
const eventsOf = (name: string) => new Set((abis[name] || []).filter((item) => item.type === 'event').map((item) => item.name));

// Code that talks to the contracts. The email watcher reads the same ABIs, so it is held to the same rules.
const APP_FOLDERS = ['components', 'pages', 'utils', 'hooks', 'services', 'blockchain', 'notifier', 'server'];
const appFiles = APP_FOLDERS.flatMap((folder) => walk(inRoot(folder), ['.ts', '.tsx']));

// ---------------------------------------------------------------- 1. chains.json
function checkChains() {
  const ids = new Set<number>();
  const keys = new Set<string>();

  for (const chain of chains) {
    if (ids.has(chain.chainId)) fail(`shared/chains.json: duplicate chainId ${chain.chainId}`);
    if (keys.has(chain.key)) fail(`shared/chains.json: duplicate key "${chain.key}"`);

    ids.add(chain.chainId);
    keys.add(chain.key);

    for (const field of ['chainId', 'key', 'name', 'kind', 'testnet', 'rpcUrls', 'currency']) {
      if (chain[field] === undefined) fail(`shared/chains.json: ${chain.key || chain.chainId} is missing "${field}"`);
    }
  }
}

// ---------------------------------------------------------------- 2. ABIs: present, in sync with each other, and with the compiled contracts
function checkAbis() {
  for (const name of contracts) {
    const jsonFile = inRoot('shared/abi', `${name}.json`);
    const tsFile = inRoot('shared/abi', `${name}.ts`);

    if (!exists(jsonFile) || !exists(tsFile)) {
      fail(`ABI for ${name} is missing in shared/abi/. Run: yarn contracts:compile`);
      continue;
    }

    const abi = readJson(jsonFile);
    abis[name] = abi;

    const expected = abiFiles(name, abi);

    if (read(tsFile) !== expected.ts) fail(`shared/abi/${name}.ts does not match ${name}.json. Run: yarn contracts:sync`);

    if (!exists(inRoot('contracts', `${name}.sol`))) fail(`contracts/${name}.sol is listed in shared/contracts.json but does not exist`);

    const artifact = inRoot('build/contracts', `${name}.json`);

    if (!exists(artifact)) {
      warn(`build/contracts/${name}.json not found: skipped the "compiled vs shared ABI" check (run truffle compile to include it)`);
      continue;
    }

    if (JSON.stringify(normalizeAbi(readJson(artifact).abi)) !== JSON.stringify(abi)) {
      fail(`${name}: the compiled contract differs from shared/abi/${name}.json (Solidity changed, ABI not synced). Run: yarn contracts:compile`);
    }
  }
}

// ---------------------------------------------------------------- 3. The front end only uses methods and events that exist
function checkFrontEndUsesRealMethods() {
  const variableToContract: Record<string, string> = { registry: 'VehicleRegistry', revocation: 'RevocationManager', license: 'LicenseRegistry' };
  const allEvents = new Set(Object.keys(abis).flatMap((name) => [...eventsOf(name)]));

  for (const file of appFiles) {
    const source = read(file);

    for (const match of source.matchAll(/\b(registry|revocation|license)\.methods\.(\w+)\s*\(/g)) {
      const [, variable, functionName] = match;

      if (!methodsOf(variableToContract[variable]).has(functionName)) {
        fail(`${relative(file)}: calls ${variable}.methods.${functionName}() but ${variableToContract[variable]} has no such function`);
      }
    }

    for (const match of source.matchAll(/\b(registry|revocation|license)\.getPastEvents\(\s*["'](\w+)["']/g)) {
      const [, variable, eventName] = match;

      if (!eventsOf(variableToContract[variable]).has(eventName)) {
        fail(`${relative(file)}: reads event ${eventName} from ${variableToContract[variable]}, which does not emit it`);
      }
    }

    for (const match of source.matchAll(/\.events(?:\s+as\s+any\))?\??\.(\w+)/g)) {
      if (!allEvents.has(match[1])) fail(`${relative(file)}: uses receipt event "${match[1]}" which no contract emits`);
    }
  }
}

// ---------------------------------------------------------------- 4. Nothing imports old or unrelated code, or raw build output
function checkNoBannedCode() {
  const banned: [RegExp, string][] = [
    [/contract-loader/, 'contract-loader belongs to the Passchain project; use blockchain/contracts'],
    [/contract_addresses/, 'contract_addresses.json belongs to the Passchain project; addresses come from shared/deployments.json'],
    [/sequence_abi/, 'sequence_abi.json belongs to the Passchain project'],
    [/from\s+["'][^"']*\/build\/contracts/, 'import from shared/abi, not from build/contracts'],
    [/require\(\s*["'][^"']*\/build\/contracts/, 'import from shared/abi, not from build/contracts'],
    [/tatum/i, 'Tatum code is unrelated to this project'],
  ];

  const scriptFiles = walk(inRoot('scripts'), ['.ts']).filter((file) => !file.endsWith('checkConsistency.ts'));
  const migrationFiles = walk(inRoot('migrations'), ['.js']);

  for (const file of [...appFiles, ...scriptFiles, ...migrationFiles]) {
    const source = read(file);

    for (const [pattern, reason] of banned) {
      if (pattern.test(source)) fail(`${relative(file)}: ${reason}`);
    }
  }
}

// ---------------------------------------------------------------- 5. Solidity: OpenZeppelin by package path, relative imports resolve
function checkSolidity() {
  for (const file of walk(inRoot('contracts'), ['.sol'])) {
    const source = read(file);

    for (const match of source.matchAll(/import\s+(?:[^"']*from\s+)?["']([^"']+)["']/g)) {
      const specifier = match[1];

      if (/^https?:/.test(specifier)) {
        fail(`${relative(file)}: URL import "${specifier}" does not work with Truffle; use the package path "@openzeppelin/contracts/..."`);
      } else if (specifier.startsWith('./') || specifier.startsWith('../')) {
        if (!exists(path.resolve(path.dirname(file), specifier))) fail(`${relative(file)}: imports ${specifier}, which does not exist`);
      } else if (specifier.startsWith('@openzeppelin/')) {
        if (!exists(inRoot('node_modules', specifier))) warn(`${relative(file)}: ${specifier} not found in node_modules (run yarn install)`);
      }
    }
  }

  if (exists(inRoot('contracts/openzeppelin')) || exists(inRoot('contracts/@openzeppelin'))) {
    fail('contracts/ contains a copy of OpenZeppelin. Delete it and import by package path (yarn add @openzeppelin/contracts).');
  }

  const pkg = readJson(inRoot('package.json'));
  const version = (pkg.devDependencies || {})['@openzeppelin/contracts'] || (pkg.dependencies || {})['@openzeppelin/contracts'];

  if (!version) {
    fail('package.json does not list @openzeppelin/contracts');
  } else if (/^[\^~]/.test(version)) {
    warn(`@openzeppelin/contracts is "${version}"; pin an exact version so the compiled bytecode is reproducible`);
  }
}

// ---------------------------------------------------------------- 6. Migrations: unique numbers, only known contracts
function checkMigrations() {
  const dir = inRoot('migrations');
  const fileForNumber: Record<number, string> = {};
  const files = exists(dir) ? fs.readdirSync(dir).filter((name) => name.endsWith('.js')) : [];

  for (const file of files) {
    const number = parseInt(file, 10);

    if (Number.isNaN(number)) fail(`migrations/${file}: file name must start with a number`);
    if (fileForNumber[number]) fail(`migrations/${file} and migrations/${fileForNumber[number]} share the number ${number}; Truffle would run both`);

    fileForNumber[number] = file;

    for (const match of read(path.join(dir, file)).matchAll(/artifacts\.require\(\s*["'](\w+)["']/g)) {
      if (!exists(inRoot('contracts', `${match[1]}.sol`)) && !/Migrations/.test(match[1])) {
        fail(`migrations/${file}: requires ${match[1]}, which has no contracts/${match[1]}.sol`);
      }
    }
  }

  for (const name of contracts) {
    const deploysIt = Object.values(fileForNumber).some((file) => read(path.join(dir, file)).includes(`contractName: "${name}"`));

    if (!deploysIt) fail(`no migration records a deployment of ${name} (call recordDeployment in its migration)`);
  }
}

// ---------------------------------------------------------------- 7. Deployments
function checkDeployments() {
  function checkFile(file: string, isPublic: boolean) {
    const fullPath = inRoot('shared', file);

    if (!exists(fullPath)) return;

    for (const [key, entry] of Object.entries(readJson(fullPath)) as [string, any][]) {
      if (key.startsWith('_')) continue;

      if (isPublic && !chains.some((chain) => String(chain.chainId) === key && chain.kind !== 'Local')) {
        fail(`shared/${file}: chain id ${key} is not a public chain in shared/chains.json`);
      }

      for (const name of contracts) {
        const deployed = entry[name];

        if (!deployed) {
          fail(`shared/${file}[${key}]: no entry for ${name} (deploy all contracts to each chain)`);
        } else if (!/^0x[0-9a-fA-F]{40}$/.test(deployed.address || '')) {
          fail(`shared/${file}[${key}].${name}: "${deployed.address}" is not an address`);
        } else if (!Number.isInteger(deployed.startBlock)) {
          fail(`shared/${file}[${key}].${name}: missing startBlock`);
        }
      }
    }
  }

  checkFile('deployments.json', true);
  checkFile('deployments.local.json', false);
}

// ---------------------------------------------------------------- 8. The app's network list reads shared/chains.json (no second copy)
function checkNetworkList() {
  const file = inRoot('blockchain/wallets/networks.ts');

  if (exists(file) && !/import\s+\w+\s+from\s+["'][^"']*shared\/chains\.json["']/.test(read(file))) {
    fail('blockchain/wallets/networks.ts must import shared/chains.json instead of keeping its own list');
  }
}

// ---------------------------------------------------------------- 9. Email notifications: list <-> ABI <-> templates <-> resolver
function checkNotifications() {
  const file = inRoot('shared/notifications.json');

  if (!exists(file)) return;

  const { notifications } = readJson(file);
  const resolverSource = exists(inRoot('notifier/resolve.ts')) ? read(inRoot('notifier/resolve.ts')) : '';
  const templateSource = exists(inRoot('notifier/templates.ts')) ? read(inRoot('notifier/templates.ts')) : '';
  const ids = new Set<string>();

  for (const rule of notifications) {
    if (ids.has(rule.id)) fail(`shared/notifications.json: duplicate id "${rule.id}"`);

    ids.add(rule.id);

    if (!contracts.includes(rule.contract)) {
      fail(`shared/notifications.json[${rule.id}]: unknown contract ${rule.contract}`);
      continue;
    }

    const event = (abis[rule.contract] || []).find((item) => item.type === 'event' && item.name === rule.event);

    if (!event) {
      fail(`shared/notifications.json[${rule.id}]: ${rule.contract} has no event ${rule.event}`);
      continue;
    }

    if (!event.inputs.some((input: any) => input.name === rule.timestampArg)) {
      fail(`shared/notifications.json[${rule.id}]: ${rule.event} has no argument "${rule.timestampArg}"`);
    }

    if (!new RegExp(`case\\s+["']${rule.id}["']`).test(resolverSource)) fail(`notifier/resolve.ts has no handler for "${rule.id}"`);
    if (!new RegExp(`\\b${rule.id}\\s*:`).test(templateSource)) fail(`notifier/templates.ts has no template "${rule.id}"`);
  }

  // The event arguments that the resolver reads (a.something) must exist on some event.
  const argumentNames = new Set(
    Object.values(abis).flatMap((abi) => abi.filter((item) => item.type === 'event').flatMap((item) => item.inputs.map((input: any) => input.name)))
  );

  for (const match of resolverSource.matchAll(/\ba\.(\w+)/g)) {
    if (!argumentNames.has(match[1])) fail(`notifier/resolve.ts reads event argument "${match[1]}", which no event has`);
  }

  // The transactions that the resolver decodes must be real functions.
  for (const match of resolverSource.matchAll(/txArgs\(\s*ctx\s*,\s*[\w.]+\s*,\s*["'](\w+)["']\s*,\s*["'](\w+)["']/g)) {
    if (!methodsOf(match[1]).has(match[2])) fail(`notifier/resolve.ts decodes ${match[1]}.${match[2]}(), which does not exist`);
  }

  for (const match of resolverSource.matchAll(/:\s*["']((?:issue|revoke|reinstate)License)["']/g)) {
    if (!methodsOf('LicenseRegistry').has(match[1])) fail(`notifier/resolve.ts decodes LicenseRegistry.${match[1]}(), which does not exist`);
  }
}

// ---------------------------------------------------------------- 10. Accounts
const EXPECTED_DISTRICTS: Record<string, number> = {
  AHA: 6, ASH: 43, BON: 12, BOE: 11, CEN: 22, EAS: 33, GAR: 29, NES: 6,
  NOR: 16, OTI: 9, SAV: 7, UPE: 15, UPW: 11, VOL: 18, WES: 14, WNO: 9,
};

// 10a. Regions and districts
function checkLocations() {
  const regions = readJson(inRoot('shared/locations/regions.json'));
  const districts = readJson(inRoot('shared/locations/districts.json'));

  if (regions.length !== 16) fail(`shared/locations/regions.json: expected 16 regions, found ${regions.length}`);
  if (districts.length !== 261) fail(`shared/locations/districts.json: expected 261 districts, found ${districts.length}`);

  const districtIds = new Set<string>();

  for (const district of districts) {
    if (districtIds.has(district.id)) fail(`districts.json: duplicate id ${district.id}`);

    districtIds.add(district.id);

    if (!regions.some((region: any) => region.code === district.region)) fail(`districts.json: ${district.id} has unknown region ${district.region}`);
  }

  for (const [code, expected] of Object.entries(EXPECTED_DISTRICTS)) {
    const found = districts.filter((district: any) => district.region === code).length;

    if (found !== expected) fail(`districts.json: region ${code} has ${found} districts, expected ${expected}`);
  }
}

// 10b. Roles, ID types and set-up steps
function checkRolesAndIdTypes() {
  const roles = readJson(inRoot('shared/roles.json'));

  for (const [capability, rule] of Object.entries(roles.capabilities) as [string, any][]) {
    for (const role of rule.roles) {
      if (!roles.roles.includes(role)) fail(`shared/roles.json: ${capability} names unknown role "${role}"`);
    }

    if (![0, 1, 2].includes(rule.minLevel)) fail(`shared/roles.json: ${capability} minLevel must be 0, 1 or 2`);
  }

  // Every capability used in the code exists. The name can be in single or double quotes.
  const codeFiles = [...walk(inRoot('pages'), ['.ts', '.tsx']), ...walk(inRoot('components'), ['.tsx']), ...walk(inRoot('server'), ['.ts'])];

  for (const file of codeFiles) {
    for (const match of read(file).matchAll(/capability(?:=|:\s*)\{?["']([a-z_]+:[a-z_:]+)["']/g)) {
      if (!roles.capabilities[match[1]]) fail(`${relative(file)} uses unknown capability "${match[1]}"`);
    }
  }

  const idTypes = readJson(inRoot('shared/id-types.json'));

  for (const type of idTypes.types) {
    if (type.example && !new RegExp(type.pattern).test(type.example)) {
      fail(`shared/id-types.json: example for ${type.code} does not match its own pattern`);
    }

    if (!['nia', 'manual'].includes(type.checker)) fail(`shared/id-types.json: ${type.code} has unknown checker "${type.checker}"`);
  }

  const onboarding = readJson(inRoot('shared/onboarding.json'));

  for (const step of [...onboarding.requiredToFinish, ...onboarding.optionalButRecommended]) {
    if (!onboarding.steps.includes(step)) fail(`shared/onboarding.json: unknown step "${step}"`);
  }

  if (onboarding.otp.resendSeconds >= onboarding.otp.ttlSeconds) fail('shared/onboarding.json: otp.resendSeconds must be shorter than otp.ttlSeconds');
}

// 10c. The firebase/ folder: indexes and rules
function checkFirebaseFiles() {
  const indexes = readJson(inRoot('firebase/firestore.indexes.json'));
  const seen = new Set<string>();

  for (const index of indexes.indexes) {
    const key = index.collectionGroup + ':' + index.fields.map((field: any) => field.fieldPath + (field.order || '')).join(',');

    if (seen.has(key)) fail(`firestore.indexes.json: duplicate index ${key}`);

    seen.add(key);

    if (index.fields.length < 2) fail(`firestore.indexes.json: ${index.collectionGroup} index has fewer than 2 fields (single-field indexes are automatic)`);
  }

  const rules = read(inRoot('firebase/firestore.rules'));

  if (/if\s+true/.test(rules)) fail("firebase/firestore.rules: contains 'if true' (an open rule)");
  if (!/match \/\{document=\*\*\}[\s\S]*if false/.test(rules)) fail('firebase/firestore.rules: missing the final deny-all rule');

  const hasConflictMarkers = /<<<<<<<|>>>>>>>|=======/.test(rules) || /<<<<<<<|>>>>>>>/.test(read(inRoot('firebase/firestore.indexes.json')));

  if (hasConflictMarkers) fail('firebase/: merge-conflict markers found');
}

// 10d. Every database collection the server uses is documented
function checkCollectionsAreDocumented() {
  const collections = new Set<string>();

  for (const file of walk(inRoot('server'), ['.ts'])) {
    for (const match of read(file).matchAll(/(?:\btx|\bdb|\bs|\bstore\(\))\.(?:get|set|create|update|delete|add|query)\(\s*["'](\w+)["']/g)) {
      collections.add(match[1]);
    }
  }

  const accountsDoc = read(inRoot('docs/ACCOUNTS.md'));
  const databaseDoc = read(inRoot('docs/database.md'));

  for (const name of collections) {
    if (!accountsDoc.includes('`' + name + '`')) fail(`docs/ACCOUNTS.md does not describe the collection "${name}"`);
    if (!databaseDoc.includes('📁 ' + name + '/')) fail(`docs/database.md has no tree for the collection "${name}"`);
  }

  const indexCount = JSON.parse(read(inRoot('firebase/firestore.indexes.json'))).indexes.length;

  if (!/exactly these 12/.test(databaseDoc) || indexCount !== 12) fail('docs/database.md says 12 indexes but firebase/firestore.indexes.json differs');
}

// 10e. Every environment variable the server reads is explained in .env.local.example
function checkEnvironmentVariables() {
  const example = read(inRoot('.env.local.example'));

  const notNeeded = new Set([
    'NODE_ENV', 'PROJECT_ROOT', 'HOME', 'FIRESTORE_INDEXES_FILE', 'STORE_ENFORCE_INDEXES', 'STORE_FILE',
    'SMS_OUTBOX_FILE', 'SMS_MOCK_FAIL', 'GOOGLE_APPLICATION_CREDENTIALS', 'DEV_LINKS_FILE',
  ]);

  for (const file of walk(inRoot('server'), ['.ts'])) {
    for (const match of read(file).matchAll(/process\.env\.([A-Z][A-Z0-9_]+)/g)) {
      const name = match[1];
      const isExplained = new RegExp('^\\s*#?\\s*' + name + '\\s*=', 'm').test(example);

      if (!notNeeded.has(name) && !isExplained) fail(`${relative(file)} reads ${name}, which is not in .env.local.example`);
    }
  }

  // No secret may sit behind a NEXT_PUBLIC_ name, because those are sent to every browser.
  for (const match of example.matchAll(/NEXT_PUBLIC_[A-Z0-9_]*(SECRET|PEPPER|PRIVATE|PASSWORD|TOKEN)[A-Z0-9_]*/g)) {
    fail(`.env.local.example: ${match[0]} would be shipped to every browser`);
  }
}

// 10f. Navigation: every link in shared/nav.json is a real page and names real capabilities and roles
function checkNavigation() {
  const nav = readJson(inRoot('shared/nav.json'));
  const roles = readJson(inRoot('shared/roles.json'));

  for (const item of nav.items) {
    const pageFile = inRoot('pages', item.href.replace(/^\//, '') + '.tsx');

    if (!exists(pageFile)) fail(`shared/nav.json links to ${item.href}, but pages${item.href}.tsx does not exist`);

    if (item.capability && !roles.capabilities[item.capability]) fail(`shared/nav.json: ${item.href} names the unknown capability "${item.capability}"`);

    for (const role of item.roles || []) {
      if (!roles.roles.includes(role)) fail(`shared/nav.json: ${item.href} names the unknown role "${role}"`);
    }

    if (!item.public && !item.capability && !item.roles) fail(`shared/nav.json: ${item.href} has no capability, roles or public flag`);
  }
}

// 10g. Every account API route goes through withSession
function checkApiRoutes() {
  const routesWithoutSession = ['pages/api/wallet-link', 'pages/api/auth-check.ts']; // these have their own checks

  for (const file of walk(inRoot('pages/api'), ['.ts'])) {
    const name = relative(file);

    if (routesWithoutSession.some((prefix) => name.startsWith(prefix))) continue;

    const source = read(file);

    if (!/withSession\(/.test(source)) fail(`${name} does not use withSession (every account route must verify the signed-in user)`);

    const readsRoleFromBody = /\.role\s*=|body\.role|req\.body\)?\.uid/.test(source);

    if (readsRoleFromBody && !name.includes('/admin/')) fail(`${name} reads a role or uid from the request body`);
  }
}

// ---------------------------------------------------------------- run everything
checkChains();
checkAbis();
checkFrontEndUsesRealMethods();
checkNoBannedCode();
checkSolidity();
checkMigrations();
checkDeployments();
checkNetworkList();
checkNotifications();
checkLocations();
checkRolesAndIdTypes();
checkFirebaseFiles();
checkCollectionsAreDocumented();
checkEnvironmentVariables();
checkNavigation();
checkApiRoutes();

for (const warning of warnings) console.log('warning:', warning);

if (errors.length) {
  console.error(`\n${errors.length} consistency problem(s):`);

  for (const error of errors) console.error(' -', error);

  process.exit(1);
}

console.log(`Consistency check passed (${contracts.length} contracts, ${chains.length} chains, ${appFiles.length} app files).`);
