// READ-ONLY check before a deployment. Sends nothing.
//
//   yarn deploy:preflight --network sepolia
//   yarn deploy:preflight --network mainnet
//
// Shows which wallet would sign, that the RPC really is the chain you expect, the balance, the current fee, the rough
// cost, and whether the contracts are already recorded for that chain. Exits with an error code if anything is wrong.
import fs from 'fs';
import path from 'path';
import { Web3 } from 'web3';
import chainFile from '../shared/chains.json';
import { rpcUrl } from '../shared/rpc';

const GAS_FOR_FULL_DEPLOYMENT = 3_800_000n; // the three contracts, about 3.76M measured, rounded up
const CONTRACT_NAMES = ['VehicleRegistry', 'RevocationManager', 'LicenseRegistry'];

const chains = chainFile.chains;
const toEth = (wei: bigint) => (Number(wei) / 1e18).toFixed(5);
const toGwei = (wei: bigint) => (Number(wei) / 1e9).toFixed(3);

function networkFromArguments() {
  const at = process.argv.indexOf('--network');

  return at > -1 ? process.argv[at + 1] : undefined;
}

function recordedContracts(chainId: number) {
  try {
    const file = path.resolve(__dirname, '..', 'shared', 'deployments.json');
    const all = JSON.parse(fs.readFileSync(file, 'utf8'));
    const entry = all[String(chainId)];

    return entry ? CONTRACT_NAMES.filter((name) => entry[name] && entry[name].address) : [];
  } catch {
    return null; // file unreadable
  }
}

async function main() {
  const key = networkFromArguments();
  const chain = chains.find((c) => c.key === key);

  if (!key || !chain || chain.kind === 'Local') {
    const names = chains.filter((c) => c.kind !== 'Local').map((c) => c.key).join(' | ');
    console.error(`Usage: yarn deploy:preflight --network <${names}>`);
    process.exit(2);
  }

  const realMoney = !chain.testnet;
  const problems: string[] = [];
  const notes: string[] = [];

  // A real deployment needs two typed confirmations. This check sends nothing, so it satisfies them itself,
  // but it tells you if ALLOW_MAINNET_DEPLOY was already sitting in your shell.
  const allowWasSet = process.env.ALLOW_MAINNET_DEPLOY === 'yes';

  if (realMoney) {
    process.env.ALLOW_MAINNET_DEPLOY = 'yes';
    process.env.CONFIRM_CHAIN_ID = String(chain.chainId);
  }

  const config = require('../truffle-config.js');
  let provider: any;

  try {
    provider = config.networks[key].provider();
  } catch (error) {
    console.error('\nNOT READY:\n' + (error as Error).message);
    process.exit(1);
  }

  const host = (() => {
    try {
      return new URL(rpcUrl(chain)).host;
    } catch {
      return '(unreadable url)';
    }
  })();

  console.log(`\nNetwork      ${chain.name} (${chain.key}), expected chain id ${chain.chainId}${realMoney ? '   REAL MONEY' : '   test network'}`);
  console.log(`RPC host     ${host}   (the key part of the address is not shown)`);

  try {
    const web3 = new Web3(provider);
    const [account] = await web3.eth.getAccounts();
    const actualChain = Number(await web3.eth.getChainId());

    console.log(`Chain id     ${actualChain} ${actualChain === chain.chainId ? '(matches)' : '(DOES NOT MATCH)'}`);

    if (actualChain !== chain.chainId) {
      problems.push(`The RPC answered with chain ${actualChain}, but ${chain.name} is ${chain.chainId}. Fix RPC_URL_${key.toUpperCase()} or INFURA_PROJECT_ID.`);
    }

    console.log(`Deployer     ${account}`);

    const balance = BigInt(await web3.eth.getBalance(account));
    const price = BigInt(await web3.eth.getGasPrice());
    const ceiling = chain.chainId === 1 && process.env.MAX_FEE_GWEI ? BigInt(Math.round(Number(process.env.MAX_FEE_GWEI) * 1e9)) : null;
    const effective = ceiling && ceiling < price ? ceiling : price;
    const cost = effective * GAS_FOR_FULL_DEPLOYMENT;
    const symbol = (chain as { currency?: { symbol?: string } }).currency?.symbol || 'ETH';

    console.log(`Balance      ${toEth(balance)} ${symbol}`);
    console.log(`Gas price    ${toGwei(price)} gwei now${ceiling ? `, your ceiling ${toGwei(ceiling)} gwei` : ''}`);
    console.log(`Rough cost   about ${toEth(cost)} for all three contracts (${GAS_FOR_FULL_DEPLOYMENT.toLocaleString()} gas)`);

    if (balance < (cost * 12n) / 10n) problems.push(`The balance is below the rough cost plus a 20% margin. Add funds to ${account}.`);
    if (ceiling && price > ceiling) notes.push(`The network fee (${toGwei(price)} gwei) is above your MAX_FEE_GWEI ceiling: a deployment would wait until fees fall.`);
    if (chain.chainId === 1 && !process.env.MAX_FEE_GWEI) notes.push('No MAX_FEE_GWEI set: on Ethereum mainnet consider a ceiling, for example MAX_FEE_GWEI=30.');
  } catch (error) {
    problems.push('Could not talk to the network: ' + String((error as Error).message || error).split('\n')[0]);
  } finally {
    try {
      provider.engine?.stop();
    } catch {
      /* the wallet provider was already stopped */
    }
  }

  const recorded = recordedContracts(chain.chainId);

  if (recorded === null) {
    console.log('Recorded     (could not read shared/deployments.json)');
  } else {
    console.log(`Recorded     ${recorded.length ? recorded.join(', ') : 'nothing yet'} in shared/deployments.json`);

    if (recorded.length) {
      notes.push('Contracts are already recorded for this chain. A new deployment creates NEW contracts at new addresses; the old ones keep working and keep their data.');
    }
  }

  if (realMoney) {
    console.log('\nTo deploy for real, type these on the command line (see the README for PowerShell):');
    console.log(`  ALLOW_MAINNET_DEPLOY=yes CONFIRM_CHAIN_ID=${chain.chainId} npx truffle migrate --network ${key}`);

    if (allowWasSet) notes.push('ALLOW_MAINNET_DEPLOY=yes is set in your shell right now. Prefer typing it only for the one deploy.');
  }

  for (const note of notes) console.log('Note: ' + note);

  if (problems.length) {
    console.error('\nNOT READY:');
    for (const problem of problems) console.error(' - ' + problem);
    process.exit(1);
  }

  console.log('\nReady. Nothing was sent.');
  process.exit(0);
}

main();
