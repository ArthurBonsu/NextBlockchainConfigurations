// Decides WHICH wallet signs a deployment, by the kind of network.
// Used by truffle-config.js and scripts/preflight.ts.
//
//   Test networks (Sepolia, Base Sepolia, ...)   TESTNET_PRIVATE_KEY or TESTNET_MNEMONIC
//                                                (the older PRIVATE_KEY / MNEMONIC names still work)
//   Real-money networks (mainnet, Base, ...)     MAINNET_PRIVATE_KEY or MAINNET_MNEMONIC only.
//                                                There is NO fall-back, and it must not be the test wallet.
//
// Nothing here prints a secret. Error messages name the variable, never its value.

export interface ChainInfo {
  key: string;
  name: string;
  chainId: number;
  testnet: boolean;
}

export type Env = Record<string, string | undefined>;

export type WalletOptions = { mnemonic: { phrase: string } } | { privateKeys: string[] };

export interface DeployerWallet {
  options: WalletOptions;
  scope: 'testnet' | 'mainnet';
  source: string; // the variable the wallet came from, e.g. "TESTNET_PRIVATE_KEY"
  warning?: string;
}

interface Secret {
  prefix: string; // "TESTNET_", "MAINNET_" or "" (the older names)
  mnemonic: string;
  key: string;
}

const clean = (value: string | undefined) => String(value || '').trim();

function readSecret(prefix: string, env: Env): Secret {
  return {
    prefix,
    mnemonic: clean(env[prefix + 'MNEMONIC']),
    key: clean(env[prefix + 'PRIVATE_KEY']).replace(/^0x/i, ''),
  };
}

const isSet = (secret: Secret) => Boolean(secret.mnemonic || secret.key);

function checkShape(secret: Secret) {
  if (secret.mnemonic) {
    const words = secret.mnemonic.split(/\s+/).length;

    if (![12, 15, 18, 21, 24].includes(words)) {
      throw new Error(`${secret.prefix}MNEMONIC must be 12, 15, 18, 21 or 24 words (it has ${words}).`);
    }
  }

  if (secret.key && !/^[0-9a-fA-F]{64}$/.test(secret.key)) {
    throw new Error(`${secret.prefix}PRIVATE_KEY must be 64 hex characters (with or without a leading 0x).`);
  }
}

// Two secrets are "the same" when they spell the same words or the same key (case and 0x do not matter).
function fingerprint(secret: Secret) {
  if (secret.mnemonic) return 'words:' + secret.mnemonic.toLowerCase().replace(/\s+/g, ' ');

  return 'key:' + secret.key.toLowerCase();
}

function toWallet(secret: Secret, scope: DeployerWallet['scope']): DeployerWallet {
  checkShape(secret);

  if (secret.mnemonic) {
    return { options: { mnemonic: { phrase: secret.mnemonic } }, scope, source: `${secret.prefix}MNEMONIC` };
  }

  return { options: { privateKeys: [secret.key] }, scope, source: `${secret.prefix}PRIVATE_KEY` };
}

// The test wallet: TESTNET_* first, then the older names.
function readTestWallet(env: Env): Secret | null {
  const tagged = readSecret('TESTNET_', env);

  if (isSet(tagged)) return tagged;

  const older = readSecret('', env);

  return isSet(older) ? older : null;
}

function mainnetWallet(chain: ChainInfo, testWallet: Secret | null, env: Env): DeployerWallet {
  const secret = readSecret('MAINNET_', env);

  if (!isSet(secret)) {
    throw new Error(
      `"${chain.key}" (${chain.name}) is a real-money network, so it needs its own wallet.\n` +
        `Set MAINNET_PRIVATE_KEY=<64 hex> (or MAINNET_MNEMONIC="twelve words ...") in .env.local. ` +
        `The test-network wallet is never used for real money.`
    );
  }

  if (secret.mnemonic && secret.key) {
    throw new Error('Set only one of MAINNET_MNEMONIC and MAINNET_PRIVATE_KEY, not both: it would be unclear which one signs.');
  }

  checkShape(secret);

  if (testWallet && fingerprint(testWallet) === fingerprint(secret)) {
    throw new Error('The mainnet wallet is the same secret as the test-network wallet. Use a separate, dedicated wallet for real money.');
  }

  return toWallet(secret, 'mainnet');
}

function testnetWallet(chain: ChainInfo, secret: Secret | null): DeployerWallet {
  if (!secret) {
    throw new Error(
      `No deployer wallet found for "${chain.key}". Put TESTNET_PRIVATE_KEY=<64 hex> (or TESTNET_MNEMONIC="twelve words ...") in .env.local. ` +
        'Use a throwaway wallet that holds only test funds.'
    );
  }

  const bothSet = Boolean(secret.mnemonic && secret.key);
  // When both are given the mnemonic wins, and we say so.
  const chosen: Secret = bothSet ? { ...secret, key: '' } : secret;
  const wallet = toWallet(chosen, 'testnet');

  if (bothSet) wallet.warning = `Both ${secret.prefix}MNEMONIC and ${secret.prefix}PRIVATE_KEY are set; using the mnemonic.`;

  return wallet;
}

// chain: an entry of shared/chains.json.
export function walletFor(chain: ChainInfo, env: Env = process.env): DeployerWallet {
  const testWallet = readTestWallet(env);

  if (!chain.testnet) return mainnetWallet(chain, testWallet, env);

  return testnetWallet(chain, testWallet);
}
