// Imported FIRST by genRealStructure.ts: points the server code at a throwaway file store, the mock SMS outbox and
// throwaway development keys, so the sample documents are produced without touching any real data.
import fs from 'fs';
import os from 'os';
import path from 'path';

const root = path.resolve(__dirname, '..', '..');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ct-structure-'));

Object.assign(process.env, {
  NODE_ENV: 'test',
  STORE_BACKEND: 'file',
  STORE_FILE: path.join(dir, 'store.json'),
  SMS_PROVIDER: 'mock',
  SMS_OUTBOX_FILE: path.join(dir, 'sms.jsonl'),
  NOTIFY_BACKEND: 'dev',
  PROJECT_ROOT: root,
});

delete process.env.ID_HASH_PEPPER;
delete process.env.OTP_SECRET;
delete process.env.ID_ENC_KEY;

// The code warns that development keys are in use; that is expected here.
console.warn = () => {};
