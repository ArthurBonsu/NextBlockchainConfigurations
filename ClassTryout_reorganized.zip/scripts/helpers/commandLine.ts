// scripts/helpers/commandLine.ts
// Reading options like  --role admin  or  --list  from the command line.

export function argValue(name: string): string | undefined {
  const position = process.argv.indexOf(`--${name}`);

  return position > -1 ? process.argv[position + 1] : undefined;
}

export function hasFlag(name: string): boolean {
  return process.argv.includes(`--${name}`);
}

// Runs the main function of a script. A failure prints one clear line and exits with a non-zero code.
export function runScript(main: () => Promise<void>): void {
  main().catch((error) => {
    console.error('Failed:', error && error.message ? error.message : error);
    process.exit(1);
  });
}
