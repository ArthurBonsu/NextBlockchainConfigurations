// scripts/idMaintenance.ts
// Run this on a schedule (once an hour is plenty):
// it does the automated ID checks that are due, then deletes ID numbers that nobody decided on in time.
//
//   yarn accounts:id-maintenance            both
//   yarn accounts:id-maintenance --purge    only the clean-up
//
// With no automated checker switched on (ID_CHECK_NIA unset) the first step does nothing, and every ID waits for a human.

import '../server/config';
import { processDue, purgeExpired } from '../server/identity';
import { hasFlag, runScript } from './helpers/commandLine';

runScript(async () => {
  if (!hasFlag('purge')) console.log('checks:', JSON.stringify(await processDue()));

  console.log('purged:', await purgeExpired());
});
