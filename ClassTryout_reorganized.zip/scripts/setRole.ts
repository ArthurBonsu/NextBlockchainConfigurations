// scripts/setRole.ts
// Gives an account a role from the command line. This is how the FIRST super administrator is made
// (nobody can promote themselves through the app). Run it on a machine that has the server .env.local.
//
//   yarn accounts:set-role --email you@example.com --role super_admin
//   yarn accounts:set-role --uid <firebase uid> --role officer
//   yarn accounts:set-role --email you@example.com --role super_admin --confirm-identity
//        (also marks their ID as confirmed: ONLY for founding administrators whose ID you have seen in person,
//         because the first reviewer cannot be confirmed by anyone else. It is written to the audit log.)
//   yarn accounts:set-role --list           shows the admins and officers
//
// The person must have signed in once, so their profile exists. Their sessions are ended so the new role applies at once.

import '../server/config';
import { roles } from '../server/auth';
import { store } from '../server/database';
import { assignRole, bootstrapConfirmIdentity, listUsers } from '../server/users';
import { argValue, hasFlag, runScript } from './helpers/commandLine';

async function listAdminsAndOfficers() {
  for (const role of ['super_admin', 'admin', 'officer']) {
    for (const user of await listUsers({ role })) {
      console.log(`${role.padEnd(12)} ${user.uid}  ${user.email || '(no email)'}  ${user.status}`);
    }
  }
}

// The person is named by --uid, or by --email (looked up in the database).
async function findUid(): Promise<string> {
  const uid = argValue('uid');

  if (uid) return uid;

  const email = argValue('email');

  if (!email) {
    console.error('Give --email or --uid.');
    process.exit(2);
  }

  const rows = await store().query('users', { where: [['email', '==', email.toLowerCase()]], limit: 2 });

  if (rows.length !== 1) {
    console.error(rows.length ? 'More than one account has that email; use --uid.' : 'No account has that email. Ask them to sign in once first.');
    process.exit(1);
  }

  return rows[0].uid;
}

runScript(async () => {
  if (hasFlag('list')) {
    await listAdminsAndOfficers();
    return;
  }

  const role = argValue('role');

  if (!role || !roles.ROLES.includes(role)) {
    console.error(`Usage: yarn accounts:set-role (--email <address> | --uid <uid>) --role <${roles.ROLES.join('|')}>`);
    process.exit(2);
  }

  const uid = await findUid();
  const user = await assignRole({ uid: 'system', role: 'system' }, uid, role, null);

  if (hasFlag('confirm-identity')) {
    await bootstrapConfirmIdentity(uid, argValue('note'));
    console.log('Identity marked confirmed (bootstrap, audit-logged).');
  }

  console.log(`OK: ${user.email || user.uid} is now ${user.role}. They must sign in again.`);
});
