// scripts/recordDeployment.ts
// Called by the migrations. It records where a contract was deployed, so the app can find it.
//
//   Public chains (listed in shared/chains.json, not "Local") go to shared/deployments.json, keyed by chain id.
//   Commit that file: it is how the front end learns the addresses.
//
//   Anything else (Ganache, any private chain) goes to shared/deployments.local.json, keyed by network id.
//   That file is git-ignored, because local addresses change every time you reset.
//
// Each entry also keeps the deployment block, so the history page scans only from there instead of from block 0
// (public RPC servers refuse to scan from block 0 on long-running chains).
//
// The migrations are plain JavaScript (Truffle requires that), so they load this file with:
//   require('tsx/cjs');   (once, in truffle-config.js)
//   const recordDeployment = require('../scripts/recordDeployment').default;

import fs from 'fs';
import path from 'path';

const sharedDir = path.resolve(__dirname, '..', 'shared');
const { chains } = JSON.parse(fs.readFileSync(path.join(sharedDir, 'chains.json'), 'utf8'));

function readJson(file: string, fallback: Record<string, any>): Record<string, any> {
  return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : fallback;
}

// Truffle gives the migration these objects. We only need a few things from each, so we describe just those.
export interface RecordDeploymentInput {
  web3: any; // Truffle's global web3
  networkId: number | string;
  contractName: string;
  instance: { address: string; transactionHash?: string };
  contractClass?: { networks?: Record<string, { transactionHash?: string }> };
  blockBefore?: number | string; // web3.eth.getBlockNumber() read just before deploying
}

export default async function recordDeployment({ web3, networkId, contractName, instance, contractClass, blockBefore }: RecordDeploymentInput) {
  const chainId = Number(await web3.eth.getChainId());

  const network = contractClass && contractClass.networks && contractClass.networks[String(networkId)];
  const txHash = instance.transactionHash || (network && network.transactionHash) || null;

  // The contract cannot have been deployed in an earlier block than `blockBefore`, so scanning from there never misses an event.
  let startBlock = Number(blockBefore || 0);

  if (txHash) {
    const receipt = await web3.eth.getTransactionReceipt(txHash);

    if (receipt) startBlock = Number(receipt.blockNumber);
  }

  const knownChain = chains.find((chain: any) => chain.chainId === chainId && chain.kind !== 'Local');
  const file = path.join(sharedDir, knownChain ? 'deployments.json' : 'deployments.local.json');
  const key = String(knownChain ? chainId : networkId);

  const allDeployments = readJson(file, {});
  const entry = allDeployments[key] || {};

  entry.chainId = chainId;
  entry.networkId = String(networkId);
  entry[contractName] = { address: instance.address, txHash: txHash || null, startBlock };
  entry.updatedAt = new Date().toISOString();

  allDeployments[key] = entry;

  fs.writeFileSync(file, JSON.stringify(allDeployments, null, 2) + '\n');

  const where = knownChain ? knownChain.name : 'local chain ' + key;

  console.log(`   > recorded ${contractName} for ${where} in ${path.basename(file)} (block ${startBlock})`);
}
