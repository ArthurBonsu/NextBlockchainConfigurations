// scripts/reviewId.ts
// Command-line ID review, for the early days before an admin screen is used. It does the same checks as the API
// and is audit-logged.
//
//   yarn accounts:review-id list [--status pending_review]
//   yarn accounts:review-id show   <docId> --as <your admin uid>      (shows the number; this is logged)
//   yarn accounts:review-id verify <docId> --as <your admin uid> [--note "text"]
//   yarn accounts:review-id reject <docId> --as <your admin uid> [--note "text"]

import '../server/config';
import { roles } from '../server/auth';
import { decide, revealNumber, reviewQueue } from '../server/identity';
import { onboardingState, requireUser } from '../server/users';
import { argValue, runScript } from './helpers/commandLine';

const [command, docId] = process.argv.slice(2);

// Who is doing the review. The decision is attributed to this person.
async function findReviewer() {
  const uid = argValue('as');

  if (!uid) throw new Error('Add --as <your admin uid> so the decision is attributed to you.');

  const user = await requireUser(uid);
  const answer = roles.check(user, 'admin:ids:review', { onboardingComplete: onboardingState(user).complete });

  if (!answer.allowed) throw new Error(`Account ${uid} may not review IDs (${answer.reason}).`);

  return { uid: user.uid, role: user.role };
}

async function listWaiting() {
  const rows = await reviewQueue({ status: argValue('status') || 'pending_review' });

  if (!rows.length) console.log('Nothing waiting.');

  for (const row of rows) {
    console.log(`${row.id}  ${row.type.padEnd(11)} ••••${row.last4}  owner ${row.uid}  ${row.createdAt}`);
  }
}

runScript(async () => {
  if (command === 'list') {
    await listWaiting();
  } else if (command === 'show') {
    const answer = await revealNumber(await findReviewer(), docId, null);

    console.log(JSON.stringify(answer, null, 2));
  } else if (command === 'verify' || command === 'reject') {
    const decision = command === 'verify' ? 'verified' : 'rejected';

    await decide({ docId, decision, by: await findReviewer(), note: argValue('note'), checker: 'manual' });

    console.log(`OK: ${docId} ${command === 'verify' ? 'confirmed' : 'rejected'}.`);
  } else {
    console.error('Commands: list | show <id> | verify <id> | reject <id>   (see the comment at the top of this file)');
    process.exit(2);
  }
});
