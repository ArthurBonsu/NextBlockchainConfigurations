// scripts/genRealStructure.ts
// Writes docs/firebaserealstructure.txt: what REAL documents look like, in the same layout as the Firebase console's
// "field / value / (type)" listing. The documents are produced by running the actual server code (on the local file store)
// with made-up people, so the shapes cannot drift from the code. Hash and ciphertext values are genuine outputs of the code
// with throwaway development keys: they are examples, not anyone's data.
//
//   yarn docs:structure            rewrite docs/firebaserealstructure.txt
//   yarn docs:structure --check    fail if a field the code writes is missing from docs/database.md

import './helpers/sampleEnv'; // must stay first: it sets up the throwaway store before the server code loads

import fs from 'fs';
import path from 'path';
import * as helpers from '../test/accounts/helpers';
import * as users from '@/server/users';
import * as otp from '@/server/phone';
import * as identity from '@/server/identity';
import { store } from '@/server/database';
import { hit } from '@/server/security';

const root = path.resolve(__dirname, '..');

type Json = null | boolean | number | string | Json[] | { [key: string]: Json };
type Doc = Record<string, Json>;

const SYSTEM = { uid: 'system', role: 'system' };

// ---- a small, believable scenario ---------------------------------------------------------------------------------

async function createPerson(uid: string, email: string, phone: string): Promise<void> {
  await helpers.complete(uid, phone);
  await store().update('users', uid, { email });
}

async function runScenario(): Promise<void> {
  await createPerson('uid_EXAMPLE_citizen', 'ama.mensah@example.test', '0241234567');
  await users.saveNotificationPrefs('uid_EXAMPLE_citizen', { sms: false });

  const citizenId = await identity.submitDocument('uid_EXAMPLE_citizen', { type: 'ghana_card', number: 'GHA-123456789-0' }, '203.0.113.7');

  await createPerson('uid_EXAMPLE_admin', 'kwame.admin@example.test', '0551234567');
  await users.assignRole(SYSTEM, 'uid_EXAMPLE_admin', 'super_admin', null);
  await users.bootstrapConfirmIdentity('uid_EXAMPLE_admin', 'Confirmed in person');

  const admin = await users.requireUser('uid_EXAMPLE_admin');

  await identity.decide({
    docId: citizenId.id,
    decision: 'verified',
    by: { uid: admin.uid, role: admin.role },
    note: 'Matches card',
    checker: 'manual',
  });

  await createPerson('uid_EXAMPLE_officer', 'yaw.officer@example.test', '0261234567');
  await users.assignRole(admin, 'uid_EXAMPLE_officer', 'officer', '203.0.113.9');

  const expiry = new Date(Date.now() + 4 * 365 * 864e5).toISOString().slice(0, 10);

  // still pending: this one shows the encrypted number
  await identity.submitDocument('uid_EXAMPLE_officer', { type: 'passport', number: 'G1234567', country: 'GH', expiry }, null);

  // someone part-way through onboarding: a live phone code and no ID
  await users.ensureUser(helpers.auth('uid_EXAMPLE_newcomer', 'efua.new@example.test', false));
  await users.saveConsents('uid_EXAMPLE_newcomer', { terms: true, privacy: true, sms: true }, '198.51.100.4');
  await otp.startPhoneVerification('uid_EXAMPLE_newcomer', '0201234567', '198.51.100.4');

  await users.saveAddress('uid_EXAMPLE_officer', {
    regionCode: 'ASH',
    districtId: 'ASH-kumasi',
    city: 'Kumasi',
    suburb: 'Adum',
    subarea: 'Near the market',
    gpsAddress: 'AK-039-5028',
    lat: 6.6885,
    lng: -1.6244,
  });

  await hit('otp:ip:198.51.100.4', 20, 3600);

  const wallet = '0x90f8bf6a479f320ead074411a4b0e7944ea8c9c1';

  await store().set('walletLinks', wallet, { uid: 'uid_EXAMPLE_citizen', address: wallet, linkedAt: new Date().toISOString() });
}

// ---- rendering (same layout as the Firebase console listing) ------------------------------------------------------

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

// the only field stored as a real Firestore Timestamp; every other time is an ISO string
const TIMESTAMP_FIELDS = new Set(['expireAt']);

function timestampText(iso: string): string {
  const date = new Date(iso);
  const hours = date.getUTCHours();
  const period = hours >= 12 ? 'PM' : 'AM';
  const pad = (n: number) => String(n).padStart(2, '0');

  return (
    `${MONTHS[date.getUTCMonth()]} ${date.getUTCDate()}, ${date.getUTCFullYear()} at ` +
    `${hours % 12 || 12}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())} ${period} UTC+0`
  );
}

function render(key: string, value: Json, out: string[]): void {
  if (value === null) {
    out.push(key, 'null', '(null)', '', '');
  } else if (Array.isArray(value)) {
    out.push('', key, '(array)', '', '');
    value.forEach((item, index) => render(String(index), item, out));
  } else if (typeof value === 'object') {
    out.push('', key, '(map)', '', '');
    Object.keys(value)
      .sort()
      .forEach((name) => render(name, value[name], out));
  } else if (typeof value === 'boolean') {
    out.push(key, String(value), '(boolean)', '', '');
  } else if (typeof value === 'number') {
    out.push(key, String(value), Number.isInteger(value) ? '(int64)' : '(double)', '', '');
  } else if (TIMESTAMP_FIELDS.has(key)) {
    out.push(key, timestampText(value), '(timestamp)', '', '');
  } else {
    out.push(key, JSON.stringify(value), '(string)', '', '');
  }
}

function renderDocument(doc: Doc, out: string[]): void {
  Object.keys(doc)
    .sort()
    .forEach((key) => render(key, doc[key], out));
}

// Every field name that appears anywhere inside a document.
function fieldNames(value: Json, found = new Set<string>()): Set<string> {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    for (const [key, inner] of Object.entries(value)) {
      found.add(key);
      fieldNames(inner, found);
    }
  }

  return found;
}

// the order in which collections are explained; the example for each is one real document
const COLLECTIONS = [
  'users',
  'identityDocuments',
  'identityClaims',
  'phoneChallenges',
  'phoneClaims',
  'locationSuggestions',
  'rateLimits',
  'auditLogs',
  'walletLinks',
];

function chooseExample(collection: string, docs: Record<string, Doc>): string {
  const ids = Object.keys(docs);

  if (collection === 'users') return 'uid_EXAMPLE_citizen';
  if (collection === 'identityDocuments') return ids.find((id) => docs[id].status === 'pending_review') || ids[0];
  if (collection === 'auditLogs') return ids.find((id) => docs[id].action === 'user.role') || ids[0];

  return ids[0];
}

function shortId(collection: string, id: string): string {
  if (collection === 'users' || collection === 'phoneChallenges') return id;

  return id.length > 40 ? id.slice(0, 12) + '…' : id;
}

// ---- the two things this script can do ----------------------------------------------------------------------------

function buildListing(database: Record<string, Record<string, Doc>>): { text: string; seen: Record<string, Set<string>> } {
  const out: string[] = [
    '[Real structure of the ClassTryout Firestore database: one real document per collection, produced by running the actual code',
    ' with made-up people (names, numbers and ids are examples). Layout follows the Firebase console listing: field, value, (type).',
    ' Every time is an ISO-8601 STRING except `expireAt`, a real Timestamp used by the TTL clean-up. Hash and ciphertext values are',
    ' genuine outputs of the code with throwaway development keys. Regenerate with:  yarn docs:structure ]',
    '',
  ];

  const seen: Record<string, Set<string>> = {};

  for (const collection of COLLECTIONS) {
    const docs = database[collection] || {};

    if (!Object.keys(docs).length) continue;

    const id = chooseExample(collection, docs);

    out.push(`${collection}: `, `(document id: ${shortId(collection, id)})`, '');
    renderDocument(docs[id], out);
    out.push('');

    // every document of the collection counts for the "is it documented" check, not only the one printed
    seen[collection] = new Set<string>();
    Object.values(docs).forEach((doc) => fieldNames(doc).forEach((name) => seen[collection].add(name)));

    if (collection === 'identityDocuments') {
      // a confirmed one, to show the number is gone after the decision
      const confirmedId = Object.keys(docs).find((key) => docs[key].status === 'verified');

      if (confirmedId) {
        out.push('identityDocuments (after confirmation): ', `(document id: ${confirmedId})`, '');
        renderDocument(docs[confirmedId], out);
        out.push('');
      }
    }
  }

  return { text: out.join('\n').replace(/\n{4,}/g, '\n\n\n'), seen };
}

// Looks for each field name inside the part of docs/database.md that describes its collection.
function findUndocumentedFields(seen: Record<string, Set<string>>): string[] {
  const markdown = fs.readFileSync(path.join(root, 'docs/database.md'), 'utf8');
  const missing: string[] = [];

  for (const [collection, fields] of Object.entries(seen)) {
    const start = markdown.indexOf(`📁 ${collection}/`);

    if (start < 0) {
      missing.push(`${collection} (collection not in docs/database.md)`);
      continue;
    }

    const ends = [markdown.indexOf('\n├── 📁', start + 10), markdown.indexOf('\n└── 📁', start + 10)].filter((n) => n > 0);
    const end = ends.length ? Math.min(...ends) : undefined;
    const section = markdown.slice(start, end);

    for (const field of fields) {
      const escaped = field.replace(/[$]/g, '\\$');
      const listed = new RegExp(`[├└│ ]\\s*${escaped}\\??:`).test(section) || section.includes(`${field}:`);

      if (!listed) missing.push(`${collection}.${field}`);
    }
  }

  return missing;
}

async function main(): Promise<void> {
  await runScenario();

  const database = JSON.parse(fs.readFileSync(process.env.STORE_FILE as string, 'utf8'));
  const { text, seen } = buildListing(database);

  if (process.argv.includes('--check')) {
    const missing = findUndocumentedFields(seen);

    if (missing.length) {
      console.error('docs/database.md is missing fields the code writes:\n - ' + missing.join('\n - '));
      process.exit(1);
    }

    console.log(`docs/database.md covers every field the code wrote in the sample (${Object.keys(seen).length} collections).`);

    return;
  }

  fs.writeFileSync(path.join(root, 'docs/firebaserealstructure.txt'), text + '\n');
  console.log(`Wrote docs/firebaserealstructure.txt (${text.split('\n').length} lines, ${Object.keys(seen).length} collections).`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
