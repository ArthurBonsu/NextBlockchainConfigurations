// -----------------------------------------------------------------------------
// Truffle config. Read it top to bottom: local chain, then free test networks, then real-money networks.
// The network list comes from shared/chains.json, the same file the front end uses, so chain ids never disagree.
//
//   yarn deploy:local                              local Ganache (run `yarn chain` first)
//   yarn deploy:sepolia                            a free test network: signed by the TESTNET_ wallet
//   yarn deploy:preflight --network mainnet        READ-ONLY check: wallet, balance, fee, rough cost
//   ALLOW_MAINNET_DEPLOY=yes CONFIRM_CHAIN_ID=1 npx truffle migrate --network mainnet      REAL MONEY
//
// Wallets (in .env.local, never committed, never behind a NEXT_PUBLIC_ name):
//   test networks         TESTNET_PRIVATE_KEY or TESTNET_MNEMONIC     (rules: scripts/deployerWallet.ts)
//   real-money networks   MAINNET_PRIVATE_KEY or MAINNET_MNEMONIC     (must be a different wallet)
//
// Real money needs three typed things so one typo cannot spend it:
//   ALLOW_MAINNET_DEPLOY=yes   CONFIRM_CHAIN_ID=<that network's chain id>   and (advised on Ethereum) MAX_FEE_GWEI=<ceiling>
// RPC address: RPC_URL_<KEY>, then ETHEREUM_PROVIDER_URL (mainnet), then Infura (INFURA_PROJECT_ID), then a public RPC.
// -----------------------------------------------------------------------------
const fs = require("fs");
const path = require("path");
const dotenv = require("dotenv");
const HDWalletProvider = require("@truffle/hdwallet-provider");
const { chains } = require("./shared/chains.json");

// The shared helpers are TypeScript. This line lets Truffle (plain JavaScript) load .ts files.
require("tsx/cjs");
const { rpcUrl } = require("./shared/rpc");
const { walletFor } = require("./scripts/deployerWallet");

// Truffle only reads ".env" on its own. Load ".env.local" as well (the first file that sets a variable wins).
for (const file of [".env.local", ".env"]) {
  const filePath = path.resolve(__dirname, file);
  if (fs.existsSync(filePath)) dotenv.config({ path: filePath });
}

// ---- Helpers ----------------------------------------------------------------

const announced = new Set(); // say which wallet is deploying once per network, not on every call

// Opens the wallet for one network. Called only when you run `--network <key>`, so no key is needed before that.
function openWallet(chain) {
  const wallet = walletFor(chain);
  const provider = new HDWalletProvider({ ...wallet.options, providerOrUrl: rpcUrl(chain) });

  if (!announced.has(chain.key)) {
    announced.add(chain.key);
    if (wallet.warning) console.log(`   ! ${wallet.warning}`);
    console.log(`   > ${chain.name} (chain ${chain.chainId}): deploying as ${provider.getAddresses()[0]}  [wallet from ${wallet.source}]`);
  }

  return provider;
}

// The two typed confirmations that real money needs.
function requireRealMoneyConfirmation(chain) {
  if (process.env.ALLOW_MAINNET_DEPLOY !== "yes") {
    throw new Error(
      `"${chain.key}" (${chain.name}) is a REAL-MONEY network. To deploy for real:\n` +
        `  ALLOW_MAINNET_DEPLOY=yes CONFIRM_CHAIN_ID=${chain.chainId} npx truffle migrate --network ${chain.key}`
    );
  }

  const confirmed = String(process.env.CONFIRM_CHAIN_ID || "").trim();
  if (confirmed !== String(chain.chainId)) {
    throw new Error(`Also set CONFIRM_CHAIN_ID=${chain.chainId} to confirm you mean ${chain.name}. (You gave "${confirmed}".)`);
  }
}

const gwei = (value) => Math.round(Number(value) * 1e9);

// ---- 1. Local chain ---------------------------------------------------------

const networks = {};

// `truffle test` uses a "development" network when one is configured. Leaving it out while testing makes
// Truffle spin up its own throwaway chain, so `yarn contracts:test` needs no Ganache running.
if (!process.argv.includes("test")) {
  networks.development = { host: "127.0.0.1", port: 7545, network_id: "*" };
}

// ---- 2. Free test networks (Sepolia, Base Sepolia, ...) ---------------------

function testNetwork(chain) {
  return {
    provider: () => openWallet(chain),
    network_id: chain.chainId, // Truffle refuses to continue if the RPC answers with a different chain
    confirmations: 2,
    timeoutBlocks: 200,
    skipDryRun: true, // skip the simulation to save time
  };
}

// ---- 3. Real-money networks (Ethereum mainnet, Base, ...) -------------------

function liveNetwork(chain) {
  const network = {
    provider: () => {
      requireRealMoneyConfirmation(chain);
      return openWallet(chain);
    },
    network_id: chain.chainId,
    confirmations: 5,
    timeoutBlocks: 500,
    skipDryRun: false, // simulate first
  };

  // A fee ceiling, for Ethereum mainnet only (a low cap could stall the L2s). The transaction waits instead of overpaying.
  if (chain.chainId === 1 && process.env.MAX_FEE_GWEI) {
    network.maxFeePerGas = gwei(process.env.MAX_FEE_GWEI);
    network.maxPriorityFeePerGas = Math.min(gwei(process.env.MAX_PRIORITY_GWEI || 2), network.maxFeePerGas);
  }

  return network;
}

for (const chain of chains) {
  if (chain.kind === "Local") continue;
  networks[chain.key] = chain.testnet ? testNetwork(chain) : liveNetwork(chain);
}

// ---- Compiler and folders ---------------------------------------------------

// Etherscan verification is optional: the plugin switches on only when it is installed.
//   yarn add -D truffle-plugin-verify   then   truffle run verify VehicleRegistry --network <key>
const plugins = [];
try {
  require.resolve("truffle-plugin-verify");
  plugins.push("truffle-plugin-verify");
} catch {
  /* not installed */
}

module.exports = {
  networks,
  plugins,
  api_keys: { etherscan: process.env.ETHERSCAN_API_KEY || "" },
  compilers: {
    solc: {
      version: "0.8.20",
      settings: {
        // "paris" avoids the PUSH0 opcode that solc 0.8.20 emits by default, so the same bytecode
        // deploys on every chain in shared/chains.json, including any L2 that lacks PUSH0.
        evmVersion: "paris",
        optimizer: { enabled: true, runs: 200 },
      },
    },
  },
  contracts_directory: "./contracts",
  contracts_build_directory: "./build/contracts",
  migrations_directory: "./migrations",
  test_directory: "./test",
  db: { enabled: false },
};
