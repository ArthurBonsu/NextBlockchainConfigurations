// hooks/useLicenseLookup.ts
// Looking up a licence by its id, or by the vehicle it belongs to.
// The licence panel and its admin buttons share this, so after an admin revokes a licence the result refreshes itself.

import { useState } from 'react';
import { findLicenseIdByVehicle, lookUpLicense, NO_LICENSE } from '@/blockchain/contracts/LicenseRegistry';
import { useActionStatus } from './useActionStatus';
import type { LicenseInfo } from '@/blockchain/types';

export function useLicenseLookup() {
  const [licenseId, setLicenseId] = useState('');
  const [vehicleToFind, setVehicleToFind] = useState('');
  const [licenseInfo, setLicenseInfo] = useState<LicenseInfo | null>(null);
  const [foundId, setFoundId] = useState('');

  const idStatus = useActionStatus();
  const vehicleStatus = useActionStatus();

  async function lookUpById(idOverride?: string) {
    const id = (typeof idOverride === 'string' ? idOverride : licenseId).trim();

    if (!id) return;

    idStatus.showPending('Reading from chain...');
    setLicenseInfo(null);

    try {
      const info = await lookUpLicense(id);

      setFoundId(id);
      setLicenseInfo(info);
      idStatus.clear();
    } catch (err) {
      idStatus.showError(err);
    }
  }

  async function findByVehicle() {
    const vehicle = vehicleToFind.trim();

    if (!vehicle) return;

    vehicleStatus.showPending('Reading from chain...');

    try {
      const id = await findLicenseIdByVehicle(vehicle);

      if (!id) {
        setLicenseInfo({ ...NO_LICENSE });
        vehicleStatus.clear();
        return;
      }

      setLicenseId(id);
      vehicleStatus.clear();

      await lookUpById(id);
    } catch (err) {
      vehicleStatus.showError(err);
    }
  }

  return {
    licenseId,
    setLicenseId,
    vehicleToFind,
    setVehicleToFind,
    licenseInfo,
    foundId,
    idStatus: idStatus.status,
    vehicleStatus: vehicleStatus.status,
    lookUpById,
    findByVehicle,
  };
}
