// hooks/useUsersTable.ts
// All the state and server calls behind the admin users table:
// the filters, the list of users, "load more", and suspend / restore / change role.

import { useCallback, useEffect, useState } from 'react';
import { useAccount } from '@/components/Authentication';
import { api, ApiError } from '@/services/api';
import type { PendingUserChange, UserFilterGroup, UserRowData } from '@/types';

const PAGE_SIZE = 25;

export function useUsersTable() {
  const { me } = useAccount();

  const can = (capability: string) => !!(me && me.capabilities[capability] && me.capabilities[capability].allowed);
  const canChangeStatus = can('admin:users:status');
  const canChangeRole = can('admin:roles:assign');

  // Filters
  const [group, setGroup] = useState<UserFilterGroup>('role');
  const [role, setRole] = useState('');
  const [status, setStatus] = useState('');
  const [email, setEmail] = useState('');
  const [level, setLevel] = useState('');
  const [region, setRegion] = useState('');

  // Results
  const [rows, setRows] = useState<UserRowData[]>([]);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [flash, setFlash] = useState('');

  // A change waiting for the admin to confirm
  const [pending, setPending] = useState<PendingUserChange | null>(null);
  const [note, setNote] = useState('');
  const [newRole, setNewRole] = useState('');
  const [busy, setBusy] = useState(false);

  // Builds the URL for the server. Only the filters of the chosen group are used.
  const buildUrl = useCallback(
    (before?: string) => {
      const params = new URLSearchParams();

      if (group === 'role') {
        if (role) params.set('role', role);
        if (status) params.set('status', status);
      }

      if (group === 'email' && email.trim()) params.set('email', email.trim());
      if (group === 'level' && level !== '') params.set('level', level);
      if (group === 'region' && region) params.set('regionCode', region);

      if (before) params.set('before', before);
      params.set('limit', String(PAGE_SIZE));

      return `/api/admin/users?${params.toString()}`;
    },
    [group, role, status, email, level, region]
  );

  // These groups need a value before the server can be asked.
  const waitingForInput =
    (group === 'level' && level === '') || (group === 'region' && !region) || (group === 'email' && !email.trim());

  const load = useCallback(
    async (append = false) => {
      if (waitingForInput) {
        setRows([]);
        setHasMore(false);
        return;
      }

      setLoading(true);
      setError('');

      try {
        const before = append && rows.length ? rows[rows.length - 1].createdAt : undefined;
        const answer = await api<{ users: UserRowData[] }>(buildUrl(before));

        setRows(append ? [...rows, ...answer.users] : answer.users);
        setHasMore(answer.users.length === PAGE_SIZE && group !== 'email');
      } catch (err) {
        setError(err instanceof ApiError ? err.message : 'Could not load users.');
      } finally {
        setLoading(false);
      }
    },
    [buildUrl, rows, group, waitingForInput]
  );

  // Reload when a filter changes. (Email waits for the Search button.)
  useEffect(() => {
    load(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [group, role, status, level, region]);

  function startChange(change: PendingUserChange) {
    setPending(change);
    setNote('');
    setNewRole(change.role || '');
  }

  function chooseNewRole(role: string) {
    setNewRole(role);

    if (pending) setPending({ ...pending, role });
  }

  async function confirmChange() {
    if (!pending) return;

    setBusy(true);
    setError('');
    setFlash('');

    try {
      if (pending.kind === 'role') {
        await api(`/api/admin/users/${pending.uid}/role`, { method: 'POST', body: { role: pending.role } });
      } else {
        await api(`/api/admin/users/${pending.uid}/status`, {
          method: 'POST',
          body: { status: pending.kind === 'suspend' ? 'suspended' : 'active', note: note.trim() || undefined },
        });
      }

      if (pending.kind === 'role') setFlash('Role changed.');
      if (pending.kind === 'suspend') setFlash('Account suspended.');
      if (pending.kind === 'restore') setFlash('Account restored.');

      setPending(null);
      setNote('');
      setNewRole('');

      await load(false);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'That did not work.');
    } finally {
      setBusy(false);
    }
  }

  return {
    me,
    canChangeStatus,
    canChangeRole,
    filters: { group, role, status, email, level, region },
    setGroup,
    setRole,
    setStatus,
    setEmail,
    setLevel,
    setRegion,
    rows,
    hasMore,
    loading,
    error,
    flash,
    pending,
    setPending,
    note,
    setNote,
    newRole,
    busy,
    load,
    startChange,
    chooseNewRole,
    confirmChange,
  };
}
