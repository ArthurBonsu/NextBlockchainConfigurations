// hooks/useFormSubmit.ts
// Runs a form's save function and keeps track of three things:
//   busy    true while saving (disable the button)
//   error   a sentence to show above the form when saving failed
//   fields  per-field messages from the server, like { phone: "That number is not valid." }

import { FormEvent, useState } from 'react';
import { ApiError } from '@/services/api';

type FieldMessages = Record<string, string>;

export function useFormSubmit(save: (event: FormEvent) => Promise<unknown>) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [fields, setFields] = useState<FieldMessages>({});

  async function run(event: FormEvent) {
    event.preventDefault();

    setBusy(true);
    setError('');
    setFields({});

    try {
      await save(event);
    } catch (err: any) {
      setError(err && err.message ? err.message : 'Something went wrong.');

      if (err instanceof ApiError) setFields(err.fields);
    }

    setBusy(false);
  }

  return { busy, error, fields, run, setError };
}
