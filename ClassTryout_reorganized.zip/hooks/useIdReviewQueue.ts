// hooks/useIdReviewQueue.ts
// The state and server calls behind the ID review queue:
// the list, "load more", showing a number for a few seconds, and confirming or rejecting an ID.

import { useCallback, useEffect, useRef, useState } from 'react';
import { api, ApiError } from '@/services/api';
import type { IdReviewDocument, PendingReview, RevealedId, ReviewDecision } from '@/types';

const PAGE_SIZE = 25;

// How long a revealed ID number stays on screen.
export const SHOW_SECONDS = 30;

export function useIdReviewQueue() {
  const [status, setStatus] = useState('pending_review');
  const [docs, setDocs] = useState<IdReviewDocument[]>([]);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [flash, setFlash] = useState('');
  const [busy, setBusy] = useState(false);

  const [shown, setShown] = useState<{ id: string; data: RevealedId } | null>(null);
  const [deciding, setDeciding] = useState<PendingReview | null>(null);
  const [note, setNote] = useState('');

  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const hideNumber = useCallback(() => {
    if (hideTimer.current) clearTimeout(hideTimer.current);

    hideTimer.current = null;
    setShown(null);
  }, []);

  // Stop the timer when the screen closes.
  useEffect(() => hideNumber, [hideNumber]);

  const load = useCallback(async (append: boolean, current: IdReviewDocument[], wantedStatus: string) => {
    setLoading(true);
    setError('');

    try {
      const params = new URLSearchParams({ status: wantedStatus, limit: String(PAGE_SIZE) });

      if (append && current.length) params.set('before', current[current.length - 1].createdAt);

      const answer = await api<{ documents: IdReviewDocument[] }>(`/api/admin/identity?${params}`);

      setDocs(append ? [...current, ...answer.documents] : answer.documents);
      setHasMore(answer.documents.length === PAGE_SIZE);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load the queue.');
    } finally {
      setLoading(false);
    }
  }, []);

  // Start fresh whenever the status filter changes.
  useEffect(() => {
    hideNumber();
    setDeciding(null);
    load(false, [], status);
  }, [status, load, hideNumber]);

  async function revealNumber(id: string) {
    setError('');
    setFlash('');

    try {
      const data = await api<RevealedId>(`/api/admin/identity/${id}/reveal`, { method: 'POST', body: {} });

      if (hideTimer.current) clearTimeout(hideTimer.current);

      setShown({ id, data });
      hideTimer.current = setTimeout(() => setShown(null), SHOW_SECONDS * 1000);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not show the number.');
    }
  }

  function startDecision(id: string, decision: ReviewDecision) {
    setDeciding({ id, decision });
    setNote('');
  }

  async function confirmDecision() {
    if (!deciding) return;

    setBusy(true);
    setError('');
    setFlash('');

    try {
      await api(`/api/admin/identity/${deciding.id}/review`, {
        method: 'POST',
        body: { decision: deciding.decision, note: note.trim() || undefined },
      });

      setFlash(
        deciding.decision === 'verified'
          ? 'ID confirmed. The person can now register vehicles.'
          : 'ID rejected. The person is told they can submit another.'
      );

      hideNumber();
      setDeciding(null);
      setNote('');

      await load(false, [], status);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'That did not work.');
    } finally {
      setBusy(false);
    }
  }

  return {
    status,
    setStatus,
    docs,
    hasMore,
    loading,
    error,
    flash,
    busy,
    shown,
    deciding,
    setDeciding,
    note,
    setNote,
    load,
    hideNumber,
    revealNumber,
    startDecision,
    confirmDecision,
  };
}
