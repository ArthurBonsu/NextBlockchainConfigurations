// hooks/useSignIn.ts
// The logic of the sign-in page, in one place:
//   - switching between "Sign in" and "Create account"
//   - the email and password fields
//   - sign in / sign up with email and password
//   - sign in with Google, GitHub or X
//   - "Forgot your password?"
// The page itself only draws the screen.

import { FormEvent, useState } from 'react';
import {
  checkNewPassword,
  friendlyAuthError,
  sendResetEmail,
  signInWithEmail,
  signInWithProvider,
  signUpWithEmail,
} from '@/services/auth';
import type { SocialProviderKind } from '@/services/auth';

export type SignInMode = 'in' | 'up';

export function useSignIn() {
  const [mode, setMode] = useState<SignInMode>('in');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [repeatedPassword, setRepeatedPassword] = useState('');

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  function clearMessages() {
    setError('');
    setInfo('');
  }

  function changeMode(newMode: SignInMode) {
    setMode(newMode);
    clearMessages();
  }

  // The email and password form.
  async function submitEmailForm(event: FormEvent) {
    event.preventDefault();
    clearMessages();

    if (mode === 'up') {
      const problem = checkNewPassword(password, repeatedPassword);

      if (problem) {
        setError(problem);
        return;
      }
    }

    setBusy(true);

    try {
      if (mode === 'up') {
        await signUpWithEmail(email, password);
      } else {
        await signInWithEmail(email, password);
      }
      // Success: AuthProvider notices the new sign-in by itself, and the page moves on.
    } catch (err) {
      setError(friendlyAuthError(err));
    }

    setBusy(false);
  }

  // The Google, GitHub and X buttons.
  async function signInWithSocial(kind: SocialProviderKind) {
    clearMessages();
    setBusy(true);

    try {
      await signInWithProvider(kind);
    } catch (err) {
      setError(friendlyAuthError(err));
    }

    setBusy(false);
  }

  async function resetPassword() {
    clearMessages();

    if (!email.trim()) {
      setError('Enter your email address above first.');
      return;
    }

    try {
      await sendResetEmail(email);
    } catch {
      // We give the same answer either way, so nobody can find out which addresses have an account.
    }

    setInfo('If that address has an account, a reset link is on its way.');
  }

  return {
    mode,
    changeMode,
    email,
    setEmail,
    password,
    setPassword,
    repeatedPassword,
    setRepeatedPassword,
    busy,
    error,
    info,
    submitEmailForm,
    signInWithSocial,
    resetPassword,
  };
}
