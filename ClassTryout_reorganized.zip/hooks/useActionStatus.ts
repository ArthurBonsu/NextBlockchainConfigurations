// hooks/useActionStatus.ts
// The little message under a button: "Confirm in your wallet...", "Done.", or an error.
// One hook, so every panel shows it the same way.

import { useState } from 'react';
import { friendlyError } from '@/utils/friendlyError';
import type { ActionStatus } from '@/blockchain/types';

const IDLE: ActionStatus = { type: 'idle', message: '' };

export function useActionStatus() {
  const [status, setStatus] = useState<ActionStatus>(IDLE);

  const isPending = status.type === 'pending';

  function showPending(message: string) {
    setStatus({ type: 'pending', message });
  }

  function showSuccess(message: string) {
    setStatus({ type: 'success', message });
  }

  // Accepts any error and turns it into a sentence a person can read.
  function showError(err: unknown) {
    setStatus({ type: 'error', message: friendlyError(err) });
  }

  function clear() {
    setStatus(IDLE);
  }

  // Removes an old error message, but leaves other messages alone.
  function clearError() {
    setStatus((current) => (current.type === 'error' ? IDLE : current));
  }

  return { status, isPending, showPending, showSuccess, showError, clear, clearError };
}
