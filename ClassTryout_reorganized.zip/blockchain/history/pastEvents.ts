// blockchain/history/pastEvents.ts
// Read old events from a contract with getPastEvents.
// Public RPC nodes refuse to return too many logs at once. When that happens, we split the block range
// in half and ask twice. This repeats until every piece is small enough.

import type { Contract } from 'web3';

// Words that appear in the error when the node says "that range is too big".
const RANGE_LIMIT_ERROR = /range|limit|exceed|too many|more than|response size|timed? ?out|payload|10000|10,000/i;

const MAX_SPLITS = 20;

export type EventFilter = Record<string, unknown>;

function errorText(err: any): string {
  return [err?.message, err?.cause?.message, err?.innerError?.message].filter(Boolean).join(' ');
}

export async function pastEventsPaged(
  contract: Contract<any>,
  eventName: string,
  fromBlock: number,
  toBlock: number,
  filter?: EventFilter,
  depth = 0
): Promise<any[]> {
  try {
    const events = await contract.getPastEvents(eventName as any, { filter, fromBlock, toBlock } as any);

    return events as any[];
  } catch (err: any) {
    const cannotSplitMore = fromBlock >= toBlock || depth >= MAX_SPLITS;
    const notARangeProblem = !RANGE_LIMIT_ERROR.test(errorText(err));

    if (cannotSplitMore || notARangeProblem) throw err;

    const middle = Math.floor((fromBlock + toBlock) / 2);
    const leftHalf = await pastEventsPaged(contract, eventName, fromBlock, middle, filter, depth + 1);
    const rightHalf = await pastEventsPaged(contract, eventName, middle + 1, toBlock, filter, depth + 1);

    return [...leftHalf, ...rightHalf];
  }
}
