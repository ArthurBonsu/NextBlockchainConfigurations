// blockchain/history/getVehicleTimeline.ts
// The full history of one vehicle, read straight from the blockchain. There is no database.
//
// Every write (register, report, revoke, reinstate, issue licence) emits an event.
// The chain keeps those events forever, so we can read them back at any time, from any computer.
//
// A note on "indexed" event fields:
//  - VehicleRegistered and VehicleRemoved are indexed by pseudonym, so the node filters them for us.
//  - The other events are not indexed by pseudonym, so we read them all and filter here in the browser.
//    That is fine for a class demo. For thousands of vehicles, index the field or use a subgraph.

import type Web3 from 'web3';
import type { Contract } from 'web3';
import { utils } from 'web3';
import { formatChainTime } from '@/utils/formatChainTime';
import { pastEventsPaged } from './pastEvents';
import type { EventFilter } from './pastEvents';
import type { TimelineEntry } from '../types';

export interface TimelineContracts {
  web3: Web3;
  registry: Contract<any>;
  revocation: Contract<any>;
  license: Contract<any>;
}

type ReadEvents = (contract: Contract<any>, eventName: string, filter?: EventFilter) => Promise<any[]>;

// One row of the timeline.
function entryFrom(event: any, type: string, timeSeconds: unknown, details: Record<string, string> = {}): TimelineEntry {
  return {
    type,
    timestamp: formatChainTime(Number(timeSeconds)),
    txHash: event.transactionHash,
    blockNumber: Number(event.blockNumber),
    details,
  };
}

// ---------------------------------------------------------------- VehicleRegistry events
async function readRegistryEntries(contracts: TimelineContracts, pseudonym: string, readEvents: ReadEvents) {
  const entries: TimelineEntry[] = [];

  const registered = await readEvents(contracts.registry, 'VehicleRegistered', { pseudonym });
  for (const event of registered) {
    entries.push(entryFrom(event, 'Vehicle Registered', event.returnValues.timestamp, { owner: event.returnValues.owner }));
  }

  const removed = await readEvents(contracts.registry, 'VehicleRemoved', { pseudonym });
  for (const event of removed) {
    entries.push(entryFrom(event, 'Vehicle Removed', event.returnValues.timestamp));
  }

  return entries;
}

// ---------------------------------------------------------------- RevocationManager events
async function readRevocationEntries(contracts: TimelineContracts, pseudonym: string, readEvents: ReadEvents) {
  const entries: TimelineEntry[] = [];

  const reports = await readEvents(contracts.revocation, 'ReportSubmitted');
  for (const event of reports) {
    if (event.returnValues.offender !== pseudonym) continue;

    entries.push(
      entryFrom(event, 'Revocation Report Submitted', event.returnValues.timestamp, {
        reporter: event.returnValues.reporter,
        reportId: event.returnValues.reportId.toString(),
      })
    );
  }

  const revoked = await readEvents(contracts.revocation, 'VehicleRevoked');
  for (const event of revoked) {
    if (event.returnValues.pseudonym !== pseudonym) continue;

    entries.push(entryFrom(event, 'Vehicle Revoked', event.returnValues.timestamp, { reason: event.returnValues.reason }));
  }

  const reinstated = await readEvents(contracts.revocation, 'VehicleReinstated');
  for (const event of reinstated) {
    if (event.returnValues.pseudonym !== pseudonym) continue;

    entries.push(entryFrom(event, 'Vehicle Reinstated', event.returnValues.timestamp));
  }

  return entries;
}

// ---------------------------------------------------------------- LicenseRegistry events
// LicenseIssued, LicenseRevoked and LicenseReinstated declare licenseId as `string indexed`.
// For an indexed string the log keeps only keccak256(licenseId), so event.returnValues.licenseId is a 0x hash,
// NOT the readable id. So:
//   1. We cannot filter by licenseId on the node. We read all events and match here.
//   2. To show the readable id, we hash the vehicle's current licence id and compare it with the hash in the event.
async function readLicenseEntries(contracts: TimelineContracts, pseudonym: string, readEvents: ReadEvents) {
  const entries: TimelineEntry[] = [];

  const hashOf = (id: string) => utils.keccak256(id).toLowerCase();

  let currentLicenseId = '';
  try {
    currentLicenseId = await contracts.license.methods.getLicenseByVehicle(pseudonym).call();
  } catch {
    // This vehicle has no licence yet.
  }

  const currentHash = currentLicenseId ? hashOf(currentLicenseId) : '';

  const labelFor = (hash: string) => (hash.toLowerCase() === currentHash ? currentLicenseId : `${hash.slice(0, 10)}…`);

  const vehicleLicenseHashes = new Set<string>();

  const issued = await readEvents(contracts.license, 'LicenseIssued');
  for (const event of issued) {
    if (event.returnValues.vehiclePseudonym !== pseudonym) continue;

    const hash = String(event.returnValues.licenseId).toLowerCase();
    vehicleLicenseHashes.add(hash);

    entries.push(
      entryFrom(event, 'License Issued', event.returnValues.issueTime, {
        licenseId: labelFor(hash),
        licenseType: event.returnValues.licenseType,
        owner: event.returnValues.owner,
      })
    );
  }

  // LicenseRevoked also carries the plain-text vehiclePseudonym, so we can match on that.
  const revoked = await readEvents(contracts.license, 'LicenseRevoked');
  for (const event of revoked) {
    const hash = String(event.returnValues.licenseId).toLowerCase();
    const isThisVehicle = event.returnValues.vehiclePseudonym === pseudonym || vehicleLicenseHashes.has(hash);

    if (!isThisVehicle) continue;

    entries.push(entryFrom(event, 'License Revoked', event.returnValues.timestamp, { licenseId: labelFor(hash) }));
  }

  // LicenseReinstated only carries the hashed licenseId, so we match against this vehicle's known hashes.
  const reinstated = await readEvents(contracts.license, 'LicenseReinstated');
  for (const event of reinstated) {
    const hash = String(event.returnValues.licenseId).toLowerCase();

    if (!vehicleLicenseHashes.has(hash)) continue;

    entries.push(entryFrom(event, 'License Reinstated', event.returnValues.timestamp, { licenseId: labelFor(hash) }));
  }

  return entries;
}

// ---------------------------------------------------------------- put it together
export async function getVehicleTimeline(
  contracts: TimelineContracts,
  vehiclePseudonym: string,
  startBlock = 0
): Promise<TimelineEntry[]> {
  const latestBlock = Number(await contracts.web3.eth.getBlockNumber());
  const fromBlock = Math.max(0, Math.min(startBlock, latestBlock));

  const readEvents: ReadEvents = (contract, eventName, filter) =>
    pastEventsPaged(contract, eventName, fromBlock, latestBlock, filter);

  const registryEntries = await readRegistryEntries(contracts, vehiclePseudonym, readEvents);
  const revocationEntries = await readRevocationEntries(contracts, vehiclePseudonym, readEvents);
  const licenseEntries = await readLicenseEntries(contracts, vehiclePseudonym, readEvents);

  const timeline = [...registryEntries, ...revocationEntries, ...licenseEntries];

  timeline.sort((a, b) => a.blockNumber - b.blockNumber);

  return timeline;
}
