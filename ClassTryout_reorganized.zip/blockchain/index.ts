// blockchain/index.ts
// One import for everything about the blockchain.
//   types      the shapes of the data (Receipt, VehicleInfo, ...)
//   wallets    connect MetaMask, pick a network, link a wallet to an account
//   contracts  one folder per smart contract: the contract itself, and the actions you can do with it
//   receipts   build the on-chain receipt shown after a transaction
//   history    read a vehicle's full timeline from the event logs

export * from './types';
export * from './wallets';
export * from './contracts';
export * from './receipts';
export * from './history';
