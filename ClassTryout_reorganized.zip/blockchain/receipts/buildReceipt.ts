// blockchain/receipts/buildReceipt.ts
// A "receipt" is built straight from what the transaction returned: the hash, the block, and the event it emitted.
// Nothing is stored anywhere else. The blockchain's own event log is the database.

import { formatChainTime } from '@/utils/formatChainTime';
import type { Receipt } from '../types';

export function buildReceipt(
  action: string,
  subject: string,
  details: Record<string, string>,
  txHash: string,
  blockNumber: number | bigint,
  timestampSeconds: bigint | number | string
): Receipt {
  return {
    action,
    subject,
    details,
    txHash,
    blockNumber: Number(blockNumber),
    timestamp: formatChainTime(timestampSeconds),
  };
}

// web3 decodes the events for us (because the contract ABI lists them).
// This reads one event's values out of a transaction receipt, or returns undefined if that event did not happen.
export function getEventValues(txReceipt: { events?: unknown }, eventName: string): Record<string, any> | undefined {
  const events = txReceipt.events as Record<string, any> | undefined;

  return events?.[eventName]?.returnValues;
}
