// blockchain/types/window.d.ts
// MetaMask (and other browser wallets) put an "ethereum" object on window.

export {};

declare global {
  interface Window {
    ethereum?: any;
  }
}
