// blockchain/types/receipt.types.ts
// What the user sees after a transaction (Receipt) and in the history page (TimelineEntry).

export interface Receipt {
  action: string;
  subject: string;
  details: Record<string, string>;
  txHash: string;
  blockNumber: number;
  timestamp: string;
}

export interface TimelineEntry {
  type: string;
  timestamp: string;
  txHash: string;
  blockNumber: number;
  details: Record<string, string>;
}
