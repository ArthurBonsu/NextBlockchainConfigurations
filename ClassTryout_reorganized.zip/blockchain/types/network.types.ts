// blockchain/types/network.types.ts
// One blockchain network, as listed in shared/chains.json.

export type NetworkKind = 'L1' | 'L2' | 'Sidechain' | 'Local';

export interface NetworkCurrency {
  name: string;
  symbol: string;
  decimals: number;
}

export interface AppNetwork {
  chainId: number;
  key: string; // the Truffle network name, e.g. "baseSepolia"
  name: string;
  kind: NetworkKind;
  testnet: boolean;
  rpcUrls: string[];
  explorer: string; // base URL with no trailing slash ("" for a local chain)
  currency: NetworkCurrency;
  infura: string | null;
}
