// blockchain/types/revocation.types.ts
// A revocation report as read from the RevocationManager.

export interface ReportInfo {
  offender: string;
  reporter: string;
  reason: string;
  timestamp: string;
  processed: boolean;
}

// What you give the contract to report a vehicle.
export interface SubmitReportInput {
  offender: string;
  reporter: string;
  reason: string;
}
