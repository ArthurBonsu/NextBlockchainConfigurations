// blockchain/types/status.types.ts
// The little "pending / success / error" message shown under a button.

export type StatusType = 'idle' | 'pending' | 'success' | 'error';

export interface ActionStatus {
  type: StatusType;
  message: string;
}
