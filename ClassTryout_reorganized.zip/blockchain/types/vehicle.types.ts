// blockchain/types/vehicle.types.ts
// A vehicle as read from the VehicleRegistry (and the RevocationManager, for the revoked flag).

export interface VehicleInfo {
  owner: string;
  registrationTime: string;
  isRegistered: boolean;
  isRevoked: boolean;
  revokedReason?: string;
}
