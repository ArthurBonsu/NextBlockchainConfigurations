// blockchain/types/license.types.ts
// A licence as read from the LicenseRegistry.

export interface LicenseInfo {
  vehiclePseudonym: string;
  owner: string;
  licenseType: string;
  issueTime: string;
  expiryTime: string;
  isActive: boolean;
  issued: boolean;
  isValid: boolean;
}

// What you give the contract to issue a licence.
export interface IssueLicenseInput {
  licenseId: string;
  vehiclePseudonym: string;
  licenseType: string;
  validityDays: number;
}
