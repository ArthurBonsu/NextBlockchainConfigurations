// blockchain/types/contract.types.ts
// The three smart contracts, and where each one is deployed.

export const CONTRACT_NAMES = ['VehicleRegistry', 'RevocationManager', 'LicenseRegistry'] as const;

export type ContractName = (typeof CONTRACT_NAMES)[number];

export interface DeploymentEntry {
  address: string;
  startBlock: number;
  txHash?: string | null;
}

// One entry per contract, for one chain.
export type Deployment = Record<ContractName, DeploymentEntry>;

// Who owns a contract, and whether it is paused (OpenZeppelin Ownable + Pausable).
export interface ContractStatus {
  name: ContractName;
  address: string;
  owner: string;
  paused: boolean;
}
