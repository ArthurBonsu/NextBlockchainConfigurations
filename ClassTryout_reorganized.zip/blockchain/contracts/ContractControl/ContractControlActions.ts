// blockchain/contracts/ContractControl/ContractControlActions.ts
// Who owns each contract, and is it paused? Plus the admin buttons: pause and resume.
// All three contracts use OpenZeppelin's Ownable and Pausable, so they answer the same questions.
// Used by components/Admin/AdminPanel and by the wallet provider (to show the "Admin" badge).

import { getContracts } from '../openContracts';
import { sendTx } from '../sendTransaction';
import type { ContractName, ContractStatus } from '../../types';

interface OwnableAndPausable {
  methods: {
    owner(): { call(): Promise<any> };
    paused(): { call(): Promise<any> };
  };
}

export interface ContractStatusReport {
  account: string;
  chainId: string;
  isAdmin: boolean;
  statuses: ContractStatus[];
}

export async function getContractStatuses(): Promise<ContractStatusReport> {
  const { registry, revocation, license, account, chainId, deployment } = await getContracts();

  const rows: { name: ContractName; contract: OwnableAndPausable }[] = [
    { name: 'VehicleRegistry', contract: registry as any },
    { name: 'RevocationManager', contract: revocation as any },
    { name: 'LicenseRegistry', contract: license as any },
  ];

  const statuses: ContractStatus[] = [];

  for (const { name, contract } of rows) {
    const [owner, paused] = await Promise.all([contract.methods.owner().call(), contract.methods.paused().call()]);

    statuses.push({
      name,
      address: deployment[name].address,
      owner: String(owner),
      paused: Boolean(paused),
    });
  }

  const isAdmin = statuses.some((status) => status.owner.toLowerCase() === account.toLowerCase());

  return { account, chainId, isAdmin, statuses };
}

// Admin only. Pauses the contract if it is running, and resumes it if it is paused.
export async function togglePause(name: ContractName, isPaused: boolean): Promise<void> {
  const { registry, revocation, license, account } = await getContracts();

  const contracts = { VehicleRegistry: registry, RevocationManager: revocation, LicenseRegistry: license };
  const contract: any = contracts[name];
  const methodName = isPaused ? 'unpause' : 'pause';

  await sendTx(contract.methods[methodName](), account);
}
