// blockchain/contracts/sendTransaction.ts
// Sends a transaction. If it fails, explains WHY.
//
// A wallet's own error is often vague ("internal JSON-RPC error").
// Replaying the same call read-only (eth_call) makes the node answer with the exact revert reason.
// Every write in the app goes through here, so every panel reports failures the same way.

interface SendableMethod<T> {
  send(options: { from: string }): Promise<T>;
  call(options: { from: string }): Promise<unknown>;
}

function userSaidNo(err: any): boolean {
  if (err?.code === 4001) return true;

  return /user (rejected|denied)/i.test(err?.message || '');
}

export async function sendTx<T>(method: SendableMethod<T>, from: string): Promise<T> {
  try {
    return await method.send({ from });
  } catch (err: any) {
    // The user pressed "Reject". There is nothing to explain.
    if (userSaidNo(err)) throw err;

    // Replay the call. If it reverts, this throws the real reason.
    await method.call({ from });

    // The replay worked, so the failure was not a revert (gas, nonce, network). Keep the original error.
    throw err;
  }
}
