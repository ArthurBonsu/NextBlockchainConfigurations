// blockchain/contracts/LicenseRegistry/LicenseRegistryContract.ts
// Opens the LicenseRegistry contract at an address.

import type Web3 from 'web3';
import { LicenseRegistryAbi } from '@/shared/abi/LicenseRegistry';

export function createLicenseRegistryContract(web3: Web3, address: string) {
  return new web3.eth.Contract(LicenseRegistryAbi, address);
}

export type LicenseRegistryContract = ReturnType<typeof createLicenseRegistryContract>;
