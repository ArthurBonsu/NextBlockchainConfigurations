// blockchain/contracts/LicenseRegistry/LicenseRegistryActions.ts
// Everything you can DO with the LicenseRegistry contract.
// Used by components/Licences/LicensePanel.
// Revoking and reinstating are admin actions: they only work for the wallet that owns the contract.

import { formatChainTime } from '@/utils/formatChainTime';
import { buildReceipt, getEventValues } from '../../receipts';
import { getContracts } from '../openContracts';
import { sendTx } from '../sendTransaction';
import type { IssueLicenseInput, LicenseInfo, Receipt } from '../../types';

const NO_LICENSE: LicenseInfo = {
  vehiclePseudonym: '',
  owner: '',
  licenseType: '',
  issueTime: '',
  expiryTime: '',
  isActive: false,
  issued: false,
  isValid: false,
};

export async function issueLicense(input: IssueLicenseInput): Promise<Receipt | null> {
  const { license, account } = await getContracts();

  const txReceipt = await sendTx(
    license.methods.issueLicense(input.licenseId, input.vehiclePseudonym, input.licenseType, input.validityDays),
    account
  );
  const event = getEventValues(txReceipt, 'LicenseIssued');

  if (!event) return null;

  return buildReceipt(
    'License Issued',
    input.licenseId,
    {
      vehicle: event.vehiclePseudonym,
      owner: event.owner,
      type: event.licenseType,
      expires: formatChainTime(event.expiryTime),
    },
    txReceipt.transactionHash,
    txReceipt.blockNumber,
    event.issueTime
  );
}

// Returns NO_LICENSE-shaped info (issued: false) when the id does not exist.
export async function lookUpLicense(licenseId: string): Promise<LicenseInfo> {
  const { license } = await getContracts();

  const found: any = await license.methods.getLicense(licenseId).call();

  if (!found.issued) return { ...NO_LICENSE };

  const isValid: boolean = await license.methods.isLicenseValid(licenseId).call();

  return {
    vehiclePseudonym: found.vehiclePseudonym,
    owner: found.owner,
    licenseType: found.licenseType,
    issueTime: formatChainTime(found.issueTime),
    expiryTime: formatChainTime(found.expiryTime),
    isActive: found.isActive,
    issued: found.issued,
    isValid,
  };
}

// Returns the licence id attached to a vehicle, or an empty string if there is none.
export async function findLicenseIdByVehicle(vehiclePseudonym: string): Promise<string> {
  const { license } = await getContracts();

  return license.methods.getLicenseByVehicle(vehiclePseudonym).call();
}

export async function revokeLicense(licenseId: string): Promise<void> {
  const { license, account } = await getContracts();

  await sendTx(license.methods.revokeLicense(licenseId), account);
}

export async function reinstateLicense(licenseId: string): Promise<void> {
  const { license, account } = await getContracts();

  await sendTx(license.methods.reinstateLicense(licenseId), account);
}

export { NO_LICENSE };
