export { createLicenseRegistryContract } from './LicenseRegistryContract';
export type { LicenseRegistryContract } from './LicenseRegistryContract';
export {
  issueLicense,
  lookUpLicense,
  findLicenseIdByVehicle,
  revokeLicense,
  reinstateLicense,
  NO_LICENSE,
} from './LicenseRegistryActions';
