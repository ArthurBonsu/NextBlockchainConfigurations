// blockchain/contracts/openContracts.ts
// Connect the wallet, find the deployment for the connected chain, and open all three contracts.
// Every action file (VehicleRegistryActions, RevocationManagerActions, ...) starts with getContracts().

import type Web3 from 'web3';
import { connectWallet } from '../wallets/connectWallet';
import { getNetwork } from '../wallets/networks';
import { getDeployment } from './deployments';
import { createVehicleRegistryContract } from './VehicleRegistry/VehicleRegistryContract';
import { createRevocationManagerContract } from './RevocationManager/RevocationManagerContract';
import { createLicenseRegistryContract } from './LicenseRegistry/LicenseRegistryContract';

// Throws a clear message if nothing is deployed at the address.
// Typical causes: the wallet is on the wrong network, or Ganache was restarted and the address is stale.
async function assertDeployed(web3: Web3, name: string, address: string, chainId: string) {
  const code = await web3.eth.getCode(address);
  const hasCode = code && code !== '0x' && code !== '0x0';

  if (hasCode) return;

  throw new Error(
    `No contract code for ${name} at ${address} on chain ${chainId}. ` +
      `Either the wallet is on the wrong network, or this address is stale (local chain restarted / contract not deployed). ` +
      `Run "yarn deploy:local" (local) or the deploy script for this network, then restart the dev server.`
  );
}

function notDeployedMessage(chainId: string, networkId: string): string {
  const network = getNetwork(chainId);
  const deployCommand = network && network.kind !== 'Local' ? `npx truffle migrate --network ${network.key}` : 'yarn deploy:local';
  const where = network ? network.name : `chain ${chainId}`;

  return (
    `The contracts are not deployed on ${where} (chain ${chainId}, network id ${networkId}). ` +
    `Deploy with "${deployCommand}", commit shared/deployments.json, and restart the dev server.`
  );
}

// Kept separate from getContracts() so it can be tested without a browser wallet.
export async function resolveContracts(web3: Web3, account: string, chainId: string, networkId: string) {
  const deployment = getDeployment(chainId, networkId);

  if (!deployment) throw new Error(notDeployedMessage(chainId, networkId));

  await assertDeployed(web3, 'VehicleRegistry', deployment.VehicleRegistry.address, chainId);
  await assertDeployed(web3, 'RevocationManager', deployment.RevocationManager.address, chainId);
  await assertDeployed(web3, 'LicenseRegistry', deployment.LicenseRegistry.address, chainId);

  const registry = createVehicleRegistryContract(web3, deployment.VehicleRegistry.address);
  const revocation = createRevocationManagerContract(web3, deployment.RevocationManager.address);
  const license = createLicenseRegistryContract(web3, deployment.LicenseRegistry.address);

  // So every .send() can leave out `from`.
  registry.defaultAccount = account;
  revocation.defaultAccount = account;
  license.defaultAccount = account;

  return { web3, registry, revocation, license, account, chainId, networkId, deployment };
}

export type OpenContracts = Awaited<ReturnType<typeof resolveContracts>>;

export async function getContracts(): Promise<OpenContracts> {
  const { web3, account, chainId, networkId } = await connectWallet();

  return resolveContracts(web3, account, chainId, networkId);
}
