// blockchain/contracts/RevocationManager/RevocationManagerContract.ts
// Opens the RevocationManager contract at an address.

import type Web3 from 'web3';
import { RevocationManagerAbi } from '@/shared/abi/RevocationManager';

export function createRevocationManagerContract(web3: Web3, address: string) {
  return new web3.eth.Contract(RevocationManagerAbi, address);
}

export type RevocationManagerContract = ReturnType<typeof createRevocationManagerContract>;
