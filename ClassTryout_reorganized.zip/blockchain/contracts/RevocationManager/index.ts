export { createRevocationManagerContract } from './RevocationManagerContract';
export type { RevocationManagerContract } from './RevocationManagerContract';
export { submitReport, getReport, processReport, reinstateVehicle } from './RevocationManagerActions';
export type { SubmitReportResult } from './RevocationManagerActions';
