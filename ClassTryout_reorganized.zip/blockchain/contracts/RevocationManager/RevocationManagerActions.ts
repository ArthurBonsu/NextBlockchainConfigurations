// blockchain/contracts/RevocationManager/RevocationManagerActions.ts
// Everything you can DO with the RevocationManager contract.
// Used by components/Revocations/RevocationPanel.
// "Admin" actions only work for the wallet that owns the contract.

import { formatChainTime } from '@/utils/formatChainTime';
import { buildReceipt, getEventValues } from '../../receipts';
import { getContracts } from '../openContracts';
import { sendTx } from '../sendTransaction';
import type { Receipt, ReportInfo, SubmitReportInput } from '../../types';

export interface SubmitReportResult {
  reportId: string | null;
  receipt: Receipt | null;
}

// Anyone can report a vehicle.
export async function submitReport(input: SubmitReportInput): Promise<SubmitReportResult> {
  const { revocation, account } = await getContracts();

  const txReceipt = await sendTx(
    revocation.methods.submitRevocationReport(input.offender, input.reporter, input.reason),
    account
  );
  const event = getEventValues(txReceipt, 'ReportSubmitted');

  if (!event) return { reportId: null, receipt: null };

  const reportId = event.reportId.toString();

  const receipt = buildReceipt(
    'Revocation Report Submitted',
    `Report #${reportId}`,
    { offender: event.offender, reporter: event.reporter },
    txReceipt.transactionHash,
    txReceipt.blockNumber,
    event.timestamp
  );

  return { reportId, receipt };
}

export async function getReport(reportId: string): Promise<ReportInfo> {
  const { revocation } = await getContracts();

  const report: any = await revocation.methods.getReport(reportId).call();

  return {
    offender: report.offender,
    reporter: report.reporter,
    reason: report.reason,
    timestamp: formatChainTime(report.timestamp),
    processed: report.processed,
  };
}

// Admin only: turns a report into a revocation.
export async function processReport(reportId: string): Promise<Receipt | null> {
  const { revocation, account } = await getContracts();

  const txReceipt = await sendTx(revocation.methods.processRevocation(reportId), account);
  const event = getEventValues(txReceipt, 'VehicleRevoked');

  if (!event) return null;

  return buildReceipt(
    'Vehicle Revoked',
    event.pseudonym,
    { reason: event.reason, reportId },
    txReceipt.transactionHash,
    txReceipt.blockNumber,
    event.timestamp
  );
}

// Admin only.
export async function reinstateVehicle(pseudonym: string): Promise<void> {
  const { revocation, account } = await getContracts();

  await sendTx(revocation.methods.reinstateVehicle(pseudonym), account);
}
