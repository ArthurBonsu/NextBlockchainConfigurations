// blockchain/contracts/deployments.ts
// Where are the contracts deployed? Two files answer that:
//   shared/deployments.json        public chains, keyed by chain id (written by the migrations)
//   shared/deployments.local.json  Ganache and private chains, keyed by network id (git-ignored)

import publicDeployments from '@/shared/deployments.json';
import localDeployments from '@/shared/deployments.local.json';
import { getNetwork } from '../wallets/networks';
import { CONTRACT_NAMES } from '../types';
import type { Deployment } from '../types';

// An entry is only usable when all three contracts have an address.
function completeDeployment(entry: any): Deployment | undefined {
  if (!entry) return undefined;

  for (const name of CONTRACT_NAMES) {
    if (!entry[name]?.address) return undefined;
  }

  return entry as Deployment;
}

// Public chains match by chain id.
// Local chains match by network id (what Truffle recorded), with chain id as a fallback,
// because Ganache Desktop reports network id 5777 but chain id 1337.
export function getDeployment(chainId: string | number, networkId?: string | number): Deployment | undefined {
  const publicMatch = completeDeployment((publicDeployments as Record<string, any>)[String(chainId)]);

  if (publicMatch) return publicMatch;

  const local = localDeployments as Record<string, any>;
  const byNetworkId = networkId !== undefined ? completeDeployment(local[String(networkId)]) : undefined;

  return byNetworkId || completeDeployment(local[String(chainId)]);
}

// True when we have addresses for all three contracts on this chain.
// A local chain's network id is arbitrary, so local chains are checked for real when you connect.
export function isDeployedOnChain(chainId: number | string): boolean {
  const isLocal = getNetwork(chainId)?.kind === 'Local' || Number(chainId) === 5777;

  if (isLocal) return true;

  return !!getDeployment(chainId);
}
