export { createVehicleRegistryContract } from './VehicleRegistryContract';
export type { VehicleRegistryContract } from './VehicleRegistryContract';
export { registerVehicle, lookUpVehicle } from './VehicleRegistryActions';
