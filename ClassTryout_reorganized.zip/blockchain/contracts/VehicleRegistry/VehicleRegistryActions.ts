// blockchain/contracts/VehicleRegistry/VehicleRegistryActions.ts
// Everything you can DO with the VehicleRegistry contract.
// Used by components/Vehicles/VehicleRegistryPanel.

import { formatChainTime } from '@/utils/formatChainTime';
import { buildReceipt, getEventValues } from '../../receipts';
import { getContracts } from '../openContracts';
import { sendTx } from '../sendTransaction';
import type { Receipt, VehicleInfo } from '../../types';

// Writes to the blockchain: the wallet asks the user to confirm.
// Returns a receipt, or null if the transaction went through without the expected event.
export async function registerVehicle(pseudonym: string): Promise<Receipt | null> {
  const { registry, account } = await getContracts();

  const txReceipt = await sendTx(registry.methods.registerVehicle(pseudonym), account);
  const event = getEventValues(txReceipt, 'VehicleRegistered');

  if (!event) return null;

  return buildReceipt(
    'Vehicle Registered',
    pseudonym,
    { owner: event.owner },
    txReceipt.transactionHash,
    txReceipt.blockNumber,
    event.timestamp
  );
}

// Reads from the blockchain: free, no wallet confirmation.
export async function lookUpVehicle(pseudonym: string): Promise<VehicleInfo> {
  const { registry, revocation } = await getContracts();

  const vehicle: any = await registry.methods.getVehicle(pseudonym).call();

  if (!vehicle.isRegistered) {
    return {
      owner: vehicle.owner,
      registrationTime: '0',
      isRegistered: false,
      isRevoked: false,
    };
  }

  const isRevoked: boolean = await revocation.methods.isRevoked(pseudonym).call();
  let revokedReason: string | undefined;

  if (isRevoked) {
    const details: any = await revocation.methods.getRevocationDetails(pseudonym).call();
    revokedReason = details.reason;
  }

  return {
    owner: vehicle.owner,
    registrationTime: formatChainTime(vehicle.registrationTime),
    isRegistered: vehicle.isRegistered,
    isRevoked,
    revokedReason,
  };
}
