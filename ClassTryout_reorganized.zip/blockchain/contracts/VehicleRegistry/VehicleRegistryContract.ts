// blockchain/contracts/VehicleRegistry/VehicleRegistryContract.ts
// Opens the VehicleRegistry contract at an address.
// The ABI is "as const", so web3 checks every method name, argument and result against the real contract.

import type Web3 from 'web3';
import { VehicleRegistryAbi } from '@/shared/abi/VehicleRegistry';

export function createVehicleRegistryContract(web3: Web3, address: string) {
  return new web3.eth.Contract(VehicleRegistryAbi, address);
}

export type VehicleRegistryContract = ReturnType<typeof createVehicleRegistryContract>;
