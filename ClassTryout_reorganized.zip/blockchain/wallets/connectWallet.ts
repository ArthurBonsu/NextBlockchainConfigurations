// blockchain/wallets/connectWallet.ts
// Connect to the browser wallet (MetaMask) and read the account and network.

import Web3 from 'web3';

export interface WalletConnection {
  web3: Web3;
  account: string;
  chainId: string;
  networkId: string;
}

export async function connectWallet(): Promise<WalletConnection> {
  if (!window.ethereum) throw new Error('MetaMask not found. Please install it.');

  await window.ethereum.request({ method: 'eth_requestAccounts' });

  const web3 = new Web3(window.ethereum);
  const accounts = await web3.eth.getAccounts();
  const chainId = (await web3.eth.getChainId()).toString();
  const networkId = (await web3.eth.net.getId()).toString();

  return { web3, account: accounts[0], chainId, networkId };
}
