// blockchain/wallets/networks.ts
// The list of networks in the network picker.
// The data lives in shared/chains.json. truffle-config.js reads the same file,
// so the website and the deploy tools can never disagree about a chain id.
// To add or change a network, edit shared/chains.json only.
//
// To hide networks from users, set this in .env.local and restart `next dev`:
//   NEXT_PUBLIC_ENABLED_CHAINS=11155111,84532,421614
// Leave it unset to show everything.

import chainsFile from '@/shared/chains.json';
import type { AppNetwork } from '../types';

export const NETWORKS: AppNetwork[] = (chainsFile.chains as unknown as AppNetwork[]).slice();

export function getNetwork(chainId: number | string): AppNetwork | undefined {
  const id = Number(chainId);

  return NETWORKS.find((network) => network.chainId === id);
}

// "Real money" means: not a testnet, and not a local chain.
export function isRealMoney(chainId: number | string): boolean {
  const network = getNetwork(chainId);

  if (!network) return false;

  return !network.testnet && network.kind !== 'Local';
}

export function networkLabel(chainId: number | string): string {
  const network = getNetwork(chainId);

  // Ganache Desktop reports chain id 1337. Some setups use 5777.
  if (!network && Number(chainId) === 5777) return 'Ganache (local)';

  return network ? network.name : `Chain ${chainId}`;
}

export function explorerTxUrl(chainId: number | string, txHash: string): string | null {
  const network = getNetwork(chainId);

  if (!network || !network.explorer) return null;

  return `${network.explorer}/tx/${txHash}`;
}

function readEnabledChainIds(): Set<number> | null {
  const raw = process.env.NEXT_PUBLIC_ENABLED_CHAINS;

  if (!raw) return null;

  const ids = raw
    .split(',')
    .map((text) => Number(text.trim()))
    .filter((id) => Number.isFinite(id) && id > 0);

  return new Set(ids);
}

// The networks offered in the picker, after the .env.local switches are applied.
export function enabledNetworks(): AppNetwork[] {
  const allowed = readEnabledChainIds();
  const showLocal = process.env.NEXT_PUBLIC_SHOW_LOCAL === 'true' || process.env.NODE_ENV !== 'production';

  return NETWORKS.filter((network) => {
    const isAllowed = !allowed || allowed.has(network.chainId);

    if (network.kind === 'Local') return showLocal && isAllowed;

    return isAllowed;
  });
}
