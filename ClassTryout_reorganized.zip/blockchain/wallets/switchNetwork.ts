// blockchain/wallets/switchNetwork.ts
// Ask the wallet to switch to a network. If the wallet has never heard of it, add it first.

import { getNetwork } from './networks';

function isUnknownChainError(err: any): boolean {
  if (err?.code === 4902) return true;

  return /unrecognized chain|not been added/i.test(err?.message || '');
}

export async function switchWalletNetwork(chainId: number): Promise<void> {
  const ethereum = typeof window !== 'undefined' ? window.ethereum : undefined;

  if (!ethereum) throw new Error('MetaMask not found. Please install it.');

  const hexChainId = '0x' + chainId.toString(16);

  try {
    await ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: hexChainId }],
    });
  } catch (err: any) {
    const network = getNetwork(chainId);

    if (!isUnknownChainError(err) || !network) throw err;

    await ethereum.request({
      method: 'wallet_addEthereumChain',
      params: [
        {
          chainId: hexChainId,
          chainName: network.name,
          rpcUrls: network.rpcUrls,
          nativeCurrency: network.currency,
          blockExplorerUrls: network.explorer ? [network.explorer] : undefined,
        },
      ],
    });
  }
}
