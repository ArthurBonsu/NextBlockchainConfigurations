// blockchain/wallets/linkedWallets.ts
// Link a wallet to the signed-in account, so the email watcher knows where to send notices.
// The server only remembers: wallet address -> account. The email is never sent to the chain.
// These functions call our own API (pages/api/wallet-link/*).

import type Web3 from 'web3';
import { getIdToken } from '@/services/auth';

export interface LinkedWallet {
  address: string;
  linkedAt: string;
}

interface CallOptions {
  method: string;
  body?: unknown;
}

async function callWalletLinkApi(path: string, options: CallOptions = { method: 'GET' }) {
  const token = await getIdToken();

  const response = await fetch(`/api/wallet-link${path}`, {
    method: options.method,
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${token}`,
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  const json = await response.json().catch(() => ({}));

  if (!response.ok) throw new Error(json.error || `Request failed (${response.status}).`);

  return json;
}

export async function listLinkedWallets(): Promise<LinkedWallet[]> {
  const json = await callWalletLinkApi('');

  return json.wallets;
}

// 1. Ask the server for a message.  2. The wallet signs it (free, no transaction).  3. Send the signature back.
export async function linkWallet(web3: Web3, account: string): Promise<void> {
  const challenge = await callWalletLinkApi('/challenge', {
    method: 'POST',
    body: { address: account },
  });

  const signature = await web3.eth.personal.sign(challenge.message, account, '');

  await callWalletLinkApi('/confirm', {
    method: 'POST',
    body: { ...challenge, signature },
  });
}

export async function unlinkWallet(address: string): Promise<void> {
  await callWalletLinkApi('', {
    method: 'DELETE',
    body: { address },
  });
}
