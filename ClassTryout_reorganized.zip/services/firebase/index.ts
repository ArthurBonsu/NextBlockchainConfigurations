export { firebaseConfigured, firebaseMissing, firebaseProjectId, getFirebaseAuth } from './firebaseClient';
