// services/firebase/firebaseClient.ts
// Firebase in the BROWSER. We only use it for sign-in.
//
// The NEXT_PUBLIC_ values below are public on purpose: they only say WHICH Firebase project to use.
// They are not secrets. Real security comes from two places:
//   1. our server checks every sign-in token (server/auth/)
//   2. the Firestore rules (firestore.rules)

import { FirebaseApp, getApp, getApps, initializeApp } from 'firebase/app';
import { Auth, connectAuthEmulator, getAuth } from 'firebase/auth';

export const firebaseConfigured = Boolean(
  process.env.NEXT_PUBLIC_FIREBASE_API_KEY && process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID
);

// Which of the four settings are empty.
// Each one is written out in full on purpose: Next.js only fills in NEXT_PUBLIC_ values it can see spelled out.
export const firebaseMissing: string[] = [
  process.env.NEXT_PUBLIC_FIREBASE_API_KEY ? '' : 'NEXT_PUBLIC_FIREBASE_API_KEY',
  process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN ? '' : 'NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN',
  process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID ? '' : 'NEXT_PUBLIC_FIREBASE_PROJECT_ID',
  process.env.NEXT_PUBLIC_FIREBASE_APP_ID ? '' : 'NEXT_PUBLIC_FIREBASE_APP_ID',
].filter(Boolean);

export const firebaseProjectId = process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || '';

let cachedAuth: Auth | null = null;

function getFirebaseApp(): FirebaseApp {
  if (getApps().length > 0) return getApp();

  return initializeApp({
    apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
    authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
    projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
    appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
  });
}

export function getFirebaseAuth(): Auth {
  if (cachedAuth) return cachedAuth;

  if (!firebaseConfigured) {
    throw new Error('Firebase sign-in is not set up. Set the NEXT_PUBLIC_FIREBASE_* values in .env.local (see .env.local.example).');
  }

  const auth = getAuth(getFirebaseApp());

  // For local testing only: talk to the Firebase emulator, e.g. http://127.0.0.1:9099
  const emulatorUrl = process.env.NEXT_PUBLIC_FIREBASE_AUTH_EMULATOR;

  if (emulatorUrl && process.env.NODE_ENV !== 'production') {
    connectAuthEmulator(auth, emulatorUrl, { disableWarnings: true });
  }

  cachedAuth = auth;

  return auth;
}
