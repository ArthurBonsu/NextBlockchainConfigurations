// services/index.ts
// Everything the browser uses to talk to other systems.
//   firebase   the Firebase app (sign-in)
//   auth       signing in and out, tokens, friendly error messages
//   api        calls to our own /api routes

export * from './firebase';
export * from './auth';
export * from './api';
