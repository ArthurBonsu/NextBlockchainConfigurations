// services/auth/authToken.ts
// The ONE place the front end asks "who is signed in?"
// It returns a Firebase ID token. Our API checks that token on the server.
//
// NEXT_PUBLIC_NOTIFY_BACKEND=dev gives a local stand-in identity, so the email flow can be tried end to end.
// The server refuses dev tokens when NODE_ENV=production, so this cannot be switched on by accident in a live deploy.

import { firebaseConfigured, getFirebaseAuth } from '../firebase';

export const AUTH_IS_DEV = process.env.NEXT_PUBLIC_NOTIFY_BACKEND === 'dev';

export class NotSignedInError extends Error {
  constructor(message = 'Sign in to your ClassTryout account to manage email notifications.') {
    super(message);
    this.name = 'NotSignedInError';
  }
}

export interface DevIdentity {
  uid: string;
  email: string;
  verified: boolean;
}

let devIdentity: DevIdentity | null = null;

export function setDevIdentity(identity: DevIdentity | null) {
  devIdentity = identity;
}

export function getDevIdentity(): DevIdentity | null {
  return devIdentity;
}

export async function getIdToken(forceRefresh = false): Promise<string> {
  if (AUTH_IS_DEV) {
    if (!devIdentity || !devIdentity.uid) throw new NotSignedInError('Enter a test account below first.');

    return `dev:${devIdentity.uid}:${devIdentity.email}:${devIdentity.verified ? 1 : 0}`;
  }

  if (!firebaseConfigured) throw new NotSignedInError('Sign-in is not set up on this site yet.');

  const user = getFirebaseAuth().currentUser;

  if (!user) throw new NotSignedInError();

  return user.getIdToken(forceRefresh);
}
