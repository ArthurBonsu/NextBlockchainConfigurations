// services/auth/browserCheck.ts
// Used by the /setup-check page. It tries to sign in with an address that cannot exist.
// The ANSWER tells us whether the key is right, Authentication is on and Email/Password sign-in is switched on.
// Nothing is created and nobody is signed in.

import { signInWithEmailAndPassword } from 'firebase/auth';
import { firebaseConfigured, getFirebaseAuth } from '@/services/firebase';

export type CheckStatus = 'ok' | 'fail' | 'warn' | 'skip';

export interface SetupCheckItem {
  id: string;
  label: string;
  status: CheckStatus;
  detail: string;
  fix: string;
}

const LABEL = 'This browser can reach Firebase Authentication, and Email/Password sign-in is on';

// These answers all mean "Firebase received our test and said the account does not exist". That is the good result.
const GOOD_ANSWERS = ['auth/invalid-credential', 'auth/user-not-found', 'auth/wrong-password', 'auth/invalid-login-credentials'];

const HOW_TO_FIX: Record<string, string> = {
  'auth/operation-not-allowed': 'Firebase console > Build > Authentication > Sign-in method > Email/Password > Enable.',
  'auth/configuration-not-found': 'Firebase console > Build > Authentication > Get started (Authentication has never been switched on for this project).',
  'auth/invalid-api-key': 'Copy NEXT_PUBLIC_FIREBASE_API_KEY again from Firebase console > Project settings > General, then restart the site.',
  'auth/network-request-failed':
    'This browser could not reach Firebase. Check the internet connection, and that no blocker is stopping identitytoolkit.googleapis.com.',
  'auth/too-many-requests': 'Firebase is rate limiting this browser. Wait a few minutes.',
};

export async function browserCheck(): Promise<SetupCheckItem> {
  const id = 'browser-auth';

  if (!firebaseConfigured) {
    return {
      id,
      label: LABEL,
      status: 'fail',
      detail: 'The sign-in page settings are missing.',
      fix: 'Fill in the NEXT_PUBLIC_FIREBASE_* values in .env.local and restart the site.',
    };
  }

  try {
    await signInWithEmailAndPassword(getFirebaseAuth(), 'setup-check@example.invalid', 'not-a-real-password');

    return { id, label: LABEL, status: 'warn', detail: 'Unexpected: a test sign-in worked.', fix: '' };
  } catch (error: any) {
    const code = String((error && error.code) || '');

    if (GOOD_ANSWERS.includes(code)) {
      return { id, label: LABEL, status: 'ok', detail: 'Firebase answered: the key is right and Email/Password is on.', fix: '' };
    }

    return {
      id,
      label: LABEL,
      status: code === 'auth/too-many-requests' ? 'warn' : 'fail',
      detail: 'Firebase said: ' + (code || (error && error.message) || 'unknown error'),
      fix: HOW_TO_FIX[code] || 'Open the browser console (F12) for more.',
    };
  }
}
