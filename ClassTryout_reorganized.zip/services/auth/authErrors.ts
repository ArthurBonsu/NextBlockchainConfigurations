// services/auth/authErrors.ts
// Firebase reports sign-in problems as codes like "auth/wrong-password".
// This turns each code into a plain sentence a student can act on.

import type { AuthError } from 'firebase/auth';

const MESSAGES: Record<string, string> = {
  // Email and password
  'auth/invalid-credential': 'That email and password do not match.',
  'auth/wrong-password': 'That email and password do not match.',
  'auth/user-not-found': 'That email and password do not match.',
  'auth/invalid-email': 'Enter a valid email address.',
  'auth/email-already-in-use': 'An account with this email already exists. Sign in instead, or reset your password.',
  'auth/weak-password': 'Choose a stronger password.',
  'auth/user-disabled': 'This account has been switched off. Contact an administrator.',

  // The pop-up used for Google, GitHub and X
  'auth/popup-closed-by-user': 'The sign-in window was closed before finishing.',
  'auth/cancelled-popup-request': 'The sign-in window was closed before finishing.',
  'auth/popup-blocked': 'Your browser blocked the sign-in window. Allow pop-ups for this site and try again.',
  'auth/account-exists-with-different-credential':
    'You already have an account with this email using a different sign-in method. Sign in that way first.',

  // Connection and set-up problems
  'auth/too-many-requests': 'Too many attempts. Wait a few minutes and try again.',
  'auth/network-request-failed': 'No connection. Check your internet and try again.',
  'auth/operation-not-allowed':
    'This sign-in method is not switched on yet (Firebase console > Authentication > Sign-in method).',
  'auth/unauthorized-domain':
    'This website address is not allowed to sign in. Add it in Firebase console > Authentication > Settings > Authorized domains.',
  'auth/invalid-api-key': 'The Firebase API key in .env.local is wrong. Copy it again and restart the site.',
  'auth/configuration-not-found': 'Authentication is not switched on in Firebase yet (Firebase console > Authentication > Get started).',
};

export function friendlyAuthError(err: unknown): string {
  const code = (err as AuthError)?.code;

  if (code && MESSAGES[code]) return MESSAGES[code];

  // Not a code we know. Log it for whoever is setting the site up, and show something kind.
  console.warn('[auth] unrecognised sign-in error:', code, (err as Error)?.message);

  return 'Could not sign you in. Try again.';
}
