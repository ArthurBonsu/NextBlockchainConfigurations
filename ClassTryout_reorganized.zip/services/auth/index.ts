export { AUTH_IS_DEV, NotSignedInError, getIdToken, getDevIdentity, setDevIdentity } from './authToken';
export type { DevIdentity } from './authToken';
export { friendlyAuthError } from './authErrors';
export { PASSWORD_MIN, checkNewPassword } from './passwordRules';
export {
  signInWithEmail,
  signUpWithEmail,
  sendResetEmail,
  sendVerificationEmail,
  signInWithProvider,
  signOutUser,
} from './signInService';
export type { SocialProviderKind } from './signInService';
export { browserCheck } from './browserCheck';
export type { SetupCheckItem, CheckStatus } from './browserCheck';
