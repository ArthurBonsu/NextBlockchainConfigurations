// services/auth/passwordRules.ts
// A long password beats a complex one. Firebase's own minimum is 6, ours is stricter.

export const PASSWORD_MIN = 10;

// Returns a message when the new password is not acceptable, or null when it is fine.
export function checkNewPassword(password: string, repeated: string): string | null {
  if (password.length < PASSWORD_MIN) {
    return `Use at least ${PASSWORD_MIN} characters. A few random words work well.`;
  }

  if (password !== repeated) return 'The two passwords do not match.';

  return null;
}
