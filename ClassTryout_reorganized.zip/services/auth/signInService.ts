// services/auth/signInService.ts
// Every way to sign in or sign up, in one file. All of them use Firebase Authentication.
//
//   email + password   signInWithEmail, signUpWithEmail, sendResetEmail
//   Google / GitHub / X   signInWithProvider('google' | 'github' | 'twitter')
//
// Each function either works, or throws a Firebase error.
// Show the error to the user with friendlyAuthError() from ./authErrors.

import {
  GithubAuthProvider,
  GoogleAuthProvider,
  TwitterAuthProvider,
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
} from 'firebase/auth';
import type { AuthProvider as FirebaseProvider, User } from 'firebase/auth';
import { getFirebaseAuth } from '../firebase';

export type SocialProviderKind = 'google' | 'github' | 'twitter';

// ---------------------------------------------------------------- email and password
export async function signInWithEmail(email: string, password: string): Promise<void> {
  await signInWithEmailAndPassword(getFirebaseAuth(), email.trim(), password);
}

export async function signUpWithEmail(email: string, password: string): Promise<void> {
  const credential = await createUserWithEmailAndPassword(getFirebaseAuth(), email.trim(), password);

  // The account exists now. If the verification email fails to send, the person can ask for it again later.
  await sendEmailVerification(credential.user).catch(() => {});
}

export async function sendResetEmail(email: string): Promise<void> {
  await sendPasswordResetEmail(getFirebaseAuth(), email.trim());
}

export async function sendVerificationEmail(user: User): Promise<void> {
  await sendEmailVerification(user);
}

// ---------------------------------------------------------------- Google, GitHub and X
function createProvider(kind: SocialProviderKind): FirebaseProvider {
  if (kind === 'google') {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' }); // let people choose which Google account

    return provider;
  }

  if (kind === 'github') {
    const provider = new GithubAuthProvider();
    provider.addScope('user:email'); // ask GitHub for the email address

    return provider;
  }

  return new TwitterAuthProvider();
}

// Opens the provider's sign-in window. The same call signs in a returning person and creates a new account.
export async function signInWithProvider(kind: SocialProviderKind): Promise<void> {
  await signInWithPopup(getFirebaseAuth(), createProvider(kind));
}

// ---------------------------------------------------------------- sign out
export async function signOutUser(): Promise<void> {
  await signOut(getFirebaseAuth());
}
