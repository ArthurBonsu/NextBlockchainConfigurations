// services/api/apiClient.ts
// Calls OUR OWN API (pages/api/*) with the signed-in person's ID token.
// When something goes wrong, the error keeps the server's code and the per-field messages.

import { getIdToken } from '../auth';

const TIMEOUT_MS = 20000;

export class ApiError extends Error {
  status: number;
  code: string;
  fields: Record<string, string>;
  retryAfter?: number;

  constructor(status: number, message: string, code: string, fields?: Record<string, string>, retryAfter?: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.fields = fields || {};
    this.retryAfter = retryAfter;
  }
}

export interface ApiOptions {
  method?: string;
  body?: unknown;
}

// One attempt, with a time limit.
async function sendOnce(path: string, options: ApiOptions, forceRefresh: boolean): Promise<Response> {
  const token = await getIdToken(forceRefresh);
  const hasBody = options.body !== undefined;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    return await fetch(path, {
      method: options.method || (hasBody ? 'POST' : 'GET'),
      headers: {
        Authorization: `Bearer ${token}`,
        ...(hasBody ? { 'Content-Type': 'application/json' } : {}),
      },
      body: hasBody ? JSON.stringify(options.body) : undefined,
      signal: controller.signal,
    });
  } catch (err: any) {
    // fetch only throws when no answer came back at all.
    const timedOut = err && err.name === 'AbortError';

    throw new ApiError(
      0,
      timedOut
        ? 'The server did not answer in time. Is the site still running?'
        : "Could not reach the site's server. Is it running, and are you online?",
      timedOut ? 'timeout' : 'network'
    );
  } finally {
    clearTimeout(timer);
  }
}

const EXPIRED_TOKEN_CODES = ['token_expired', 'unauthenticated', 'invalid_token'];

export async function api<T = any>(path: string, options: ApiOptions = {}): Promise<T> {
  let response = await sendOnce(path, options, false);

  // An ID token lasts one hour. If the server says it expired, get a fresh one from Firebase and try once more.
  if (response.status === 401) {
    const answer = await response.clone().json().catch(() => null);

    if (answer && EXPIRED_TOKEN_CODES.includes(answer.code)) {
      response = await sendOnce(path, options, true);
    }
  }

  let data: any = null;
  try {
    data = await response.json();
  } catch {
    // The answer had no body.
  }

  if (!response.ok) {
    throw new ApiError(
      response.status,
      (data && data.error) || `Request failed (${response.status}).`,
      (data && data.code) || 'error',
      data && data.fields,
      data && data.retryAfter
    );
  }

  return data as T;
}
