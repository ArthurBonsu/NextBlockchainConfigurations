// Firebase on the BROWSER side: sign-in only. These NEXT_PUBLIC_ values are public by design (they identify the project;
// they are not secrets). Security comes from the server verifying every ID token and from the Firestore rules.
import { FirebaseApp, getApp, getApps, initializeApp } from "firebase/app";
import { Auth, connectAuthEmulator, getAuth } from "firebase/auth";

export const firebaseConfigured = Boolean(process.env.NEXT_PUBLIC_FIREBASE_API_KEY && process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID);

let auth: Auth | null = null;

export function getFirebaseAuth(): Auth {
  if (auth) return auth;
  if (!firebaseConfigured) {
    throw new Error("Firebase sign-in is not set up. Set the NEXT_PUBLIC_FIREBASE_* values in .env.local (see .env.local.example).");
  }
  const app: FirebaseApp = getApps().length
    ? getApp()
    : initializeApp({
        apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
        authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
        projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
        appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
      });
  auth = getAuth(app);
  const emu = process.env.NEXT_PUBLIC_FIREBASE_AUTH_EMULATOR; // e.g. http://127.0.0.1:9099 (local testing only)
  if (emu && process.env.NODE_ENV !== "production") connectAuthEmulator(auth, emu, { disableWarnings: true });
  return auth;
}
