// Turns the many shapes of wallet / web3 / contract errors into one short, human-readable sentence
// for the UI. Never shows raw JSON receipts.
//
// OpenZeppelin 5 reports failures as custom errors (not require() strings). Wallets hand back
// only a 4-byte selector, so both the error name (when web3 could decode it) and the raw
// selector are recognised.
const CUSTOM_ERRORS: { name: string; selector: string; message: string }[] = [
  {
    name: "OwnableUnauthorizedAccount",
    selector: "0x118cdaa7",
    message: "Only the admin wallet can do this. You are connected with a different wallet.",
  },
  { name: "OwnableInvalidOwner", selector: "0x1e4fbdf7", message: "That is not a valid admin address." },
  { name: "EnforcedPause", selector: "0xd93c0665", message: "This contract is paused by the admin. Please try again later." },
  { name: "ExpectedPause", selector: "0x8dfc202b", message: "The contract is not paused." },
];

export function friendlyError(err: any): string {
  if (!err) return "Something went wrong.";

  // User pressed "Reject" in the wallet
  if (err.code === 4001 || err.code === "ACTION_REJECTED" || /user (rejected|denied)/i.test(err.message || "")) {
    return "You rejected the request in your wallet.";
  }

  const parts: string[] = [
    err.cause?.message,
    err.cause?.data?.message,
    err.data?.message,
    err.data?.reason,
    err.reason,
    err.message,
  ].filter(Boolean);
  const text = parts.join(" | ");

  // Custom errors: by decoded name, or by selector anywhere in the error payload.
  const payload = (text + " " + safeJson(err.data) + " " + safeJson(err.cause?.data) + " " + safeJson(err.cause)).toLowerCase();
  const decodedName: string | undefined = err.cause?.errorName || err.errorName || err.innerError?.errorName;
  for (const e of CUSTOM_ERRORS) {
    if (decodedName === e.name || payload.includes(e.name.toLowerCase()) || payload.includes(e.selector)) return e.message;
  }

  // Revert reason strings: "execution reverted: Pseudonym already registered"
  const reason =
    text.match(/execution reverted:?\s*([^"|{}\n]+)/i) ||
    text.match(/reverted with reason string ['"]([^'"]+)['"]/i) ||
    text.match(/Reason given:\s*([^"|{}\n]+)/i) ||
    text.match(/revert\s+([A-Z][^"|{}\n]{3,})/);
  if (reason && reason[1].trim()) return reason[1].trim().replace(/\.$/, "") + ".";

  if (/out of gas/i.test(text)) return "The transaction ran out of gas. Try again and let the wallet set the gas limit.";
  if (/insufficient funds/i.test(text)) return "This wallet doesn't have enough ETH to pay for gas.";
  if (/Transaction has been reverted by the EVM|Error happened while trying to execute a function inside a smart contract/i.test(text)) {
    return "The contract rejected this transaction (it reverted). Check that the IDs exist, aren't already used, and that you are using the admin wallet for admin actions.";
  }
  if (/nonce/i.test(text) && /too low|already/i.test(text)) {
    return "Wallet nonce mismatch. If you reset Ganache, reset the account in MetaMask (Settings > Advanced > Clear activity tab data).";
  }

  // Strip any JSON blob and cap length
  const cleaned = (err.message || String(err)).replace(/\{[\s\S]*\}/g, "").replace(/\s+/g, " ").trim();
  return (cleaned || "Something went wrong.").slice(0, 240);
}

function safeJson(v: unknown): string {
  try {
    return v === undefined ? "" : JSON.stringify(v);
  } catch {
    return "";
  }
}
