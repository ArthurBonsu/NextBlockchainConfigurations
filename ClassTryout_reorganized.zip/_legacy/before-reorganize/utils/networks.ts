// ---------------------------------------------------------------------------
// Network list for the network picker. The data lives in shared/chains.json, the same file
// truffle-config.js uses, so the front end and the deployment tooling cannot disagree.
// To add or change a network, edit that file only.
//
// MetaMask already knows most of these chains; rpcUrls/explorer are only used when the
// wallet has never seen the chain and we have to ask it to add it (wallet_addEthereumChain).
//
// To hide networks from users, set in .env.local (then restart `next dev`):
//   NEXT_PUBLIC_ENABLED_CHAINS=11155111,84532,421614
// Leave it unset to show everything.
// ---------------------------------------------------------------------------
import chainsFile from "../shared/chains.json";

export type NetworkKind = "L1" | "L2" | "Sidechain" | "Local";

export interface AppNetwork {
  chainId: number;
  key: string; // Truffle network name, e.g. "baseSepolia" -> `truffle migrate --network baseSepolia`
  name: string;
  kind: NetworkKind;
  testnet: boolean;
  rpcUrls: string[];
  explorer: string; // base URL, no trailing slash ("" for local)
  currency: { name: string; symbol: string; decimals: number };
  infura: string | null;
}

export const NETWORKS: AppNetwork[] = (chainsFile.chains as unknown as AppNetwork[]).slice();

export function getNetwork(chainId: number | string): AppNetwork | undefined {
  const id = Number(chainId);
  return NETWORKS.find((n) => n.chainId === id);
}

// Real money = not a testnet and not local.
export function isRealMoney(chainId: number | string): boolean {
  const n = getNetwork(chainId);
  return !!n && !n.testnet && n.kind !== "Local";
}

export function networkLabel(chainId: number | string): string {
  const n = getNetwork(chainId);
  // Ganache Desktop reports chain id 1337; some setups use 5777.
  if (!n && Number(chainId) === 5777) return "Ganache (local)";
  return n ? n.name : `Chain ${chainId}`;
}

export function explorerTxUrl(chainId: number | string, txHash: string): string | null {
  const n = getNetwork(chainId);
  return n && n.explorer ? `${n.explorer}/tx/${txHash}` : null;
}

// The networks offered in the picker, after applying env switches.
export function enabledNetworks(): AppNetwork[] {
  const raw = process.env.NEXT_PUBLIC_ENABLED_CHAINS;
  const allow = raw
    ? new Set(
        raw
          .split(",")
          .map((s) => Number(s.trim()))
          .filter((n) => Number.isFinite(n) && n > 0)
      )
    : null;
  const showLocal = process.env.NEXT_PUBLIC_SHOW_LOCAL === "true" || process.env.NODE_ENV !== "production";
  return NETWORKS.filter((n) => {
    if (n.kind === "Local") return showLocal && (!allow || allow.has(n.chainId));
    return !allow || allow.has(n.chainId);
  });
}

// Ask the wallet to switch to a network, adding it first if the wallet doesn't know it.
export async function switchWalletNetwork(chainId: number): Promise<void> {
  const eth = typeof window !== "undefined" ? (window as any).ethereum : undefined;
  if (!eth) throw new Error("MetaMask not found. Please install it.");
  const hexId = "0x" + chainId.toString(16);
  try {
    await eth.request({ method: "wallet_switchEthereumChain", params: [{ chainId: hexId }] });
  } catch (err: any) {
    const unknownChain = err?.code === 4902 || /unrecognized chain|not been added/i.test(err?.message || "");
    const n = getNetwork(chainId);
    if (!unknownChain || !n) throw err;
    await eth.request({
      method: "wallet_addEthereumChain",
      params: [
        {
          chainId: hexId,
          chainName: n.name,
          rpcUrls: n.rpcUrls,
          nativeCurrency: n.currency,
          blockExplorerUrls: n.explorer ? [n.explorer] : undefined,
        },
      ],
    });
  }
}
