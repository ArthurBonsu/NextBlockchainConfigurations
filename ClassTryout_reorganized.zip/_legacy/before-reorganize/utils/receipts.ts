import { Contract, utils } from "web3";
import type Web3 from "web3";

/**
 * This file is the answer to "how do we see all this on the blockchain
 * without building a centralized database": we don't store anything
 * anywhere off-chain. Every write (register / issue / revoke / reinstate)
 * emits an event. A block explorer, a wallet, or this file's
 * `getVehicleTimeline` can all reconstruct full history purely by reading
 * those events back from the chain itself — the chain's own event log IS
 * the database. Two pieces make this work:
 *
 * 1. A "receipt" for a fresh transaction is built straight from the
 *    receipt web3.js hands back from `.send()` — it already comes with
 *    `.events` decoded (web3.js does this automatically when the
 *    contract's ABI has the event), so there's no manual log-parsing
 *    needed. No write to anywhere else happens.
 * 2. History for something you didn't just do yourself (or are revisiting
 *    later, in a new browser session) is read back with
 *    `contract.getPastEvents(...)` — an RPC call that asks the node "give
 *    me every log matching this event, optionally filtered by an indexed
 *    argument". That's a trustless read straight from chain state, not a
 *    call to any server Claude or you control.
 */

export interface Receipt {
  action: string;
  subject: string;
  details: Record<string, string>;
  txHash: string;
  blockNumber: number;
  timestamp: string;
}

export function buildReceipt(
  action: string,
  subject: string,
  details: Record<string, string>,
  txHash: string,
  blockNumber: number | bigint,
  timestampSeconds: bigint | number | string
): Receipt {
  return {
    action,
    subject,
    details,
    txHash,
    blockNumber: Number(blockNumber),
    timestamp: new Date(Number(timestampSeconds) * 1000).toLocaleString(),
  };
}

const RANGE_LIMIT_ERROR = /range|limit|exceed|too many|more than|response size|timed? ?out|payload|10000|10,000/i;

// getPastEvents over a block range, splitting the range in half whenever the node rejects it as too large.
async function pastEventsPaged(
  c: Contract<any>,
  eventName: string,
  from: number,
  to: number,
  filter?: Record<string, unknown>,
  depth = 0
): Promise<any[]> {
  try {
    return (await c.getPastEvents(eventName as any, { filter, fromBlock: from, toBlock: to } as any)) as any[];
  } catch (err: any) {
    const text = [err?.message, err?.cause?.message, err?.innerError?.message].filter(Boolean).join(" ");
    if (from >= to || depth >= 20 || !RANGE_LIMIT_ERROR.test(text)) throw err;
    const mid = Math.floor((from + to) / 2);
    const left = await pastEventsPaged(c, eventName, from, mid, filter, depth + 1);
    const right = await pastEventsPaged(c, eventName, mid + 1, to, filter, depth + 1);
    return [...left, ...right];
  }
}

export interface TimelineEntry {
  type: string;
  timestamp: string;
  txHash: string;
  blockNumber: number;
  details: Record<string, string>;
}

/**
 * Pulls the full on-chain history for one vehicle pseudonym by querying
 * every relevant event across all three contracts and merging the results
 * into one chronological timeline. No off-chain storage involved — this
 * runs fresh, live, every time it's called.
 *
 * Note on indexing: VehicleRegistered/VehicleRemoved are indexed by
 * pseudonym, so those two queries are filtered efficiently at the RPC
 * level via web3's `filter` option. VehicleRevoked/VehicleReinstated/
 * LicenseIssued were NOT declared with `indexed` on the pseudonym field
 * (an easy thing to miss when writing events), so those come back as the
 * full event list and get filtered client-side here instead. Fine for a
 * demo's event volume; for a production deployment with thousands of
 * vehicles, redeploy those events with the pseudonym's hash indexed (or
 * run a subgraph) so the node does that filtering instead of the browser.
 */
export async function getVehicleTimeline(
  contracts: { web3: Web3; registry: Contract<any>; revocation: Contract<any>; license: Contract<any> },
  vehiclePseudonym: string,
  startBlock = 0
): Promise<TimelineEntry[]> {
  const { web3, registry, revocation, license } = contracts;
  const entries: TimelineEntry[] = [];
  const latest = Number(await web3.eth.getBlockNumber());
  const fromBlock = Math.max(0, Math.min(startBlock, latest));

  // Reads one event type over [fromBlock, latest]. Public RPCs cap how many blocks / results one
  // eth_getLogs call may cover; when a call is rejected for that reason the range is halved and retried.
  const getEvents = (c: Contract<any>, eventName: string, filter?: Record<string, unknown>) =>
    pastEventsPaged(c, eventName, fromBlock, latest, filter);

  // --- Registration (indexed — efficient) ---
  const registeredEvents = await getEvents(registry, "VehicleRegistered", { pseudonym: vehiclePseudonym });
  for (const e of registeredEvents as any[]) {
    entries.push({
      type: "Vehicle Registered",
      timestamp: new Date(Number(e.returnValues.timestamp) * 1000).toLocaleString(),
      txHash: e.transactionHash,
      blockNumber: Number(e.blockNumber),
      details: { owner: e.returnValues.owner },
    });
  }

  // --- Removal (indexed — efficient) ---
  const removedEvents = await getEvents(registry, "VehicleRemoved", { pseudonym: vehiclePseudonym });
  for (const e of removedEvents as any[]) {
    entries.push({
      type: "Vehicle Removed",
      timestamp: new Date(Number(e.returnValues.timestamp) * 1000).toLocaleString(),
      txHash: e.transactionHash,
      blockNumber: Number(e.blockNumber),
      details: {},
    });
  }

  // --- Revocation reports naming this vehicle as offender (not indexed by pseudonym — filtered here) ---
  const allReports = await getEvents(revocation, "ReportSubmitted");
  for (const e of allReports as any[]) {
    if (e.returnValues.offender === vehiclePseudonym) {
      entries.push({
        type: "Revocation Report Submitted",
        timestamp: new Date(Number(e.returnValues.timestamp) * 1000).toLocaleString(),
        txHash: e.transactionHash,
        blockNumber: Number(e.blockNumber),
        details: { reporter: e.returnValues.reporter, reportId: e.returnValues.reportId.toString() },
      });
    }
  }

  // --- Revocations / reinstatements (not indexed by pseudonym — filtered here) ---
  const allRevocations = await getEvents(revocation, "VehicleRevoked");
  for (const e of allRevocations as any[]) {
    if (e.returnValues.pseudonym === vehiclePseudonym) {
      entries.push({
        type: "Vehicle Revoked",
        timestamp: new Date(Number(e.returnValues.timestamp) * 1000).toLocaleString(),
        txHash: e.transactionHash,
        blockNumber: Number(e.blockNumber),
        details: { reason: e.returnValues.reason },
      });
    }
  }

  const allReinstatements = await getEvents(revocation, "VehicleReinstated");
  for (const e of allReinstatements as any[]) {
    if (e.returnValues.pseudonym === vehiclePseudonym) {
      entries.push({
        type: "Vehicle Reinstated",
        timestamp: new Date(Number(e.returnValues.timestamp) * 1000).toLocaleString(),
        txHash: e.transactionHash,
        blockNumber: Number(e.blockNumber),
        details: {},
      });
    }
  }

  // --- Licenses ---
  // LicenseIssued / LicenseRevoked / LicenseReinstated declare `licenseId` as `string indexed`.
  // For an indexed string the log stores only keccak256(licenseId), so event.returnValues.licenseId
  // is that 0x-hash, NOT the readable id. Two consequences handled here:
  //   1. Passing that hash back as a `filter` re-hashes it and matches nothing — so we do NOT filter
  //      by licenseId at the RPC level; we read all events and match client-side.
  //   2. To show the readable id, hash the vehicle's current license id (from the view function
  //      getLicenseByVehicle) and compare it with the hash in the event.
  const hashOf = (id: string) => utils.keccak256(id).toLowerCase();
  let currentLicenseId = "";
  try {
    currentLicenseId = await license.methods.getLicenseByVehicle(vehiclePseudonym).call();
  } catch {
    /* no license yet */
  }
  const currentHash = currentLicenseId ? hashOf(currentLicenseId) : "";
  const labelFor = (hash: string) =>
    hash.toLowerCase() === currentHash ? currentLicenseId : `${hash.slice(0, 10)}…`;

  const vehicleLicenseHashes = new Set<string>();

  const allLicenses = await getEvents(license, "LicenseIssued");
  for (const e of allLicenses as any[]) {
    if (e.returnValues.vehiclePseudonym === vehiclePseudonym) {
      const h = String(e.returnValues.licenseId).toLowerCase();
      vehicleLicenseHashes.add(h);
      entries.push({
        type: "License Issued",
        timestamp: new Date(Number(e.returnValues.issueTime) * 1000).toLocaleString(),
        txHash: e.transactionHash,
        blockNumber: Number(e.blockNumber),
        details: {
          licenseId: labelFor(h),
          licenseType: e.returnValues.licenseType,
          owner: e.returnValues.owner,
        },
      });
    }
  }

  // LicenseRevoked also carries the plain-text vehiclePseudonym, so match on that.
  const allLicenseRevocations = await getEvents(license, "LicenseRevoked");
  for (const e of allLicenseRevocations as any[]) {
    const h = String(e.returnValues.licenseId).toLowerCase();
    if (e.returnValues.vehiclePseudonym === vehiclePseudonym || vehicleLicenseHashes.has(h)) {
      entries.push({
        type: "License Revoked",
        timestamp: new Date(Number(e.returnValues.timestamp) * 1000).toLocaleString(),
        txHash: e.transactionHash,
        blockNumber: Number(e.blockNumber),
        details: { licenseId: labelFor(h) },
      });
    }
  }

  // LicenseReinstated only carries the (hashed) licenseId, so match against this vehicle's known hashes.
  const allLicenseReinstatements = await getEvents(license, "LicenseReinstated");
  for (const e of allLicenseReinstatements as any[]) {
    const h = String(e.returnValues.licenseId).toLowerCase();
    if (vehicleLicenseHashes.has(h)) {
      entries.push({
        type: "License Reinstated",
        timestamp: new Date(Number(e.returnValues.timestamp) * 1000).toLocaleString(),
        txHash: e.transactionHash,
        blockNumber: Number(e.blockNumber),
        details: { licenseId: labelFor(h) },
      });
    }
  }

  entries.sort((a, b) => a.blockNumber - b.blockNumber);
  return entries;
}
