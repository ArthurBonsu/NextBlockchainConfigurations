// Calls our own API with the signed-in person's ID token. Errors keep the server's machine-readable code and field messages.
import { getIdToken } from "./auth";

export class ApiError extends Error {
  status: number;
  code: string;
  fields: Record<string, string>;
  retryAfter?: number;
  constructor(status: number, message: string, code: string, fields?: Record<string, string>, retryAfter?: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.fields = fields || {};
    this.retryAfter = retryAfter;
  }
}

export async function api<T = any>(path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  const token = await getIdToken();
  const res = await fetch(path, {
    method: init.method || (init.body !== undefined ? "POST" : "GET"),
    headers: { Authorization: `Bearer ${token}`, ...(init.body !== undefined ? { "Content-Type": "application/json" } : {}) },
    body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
  });
  let data: any = null;
  try {
    data = await res.json();
  } catch {
    /* empty body */
  }
  if (!res.ok) throw new ApiError(res.status, (data && data.error) || `Request failed (${res.status}).`, (data && data.code) || "error", data && data.fields, data && data.retryAfter);
  return data as T;
}
