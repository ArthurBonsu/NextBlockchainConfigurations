// What GET /api/me returns (server/users.js `view`). Kept by hand next to the server code; the consistency check compares the field names.
export type Capability = { allowed: boolean; reason?: string; need?: { roles?: string[]; level?: number; have?: number } };
export type IdDocument = { id: string; type: string; label: string; last4: string; country: string | null; expiry: string | null; status: string; createdAt: string; note?: string | null };
export type Address = {
  regionCode: string; regionName: string; districtId: string; districtName: string; city: string; suburb: string;
  subarea?: string; street?: string; gpsAddress?: string; lat?: number; lng?: number;
};
export type Me = {
  uid: string;
  email: string | null;
  emailVerified: boolean;
  provider: string;
  role: "citizen" | "officer" | "admin" | "super_admin";
  status: "active" | "suspended";
  profile: { givenName?: string; familyName?: string; otherNames?: string; displayName?: string; dob?: string; gender?: string; nationality?: string };
  phone: { verified: boolean; masked?: string; verifiedAt?: string };
  address: Address | null;
  identity: { level: 0 | 1 | 2; types: string[] };
  consents: Record<string, { version: string; at: string }>;
  notifications: { email: boolean; sms: boolean };
  onboarding: { steps: string[]; done: Record<string, boolean>; complete: boolean; next: string | null; required: string[]; optional: string[] };
  capabilities: Record<string, Capability>;
  documents?: IdDocument[];
  pendingPhone?: { masked: string; resendAfter: string; expiresAt: string } | null;
  suggestedName?: string | null;
  createdAt: string;
};
