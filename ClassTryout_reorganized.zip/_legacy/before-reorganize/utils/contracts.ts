import Web3 from "web3";
import { VehicleRegistryAbi } from "../shared/abi/VehicleRegistry";
import { RevocationManagerAbi } from "../shared/abi/RevocationManager";
import { LicenseRegistryAbi } from "../shared/abi/LicenseRegistry";
import publicDeployments from "../shared/deployments.json";
import localDeployments from "../shared/deployments.local.json";
import { getNetwork } from "./networks";

declare global {
  interface Window {
    ethereum?: any;
  }
}

// ---------------------------------------------------------------------------
// WHERE EVERYTHING COMES FROM (one place for each thing)
//
//  ABI        shared/abi/*.ts          generated from contracts/*.sol by `npm run contracts:compile`.
//                                      It depends only on the Solidity source, never on a deployment,
//                                      so it exists (and every method name is type-checked) before
//                                      anything is deployed anywhere.
//  ADDRESSES  shared/deployments.json  public chains, keyed by chain id; written by the migrations.
//             shared/deployments.local.json  Ganache / private chains, keyed by network id; git-ignored.
//  NETWORKS   shared/chains.json       (through utils/networks.ts) the same list truffle-config.js uses.
//
// Nothing here reads build/contracts/ or any Passchain file.
// ---------------------------------------------------------------------------

export const CONTRACT_NAMES = ["VehicleRegistry", "RevocationManager", "LicenseRegistry"] as const;
export type ContractName = (typeof CONTRACT_NAMES)[number];

export interface DeploymentEntry {
  address: string;
  startBlock: number;
  txHash?: string | null;
}
export type Deployment = Record<ContractName, DeploymentEntry>;

function complete(entry: any): Deployment | undefined {
  if (!entry) return undefined;
  for (const name of CONTRACT_NAMES) if (!entry[name]?.address) return undefined;
  return entry as Deployment;
}

// Looks up the deployment for the connected chain. Public chains match by chain id.
// Local chains match by network id (what Truffle recorded), with chain id as a fallback,
// because Ganache Desktop reports network id 5777 but chain id 1337.
export function getDeployment(chainId: string | number, networkId?: string | number): Deployment | undefined {
  const pub = complete((publicDeployments as Record<string, any>)[String(chainId)]);
  if (pub) return pub;
  const local = localDeployments as Record<string, any>;
  return complete(networkId !== undefined ? local[String(networkId)] : undefined) || complete(local[String(chainId)]);
}

// True when we have addresses for all three contracts on this chain. Used by the network picker to
// label chains with no deployment. A local chain's network id is arbitrary, so local chains are
// checked for real on connect instead.
export function isDeployedOnChain(chainId: number | string): boolean {
  if (getNetwork(chainId)?.kind === "Local" || Number(chainId) === 5777) return true;
  return !!getDeployment(chainId);
}

export async function connectWallet(): Promise<{ web3: Web3; account: string; chainId: string; networkId: string }> {
  if (!window.ethereum) throw new Error("MetaMask not found. Please install it.");
  await window.ethereum.request({ method: "eth_requestAccounts" });

  const web3 = new Web3(window.ethereum);
  const accounts = await web3.eth.getAccounts();
  const chainId = (await web3.eth.getChainId()).toString();
  const networkId = (await web3.eth.net.getId()).toString();

  return { web3, account: accounts[0], chainId, networkId };
}

// Throws a clear message if nothing is deployed at the address (stale address after a
// Ganache restart, wrong network selected in the wallet, or a hand-edited deployments file).
async function assertDeployed(web3: Web3, name: string, address: string, chainId: string) {
  const code = await web3.eth.getCode(address);
  if (!code || code === "0x" || code === "0x0") {
    throw new Error(
      `No contract code for ${name} at ${address} on chain ${chainId}. ` +
        `Either the wallet is on the wrong network, or this address is stale (local chain restarted / contract not deployed). ` +
        `Run "npm run deploy:local" (local) or the deploy script for this network, then restart the dev server.`
    );
  }
}

// Split out from getContracts() so it can be tested without a browser wallet.
export async function resolveContracts(web3: Web3, account: string, chainId: string, networkId: string) {
  const deployment = getDeployment(chainId, networkId);
  if (!deployment) {
    const n = getNetwork(chainId);
    const how = n && n.kind !== "Local" ? `npx truffle migrate --network ${n.key}` : "npm run deploy:local";
    throw new Error(
      `The contracts are not deployed on ${n ? n.name : "chain " + chainId} (chain ${chainId}, network id ${networkId}). ` +
        `Deploy with "${how}", commit shared/deployments.json, and restart the dev server.`
    );
  }

  await assertDeployed(web3, "VehicleRegistry", deployment.VehicleRegistry.address, chainId);
  await assertDeployed(web3, "RevocationManager", deployment.RevocationManager.address, chainId);
  await assertDeployed(web3, "LicenseRegistry", deployment.LicenseRegistry.address, chainId);

  // The ABIs are `as const`, so every .methods.<name>(...) below is type-checked against the real contract.
  const registry = new web3.eth.Contract(VehicleRegistryAbi, deployment.VehicleRegistry.address);
  const revocation = new web3.eth.Contract(RevocationManagerAbi, deployment.RevocationManager.address);
  const license = new web3.eth.Contract(LicenseRegistryAbi, deployment.LicenseRegistry.address);

  // So every .send() call can omit `from` if it wants to; components still pass { from: account } for clarity.
  registry.defaultAccount = account;
  revocation.defaultAccount = account;
  license.defaultAccount = account;

  return { web3, registry, revocation, license, account, chainId, networkId, deployment };
}

export async function getContracts() {
  const { web3, account, chainId, networkId } = await connectWallet();
  return resolveContracts(web3, account, chainId, networkId);
}

// What the connected wallet is allowed to do, read from the contracts themselves (OpenZeppelin Ownable / Pausable).
export interface ContractStatus {
  name: ContractName;
  address: string;
  owner: string;
  paused: boolean;
}

export async function getContractStatuses(): Promise<{ account: string; chainId: string; isAdmin: boolean; statuses: ContractStatus[] }> {
  const { registry, revocation, license, account, chainId, deployment } = await getContracts();
  const rows: { name: ContractName; c: { methods: { owner(): { call(): Promise<any> }; paused(): { call(): Promise<any> } } } }[] = [
    { name: "VehicleRegistry", c: registry as any },
    { name: "RevocationManager", c: revocation as any },
    { name: "LicenseRegistry", c: license as any },
  ];
  const statuses: ContractStatus[] = [];
  for (const { name, c } of rows) {
    const [owner, paused] = await Promise.all([c.methods.owner().call(), c.methods.paused().call()]);
    statuses.push({ name, address: deployment[name].address, owner: String(owner), paused: Boolean(paused) });
  }
  const isAdmin = statuses.some((s) => s.owner.toLowerCase() === account.toLowerCase());
  return { account, chainId, isAdmin, statuses };
}

// Sends a transaction and, when it fails, explains WHY. A wallet's own error is often vague ("internal JSON-RPC
// error"). Replaying the same call read-only (eth_call) makes the node answer with the exact revert reason, which web3
// decodes against the contract ABI, including OpenZeppelin's custom errors such as OwnableUnauthorizedAccount.
// Every write in the app goes through this, so every panel reports failures the same way.
export async function sendTx<T>(
  method: { send(options: { from: string }): Promise<T>; call(options: { from: string }): Promise<unknown> },
  from: string
): Promise<T> {
  try {
    return await method.send({ from });
  } catch (err: any) {
    if (err?.code === 4001 || /user (rejected|denied)/i.test(err?.message || "")) throw err; // user said no: nothing to explain
    try {
      await method.call({ from });
    } catch (reason) {
      throw reason; // the simulation shows the real revert reason
    }
    throw err; // the simulation succeeded: the failure was not a revert (gas, nonce, network), keep the original
  }
}
