// Browser side of the wallet-link API (pages/api/wallet-link/*). The email address is never sent to or stored by the
// chain; the server only remembers  wallet address -> account.
import Web3 from "web3";
import { getIdToken } from "./auth";

export type LinkedWallet = { address: string; linkedAt: string };

async function call(path: string, init: { method: string; body?: unknown } = { method: "GET" }) {
  const token = await getIdToken();
  const res = await fetch(`/api/wallet-link${path}`, {
    method: init.method,
    headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
    body: init.body ? JSON.stringify(init.body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || `Request failed (${res.status}).`);
  return json;
}

export async function listLinkedWallets(): Promise<LinkedWallet[]> {
  return (await call("")).wallets;
}

// Ask the server for a message, have the wallet sign it (free, no transaction), send the signature back.
export async function linkWallet(web3: Web3, account: string): Promise<void> {
  const challenge = await call("/challenge", { method: "POST", body: { address: account } });
  const signature = await web3.eth.personal.sign(challenge.message, account, "");
  await call("/confirm", { method: "POST", body: { ...challenge, signature } });
}

export async function unlinkWallet(address: string): Promise<void> {
  await call("", { method: "DELETE", body: { address } });
}
