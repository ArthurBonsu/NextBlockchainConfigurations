// Fixed-window counters kept in Firestore (collection "rateLimits"), so limits hold across serverless instances.
// Keys are hashed before they are stored, so IP addresses and phone numbers are not written in the clear.
const { store, nowIso } = require("./store.js");
const { sha256 } = require("./crypto.js");
const { tooMany } = require("./httpError.js");

// hit("otp:phone:+233...", 5, 86400)  -> throws a 429 HttpError when the limit is passed.
async function hit(key, limit, windowSeconds, message) {
  const now = Date.now();
  const bucket = Math.floor(now / (windowSeconds * 1000));
  const id = sha256(`${key}|${windowSeconds}`).slice(0, 40) + "-" + bucket;
  const resetAt = (bucket + 1) * windowSeconds * 1000;
  const count = await store().transaction(async (tx) => {
    const cur = await tx.get("rateLimits", id);
    const n = (cur ? cur.count : 0) + 1;
    await tx.set("rateLimits", id, { count: n, windowSeconds, createdAt: cur ? cur.createdAt : nowIso(), expireAt: new Date(resetAt + 3600_000).toISOString() });
    return n;
  });
  if (count > limit) {
    const retryAfter = Math.max(1, Math.ceil((resetAt - now) / 1000));
    throw tooMany(message || "Too many attempts. Please wait and try again.", retryAfter);
  }
  return { count, remaining: limit - count };
}

module.exports = { hit };
