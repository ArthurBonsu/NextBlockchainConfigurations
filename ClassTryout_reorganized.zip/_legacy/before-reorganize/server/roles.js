// "Can this account do this?" One function the API and the UI both rely on. The rules are data: shared/roles.json.
const policy = require("../shared/roles.json");

const ROLES = policy.roles;
const isRole = (r) => ROLES.includes(r);

// user = the users/{uid} document. onboardingComplete is passed in (computed in users.js) to avoid a require cycle.
// Returns { allowed, reason, need } where reason is one of:
//   unknown_capability | suspended | role | onboarding | email_unverified | level
function check(user, capability, { onboardingComplete }) {
  const cap = policy.capabilities[capability];
  if (!cap) return { allowed: false, reason: "unknown_capability" };
  if (!user) return { allowed: false, reason: "role", need: { roles: cap.roles } };
  if (user.status === "suspended") return { allowed: false, reason: "suspended" };
  if (!cap.roles.includes(user.role)) return { allowed: false, reason: "role", need: { roles: cap.roles } };
  if (capability !== "account:use" && !onboardingComplete) return { allowed: false, reason: "onboarding" };
  if (capability !== "account:use" && user.email && user.emailVerified === false) return { allowed: false, reason: "email_unverified" };
  const level = (user.identity && user.identity.level) || 0;
  if (level < cap.minLevel) return { allowed: false, reason: "level", need: { level: cap.minLevel, have: level } };
  return { allowed: true };
}

function all(user, ctx) {
  const out = {};
  for (const name of Object.keys(policy.capabilities)) out[name] = check(user, name, ctx);
  return out;
}

const REASONS = {
  suspended: "This account is suspended.",
  role: "Your role does not allow this.",
  onboarding: "Finish setting up your account first.",
  email_unverified: "Verify your email address first.",
  level: "This needs a confirmed ID. Add your ID and wait for it to be confirmed.",
  unknown_capability: "Unknown action.",
};

module.exports = { policy, ROLES, isRole, check, all, REASONS };
