// Generic HTTP SMS provider, for any gateway that accepts a JSON POST or a GET with query parameters.
//   SMS_HTTP_URL        endpoint. In GET mode, {to} {text} {from} are replaced (URL-encoded) in the URL.
//   SMS_HTTP_METHOD     POST (default) or GET
//   SMS_HTTP_HEADERS    JSON object of headers, e.g. {"Authorization":"Bearer ..."}   (secret: keep in .env.local)
//   SMS_HTTP_BODY       JSON template for POST, e.g. {"sender":"{from}","to":"{to}","message":"{text}"}
//   SMS_SENDER_ID       sender name (at most 11 characters, registered with the provider)
// Success = any 2xx response. The response body is never logged (it can echo secrets).
async function send({ to, text }) {
  const url = process.env.SMS_HTTP_URL;
  if (!url) throw new Error("SMS_HTTP_URL is not configured.");
  const method = (process.env.SMS_HTTP_METHOD || "POST").toUpperCase();
  const from = process.env.SMS_SENDER_ID || "";
  const headers = process.env.SMS_HTTP_HEADERS ? JSON.parse(process.env.SMS_HTTP_HEADERS) : {};
  const fill = (tpl, enc) => tpl.replace(/\{to\}/g, enc(to)).replace(/\{text\}/g, enc(text)).replace(/\{from\}/g, enc(from));
  let res;
  if (method === "GET") {
    res = await fetch(fill(url, encodeURIComponent), { method: "GET", headers });
  } else {
    const tpl = process.env.SMS_HTTP_BODY || '{"sender":"{from}","recipient":"{to}","message":"{text}"}';
    const body = fill(tpl, (v) => JSON.stringify(v).slice(1, -1)); // JSON-escape inside the template
    res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json", ...headers }, body });
  }
  if (!res.ok) throw new Error(`SMS provider answered HTTP ${res.status}.`);
  return { id: null };
}
module.exports = { send };
