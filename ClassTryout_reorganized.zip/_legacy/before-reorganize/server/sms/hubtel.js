// Hubtel preset. UNVERIFIED: confirm the endpoint and parameters in your Hubtel dashboard/documentation before going live.
//   HUBTEL_CLIENT_ID, HUBTEL_CLIENT_SECRET, SMS_SENDER_ID
async function send({ to, text }) {
  const { HUBTEL_CLIENT_ID: id, HUBTEL_CLIENT_SECRET: secret } = process.env;
  if (!id || !secret) throw new Error("HUBTEL_CLIENT_ID / HUBTEL_CLIENT_SECRET are not configured.");
  const res = await fetch("https://smsc.hubtel.com/v1/messages/send", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: "Basic " + Buffer.from(`${id}:${secret}`).toString("base64") },
    body: JSON.stringify({ From: process.env.SMS_SENDER_ID || "ClassTryout", To: to.replace(/^\+/, ""), Content: text }),
  });
  if (!res.ok) throw new Error(`Hubtel answered HTTP ${res.status}.`);
  return { id: null };
}
module.exports = { send };
