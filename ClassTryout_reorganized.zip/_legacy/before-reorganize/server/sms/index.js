// Provider-neutral SMS sending. Choose with SMS_PROVIDER:
//   mock      writes each message to a local outbox file (SMS_OUTBOX_FILE); for tests and local work. Refused in production.
//   console   prints the message (never in production)
//   http      any provider with a simple JSON/GET HTTP API, configured by SMS_HTTP_* variables (see sms/http.js)
//   arkesel   preset for Arkesel's v2 API   (UNVERIFIED against live docs: check before relying on it)
//   hubtel    preset for Hubtel's messaging API (UNVERIFIED against live docs: check before relying on it)
//
// Adding a provider = one file exporting  send({ to, text }) -> { id? }  and one line in PROVIDERS.
// Our own code, not the provider, generates and checks one-time codes, so switching provider never changes how codes behave.
const { isProd } = require("../config.js");

const PROVIDERS = {
  mock: () => require("./mock.js"),
  console: () => require("./consoleProvider.js"),
  http: () => require("./http.js"),
  arkesel: () => require("./arkesel.js"),
  hubtel: () => require("./hubtel.js"),
};

function providerName() {
  return (process.env.SMS_PROVIDER || (isProd() ? "" : "mock")).toLowerCase();
}

function getProvider() {
  const name = providerName();
  if (!name) throw new Error("SMS_PROVIDER is not configured. Set it in .env.local (see .env.local.example).");
  if (isProd() && (name === "mock" || name === "console")) throw new Error(`SMS_PROVIDER=${name} is refused in production.`);
  if (!PROVIDERS[name]) throw new Error(`Unknown SMS_PROVIDER "${name}" (${Object.keys(PROVIDERS).join(", ")}).`);
  return { name, impl: PROVIDERS[name]() };
}

// to: E.164 ("+233241234567"). Throws on failure; the caller decides what to tell the user.
async function sendSms({ to, text }) {
  if (!/^\+[1-9][0-9]{7,14}$/.test(to)) throw new Error("Invalid recipient.");
  const { name, impl } = getProvider();
  const res = await impl.send({ to, text: String(text).slice(0, 480) });
  return { provider: name, id: (res && res.id) || null };
}

module.exports = { sendSms, providerName };
