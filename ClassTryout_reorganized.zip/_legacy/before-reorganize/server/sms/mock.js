// Test provider: appends each message as a JSON line to SMS_OUTBOX_FILE (default .data/sms-outbox.jsonl).
const fs = require("fs");
const path = require("path");
const { root } = require("../env.js");

const file = () => process.env.SMS_OUTBOX_FILE || path.join(root, ".data", "sms-outbox.jsonl");

async function send({ to, text }) {
  if (process.env.SMS_MOCK_FAIL === "1") throw new Error("mock provider told to fail");
  fs.mkdirSync(path.dirname(file()), { recursive: true });
  const id = "mock-" + Date.now() + "-" + Math.random().toString(16).slice(2, 8);
  fs.appendFileSync(file(), JSON.stringify({ id, to, text, at: new Date().toISOString() }) + "\n");
  return { id };
}

// Test helper: the latest message sent to a number.
function lastTo(to) {
  try {
    const rows = fs.readFileSync(file(), "utf8").split("\n").filter(Boolean).map((l) => JSON.parse(l));
    return rows.reverse().find((r) => r.to === to) || null;
  } catch {
    return null;
  }
}

module.exports = { send, lastTo, file };
