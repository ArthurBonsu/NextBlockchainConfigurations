async function send({ to, text }) {
  console.log(`[sms:console] to ${to}: ${text}`);
  return { id: "console" };
}
module.exports = { send };
