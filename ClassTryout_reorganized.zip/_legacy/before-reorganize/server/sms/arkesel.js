// Arkesel v2 preset. UNVERIFIED: written from the public description of the API; confirm endpoint, field names and
// sender-ID rules against Arkesel's current documentation (and your account) before going live.
//   ARKESEL_API_KEY, SMS_SENDER_ID
async function send({ to, text }) {
  const key = process.env.ARKESEL_API_KEY;
  if (!key) throw new Error("ARKESEL_API_KEY is not configured.");
  const res = await fetch("https://sms.arkesel.com/api/v2/sms/send", {
    method: "POST",
    headers: { "api-key": key, "Content-Type": "application/json" },
    body: JSON.stringify({ sender: process.env.SMS_SENDER_ID || "ClassTryout", message: text, recipients: [to.replace(/^\+/, "")] }),
  });
  if (!res.ok) throw new Error(`Arkesel answered HTTP ${res.status}.`);
  return { id: null };
}
module.exports = { send };
