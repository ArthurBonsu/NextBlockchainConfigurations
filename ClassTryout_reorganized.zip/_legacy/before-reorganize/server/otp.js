// Phone verification with one-time codes. WE generate and check the codes (the SMS provider only carries the message),
// so changing provider never changes how verification behaves.
//
//   phoneChallenges/{uid}   one live challenge per account (a resend replaces it)
//     { uid, phone (E.164), codeHmac, attempts, status, createdAt, resendAfter, expireAt }
//   phoneClaims/{hmac(phone)}   one verified phone per account:  { uid, claimedAt }
//
// Protections: consent first; per-phone, per-account and per-IP send limits; 60 s between sends; 5 wrong guesses lock the code;
// codes expire after 10 minutes; codes are stored only as a keyed hash; the code is never returned by the API or logged.
const onboarding = require("../shared/onboarding.json");
const { store, nowIso } = require("./store.js");
const { hmac, otpHmac, safeEqualHex, randomCode } = require("./crypto.js");
const { hit } = require("./rateLimit.js");
const { sendSms } = require("./sms/index.js");
const { normaliseGhPhone, last4, mask } = require("./phone.js");
const { bad, conflict, tooMany, forbidden, HttpError } = require("./httpError.js");
const { requireUser, touchOnboarding } = require("./users.js");
const { audit } = require("./audit.js");

const cfg = onboarding.otp;
const phoneClaimId = (e164) => hmac("phone", e164);

async function startPhoneVerification(uid, rawPhone, ip) {
  const phone = normaliseGhPhone(rawPhone);
  const u = await requireUser(uid);
  if (u.status === "suspended") throw forbidden("This account is suspended.", "suspended");
  const sms = u.consents && u.consents.sms;
  if (!(sms && sms.version === onboarding.consents.sms.version)) throw forbidden("Accept the SMS agreement first.", "consent_required");
  if (u.phone && u.phone.verified && u.phone.e164 === phone) throw conflict("This number is already verified on your account.", "already_verified");

  // Someone else already verified this number?
  const claim = await store().get("phoneClaims", phoneClaimId(phone));
  if (claim && claim.uid !== uid) throw conflict("This number is already used by another account.", "phone_in_use");

  // Wait between sends (checked before the counters so an impatient double-click does not burn the daily allowance).
  const existing = await store().get("phoneChallenges", uid);
  if (existing && existing.phone === phone && existing.resendAfter > nowIso()) {
    const wait = Math.max(1, Math.ceil((Date.parse(existing.resendAfter) - Date.now()) / 1000));
    throw tooMany(`Please wait ${wait} seconds before asking for another code.`, wait);
  }
  await hit(`otp:phone:${phone}`, cfg.maxSendsPerPhonePerDay, 86400, "Too many codes sent to this number today. Try again tomorrow.");
  await hit(`otp:uid:${uid}`, cfg.maxSendsPerUidPerDay, 86400, "Too many codes requested today. Try again tomorrow.");
  if (ip) await hit(`otp:ip:${ip}`, cfg.maxSendsPerIpPerHour, 3600, "Too many requests from this network. Try again later.");

  const code = randomCode(cfg.length);
  const now = Date.now();
  const challenge = {
    uid,
    phone,
    codeHmac: otpHmac(uid, phone, code),
    attempts: 0,
    status: "pending",
    createdAt: new Date(now).toISOString(),
    resendAfter: new Date(now + cfg.resendSeconds * 1000).toISOString(),
    expireAt: new Date(now + cfg.ttlSeconds * 1000).toISOString(),
  };
  await store().set("phoneChallenges", uid, challenge);
  try {
    await sendSms({ to: phone, text: `${code} is your ClassTryout code. It expires in ${Math.round(cfg.ttlSeconds / 60)} minutes. Do not share it.` });
  } catch (e) {
    await store().delete("phoneChallenges", uid);
    console.error("[otp] SMS send failed:", e && e.message); // message only: never the code or number
    throw new HttpError(502, "We could not send the SMS right now. Try again in a few minutes.", "sms_failed");
  }
  return { sentTo: mask(phone), expiresInSeconds: cfg.ttlSeconds, resendInSeconds: cfg.resendSeconds };
}

async function confirmPhoneVerification(uid, rawCode, ip) {
  const code = String(rawCode || "").replace(/\s/g, "");
  if (!new RegExp(`^[0-9]{${cfg.length}}$`).test(code)) throw bad(`Enter the ${cfg.length}-digit code.`, { code: "Check the code." });
  await hit(`otp:confirm:${uid}`, 30, 3600, "Too many attempts. Try again later.");

  const result = await store().transaction(async (tx) => {
    const ch = await tx.get("phoneChallenges", uid);
    const u = await tx.get("users", uid);
    if (!ch || ch.status !== "pending") return { error: new HttpError(410, "Ask for a new code.", "no_challenge") };
    if (ch.expireAt <= nowIso()) {
      return { error: new HttpError(410, "That code has expired. Ask for a new one.", "expired") };
    }
    if (ch.attempts >= cfg.maxAttempts) return { error: new HttpError(429, "Too many wrong codes. Ask for a new code.", "locked") };

    const ok = safeEqualHex(ch.codeHmac, otpHmac(uid, ch.phone, code));
    if (!ok) {
      await tx.update("phoneChallenges", uid, { attempts: ch.attempts + 1 });
      const left = cfg.maxAttempts - ch.attempts - 1;
      return { error: new HttpError(422, left > 0 ? `That code is not right. ${left} ${left === 1 ? "try" : "tries"} left.` : "Too many wrong codes. Ask for a new code.", left > 0 ? "wrong_code" : "locked", { fields: { code: "Not right." } }) };
    }

    const claimId = phoneClaimId(ch.phone);
    const claim = await tx.get("phoneClaims", claimId);
    if (claim && claim.uid !== uid) return { error: new HttpError(409, "This number is already used by another account.", "phone_in_use") };
    const oldId = u.phone && u.phone.verified && u.phone.e164 && u.phone.e164 !== ch.phone ? phoneClaimId(u.phone.e164) : null;

    await tx.set("phoneClaims", claimId, { uid, claimedAt: nowIso() });
    if (oldId) await tx.delete("phoneClaims", oldId); // free the number the person is moving away from
    const now = nowIso();
    await tx.update("users", uid, touchOnboarding(u, {
      phone: { e164: ch.phone, last4: last4(ch.phone), masked: mask(ch.phone), verified: true, verifiedAt: now },
      updatedAt: now,
    }));
    await tx.delete("phoneChallenges", uid);
    return { ok: true, replaced: !!oldId };
  });
  if (result.error) throw result.error;
  await audit({ actor: { uid, role: "self" }, action: "phone.verified", target: { type: "user", id: uid }, ip });
  return requireUser(uid);
}

module.exports = { startPhoneVerification, confirmPhoneVerification, phoneClaimId };
