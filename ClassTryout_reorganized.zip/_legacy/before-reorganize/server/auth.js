// Verifies the signed-in user from an "Authorization: Bearer <Firebase ID token>" header.
//   firebase backend: real verification with Firebase Admin (checks signature, expiry, revocation only when checkRevoked is set)
//   dev backend:      token is "dev:<uid>:<email>:<1|0 verified>"  (local testing only, refused in production)
async function verifyBearer(header, { checkRevoked = false } = {}) {
  const m = /^Bearer\s+(.+)$/i.exec(header || "");
  if (!m) throw new AuthError("Sign in first (missing Authorization header).");
  const token = m[1].trim();
  const backend = (process.env.NOTIFY_BACKEND || "firebase").toLowerCase();

  if (backend === "dev") {
    if (process.env.NODE_ENV === "production") throw new AuthError("NOTIFY_BACKEND=dev is refused in production.");
    const [tag, uid, email, verified] = token.split(":");
    if (tag !== "dev" || !uid) throw new AuthError("Invalid dev token.");
    return { uid, email: email || undefined, emailVerified: verified === "1", provider: "dev", name: undefined };
  }

  const { getAdmin } = require("./firebaseAdmin.js");
  try {
    // checkRevoked asks Firebase whether the user's sessions were revoked (done when a role changes). One extra network call.
    const d = await getAdmin().auth().verifyIdToken(token, checkRevoked);
    return {
      uid: d.uid,
      email: d.email,
      emailVerified: !!d.email_verified,
      provider: (d.firebase && d.firebase.sign_in_provider) || "unknown",
      name: d.name,
    };
  } catch (e) {
    if (/not configured/i.test(String(e && e.message))) throw e; // server misconfiguration, not a bad token
    throw new AuthError("Your sign-in has expired or is invalid. Sign in again.");
  }
}

class AuthError extends Error {
  constructor(message) {
    super(message);
    this.name = "AuthError";
  }
}

module.exports = { verifyBearer, AuthError };
