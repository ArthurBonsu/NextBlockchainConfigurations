// Small crypto helpers. No ID number or code is ever stored in plain text.
const crypto = require("crypto");
const { secret, encKey } = require("./config.js");

// Keyed hash with a label so the same value hashes differently for different purposes.
function hmac(label, value) {
  return crypto.createHmac("sha256", secret("ID_HASH_PEPPER")).update(`${label}:${value}`).digest("hex");
}

function otpHmac(uid, phone, code) {
  return crypto.createHmac("sha256", secret("OTP_SECRET")).update(`otp:${uid}:${phone}:${code}`).digest("hex");
}

function safeEqualHex(a, b) {
  const x = Buffer.from(String(a), "hex");
  const y = Buffer.from(String(b), "hex");
  return x.length === y.length && x.length > 0 && crypto.timingSafeEqual(x, y);
}

// AES-256-GCM. Output "v1.<iv>.<tag>.<ciphertext>" (base64url).
function encrypt(plain, aad = "") {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", encKey(), iv);
  if (aad) c.setAAD(Buffer.from(aad));
  const ct = Buffer.concat([c.update(String(plain), "utf8"), c.final()]);
  return ["v1", iv.toString("base64url"), c.getAuthTag().toString("base64url"), ct.toString("base64url")].join(".");
}

function decrypt(blob, aad = "") {
  const [v, iv, tag, ct] = String(blob).split(".");
  if (v !== "v1" || !iv || !tag || !ct) throw new Error("Unreadable encrypted value.");
  const d = crypto.createDecipheriv("aes-256-gcm", encKey(), Buffer.from(iv, "base64url"));
  if (aad) d.setAAD(Buffer.from(aad));
  d.setAuthTag(Buffer.from(tag, "base64url"));
  return Buffer.concat([d.update(Buffer.from(ct, "base64url")), d.final()]).toString("utf8");
}

// Uniformly random numeric code (no modulo bias).
function randomCode(length = 6) {
  let s = "";
  while (s.length < length) s += String(crypto.randomInt(0, 10));
  return s;
}

const sha256 = (v) => crypto.createHash("sha256").update(String(v)).digest("hex");

module.exports = { hmac, otpHmac, safeEqualHex, encrypt, decrypt, randomCode, sha256 };
