// Ghana mobile numbers. We normalise to E.164 (+233XXXXXXXXX) and validate the shape only.
// We deliberately do NOT work out the network from the prefix: numbers move between networks (portability),
// so the prefix says nothing reliable about who carries the SMS.
const { bad } = require("./httpError.js");

// Mobile numbers: 9 digits after +233 starting 2 or 5 (020/023/024/025/026/027/028/029, 050/053/054/055/056/057/059).
const GH_MOBILE = /^[25][0-9]{8}$/;

function normaliseGhPhone(input) {
  let s = String(input || "").replace(/[\s().-]/g, "");
  if (!s) throw bad("Enter your mobile number.", { phone: "Required." });
  if (s.startsWith("+")) s = s.slice(1);
  if (s.startsWith("00")) s = s.slice(2);
  if (s.startsWith("233")) s = s.slice(3);
  else if (s.startsWith("0")) s = s.slice(1);
  if (!/^[0-9]+$/.test(s) || !GH_MOBILE.test(s)) {
    throw bad("Enter a Ghana mobile number, for example 024 123 4567 or +233 24 123 4567.", { phone: "Not a Ghana mobile number." });
  }
  return "+233" + s;
}

const last4 = (e164) => e164.slice(-4);
const mask = (e164) => e164.replace(/^(\+233)\d{5}(\d{4})$/, "$1•••••$2");

module.exports = { normaliseGhPhone, last4, mask };
