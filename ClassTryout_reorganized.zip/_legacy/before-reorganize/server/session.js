// The front door of every account API route.
//
//   export default withSession(["GET","POST"], async (req, res, ctx) => { ... }, { capability: "vehicle:register" });
//
// ctx = { auth, user, ip, can(capability) }
//   1. verifies the Firebase ID token (and, by default, that the sessions have not been revoked)
//   2. loads (or creates) users/{uid}
//   3. refuses suspended accounts
//   4. if `capability` is given: role, onboarding, email and ID-level checks (server side: the UI gate is only a convenience)
// Errors become JSON  { error, code, fields? }  with the right status. Server set-up problems are 500 and say what to fix.
const { verifyBearer, AuthError } = require("./auth.js");
const { HttpError, forbidden } = require("./httpError.js");
const { StoreError } = require("./store.js");
const users = require("./users.js");
const roles = require("./roles.js");

function clientIp(req) {
  const trust = String(process.env.TRUST_PROXY || "true").toLowerCase() !== "false";
  if (trust) {
    const xff = req.headers["x-forwarded-for"];
    if (xff) return String(Array.isArray(xff) ? xff[0] : xff).split(",")[0].trim().slice(0, 64);
    const real = req.headers["x-real-ip"];
    if (real) return String(real).slice(0, 64);
  }
  return (req.socket && req.socket.remoteAddress) || null;
}

function sendError(res, e) {
  if (e instanceof AuthError) return res.status(401).json({ error: e.message, code: "unauthenticated" });
  if (e instanceof HttpError) {
    if (e.extra && e.extra.retryAfter) res.setHeader("Retry-After", String(e.extra.retryAfter));
    return res.status(e.status).json({ error: e.message, code: e.code, ...(e.extra || {}) });
  }
  const message = (e && e.message) || "Something went wrong.";
  const isSetup = /not configured|STORE_BACKEND|SMS_PROVIDER|ID_ENC_KEY|ID_HASH_PEPPER|OTP_SECRET|WALLET_LINK_SECRET|composite index/i.test(message) || e instanceof StoreError;
  if (isSetup) return res.status(500).json({ error: message, code: "server_setup" });
  console.error("[api] unexpected error:", message);
  return res.status(500).json({ error: "Something went wrong on our side. Try again.", code: "internal" });
}

function withSession(methods, handler, opts = {}) {
  return async (req, res) => {
    res.setHeader("Cache-Control", "no-store");
    if (!methods.includes(req.method)) {
      res.setHeader("Allow", methods.join(", "));
      return res.status(405).json({ error: "Method not allowed.", code: "method" });
    }
    try {
      const auth = await verifyBearer(req.headers.authorization, { checkRevoked: opts.checkRevoked !== false });
      const user = await users.ensureUser(auth);
      if (user.status === "suspended" && !opts.allowSuspended) throw forbidden("This account is suspended.", "suspended");
      const ip = clientIp(req);
      const ctx = {
        auth, user, ip,
        onboardingComplete: users.onboardingState(user).complete,
        can: (cap) => roles.check(user, cap, { onboardingComplete: users.onboardingState(user).complete }),
      };
      if (opts.capability) {
        const r = ctx.can(opts.capability);
        if (!r.allowed) throw forbidden(roles.REASONS[r.reason] || "Not allowed.", r.reason, { need: r.need });
      }
      return await handler(req, res, ctx);
    } catch (e) {
      return sendError(res, e);
    }
  };
}

module.exports = { withSession, clientIp, sendError };
