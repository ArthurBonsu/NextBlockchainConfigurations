// Small helpers so the three wallet-link routes behave the same way.
const { verifyBearer, AuthError } = require("./auth.js");

// Wraps a handler: verifies the signed-in user, only allows listed methods, turns thrown errors into JSON.
function withUser(methods, handler) {
  return async (req, res) => {
    res.setHeader("Cache-Control", "no-store");
    if (!methods.includes(req.method)) {
      res.setHeader("Allow", methods.join(", "));
      return res.status(405).json({ error: "Method not allowed." });
    }
    try {
      const user = await verifyBearer(req.headers.authorization);
      return await handler(req, res, user);
    } catch (e) {
      if (e instanceof AuthError) return res.status(401).json({ error: e.message });
      const message = e && e.message ? e.message : "Something went wrong.";
      const isSetup = /not configured|WALLET_LINK_SECRET/.test(message);
      // Setup problems are the server owner's to fix; show them. Everything else is a plain 400.
      return res.status(isSetup ? 500 : 400).json({ error: message });
    }
  };
}

module.exports = { withUser };
