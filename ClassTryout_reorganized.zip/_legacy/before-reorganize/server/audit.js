// Append-only record of who did what to whom. Written for every role change, ID decision, status change and ID-number reveal.
// Secrets and ID/phone numbers are stripped before anything is written.
const { store, nowIso } = require("./store.js");

const SENSITIVE = /(number|secret|token|hash|hmac|password|pepper|e164|^enc|otp|phone|apikey|api_key)/i;

function redact(value, depth = 0) {
  if (value === null || value === undefined) return value;
  if (Array.isArray(value)) return depth > 3 ? "[...]" : value.map((v) => redact(v, depth + 1));
  if (typeof value === "object") {
    if (depth > 3) return "[...]";
    const out = {};
    for (const [k, v] of Object.entries(value)) out[k] = SENSITIVE.test(k) ? "[removed]" : redact(v, depth + 1);
    return out;
  }
  if (typeof value === "string" && value.length > 300) return value.slice(0, 300) + "...";
  return value;
}

// actor: { uid, role } or { uid: "system", role: "system" }; target: { type, id }
async function audit({ actor, action, target, before, after, note, ip }) {
  const row = {
    at: nowIso(),
    actor: { uid: actor.uid, role: actor.role || null },
    action,
    target: target || null,
    before: before === undefined ? null : redact(before),
    after: after === undefined ? null : redact(after),
    note: note ? String(note).slice(0, 500) : null,
    ip: ip || null,
  };
  return store().add("auditLogs", row);
}

module.exports = { audit, redact };
