// Wallet <-> account links. The email address NEVER goes on the chain and is never stored here:
// we store only  wallet address -> Firebase uid.  The email is looked up from Firebase Auth at send time,
// so a changed or unverified email is always respected.
//
// Backends (NOTIFY_BACKEND):
//   firebase  (default)  links in Firestore collection "walletLinks"; verified email from Firebase Auth
//   dev                  links in a local JSON file with a fake account; for local testing only
const fs = require("fs");
const path = require("path");
const { root } = require("./env.js");

const BACKEND = () => (process.env.NOTIFY_BACKEND || "firebase").toLowerCase();
const COLLECTION = "walletLinks";

function normalizeAddress(address) {
  if (!/^0x[0-9a-fA-F]{40}$/.test(String(address || ""))) throw new Error("Not a valid wallet address.");
  return address.toLowerCase();
}

// ---- dev backend (file) --------------------------------------------------------------------------------
function devFile() {
  return process.env.DEV_LINKS_FILE || path.join(root, "notifier", "data", "dev-links.json");
}
function devRead() {
  try {
    return JSON.parse(fs.readFileSync(devFile(), "utf8"));
  } catch {
    return { links: {} };
  }
}
function devWrite(data) {
  fs.mkdirSync(path.dirname(devFile()), { recursive: true });
  fs.writeFileSync(devFile(), JSON.stringify(data, null, 2));
}

function assertBackend() {
  if (BACKEND() === "dev" && process.env.NODE_ENV === "production") {
    throw new Error("NOTIFY_BACKEND=dev is for local testing only and is refused when NODE_ENV=production.");
  }
}

// ---- operations ----------------------------------------------------------------------------------------
// account = { uid, email?, emailVerified? } (email fields are used by the dev backend only)
async function saveLink(address, account) {
  assertBackend();
  const key = normalizeAddress(address);
  const record = { uid: account.uid, address: key, linkedAt: new Date().toISOString() };
  if (BACKEND() === "dev") {
    const data = devRead();
    data.links[key] = { ...record, email: account.email, emailVerified: !!account.emailVerified };
    devWrite(data);
  } else {
    const { getAdmin } = require("./firebaseAdmin.js");
    // The signature proves control of the wallet, so the newest proof wins (a user who switches account just re-links).
    await getAdmin().firestore().collection(COLLECTION).doc(key).set(record);
  }
  return record;
}

async function listLinks(uid) {
  assertBackend();
  if (BACKEND() === "dev") {
    return Object.values(devRead().links).filter((l) => l.uid === uid).map(({ address, linkedAt }) => ({ address, linkedAt }));
  }
  const { getAdmin } = require("./firebaseAdmin.js");
  const snap = await getAdmin().firestore().collection(COLLECTION).where("uid", "==", uid).get();
  return snap.docs.map((d) => ({ address: d.data().address, linkedAt: d.data().linkedAt }));
}

async function removeLink(address, uid) {
  assertBackend();
  const key = normalizeAddress(address);
  if (BACKEND() === "dev") {
    const data = devRead();
    if (data.links[key] && data.links[key].uid === uid) {
      delete data.links[key];
      devWrite(data);
      return true;
    }
    return false;
  }
  const { getAdmin } = require("./firebaseAdmin.js");
  const ref = getAdmin().firestore().collection(COLLECTION).doc(key);
  const snap = await ref.get();
  if (!snap.exists || snap.data().uid !== uid) return false;
  await ref.delete();
  return true;
}

// -> { email, uid } or { reason } where reason is one of: not-linked | no-email | email-not-verified | account-disabled
async function emailForWallet(address) {
  assertBackend();
  const key = normalizeAddress(address);
  if (BACKEND() === "dev") {
    const l = devRead().links[key];
    if (!l) return { reason: "not-linked" };
    if (!l.email) return { reason: "no-email" };
    if (!l.emailVerified) return { reason: "email-not-verified" };
    return { email: l.email, uid: l.uid };
  }
  const { getAdmin } = require("./firebaseAdmin.js");
  const admin = getAdmin();
  const snap = await admin.firestore().collection(COLLECTION).doc(key).get();
  if (!snap.exists) return { reason: "not-linked" };
  const { uid } = snap.data();
  let user;
  try {
    user = await admin.auth().getUser(uid);
  } catch (e) {
    if (e && e.code === "auth/user-not-found") return { reason: "not-linked" };
    throw e;
  }
  if (user.disabled) return { reason: "account-disabled" };
  if (!user.email) return { reason: "no-email" };
  if (!user.emailVerified) return { reason: "email-not-verified" };
  return { email: user.email, uid };
}

module.exports = { normalizeAddress, saveLink, listLinks, removeLink, emailForWallet };
