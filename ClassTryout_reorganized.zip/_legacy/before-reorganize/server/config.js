// Settings read from the environment, in one place. Server only.
//
// Secrets (never NEXT_PUBLIC_, never committed):
//   ID_HASH_PEPPER   secret used to HMAC ID numbers and phone numbers (so a leaked database cannot be brute-forced)
//   ID_ENC_KEY       32-byte key (64 hex characters or base64) that encrypts an ID number while a check is pending
//   OTP_SECRET       secret used to HMAC one-time SMS codes
// Outside production a throwaway value is used (with one warning) so local work and tests run without setup.
// In production a missing secret is an error, never a silent default.
const crypto = require("crypto");

const isProd = () => process.env.NODE_ENV === "production";

let warned = false;
function secret(name, { minLength = 16 } = {}) {
  const v = process.env[name];
  if (v && v.length >= minLength) return v;
  if (isProd()) {
    throw new Error(`${name} is not configured (at least ${minLength} characters). See .env.local.example.`);
  }
  if (!warned) {
    warned = true;
    console.warn(`[config] ${name} (and other secrets) not set: using throwaway development values. Never do this in production.`);
  }
  return crypto.createHash("sha256").update("classtryout-dev-only:" + name).digest("hex");
}

function encKey() {
  const v = process.env.ID_ENC_KEY;
  if (v) {
    const buf = /^[0-9a-fA-F]{64}$/.test(v) ? Buffer.from(v, "hex") : Buffer.from(v, "base64");
    if (buf.length !== 32) throw new Error("ID_ENC_KEY must be 32 bytes (64 hex characters, or base64 of 32 bytes).");
    return buf;
  }
  if (isProd()) throw new Error("ID_ENC_KEY is not configured. See .env.local.example.");
  return crypto.createHash("sha256").update("classtryout-dev-only:ID_ENC_KEY").digest();
}

const bool = (v, d = false) => (v === undefined || v === "" ? d : /^(1|true|yes|on)$/i.test(String(v)));

module.exports = { isProd, secret, encKey, bool };
