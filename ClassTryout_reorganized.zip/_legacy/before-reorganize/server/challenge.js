// Stateless wallet-link challenge. The server signs (uid, address, nonce, expiry) with WALLET_LINK_SECRET, so nothing
// has to be stored between "give me a challenge" and "here is the signature".
const crypto = require("crypto");
const { normalizeAddress } = require("./links.js");

const TTL_MS = 10 * 60 * 1000;

function secret() {
  const s = process.env.WALLET_LINK_SECRET;
  if (!s || s.length < 16) {
    throw new Error("WALLET_LINK_SECRET is not set (min 16 characters). Generate one: node -e \"console.log(require('crypto').randomBytes(32).toString('hex'))\"");
  }
  return s;
}

function messageFor({ uid, address, nonce, issuedAt, expiresAt }) {
  return [
    "ClassTryout: link this wallet to my account",
    "",
    `Wallet: ${address}`,
    `Account: ${uid}`,
    `Nonce: ${nonce}`,
    `Issued: ${issuedAt}`,
    `Expires: ${expiresAt}`,
    "",
    "Signing this message costs no gas. It only proves I control this wallet.",
  ].join("\n");
}

function mac(fields) {
  return crypto.createHmac("sha256", secret()).update([fields.uid, fields.address, fields.nonce, fields.expiresAt].join("|")).digest("hex");
}

function createChallenge(uid, address) {
  const addr = normalizeAddress(address);
  const now = Date.now();
  const fields = {
    uid,
    address: addr,
    nonce: crypto.randomBytes(16).toString("hex"),
    issuedAt: new Date(now).toISOString(),
    expiresAt: new Date(now + TTL_MS).toISOString(),
  };
  return { address: addr, nonce: fields.nonce, issuedAt: fields.issuedAt, expiresAt: fields.expiresAt, mac: mac(fields), message: messageFor(fields) };
}

// Returns the message that must have been signed, or throws.
function checkChallenge(uid, { address, nonce, issuedAt, expiresAt, mac: given }) {
  const addr = normalizeAddress(address);
  const fields = { uid, address: addr, nonce, issuedAt, expiresAt };
  const expected = mac(fields);
  const a = Buffer.from(String(given || ""), "hex");
  const b = Buffer.from(expected, "hex");
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw new Error("This link request was not issued to your account. Start again.");
  if (Date.now() > Date.parse(expiresAt)) throw new Error("This link request expired. Start again.");
  return messageFor(fields);
}

module.exports = { createChallenge, checkChallenge };
