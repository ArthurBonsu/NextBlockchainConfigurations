// users/{uid}: the one profile document per signed-in person. The document id IS the Firebase uid.
// Only these functions write it, always through the Admin SDK; browsers can only read their own copy (see firebase/firestore.rules).
const onboarding = require("../shared/onboarding.json");
const rolesPolicy = require("./roles.js");
const { store, nowIso, REMOVE } = require("./store.js");
const { sha256 } = require("./crypto.js");
const { audit } = require("./audit.js");
const { bad, forbidden, conflict, notFound } = require("./httpError.js");
const { validateAddress, clean } = require("./locations.js");
const { mask } = require("./phone.js");

const NAME = /^[\p{L}][\p{L} .'’-]{0,59}$/u;

function baseUser(auth) {
  const now = nowIso();
  return {
    uid: auth.uid,
    email: auth.email ? auth.email.toLowerCase() : null,
    emailVerified: !!auth.emailVerified,
    provider: auth.provider || "unknown",
    role: "citizen",
    status: "active",
    createdAt: now,
    updatedAt: now,
    lastLoginAt: now,
    profile: {},
    phone: { verified: false },
    address: null,
    identity: { level: 0, types: [] },
    consents: {},
    notifications: { email: true, sms: true },
    onboarding: { completedAt: null },
    schemaVersion: 1,
  };
}

// Called on every authenticated request that needs the profile. Creates it the first time a uid is seen.
async function ensureUser(auth) {
  const s = store();
  const existing = await s.get("users", auth.uid);
  if (!existing) {
    try {
      await s.create("users", auth.uid, baseUser(auth));
    } catch (e) {
      if (!(e && e.code === "already-exists")) throw e; // two first requests raced; the other one won
    }
    return s.get("users", auth.uid);
  }
  const patch = {};
  const emailNow = auth.email ? auth.email.toLowerCase() : null;
  if (emailNow !== existing.email) patch.email = emailNow;
  if (!!auth.emailVerified !== !!existing.emailVerified) patch.emailVerified = !!auth.emailVerified;
  const stale = !existing.lastLoginAt || Date.now() - Date.parse(existing.lastLoginAt) > 3600_000;
  if (stale) patch.lastLoginAt = nowIso();
  if (Object.keys(patch).length) {
    patch.updatedAt = nowIso();
    await s.update("users", auth.uid, patch);
    return { ...existing, ...patch };
  }
  return existing;
}

// ---- onboarding state: computed from the data, never stored, so it cannot drift -----------------------------
function stepsDone(u) {
  const c = u.consents || {};
  const p = u.profile || {};
  const a = u.address || {};
  return {
    consent: Object.keys(onboarding.consents).every((k) => c[k] && c[k].version === onboarding.consents[k].version),
    profile: !!(p.givenName && p.familyName && p.dob && p.gender),
    phone: !!(u.phone && u.phone.verified),
    address: !!(a.regionCode && a.districtId && a.city && a.suburb),
    id: ((u.identity && u.identity.level) || 0) >= 1,
  };
}

function onboardingState(u) {
  const done = stepsDone(u);
  const required = onboarding.requiredToFinish;
  const complete = required.every((k) => done[k]);
  const next = onboarding.steps.find((k) => !done[k] && required.includes(k)) || onboarding.steps.find((k) => !done[k]) || null;
  return { steps: onboarding.steps, done, complete, next, required, optional: onboarding.optionalButRecommended };
}

// What the browser is allowed to see about itself (no hashes, no internals).
function view(u, extra = {}) {
  const st = onboardingState(u);
  return {
    uid: u.uid,
    email: u.email,
    emailVerified: u.emailVerified,
    provider: u.provider,
    role: u.role,
    status: u.status,
    profile: u.profile || {},
    phone: u.phone && u.phone.verified ? { verified: true, masked: u.phone.masked, verifiedAt: u.phone.verifiedAt } : { verified: false },
    address: u.address || null,
    identity: { level: (u.identity && u.identity.level) || 0, types: (u.identity && u.identity.types) || [] },
    consents: Object.fromEntries(Object.entries(u.consents || {}).map(([k, v]) => [k, { version: v.version, at: v.at }])),
    notifications: u.notifications,
    onboarding: st,
    capabilities: rolesPolicy.all(u, { onboardingComplete: st.complete }),
    createdAt: u.createdAt,
    ...extra,
  };
}

async function requireUser(uid) {
  const u = await store().get("users", uid);
  if (!u) throw notFound("Account not found.");
  return u;
}

function touchOnboarding(u, patch) {
  // Stamp the moment the required steps were first all done.
  const merged = { ...u, ...patch };
  const st = onboardingState(merged);
  if (st.complete && !(u.onboarding && u.onboarding.completedAt)) patch["onboarding.completedAt"] = nowIso();
  return patch;
}

// ---- steps ---------------------------------------------------------------------------------------------------
async function saveConsents(uid, body, ip) {
  const b = body || {};
  const missing = Object.keys(onboarding.consents).filter((k) => b[k] !== true);
  if (missing.length) throw bad("Please accept all three agreements to continue.", Object.fromEntries(missing.map((k) => [k, "Required."])));
  const u = await requireUser(uid);
  const at = nowIso();
  const ipHash = ip ? sha256("ip:" + ip).slice(0, 16) : null;
  const patch = {};
  for (const [k, def] of Object.entries(onboarding.consents)) {
    if (!(u.consents && u.consents[k] && u.consents[k].version === def.version)) patch[`consents.${k}`] = { version: def.version, at, ipHash };
  }
  if (!Object.keys(patch).length) return u;
  patch.updatedAt = at;
  await store().update("users", uid, touchOnboarding(u, patch));
  return requireUser(uid);
}

function validDob(s) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(s || ""))) throw bad("Enter your date of birth.", { dob: "Use the date picker." });
  const d = new Date(s + "T00:00:00Z");
  if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== s) throw bad("That date does not exist.", { dob: "Not a real date." });
  const now = new Date();
  let age = now.getUTCFullYear() - d.getUTCFullYear();
  if (now.getUTCMonth() < d.getUTCMonth() || (now.getUTCMonth() === d.getUTCMonth() && now.getUTCDate() < d.getUTCDate())) age--;
  if (age < onboarding.minAge) throw bad(`You must be at least ${onboarding.minAge} to register.`, { dob: `At least ${onboarding.minAge}.` });
  if (age > 120) throw bad("Check your date of birth.", { dob: "Check this." });
  return s;
}

async function saveProfile(uid, body) {
  const b = body || {};
  const u = await requireUser(uid);
  if (u.identity && u.identity.level >= 2) {
    throw conflict("Your name and date of birth are locked because your ID is confirmed. Contact support to correct them.", "locked");
  }
  const fields = {};
  for (const [key, label] of [["givenName", "First name"], ["familyName", "Surname"]]) {
    const v = clean(b[key]);
    if (!NAME.test(v)) fields[key] = `${label}: letters, spaces and . ' - only.`;
  }
  const otherNames = clean(b.otherNames);
  if (otherNames && !NAME.test(otherNames)) fields.otherNames = "Letters, spaces and . ' - only.";
  if (Object.keys(fields).length) throw bad("Check your name.", fields);
  const dob = validDob(b.dob);
  if (!onboarding.genders.includes(b.gender)) throw bad("Choose an option for gender.", { gender: "Choose one." });
  const nationality = String(b.nationality || "GH").toUpperCase();
  if (!/^[A-Z]{2}$/.test(nationality)) throw bad("Choose your nationality.", { nationality: "Two-letter country code." });

  const profile = { givenName: clean(b.givenName), familyName: clean(b.familyName), dob, gender: b.gender, nationality };
  if (otherNames) profile.otherNames = otherNames;
  profile.displayName = [profile.givenName, profile.familyName].join(" ");
  await store().update("users", uid, touchOnboarding(u, { profile, updatedAt: nowIso() }));
  return requireUser(uid);
}

const suggestionId = (districtId, suburbKey) => sha256(`${districtId}|${suburbKey}`).slice(0, 32);

async function saveAddress(uid, body) {
  const address = validateAddress(body);
  address.updatedAt = nowIso();
  const s = store();
  await s.transaction(async (tx) => {
    const u = await tx.get("users", uid);
    if (!u) throw notFound("Account not found.");
    const sid = suggestionId(address.districtId, address.suburbKey);
    const sug = await tx.get("locationSuggestions", sid);
    const sameAsBefore = u.address && u.address.districtId === address.districtId && u.address.suburbKey === address.suburbKey;
    const patch = touchOnboarding(u, { address, updatedAt: address.updatedAt });
    await tx.update("users", uid, patch);
    if (!sameAsBefore) {
      await tx.set("locationSuggestions", sid, {
        districtId: address.districtId,
        regionCode: address.regionCode,
        suburb: sug ? sug.suburb : address.suburb,
        suburbKey: address.suburbKey,
        city: sug ? sug.city : address.city,
        count: (sug ? sug.count : 0) + 1,
        createdAt: sug ? sug.createdAt : address.updatedAt,
        updatedAt: address.updatedAt,
      });
    }
  });
  return requireUser(uid);
}

async function suburbSuggestions(districtId) {
  if (!districtId) throw bad("districtId is required.", { districtId: "Required." });
  const rows = await store().query("locationSuggestions", { where: [["districtId", "==", String(districtId)]], orderBy: [["count", "desc"]], limit: 50 });
  return rows.map((r) => ({ suburb: r.suburb, city: r.city, count: r.count }));
}

async function saveNotificationPrefs(uid, body) {
  const b = body || {};
  const u = await requireUser(uid);
  const patch = { updatedAt: nowIso() };
  if (typeof b.email === "boolean") patch["notifications.email"] = b.email;
  if (typeof b.sms === "boolean") patch["notifications.sms"] = b.sms;
  await store().update("users", u.uid, patch);
  return requireUser(uid);
}

// ---- admin: role and status ------------------------------------------------------------------------------------
async function revokeSessions(uid) {
  if ((process.env.NOTIFY_BACKEND || "firebase").toLowerCase() === "dev") return;
  try {
    const { getAdmin } = require("./firebaseAdmin.js");
    await getAdmin().auth().revokeRefreshTokens(uid);
  } catch (e) {
    if (/not configured/i.test(String(e && e.message))) return; // no Firebase Admin in this environment (tests)
    throw e;
  }
}

async function setClaims(uid, role) {
  if ((process.env.NOTIFY_BACKEND || "firebase").toLowerCase() === "dev") return;
  try {
    const { getAdmin } = require("./firebaseAdmin.js");
    await getAdmin().auth().setCustomUserClaims(uid, { role });
  } catch (e) {
    if (/not configured/i.test(String(e && e.message))) return;
    throw e;
  }
}

// actor = the users doc of whoever is acting (or { uid: "system", role: "system" } from a script).
async function assignRole(actor, targetUid, role, ip) {
  if (!rolesPolicy.isRole(role)) throw bad(`Role must be one of: ${rolesPolicy.ROLES.join(", ")}.`, { role: "Unknown role." });
  const s = store();
  const target = await requireUser(targetUid);
  if (actor.uid === targetUid && actor.uid !== "system") throw forbidden("You cannot change your own role.", "self");
  if (target.role === "super_admin" && role !== "super_admin") {
    // At least one OTHER super administrator who is not suspended must remain: a suspended one cannot sign in, so it does not count.
    const supers = await s.query("users", { where: [["role", "==", "super_admin"]], limit: 100 });
    const othersActive = supers.filter((x) => x.uid !== targetUid && x.status !== "suspended");
    if (!othersActive.length) throw conflict("That would leave no active super administrator. Promote and sign in the replacement first.", "last_super_admin");
  }
  if (target.role === role) return target;
  await s.update("users", targetUid, { role, updatedAt: nowIso() });
  await setClaims(targetUid, role);
  await revokeSessions(targetUid); // forces a fresh token, so a demoted account loses access within minutes, not hours
  await audit({ actor, action: "user.role", target: { type: "user", id: targetUid }, before: { role: target.role }, after: { role }, ip });
  return requireUser(targetUid);
}

async function setStatus(actor, targetUid, status, note, ip) {
  if (!["active", "suspended"].includes(status)) throw bad("Status must be active or suspended.", { status: "Unknown status." });
  const target = await requireUser(targetUid);
  if (actor.uid === targetUid) throw forbidden("You cannot change your own status.", "self");
  if (target.role === "super_admin" && actor.role !== "super_admin") throw forbidden("Only a super administrator can suspend a super administrator.", "role");
  if (target.status === status) return target;
  await store().update("users", targetUid, { status, updatedAt: nowIso() });
  if (status === "suspended") await revokeSessions(targetUid);
  await audit({ actor, action: "user.status", target: { type: "user", id: targetUid }, before: { status: target.status }, after: { status }, note, ip });
  return requireUser(targetUid);
}

// Founding administrators only: the first reviewer cannot be confirmed by anyone else, so a person with server access (who has
// seen the person's ID in real life) marks them confirmed from the command line. Always audit-logged as a bootstrap.
async function bootstrapConfirmIdentity(uid, note) {
  const u = await requireUser(uid);
  const now = nowIso();
  await store().update("users", uid, { "identity.level": 2, "identity.verifiedAt": now, "identity.bootstrap": true, updatedAt: now });
  await audit({ actor: { uid: "system", role: "system" }, action: "identity.bootstrap", target: { type: "user", id: uid }, before: { level: (u.identity && u.identity.level) || 0 }, after: { level: 2 }, note: note || "Confirmed in person by server operator" });
}

// Admin lists. Exactly one filter group at a time keeps the number of indexes small and known (see firebase/firestore.indexes.json).
async function listUsers(q = {}) {
  const where = [];
  const groups = [];
  if (q.role || q.status) {
    groups.push("role/status");
    if (q.role) where.push(["role", "==", String(q.role)]);
    if (q.status) where.push(["status", "==", String(q.status)]);
  }
  if (q.regionCode) { groups.push("region"); where.push(["address.regionCode", "==", String(q.regionCode)]); }
  if (q.districtId) { groups.push("district"); where.push(["address.districtId", "==", String(q.districtId)]); }
  if (q.level !== undefined && q.level !== "") { groups.push("level"); where.push(["identity.level", "==", Number(q.level)]); }
  if (q.email) { groups.push("email"); where.push(["email", "==", String(q.email).toLowerCase()]); }
  if (groups.length > 1) throw bad("Use one filter group at a time: role/status, region, district, ID level or email.");
  if (q.before && !q.email) where.push(["createdAt", "<", String(q.before)]);
  const limit = Math.min(Math.max(parseInt(q.limit, 10) || 25, 1), 100);
  const orderBy = q.email ? [] : [["createdAt", "desc"]];
  const rows = await store().query("users", { where, orderBy, limit });
  return rows.map((u) => ({
    uid: u.uid, email: u.email, role: u.role, status: u.status, createdAt: u.createdAt,
    name: u.profile && u.profile.displayName, phone: u.phone && u.phone.verified ? u.phone.masked : null,
    region: u.address && u.address.regionName, district: u.address && u.address.districtName, suburb: u.address && u.address.suburb,
    level: (u.identity && u.identity.level) || 0, onboardingComplete: !!(u.onboarding && u.onboarding.completedAt),
  }));
}

module.exports = {
  ensureUser, requireUser, onboardingState, stepsDone, view, touchOnboarding,
  saveConsents, saveProfile, saveAddress, suburbSuggestions, saveNotificationPrefs,
  assignRole, setStatus, listUsers, bootstrapConfirmIdentity, mask,
};
