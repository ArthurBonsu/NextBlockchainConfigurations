// Identity documents.
//   identityDocuments/{id}    one per submitted ID. The number is stored as an HMAC (+ last 4 digits for display).
//                             The full number is kept ENCRYPTED only while a check/review is pending, then deleted.
//   identityClaims/{hmac}     { uid, docId }, created in the same transaction: one ID can belong to one account only.
// users/{uid}.identity.level:  0 none | 1 ID given, format valid, not confirmed | 2 confirmed (automated check or human reviewer)
const idTypes = require("../../shared/id-types.json");
const { store, nowIso, REMOVE } = require("../store.js");
const { hmac, encrypt, decrypt } = require("../crypto.js");
const { hit } = require("../rateLimit.js");
const { audit } = require("../audit.js");
const { bad, conflict, forbidden, notFound, HttpError } = require("../httpError.js");
const { routeFor } = require("./checkers.js");
const { requireUser } = require("../users.js");

const typeOf = (code) => idTypes.types.find((t) => t.code === code);
const PENDING = ["pending_check", "pending_review", "submitted"];
const DAY = 86400_000;

// Canonical form: upper case, no spaces or hyphens (so "gha-123456789-0" and "GHA1234567890" are the same ID).
function canonical(typeCode, raw) {
  const t = typeOf(typeCode);
  if (!t) throw bad("Choose an ID type.", { type: "Choose a type." });
  let s = String(raw || "").toUpperCase().trim();
  if (typeCode === "ghana_card") {
    const flat = s.replace(/[\s-]/g, "");
    const m = /^GHA([0-9]{9})([0-9])$/.exec(flat);
    if (!m) throw bad(`A Ghana Card number looks like ${t.example}.`, { number: "Check the number." });
    return { display: `GHA-${m[1]}-${m[2]}`, key: flat };
  }
  if (!new RegExp(t.pattern).test(s)) throw bad(`That does not look like a valid ${t.label} number.${t.example ? " Example: " + t.example : ""}`, { number: "Check the number." });
  return { display: s, key: s.replace(/[\s/-]/g, "") };
}

function validExpiry(t, raw) {
  const s = String(raw || "").trim();
  if (!s) {
    if (t.needsExpiry) throw bad("Enter the expiry date shown on the ID.", { expiry: "Required." });
    return null;
  }
  const d = new Date(s + "T00:00:00Z");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s) || Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== s) throw bad("Enter a real expiry date.", { expiry: "Not a real date." });
  if (d.getTime() < Date.now() - DAY) throw bad("That ID has expired.", { expiry: "Expired." });
  if (d.getTime() > Date.now() + 25 * 365 * DAY) throw bad("Check the expiry date.", { expiry: "Too far ahead." });
  return s;
}

function docView(d) {
  const t = typeOf(d.type);
  return { id: d.id, type: d.type, label: t ? t.label : d.type, last4: d.last4, country: d.country || null, expiry: d.expiry || null, status: d.status, createdAt: d.createdAt, reviewedAt: d.reviewedAt || null, note: d.status === "rejected" ? d.note || null : null };
}

async function listMyDocuments(uid) {
  const rows = await store().query("identityDocuments", { where: [["uid", "==", uid]], orderBy: [["createdAt", "desc"]], limit: 20 });
  return rows.map(docView);
}

// Level from the person's documents. Called inside transactions with the documents already read.
function levelFrom(docs) {
  if (docs.some((d) => d.status === "verified")) return 2;
  if (docs.some((d) => d.status !== "rejected" && d.status !== "expired")) return 1;
  return 0;
}

async function submitDocument(uid, body, ip) {
  const b = body || {};
  const t = typeOf(b.type);
  if (!t) throw bad("Choose an ID type.", { type: "Choose a type." });
  const num = canonical(b.type, b.number);
  let country = t.country;
  if (!country) {
    country = String(b.country || "").toUpperCase();
    if (!/^[A-Z]{2}$/.test(country)) throw bad("Choose the country that issued this ID.", { country: "Required." });
  }
  const expiry = validExpiry(t, b.expiry);
  await hit(`id:uid:${uid}`, 10, 86400, "You have submitted too many IDs today. Try again tomorrow.");
  if (ip) await hit(`id:ip:${ip}`, 40, 3600, "Too many requests from this network. Try again later.");

  const claimId = hmac("id", `${b.type}:${country}:${num.key}`);
  const route = routeFor(b.type);
  const now = nowIso();
  let docId;
  await store().transaction(async (tx) => {
    const u = await tx.get("users", uid);
    if (!u) throw notFound("Account not found.");
    if (u.status === "suspended") throw forbidden("This account is suspended.", "suspended");
    const claim = await tx.get("identityClaims", claimId);
    if (claim && claim.uid !== uid) throw conflict("This ID is already linked to another account. If you think this is a mistake, contact support.", "id_in_use");
    if (claim) {
      const prev = await tx.get("identityDocuments", claim.docId);
      if (prev && prev.status !== "rejected" && prev.status !== "expired") throw conflict("You have already added this ID.", "already_added");
    }
    const mine = await tx.query("identityDocuments", { where: [["uid", "==", uid]], orderBy: [["createdAt", "desc"]], limit: 20 });
    if (mine.filter((d) => d.status !== "rejected" && d.status !== "expired").length >= 5) throw conflict("You can have at most 5 IDs on file.", "too_many");

    const doc = {
      uid, type: b.type, country, expiry, last4: num.key.slice(-4),
      numberHmac: claimId,
      encNumber: encrypt(num.display, `idnum:${uid}`),
      encExpiresAt: new Date(Date.now() + idTypes.retryDays * DAY).toISOString(),
      status: route.status, checker: route.checker, attempts: 0,
      nextAttemptAt: route.status === "pending_check" ? now : null,
      createdAt: now, updatedAt: now,
    };
    docId = await tx.add("identityDocuments", doc);
    await tx.set("identityClaims", claimId, { uid, docId, type: b.type, createdAt: now });
    const types = [...new Set([...(u.identity.types || []), b.type])];
    await tx.update("users", uid, { "identity.level": Math.max(1, (u.identity && u.identity.level) || 0), "identity.types": types, "identity.updatedAt": now, updatedAt: now });
  });
  await audit({ actor: { uid, role: "self" }, action: "identity.submit", target: { type: "identityDocument", id: docId }, after: { type: b.type, status: route.status, checker: route.checker }, ip });
  const saved = await store().get("identityDocuments", docId);
  return docView({ id: docId, ...saved });
}

// A person withdraws an ID that is still unconfirmed (typo, wrong ID). Confirmed IDs can only be changed by an administrator.
async function withdrawDocument(uid, docId) {
  await store().transaction(async (tx) => {
    const d = await tx.get("identityDocuments", docId);
    if (!d || d.uid !== uid) throw notFound("ID not found.");
    if (d.status === "verified") throw conflict("A confirmed ID cannot be removed. Contact support.", "confirmed");
    const u = await tx.get("users", uid);
    const mine = await tx.query("identityDocuments", { where: [["uid", "==", uid]], orderBy: [["createdAt", "desc"]], limit: 20 });
    await tx.delete("identityClaims", d.numberHmac);
    await tx.delete("identityDocuments", docId);
    const level = levelFrom(mine.filter((x) => x.id !== docId));
    const types = [...new Set(mine.filter((x) => x.id !== docId).map((x) => x.type))];
    await tx.update("users", uid, { "identity.level": level, "identity.types": types, "identity.updatedAt": nowIso(), updatedAt: nowIso() });
  });
}

// ---- decisions (human reviewer, or the check worker) -----------------------------------------------------------
async function decide({ docId, decision, by, note, checker, ip }) {
  if (!["verified", "rejected"].includes(decision)) throw bad("Decision must be verified or rejected.");
  let target;
  await store().transaction(async (tx) => {
    const d = await tx.get("identityDocuments", docId);
    if (!d) throw notFound("ID not found.");
    if (!PENDING.includes(d.status)) throw conflict("That ID has already been decided.", "decided");
    if (by.uid === d.uid) throw forbidden("You cannot review your own ID.", "self");
    const mine = await tx.query("identityDocuments", { where: [["uid", "==", d.uid]], orderBy: [["createdAt", "desc"]], limit: 20 });
    const now = nowIso();
    const after = { ...d, status: decision };
    await tx.update("identityDocuments", docId, {
      status: decision, reviewedBy: by.uid, reviewedAt: now, note: note ? String(note).slice(0, 300) : null, checker: checker || d.checker,
      encNumber: REMOVE, encExpiresAt: REMOVE, nextAttemptAt: null, updatedAt: now,
    });
    if (decision === "rejected") await tx.delete("identityClaims", d.numberHmac); // lets the person correct a typo and resubmit
    const level = levelFrom(mine.map((x) => (x.id === docId ? after : x)));
    const patch = { "identity.level": level, "identity.updatedAt": now, updatedAt: now };
    if (decision === "verified") patch["identity.verifiedAt"] = now;
    await tx.update("users", d.uid, patch);
    target = { uid: d.uid, type: d.type };
  });
  await audit({ actor: by, action: `identity.${decision}`, target: { type: "identityDocument", id: docId }, after: { owner: target.uid, type: target.type, checker: checker || "manual" }, note, ip });
  return { docId, decision };
}

async function reviewQueue({ status = "pending_review", before, limit = 25 } = {}) {
  if (!idTypes.statuses.includes(status)) throw bad("Unknown status.");
  const where = [["status", "==", status]];
  if (before) where.push(["createdAt", "<", String(before)]);
  const rows = await store().query("identityDocuments", { where, orderBy: [["createdAt", "desc"]], limit: Math.min(Math.max(+limit || 25, 1), 100) });
  return rows.map((d) => ({ ...docView(d), uid: d.uid, checker: d.checker, attempts: d.attempts }));
}

// A reviewer needs the number to compare it with the card. Every reveal is audit-logged and rate-limited.
async function revealNumber(actor, docId, ip) {
  await hit(`id:reveal:${actor.uid}`, 60, 3600, "Too many ID look-ups. Try again later.");
  const d = await store().get("identityDocuments", docId);
  if (!d) throw notFound("ID not found.");
  if (!d.encNumber) throw conflict("The number was removed after the decision.", "removed");
  const u = await store().get("users", d.uid);
  const number = decrypt(d.encNumber, `idnum:${d.uid}`);
  await audit({ actor, action: "identity.reveal", target: { type: "identityDocument", id: docId }, ip });
  const p = (u && u.profile) || {};
  return { number, type: d.type, country: d.country, expiry: d.expiry, holder: { name: p.displayName || null, dob: p.dob || null } };
}

// Housekeeping: a number nobody decided on within the retention window is deleted and the document marked expired.
async function purgeExpired(now = new Date()) {
  const cutoff = now.toISOString();
  let purged = 0;
  for (const status of PENDING) {
    const rows = await store().query("identityDocuments", { where: [["status", "==", status]], orderBy: [["createdAt", "desc"]], limit: 500 });
    for (const d of rows) {
      if (d.encExpiresAt && d.encExpiresAt <= cutoff) {
        await store().update("identityDocuments", d.id, { status: "expired", encNumber: REMOVE, encExpiresAt: REMOVE, nextAttemptAt: null, updatedAt: cutoff });
        await store().delete("identityClaims", d.numberHmac);
        const mine = await store().query("identityDocuments", { where: [["uid", "==", d.uid]], orderBy: [["createdAt", "desc"]], limit: 20 });
        await store().update("users", d.uid, { "identity.level": levelFrom(mine.map((x) => (x.id === d.id ? { ...x, status: "expired" } : x))), updatedAt: cutoff });
        purged++;
      }
    }
  }
  return purged;
}

module.exports = { submitDocument, withdrawDocument, listMyDocuments, decide, reviewQueue, revealNumber, purgeExpired, canonical, docView, PENDING };
