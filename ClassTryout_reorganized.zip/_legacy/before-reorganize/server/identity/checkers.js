// Routes for confirming an ID. A checker NEVER sits inside the sign-up request:
//   submit  ->  document saved (level 1)  ->  status pending_check or pending_review  ->  a worker / a human decides later.
// If a checker is down, slow, or switched off, the person is already onboarded at level 1 and the document waits for a human.
//
// A checker is { name, enabled(), check({ type, number, profile }) } returning one of:
//   { outcome: "verified" }
//   { outcome: "rejected", reason }            the authority said the ID does not match
//   { outcome: "unavailable", reason }         outage, timeout, no access (the worker retries, then hands to a human)
//
// "nia" (Ghana Card, National Identification Authority) is a placeholder until you have NIA's (or an approved partner's) API access.
// Nothing here calls NIA yet; with ID_CHECK_NIA unset every Ghana Card goes to a human reviewer. Plan B adds the real call.
const types = require("../../shared/id-types.json").types;

const nia = {
  name: "nia",
  enabled: () => /^(1|true|on|yes)$/i.test(process.env.ID_CHECK_NIA || ""),
  async check() {
    return { outcome: "unavailable", reason: "NIA integration is not connected yet." };
  },
};

const manual = { name: "manual", enabled: () => true, async check() { return { outcome: "unavailable", reason: "manual review only" }; } };

const REGISTRY = { nia, manual };

// Which route a new document takes: an automated checker when one is switched on for this type, otherwise a human.
function routeFor(typeCode) {
  const t = types.find((x) => x.code === typeCode);
  const c = t && REGISTRY[t.checker];
  if (c && c.name !== "manual" && c.enabled()) return { checker: c.name, status: "pending_check" };
  return { checker: "manual", status: "pending_review" };
}

const get = (name) => REGISTRY[name] || null;

module.exports = { routeFor, get, REGISTRY };
