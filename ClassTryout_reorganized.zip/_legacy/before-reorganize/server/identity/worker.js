// The automated-check worker (Plan B runs it on a schedule). Safe to run any time; it only touches documents in "pending_check".
//   verified    -> level 2
//   rejected    -> kept for a human to look at (a mismatch can be a typo or an NIA data error, so we never auto-reject)
//   unavailable -> retry later with back-off; after the retention window the document is handed to a human reviewer
// Nothing here can stop anyone using the app: people are at level 1 from the moment they submit.
const { store, nowIso } = require("../store.js");
const { decrypt } = require("../crypto.js");
const checkers = require("./checkers.js");
const { decide } = require("./index.js");

const SYSTEM = { uid: "system", role: "system" };

async function processDue({ now = new Date(), registry = checkers.REGISTRY, limit = 50 } = {}) {
  const iso = now.toISOString();
  const rows = await store().query("identityDocuments", { where: [["status", "==", "pending_check"], ["nextAttemptAt", "<=", iso]], orderBy: [["nextAttemptAt", "asc"]], limit });
  const out = { checked: 0, verified: 0, toReview: 0, retry: 0 };
  for (const d of rows) {
    const c = registry[d.checker];
    out.checked++;
    let r;
    try {
      const u = await store().get("users", d.uid);
      r = c && c.enabled() ? await c.check({ type: d.type, number: decrypt(d.encNumber, `idnum:${d.uid}`), profile: (u && u.profile) || {} }) : { outcome: "unavailable", reason: "checker off" };
    } catch (e) {
      r = { outcome: "unavailable", reason: String(e && e.message).slice(0, 100) };
    }
    if (r.outcome === "verified") {
      await decide({ docId: d.id, decision: "verified", by: SYSTEM, checker: d.checker, note: "Confirmed automatically." });
      out.verified++;
    } else if (r.outcome === "rejected") {
      await store().update("identityDocuments", d.id, { status: "pending_review", checker: "manual", note: `Automated check did not match: ${String(r.reason || "").slice(0, 120)}`, nextAttemptAt: null, updatedAt: nowIso() });
      out.toReview++;
    } else {
      const attempts = (d.attempts || 0) + 1;
      if (d.encExpiresAt && d.encExpiresAt <= iso || attempts >= 12) {
        await store().update("identityDocuments", d.id, { status: "pending_review", checker: "manual", attempts, nextAttemptAt: null, updatedAt: nowIso() });
        out.toReview++;
      } else {
        const backoffMin = Math.min(15 * 2 ** (attempts - 1), 24 * 60);
        await store().update("identityDocuments", d.id, { attempts, nextAttemptAt: new Date(now.getTime() + backoffMin * 60000).toISOString(), updatedAt: nowIso() });
        out.retry++;
      }
    }
  }
  return out;
}

module.exports = { processDue };
