// Ghana's administrative hierarchy: 16 regions > 261 districts (MMDAs) > city/town > suburb > optional sub-area.
// Regions and districts come from shared/locations/*.json (counts checked against the official list by scripts/check-consistency.js).
// Cities, suburbs and sub-areas are free text on purpose: no list covers every neighbourhood in the country, and people
// name them differently. We keep a NORMALISED KEY next to each so "East Legon", "east  legon" and "E. Legon" group together.
const regions = require("../shared/locations/regions.json");
const districts = require("../shared/locations/districts.json");
const { bad } = require("./httpError.js");

const regionByCode = new Map(regions.map((r) => [r.code, r]));
const districtById = new Map(districts.map((d) => [d.id, d]));

// GhanaPostGPS digital address: 2-3 letters, 3-4 digits (plus a 4-digit part), e.g. GA-543-1234.
const GPS = /^[A-Z]{2,3}-[0-9]{3,4}-[0-9]{4}$/;

const clean = (s) => String(s == null ? "" : s).normalize("NFKC").replace(/\s+/g, " ").trim();

// "East  Legon (Ext.)" -> "east legon ext"
function normKey(s) {
  return clean(s)
    .toLowerCase()
    .replace(/\bext(ension)?\b\.?/g, "ext")
    .replace(/[^\p{L}\p{N} ]/gu, "")
    .replace(/\s+/g, " ")
    .trim();
}

function validPlace(label, v, { required, max = 80 } = {}) {
  const s = clean(v);
  if (!s) {
    if (required) throw bad(`${label} is required.`, { [label.toLowerCase()]: "Required." });
    return "";
  }
  if (s.length > max || s.length < 2) throw bad(`${label} must be 2-${max} characters.`, { [label.toLowerCase()]: "Check this." });
  if (!/^[\p{L}\p{N} .,'’()/&-]+$/u.test(s)) throw bad(`${label} has characters we do not accept.`, { [label.toLowerCase()]: "Letters, numbers and . , ' ( ) / & - only." });
  return s;
}

// Returns the address object stored on users/{uid}.address, or throws a 422 HttpError.
function validateAddress(input) {
  const body = input || {};
  const region = regionByCode.get(String(body.regionCode || ""));
  if (!region) throw bad("Choose your region.", { regionCode: "Choose a region." });
  const district = districtById.get(String(body.districtId || ""));
  if (!district) throw bad("Choose your district.", { districtId: "Choose a district." });
  if (district.region !== region.code) throw bad("That district is not in the region you chose.", { districtId: "Not in this region." });

  const city = validPlace("City", body.city, { required: true });
  const suburb = validPlace("Suburb", body.suburb, { required: true });
  const subarea = validPlace("Sub-area", body.subarea, { max: 100 });
  const street = validPlace("Street", body.street, { max: 120 });

  let gpsAddress = clean(body.gpsAddress).toUpperCase();
  if (gpsAddress && !GPS.test(gpsAddress)) throw bad("GhanaPostGPS looks like GA-543-1234.", { gpsAddress: "Check the format." });

  const out = {
    regionCode: region.code,
    regionName: region.name,
    districtId: district.id,
    districtName: district.name,
    city,
    cityKey: normKey(city),
    suburb,
    suburbKey: normKey(suburb),
  };
  if (subarea) { out.subarea = subarea; out.subareaKey = normKey(subarea); }
  if (street) out.street = street;
  if (gpsAddress) out.gpsAddress = gpsAddress;
  if (body.lat !== undefined && body.lat !== null && body.lat !== "") {
    const lat = Number(body.lat), lng = Number(body.lng);
    // Ghana sits roughly between 4.5-11.5 N and 3.5 W-1.5 E.
    if (!(lat >= 4 && lat <= 12 && lng >= -4 && lng <= 2)) throw bad("That location is outside Ghana.", { lat: "Outside Ghana." });
    out.lat = Math.round(lat * 1e6) / 1e6;
    out.lng = Math.round(lng * 1e6) / 1e6;
  }
  if (body.placeId) out.placeId = clean(body.placeId).slice(0, 200);
  return out;
}

module.exports = { regions, districts, regionByCode, districtById, normKey, validateAddress, clean, GPS };
