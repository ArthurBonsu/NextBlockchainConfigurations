// Firebase Admin (server only). Credentials come from the environment and are never exposed to the browser.
//   FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY   (from a service-account JSON)
// or GOOGLE_APPLICATION_CREDENTIALS pointing at that JSON file.
// Local testing: FIREBASE_AUTH_EMULATOR_HOST + FIREBASE_PROJECT_ID (no credentials; refused when NODE_ENV=production).
//
// firebase-admin v13+ has NO namespaced API (admin.auth(), admin.firestore()): only the modular imports below exist.
// getAdmin() returns a small facade so the rest of the code can keep writing getAdmin().auth() / .firestore() / .FieldValue.
let facade;

function getAdmin() {
  if (facade) return facade;
  const { initializeApp, cert, applicationDefault, getApps } = require("firebase-admin/app");
  const { getAuth } = require("firebase-admin/auth");
  const { getFirestore, FieldValue } = require("firebase-admin/firestore");

  const { FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY } = process.env;
  let app;
  if (getApps().length) {
    app = getApps()[0];
  } else if (process.env.FIREBASE_AUTH_EMULATOR_HOST && FIREBASE_PROJECT_ID && process.env.NODE_ENV !== "production") {
    app = initializeApp({ projectId: FIREBASE_PROJECT_ID });
  } else if (FIREBASE_PROJECT_ID && FIREBASE_CLIENT_EMAIL && FIREBASE_PRIVATE_KEY) {
    app = initializeApp({
      credential: cert({
        projectId: FIREBASE_PROJECT_ID,
        clientEmail: FIREBASE_CLIENT_EMAIL,
        // .env files store the key with literal "\n"; Firebase needs real newlines.
        privateKey: FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n"),
      }),
    });
  } else if (process.env.GOOGLE_APPLICATION_CREDENTIALS) {
    app = initializeApp({ credential: applicationDefault() });
  } else {
    throw new Error(
      "Firebase Admin is not configured. Set FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL and FIREBASE_PRIVATE_KEY " +
        "(or GOOGLE_APPLICATION_CREDENTIALS) in .env.local. See .env.local.example."
    );
  }
  facade = { app, auth: () => getAuth(app), firestore: () => getFirestore(app), FieldValue };
  return facade;
}

module.exports = { getAdmin };
