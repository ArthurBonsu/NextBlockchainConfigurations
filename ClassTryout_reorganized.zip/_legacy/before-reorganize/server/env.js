// Loads .env.local then .env (first file that sets a variable wins), the same two files truffle-config.js reads.
// Next.js loads these itself; this is for the plain-Node notifier.
const fs = require("fs");
const path = require("path");
const dotenv = require("dotenv");

// Project root. Under Next.js the server code is bundled, so __dirname points into .next/: use the working directory
// (Next, the notifier and the scripts all run from the project root) and fall back to the file location.
const root =
  process.env.PROJECT_ROOT ||
  (fs.existsSync(path.join(process.cwd(), "shared", "roles.json")) ? process.cwd() : path.resolve(__dirname, ".."));
for (const file of [".env.local", ".env"]) {
  const p = path.join(root, file);
  if (fs.existsSync(p)) dotenv.config({ path: p });
}

module.exports = { root };
