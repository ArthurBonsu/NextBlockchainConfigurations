// An error that knows its HTTP status. `code` is a stable machine-readable word the UI can switch on.
class HttpError extends Error {
  constructor(status, message, code, extra) {
    super(message);
    this.name = "HttpError";
    this.status = status;
    this.code = code || "error";
    this.extra = extra || undefined; // e.g. { fields: {...} } or { retryAfter: 30 }
  }
}
const bad = (message, fields) => new HttpError(422, message, "invalid", fields ? { fields } : undefined);
const forbidden = (message, code, extra) => new HttpError(403, message, code || "forbidden", extra);
const conflict = (message, code) => new HttpError(409, message, code || "conflict");
const tooMany = (message, retryAfter) => new HttpError(429, message, "rate_limited", { retryAfter });
const notFound = (message) => new HttpError(404, message, "not_found");

module.exports = { HttpError, bad, forbidden, conflict, tooMany, notFound };
