// One small data layer over Firestore, so the rest of the code never touches Firestore directly.
//
// Backends (STORE_BACKEND):
//   firestore  (default)  Firestore through the Firebase Admin SDK (the only writer; security rules deny browsers).
//   file                  a local JSON file, for tests and offline work. REFUSED when NODE_ENV=production.
//                         It pretends to be Firestore closely enough to catch the mistakes that hurt:
//                         a query that would need a composite index fails here unless firebase/firestore.indexes.json has it.
//
// Time values are ISO-8601 strings everywhere (they sort correctly and compare the same on both backends).
// The one exception is the field "expireAt": it is written as a real Firestore Timestamp so a TTL policy can delete the document,
// and is turned back into an ISO string when read.
//
// Updates use dotted field paths ("identity.level") the same way Firestore does; store.REMOVE deletes a field.
const fs = require("fs");
const path = require("path");
const { root } = require("./env.js");

const REMOVE = Symbol("remove-field");
const BACKEND = () => (process.env.STORE_BACKEND || "firestore").toLowerCase();

class StoreError extends Error {
  constructor(message, code) {
    super(message);
    this.name = "StoreError";
    this.code = code;
  }
}

// ---------------------------------------------------------------------------------------------------------
// shared helpers
// ---------------------------------------------------------------------------------------------------------
const clone = (v) => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));

function getPath(obj, p) {
  let cur = obj;
  for (const k of p.split(".")) {
    if (cur === null || typeof cur !== "object") return undefined;
    cur = cur[k];
  }
  return cur;
}

function setPath(obj, p, value) {
  const keys = p.split(".");
  let cur = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    if (cur[keys[i]] === null || typeof cur[keys[i]] !== "object") cur[keys[i]] = {};
    cur = cur[keys[i]];
  }
  const last = keys[keys.length - 1];
  if (value === REMOVE) delete cur[last];
  else cur[last] = value;
}

function applyUpdate(doc, patch) {
  const out = clone(doc) || {};
  for (const [k, v] of Object.entries(patch)) setPath(out, k, v === undefined ? REMOVE : clone2(v));
  return out;
}
const clone2 = (v) => (v === REMOVE ? REMOVE : clone(v));

// ---------------------------------------------------------------------------------------------------------
// index emulation (file backend)
// ---------------------------------------------------------------------------------------------------------
let indexCache;
function loadIndexes() {
  if (indexCache) return indexCache;
  const file = process.env.FIRESTORE_INDEXES_FILE || path.join(root, "firebase", "firestore.indexes.json");
  try {
    indexCache = JSON.parse(fs.readFileSync(file, "utf8")).indexes || [];
  } catch {
    indexCache = [];
  }
  return indexCache;
}

const EQ = new Set(["==", "in", "array-contains", "array-contains-any"]);

// The composite index a query would need, or null when Firestore can answer it from the automatic single-field indexes.
function requiredIndex(collection, q) {
  const where = q.where || [];
  const order = q.orderBy || [];
  const eqFields = [...new Set(where.filter((w) => w[1] === "==").map((w) => w[0]))];
  const rangeFields = [...new Set(where.filter((w) => !EQ.has(w[1])).map((w) => w[0]))];
  const orderFields = order.map((o) => o[0]);
  const all = new Set([...where.map((w) => w[0]), ...orderFields]);
  if (all.size <= 1 && order.length <= 1) return null;
  if (!order.length && !rangeFields.length) return null; // equality filters only: merged from single-field indexes
  const tail = [];
  for (const f of rangeFields) if (!tail.some((t) => t[0] === f)) tail.push([f, order.find((o) => o[0] === f)?.[1] || "asc"]);
  for (const o of order) if (!tail.some((t) => t[0] === o[0])) tail.push([o[0], o[1] || "asc"]);
  const lead = eqFields.filter((f) => !tail.some((t) => t[0] === f));
  return { collection, lead, tail };
}

function indexMatches(idx, need) {
  if (idx.collectionGroup !== need.collection) return false;
  const fields = idx.fields.map((f) => [f.fieldPath, f.order === "DESCENDING" ? "desc" : f.order === "ASCENDING" ? "asc" : f.arrayConfig]);
  if (fields.length !== need.lead.length + need.tail.length) return false;
  const lead = fields.slice(0, need.lead.length).map((f) => f[0]).sort();
  if (JSON.stringify(lead) !== JSON.stringify([...need.lead].sort())) return false;
  const tail = fields.slice(need.lead.length);
  return need.tail.every((t, i) => tail[i][0] === t[0] && tail[i][1] === (t[1] || "asc"));
}

function assertIndex(collection, q) {
  if (String(process.env.STORE_ENFORCE_INDEXES || "true").toLowerCase() === "false") return;
  const need = requiredIndex(collection, q);
  if (!need) return;
  if (loadIndexes().some((i) => indexMatches(i, need))) return;
  const desc = [...need.lead.map((f) => `${f} ASC`), ...need.tail.map((t) => `${t[0]} ${String(t[1]).toUpperCase()}`)].join(", ");
  throw new StoreError(`This query needs a composite index on ${collection} (${desc}). Add it to firebase/firestore.indexes.json.`, "failed-precondition");
}

function compare(a, b) {
  if (a === b) return 0;
  if (a === undefined || a === null) return -1;
  if (b === undefined || b === null) return 1;
  return a < b ? -1 : 1;
}

function matches(doc, [field, op, value]) {
  const v = getPath(doc, field);
  switch (op) {
    case "==": return v === value;
    case "!=": return v !== undefined && v !== value;
    case "<": return v !== undefined && v < value;
    case "<=": return v !== undefined && v <= value;
    case ">": return v !== undefined && v > value;
    case ">=": return v !== undefined && v >= value;
    case "in": return Array.isArray(value) && value.includes(v);
    case "array-contains": return Array.isArray(v) && v.includes(value);
    default: throw new StoreError(`Unsupported operator ${op}`);
  }
}

// ---------------------------------------------------------------------------------------------------------
// file backend
// ---------------------------------------------------------------------------------------------------------
class FileStore {
  constructor() {
    this.queue = Promise.resolve();
  }
  file() {
    return process.env.STORE_FILE || path.join(root, ".data", "dev-store.json");
  }
  read() {
    try {
      return JSON.parse(fs.readFileSync(this.file(), "utf8"));
    } catch {
      return {};
    }
  }
  write(db) {
    fs.mkdirSync(path.dirname(this.file()), { recursive: true });
    fs.writeFileSync(this.file(), JSON.stringify(db, null, 1));
  }
  // Serialise every operation so two requests cannot interleave a read-modify-write.
  lock(fn) {
    const run = this.queue.then(fn, fn);
    this.queue = run.catch(() => {});
    return run;
  }
  ops(db, dirty) {
    const col = (c) => (db[c] = db[c] || {});
    return {
      get: async (c, id) => clone(col(c)[id]) || null,
      create: async (c, id, data) => {
        if (col(c)[id]) throw new StoreError(`${c}/${id} already exists`, "already-exists");
        col(c)[id] = clone(data);
        dirty();
      },
      set: async (c, id, data) => {
        col(c)[id] = clone(data);
        dirty();
      },
      update: async (c, id, patch) => {
        if (!col(c)[id]) throw new StoreError(`${c}/${id} does not exist`, "not-found");
        col(c)[id] = applyUpdate(col(c)[id], patch);
        dirty();
      },
      delete: async (c, id) => {
        delete col(c)[id];
        dirty();
      },
      add: async (c, data) => {
        const id = require("crypto").randomBytes(10).toString("hex");
        col(c)[id] = clone(data);
        dirty();
        return id;
      },
      query: async (c, q = {}) => {
        assertIndex(c, q);
        let rows = Object.entries(col(c)).map(([id, d]) => ({ id, ...clone(d) }));
        for (const w of q.where || []) rows = rows.filter((r) => matches(r, w));
        for (const [f, dir] of [...(q.orderBy || [])].reverse()) {
          rows.sort((a, b) => (dir === "desc" ? -1 : 1) * compare(getPath(a, f), getPath(b, f)));
        }
        if (q.limit) rows = rows.slice(0, q.limit);
        return rows;
      },
    };
  }
  async single(fn) {
    return this.lock(async () => {
      const db = this.read();
      let changed = false;
      const out = await fn(this.ops(db, () => (changed = true)));
      if (changed) this.write(db);
      return out;
    });
  }
  async transaction(fn) {
    // Writes are applied only if fn completes without throwing.
    return this.single(async (ops) => {
      const snapshot = clone(this.read());
      try {
        return await fn(ops);
      } catch (e) {
        this.write(snapshot); // undo anything written before the failure
        throw e;
      }
    });
  }
  get(c, id) { return this.single((o) => o.get(c, id)); }
  create(c, id, d) { return this.single((o) => o.create(c, id, d)); }
  set(c, id, d) { return this.single((o) => o.set(c, id, d)); }
  update(c, id, p) { return this.single((o) => o.update(c, id, p)); }
  delete(c, id) { return this.single((o) => o.delete(c, id)); }
  add(c, d) { return this.single((o) => o.add(c, d)); }
  query(c, q) { return this.single((o) => o.query(c, q)); }
}

// ---------------------------------------------------------------------------------------------------------
// firestore backend
// ---------------------------------------------------------------------------------------------------------
function toFs(data) {
  const out = {};
  for (const [k, v] of Object.entries(data)) {
    if (k === "expireAt" && typeof v === "string") out[k] = new Date(v);
    else out[k] = v;
  }
  return out;
}
function patchToFs(patch, FieldValue) {
  const out = {};
  for (const [k, v] of Object.entries(patch)) {
    if (v === REMOVE) out[k] = FieldValue.delete();
    else if (k === "expireAt" && typeof v === "string") out[k] = new Date(v);
    else out[k] = v === undefined ? FieldValue.delete() : v;
  }
  return out;
}
function fromFs(data) {
  if (!data) return null;
  const out = { ...data };
  if (out.expireAt && typeof out.expireAt.toDate === "function") out.expireAt = out.expireAt.toDate().toISOString();
  return out;
}

class FirestoreStore {
  admin() {
    return require("./firebaseAdmin.js").getAdmin();
  }
  db() {
    return this.admin().firestore();
  }
  async get(c, id) {
    const s = await this.db().collection(c).doc(id).get();
    return s.exists ? fromFs(s.data()) : null;
  }
  async create(c, id, d) {
    try {
      await this.db().collection(c).doc(id).create(toFs(d));
    } catch (e) {
      if (e && (e.code === 6 || /already exists/i.test(e.message))) throw new StoreError(`${c}/${id} already exists`, "already-exists");
      throw e;
    }
  }
  async set(c, id, d) { await this.db().collection(c).doc(id).set(toFs(d)); }
  async update(c, id, p) { await this.db().collection(c).doc(id).update(patchToFs(p, this.admin().FieldValue)); }
  async delete(c, id) { await this.db().collection(c).doc(id).delete(); }
  async add(c, d) { return (await this.db().collection(c).add(toFs(d))).id; }
  async query(c, q = {}) {
    let ref = this.db().collection(c);
    for (const [f, op, v] of q.where || []) ref = ref.where(f, op, v);
    for (const [f, dir] of q.orderBy || []) ref = ref.orderBy(f, dir || "asc");
    if (q.limit) ref = ref.limit(q.limit);
    return (await ref.get()).docs.map((d) => ({ id: d.id, ...fromFs(d.data()) }));
  }
  // Firestore transactions need every read before the first write; callers in this code base follow that rule.
  async transaction(fn) {
    const db = this.db();
    const FieldValue = this.admin().FieldValue;
    return db.runTransaction(async (tx) => {
      const ref = (c, id) => db.collection(c).doc(id);
      return fn({
        get: async (c, id) => {
          const s = await tx.get(ref(c, id));
          return s.exists ? fromFs(s.data()) : null;
        },
        create: async (c, id, d) => void tx.create(ref(c, id), toFs(d)),
        set: async (c, id, d) => void tx.set(ref(c, id), toFs(d)),
        update: async (c, id, p) => void tx.update(ref(c, id), patchToFs(p, FieldValue)),
        delete: async (c, id) => void tx.delete(ref(c, id)),
        add: async (c, d) => {
          const r = db.collection(c).doc();
          tx.set(r, toFs(d));
          return r.id;
        },
        query: async (c, q = {}) => {
          let r = db.collection(c);
          for (const [f, op, v] of q.where || []) r = r.where(f, op, v);
          for (const [f, dir] of q.orderBy || []) r = r.orderBy(f, dir || "asc");
          if (q.limit) r = r.limit(q.limit);
          return (await tx.get(r)).docs.map((d) => ({ id: d.id, ...fromFs(d.data()) }));
        },
      });
    });
  }
}

let instance;
let instanceKind;
function store() {
  const kind = BACKEND();
  if (kind === "file" && process.env.NODE_ENV === "production") {
    throw new Error("STORE_BACKEND=file is for local testing only and is refused when NODE_ENV=production.");
  }
  if (kind !== "file" && kind !== "firestore") throw new Error(`Unknown STORE_BACKEND "${kind}" (use firestore or file).`);
  if (!instance || instanceKind !== kind) {
    instance = kind === "file" ? new FileStore() : new FirestoreStore();
    instanceKind = kind;
  }
  return instance;
}

const nowIso = () => new Date().toISOString();

module.exports = { store, REMOVE, StoreError, nowIso, requiredIndex, indexMatches, getPath, applyUpdate };
