# Project tree (updated: Plan A, accounts)

`NEW` = added in this pack, `CHANGED` = replaces your file, `MOVE` = leaves the build path (script does it),
`GENERATED` = written by a command, never edit by hand.

```
classtryout/
│
├── contracts/                              Solidity: the source of truth for everything below
│   ├── VehicleRegistry.sol                 CHANGED  OpenZeppelin Ownable + Pausable, removeVehicle hardening
│   ├── RevocationManager.sol               CHANGED  OpenZeppelin Ownable + Pausable
│   ├── LicenseRegistry.sol                 CHANGED  OpenZeppelin Ownable + Pausable
│   ├── IVehicleRegistry.sol                unchanged
│   └── IRevocationManager.sol              unchanged
│       (OpenZeppelin is imported by package path from node_modules; no copy lives in this folder)
│
├── migrations/
│   ├── 2_deploy_vehicle_registry.js        CHANGED  records address + deploy block
│   ├── 3_deploy_revocation_manager.js      CHANGED  wires the registry once, records address + block
│   └── 4_deploy_license_registry.js        NEW      replaces 16_* (no more duplicate "16")
│
├── shared/                                 ONE place the contracts, scripts and front end all read from
│   ├── chains.json                         NEW  every network (chain id, name, RPC, explorer, Infura name)
│   ├── contracts.json                      NEW  which contracts the app uses
│   ├── abi/                                GENERATED  <Name>.json + <Name>.ts, from the compiled contracts
│   ├── notifications.json                  NEW  which event sends which email (checked against the ABI)
│   ├── rpc.js                              NEW  which RPC URL to use for a chain (deploys and the watcher share it)
│   ├── roles.json                          NEW  roles, capabilities and the ID level each needs (server enforces, UI reads)
│   ├── id-types.json                       NEW  accepted ID types, shape patterns, which checker, retention days
│   ├── onboarding.json                     NEW  steps, consent texts + versions, SMS code rules
│   ├── locations/regions.json              NEW  16 regions
│   ├── locations/districts.json            NEW  261 districts (MMDAs) with their towns
│   ├── deployments.json                    NEW  public-chain addresses + deploy block, written by migrations; COMMIT
│   └── deployments.local.json              GENERATED  local-chain addresses; git-ignored
│
├── scripts/
│   ├── sync-contracts.js                   NEW  build output -> shared/abi
│   ├── record-deployment.js                NEW  used by the migrations -> shared/deployments*.json
│   ├── check-consistency.js                NEW  `npm run check`: fails if anything drifted apart
│   ├── cleanup-legacy.sh                   NEW  moves Passchain / old files out of the build path (dry run by default)
│   ├── set-role.js                         NEW  make the first super administrator; change roles; --confirm-identity for founders
│   ├── gen-real-structure.js               NEW  runs the real code on made-up people -> docs/firebaserealstructure.txt; --check = every field is in database.md
│   ├── review-id.js                        NEW  command-line ID review (list / show / verify / reject), audit-logged
│   └── id-maintenance.js                   NEW  automated ID checks that are due + delete undecided ID numbers (run hourly)
│
├── notifier/                               NEW  email watcher (plain Node, runs on its own: npm run notify)
│   ├── index.js                            entry point: loop / --once / --status
│   ├── watcher.js                          reads new events per chain, idempotent, retries, confirmations
│   ├── resolve.js                          event -> which wallet, which email, with readable names
│   ├── templates.js                        the six emails (text + HTML)
│   ├── mailer.js                           SMTP via Nodemailer (or outbox / log for testing)
│   ├── deployments.js                      addresses + start block from shared/deployments*.json
│   ├── state.js                            its memory (notifier/data/state.json, git-ignored, no emails in it)
│   └── data/                               GENERATED  state, test outbox, dev accounts; git-ignored
│
├── server/                                 server-only code used by /api, the watcher and the scripts (never sent to the browser)
│   ├── env.js  config.js  crypto.js        CHANGED/NEW  .env loading + project root, secrets, HMAC / AES-GCM / random codes
│   ├── firebaseAdmin.js  auth.js           CHANGED  Admin SDK (v14 modular API; emulator aware), token check (+ revocation)
│   ├── httpError.js  session.js            NEW  typed errors; withSession(): token -> profile -> role/level gate -> JSON errors
│   ├── store.js                            NEW  one data layer: Firestore, or a local file store that enforces the index rule
│   ├── users.js                            NEW  profile, consents, address, onboarding state, role + status changes, admin lists
│   ├── roles.js                            NEW  "can this account do this?" (reads shared/roles.json)
│   ├── locations.js  phone.js              NEW  region/district/suburb validation; Ghana mobile numbers -> +233
│   ├── otp.js                              NEW  SMS one-time codes: limits, attempts, expiry, one number per account
│   ├── rateLimit.js  audit.js              NEW  counters in Firestore; append-only audit log with secrets stripped
│   ├── identity/                           NEW  index.js (submit, withdraw, review, reveal, purge), checkers.js (NIA = placeholder,
│   │                                            manual), worker.js (automated checks with retry, hands over to a human)
│   ├── sms/                                NEW  index.js + mock, console, http, arkesel, hubtel (provider-neutral)
│   ├── links.js  challenge.js              wallet -> account links; signed-message challenge   (unchanged)
│   └── apiHelpers.js                       the wallet-link routes' wrapper                      (unchanged)
│
├── firebase/                               NEW
│   ├── firestore.rules                     browsers may read only their own users/{uid}; everything else denied
│   ├── firestore.indexes.json              the 12 composite indexes the queries need
│   └── README.md                           console steps, TTL, first admin, emulator, go-live checklist
├── firebase.json                           NEW  rules + indexes + emulator ports
│
├── test/
│   ├── registry.test.js                    NEW  21 contract tests (`npm run contracts:test`)
│   └── accounts/                           NEW  26 unit tests for accounts (`npm run test:accounts`)
│
├── utils/
│   ├── contracts.ts                        CHANGED  typed ABIs + shared/deployments; sendTx(); getContractStatuses()
│   ├── networks.ts                         CHANGED  reads shared/chains.json
│   ├── receipts.ts                         CHANGED  reads history from the deploy block, in pages
│   ├── errors.ts                           CHANGED  understands OpenZeppelin custom errors
│   ├── auth.ts                             CHANGED  the one place the app asks "who is signed in": a Firebase ID token
│   ├── firebaseClient.ts  api.ts           NEW  Firebase sign-in on the browser; fetch with the token, typed errors
│   ├── accountTypes.ts                     NEW  the shape of GET /api/me
│   ├── walletLink.ts                       NEW  browser side of the wallet-link API
│   ├── contract-loader.ts                  MOVE  Passchain code; nothing here uses it
│   └── logger.ts                           MOVE  unrelated to this app
│
├── components/
│   ├── WalletBar.tsx                       CHANGED  network picker, live-network / not-deployed banners, Admin badge
│   ├── VehicleRegistryPanel.tsx            CHANGED  sendTx, friendly errors
│   ├── LicensePanel.tsx                    CHANGED  sendTx, admin revoke / reinstate, find by vehicle
│   ├── RevocationPanel.tsx                 CHANGED  sendTx, friendly errors
│   ├── VehicleHistory.tsx                  CHANGED  scans from the deploy block, explorer links
│   ├── ReceiptCard.tsx                     CHANGED  explorer link on the tx hash
│   ├── AdminPanel.tsx                      NEW      owner + paused status; Pause / Resume for the admin
│   ├── NotifyPanel.tsx                     NEW      link / unlink this wallet for email notifications
│   ├── TxLink.tsx                          NEW      tx hash -> block explorer link
│   └── auth/                               NEW
│       ├── AuthProvider.tsx                who is signed in (Firebase) + the server's view of them (/api/me)
│       ├── AccountBar.tsx                  top bar: name, role, account, sign out
│       ├── CapabilityGate.tsx              hides/locks a panel unless the account may use it (NEXT_PUBLIC_REQUIRE_ACCOUNT)
│       ├── IdStep.tsx                      add / list / remove IDs (used in onboarding and on the account page)
│       └── ui.tsx                          Field, Notice, safeNext
│
├── pages/
│   ├── index.tsx                           unchanged  redirects to /vehicle-demo
│   ├── _app.tsx                            NEW        wraps every page in <AuthProvider>
│   ├── signin.tsx                          NEW        sign in / create account / reset password / GitHub / X
│   ├── onboarding.tsx                      NEW        agreements, about you, phone code, address, ID
│   ├── account.tsx                         NEW        profile, role, capabilities, IDs, notification preferences
│   ├── vehicle-demo.tsx                    CHANGED    account bar + capability gates around register / issue / revoke
│   ├── api/wallet-link/                    NEW        challenge.ts, confirm.ts, index.ts (list / unlink)
│   ├── api/me/                             NEW        index.ts (GET profile), notifications.ts
│   ├── api/onboarding/                     NEW        consent, profile, address, phone/start, phone/confirm
│   ├── api/identity/  api/locations/       NEW        IDs; suburb suggestions
│   ├── api/capability/[name].ts            NEW        200 / 403 check to call before an action that matters
│   ├── api/admin/                          NEW        users (list, role, status), identity (queue, review, reveal)
│   └── app.tsx                             MOVE  unrelated; Next.js would build it as a route
│
├── styles/
│   ├── VehicleDemo.module.css              CHANGED  (rename from VehicleDemo.module_1.css)
│   └── Account.module.css                  NEW
│
├── docs/
│   ├── PROJECT_TREE.md                     this file
│   ├── ACCOUNTS.md                         NEW  roles, flows, API, commands, limits
│   ├── database.md                         NEW  the full database schema as a tree (Firestore + on-chain data + files), indexes, rules
│   ├── firebaserealstructure.txt           GENERATED  real example documents in the Firebase console layout (`npm run docs:structure`)
│   └── remix-templates/                    MOVE  2_Owner.sol, 3_Ballot.sol, Storage.sol (kept for teaching)
│
├── e2e/                                    NEW  optional tests: flow, multi-network, notify (watcher + API), notify-ui (panel),
│                                            accounts (sign-up to confirmed ID in a real browser, against the Auth emulator)
│
├── truffle-config.js                       CHANGED  networks come from shared/chains.json; reads .env.local
├── package.json                            CHANGED  scripts + OpenZeppelin 5.0.2 pinned + firebase (browser SDK)
├── tsconfig.json                           CHANGED  strict mode
├── .env.local.example                      NEW
│
├── _legacy/                                where cleanup-legacy.sh puts: config/, context/, data/, outputs/, services/,
│                                           tatum-*.ts, useTransactionContext.tsx, contract_addresses.json,
│                                           sequence_abi.json, 1_/16_ migrations, and the old build/contracts
└── build/contracts/                        GENERATED by truffle compile; git-ignored; never imported by the app
```

## Who reads what

| Thing | Single source | Read by |
|---|---|---|
| Contract behaviour | `contracts/*.sol` | `truffle compile`, tests |
| ABI (method names, args, events, errors) | `shared/abi/` (from the compiled contracts) | `utils/contracts.ts`, `utils/receipts.ts`, `npm run check` |
| Networks | `shared/chains.json` | `truffle-config.js`, `utils/networks.ts`, `record-deployment.js`, `npm run check` |
| Addresses + deploy block | `shared/deployments*.json` (migrations write them) | `utils/contracts.ts` (and through it every component and page) |
| Admin / pause state | the contracts themselves (OpenZeppelin `owner()`, `paused()`) | `AdminPanel`, `WalletBar` |
| Which event sends which email | `shared/notifications.json` | `notifier/`, `npm run check` |
| Who gets the email | wallet link (`server/links.js`) -> Firebase Auth verified email | `notifier/watcher.js`, `/api/wallet-link` |
| RPC endpoint per chain | `shared/rpc.js` | `truffle-config.js`, `notifier/` |
| Error wording | `utils/errors.ts` | every panel |
| Roles and what each may do | `shared/roles.json` | `server/roles.js` (enforces), `CapabilityGate` / account page (display), `npm run check` |
| Regions and districts | `shared/locations/*.json` | `server/locations.js` (validates), onboarding form, `npm run check` (261 / per-region counts) |
| ID types and shape rules | `shared/id-types.json` | `server/identity/`, `IdStep` |
| Onboarding steps, consent versions, SMS code rules | `shared/onboarding.json` | `server/users.js`, `server/otp.js`, onboarding page |
| Database schema (every collection and field) | the code | `docs/database.md`; `npm run check` fails if the code writes a field the file does not list |
| Which queries need an index | the code's queries | `firebase/firestore.indexes.json`; the local store fails a query that is missing one |
