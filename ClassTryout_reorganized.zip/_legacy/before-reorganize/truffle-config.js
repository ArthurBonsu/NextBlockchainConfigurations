// -----------------------------------------------------------------------------
// Truffle config. The list of networks comes from shared/chains.json, the same file the front end
// uses, so the two can never disagree about chain ids.
//
//   npm run deploy:local            local Ganache (npm run chain)
//   npx truffle migrate --network sepolia | baseSepolia | arbitrumSepolia | optimismSepolia | polygonAmoy   (free testnets)
//   ALLOW_MAINNET_DEPLOY=yes npx truffle migrate --network mainnet | base | arbitrum | optimism | polygon    (REAL MONEY)
//
// Secrets are read from .env.local (the file Next.js uses) or .env. Never commit them.
// -----------------------------------------------------------------------------
const fs = require("fs");
const path = require("path");
const dotenv = require("dotenv");
const HDWalletProvider = require("@truffle/hdwallet-provider");
const { chains } = require("./shared/chains.json");
const { rpcUrl } = require("./shared/rpc.js");

// Truffle only reads ".env" on its own. Load ".env.local" as well (the first file that sets a variable wins).
for (const file of [".env.local", ".env"]) {
  const p = path.resolve(__dirname, file);
  if (fs.existsSync(p)) dotenv.config({ path: p });
}

const { MNEMONIC, PRIVATE_KEY } = process.env;

// One deployer wallet for every network: a mnemonic OR a private key (use a throwaway wallet).
function walletOptions(providerOrUrl) {
  const opts = { providerOrUrl };
  if (MNEMONIC && MNEMONIC.trim()) {
    opts.mnemonic = { phrase: MNEMONIC.trim() };
  } else if (PRIVATE_KEY && PRIVATE_KEY.trim()) {
    opts.privateKeys = [PRIVATE_KEY.trim().replace(/^0x/, "")];
  } else {
    throw new Error('No deployer wallet found. Put MNEMONIC="twelve words ..." or PRIVATE_KEY=<64 hex chars> in .env.local (throwaway wallet only).');
  }
  return opts;
}

const networks = {};

// `truffle test` uses a "development" network when one is configured. Leaving it out while testing makes
// Truffle spin up its own throwaway chain, so `npm run contracts:test` needs no Ganache running.
if (!process.argv.includes("test")) {
  networks.development = { host: "127.0.0.1", port: 7545, network_id: "*" };
}

for (const chain of chains) {
  if (chain.kind === "Local") continue;
  const realMoney = !chain.testnet;
  networks[chain.key] = {
    // `provider` is a function: nothing is created, and no key is needed, until you run `--network <key>`.
    provider: () => {
      if (realMoney && process.env.ALLOW_MAINNET_DEPLOY !== "yes") {
        throw new Error(
          `"${chain.key}" (${chain.name}) is a REAL-MONEY network. Re-run with ALLOW_MAINNET_DEPLOY=yes if you really mean it:\n` +
            `  ALLOW_MAINNET_DEPLOY=yes npx truffle migrate --network ${chain.key}`
        );
      }
      return new HDWalletProvider(walletOptions(rpcUrl(chain)));
    },
    network_id: chain.chainId,
    // No fixed gas / gasPrice: Truffle estimates both, which is right on every chain here.
    confirmations: 2,
    timeoutBlocks: 200,
    skipDryRun: true,
  };
}

module.exports = {
  networks,
  compilers: {
    solc: {
      version: "0.8.20",
      settings: {
        // "paris" avoids the PUSH0 opcode that solc 0.8.20 emits by default, so the same bytecode
        // deploys on every chain in shared/chains.json, including any L2 that lacks PUSH0.
        evmVersion: "paris",
        optimizer: { enabled: true, runs: 200 },
      },
    },
  },
  contracts_directory: "./contracts",
  contracts_build_directory: "./build/contracts",
  migrations_directory: "./migrations",
  test_directory: "./test",
  db: { enabled: false },
};
