// What should this person do next? A pure function, so it is unit-tested (test/accounts/journey.test.js) and the dashboard
// only has to draw the answer. The order is the order of the real journey:
//   verify email -> finish set-up -> confirmed ID -> wallet connected on a deployed network -> (optional) link wallet.
// Nothing here is a permission: the server and the capability gates decide that. This only guides.
//
// input:  me      the object from GET /api/me
//         wallet  { connected: boolean, deployed: boolean, networkName: string }
//         linked  true / false, or null when it could not be read
// output: { steps: [{ id, title, detail, status, href?, action?, cta, optional? }], next }
//         status: "done" | "current" | "waiting" | "todo"
//         next:   the first step that is not done (optional steps only count once the rest are done), or null
function buildJourney({ me, wallet, linked }) {
  const steps = [];

  if (me.email) {
    steps.push({
      id: "email",
      title: "Verify your email address",
      detail: me.emailVerified ? "Verified." : `We sent a link to ${me.email}. Vehicles and licences stay locked until you use it.`,
      status: me.emailVerified ? "done" : "todo",
      href: "/account",
      cta: "Open my account",
    });
  }

  const setupDone = !!me.onboarding.complete;
  steps.push({
    id: "setup",
    title: "Finish setting up your account",
    detail: setupDone ? "Agreements, details, phone and address are saved." : "Agreements, your details, a phone code and your address.",
    status: setupDone ? "done" : "todo",
    href: "/onboarding",
    cta: setupDone ? "Edit details" : "Continue set-up",
  });

  const level = me.identity.level;
  steps.push({
    id: "id",
    title: "Get your ID confirmed",
    detail:
      level >= 2 ? "Your ID is confirmed." :
      level === 1 ? "Your ID is added and waiting for a reviewer. You will be unlocked as soon as it is confirmed." :
      "Add your Ghana Card, passport or another ID. This unlocks registering vehicles and issuing licences.",
    status: level >= 2 ? "done" : level === 1 ? "waiting" : "todo",
    href: "/account#id",
    cta: level === 1 ? "View status" : "Add my ID",
  });

  const walletOk = !!(wallet && wallet.connected && wallet.deployed);
  steps.push({
    id: "wallet",
    title: "Connect your wallet",
    detail: walletOk
      ? `Connected on ${wallet.networkName}.`
      : wallet && wallet.connected && !wallet.deployed
      ? `${wallet.networkName} has no ClassTryout contracts yet. Switch to a network marked as deployed, such as Sepolia.`
      : "Use MetaMask on a test network such as Sepolia. Blockchain actions are signed by your wallet.",
    status: walletOk ? "done" : "todo",
    action: "connect",
    cta: wallet && wallet.connected ? "Choose a network" : "Connect wallet",
  });

  steps.push({
    id: "link",
    title: "Link your wallet for email notices",
    detail: linked === true ? "Linked. You will be emailed about your vehicles and licences." : "Optional. Sign one free message so we know where to send registration and licence notices.",
    status: linked === true ? "done" : "todo",
    href: "/notifications",
    cta: "Link my wallet",
    optional: true,
  });

  const required = steps.filter((s) => !s.optional);
  const firstOpen = required.find((s) => s.status !== "done") || steps.find((s) => s.status !== "done") || null;
  if (firstOpen) firstOpen.status = firstOpen.status === "waiting" ? "waiting" : "current";
  return { steps, next: firstOpen };
}

module.exports = { buildJourney };
