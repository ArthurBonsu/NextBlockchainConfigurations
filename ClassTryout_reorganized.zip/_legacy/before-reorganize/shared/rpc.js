// One place that decides which RPC endpoint to use for a chain. Used by truffle-config.js (deploying) and
// notifier/ (the email watcher), so the two can never talk to different endpoints by accident.
//
// Order: RPC_URL_<KEY> override -> ETHEREUM_PROVIDER_URL (mainnet only) -> Infura (INFURA_PROJECT_ID) -> public RPC.
function rpcUrl(chain, env = process.env) {
  const override = env["RPC_URL_" + chain.key.toUpperCase()];
  if (override) return override;
  if (chain.key === "mainnet" && env.ETHEREUM_PROVIDER_URL) return env.ETHEREUM_PROVIDER_URL;
  if (env.INFURA_PROJECT_ID && chain.infura) return `https://${chain.infura}.infura.io/v3/${env.INFURA_PROJECT_ID}`;
  return chain.rpcUrls[0];
}

module.exports = { rpcUrl };
