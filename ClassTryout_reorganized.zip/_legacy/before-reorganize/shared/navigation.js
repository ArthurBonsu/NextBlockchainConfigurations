// Which navigation items does this person see? A pure function (unit-tested in test/accounts/journey.test.js).
// This is a convenience, never a permission: the server checks every action again, and the contracts are open.
const policy = require("./roles.json");

function visibleItems(items, me, { requireAccount = false } = {}) {
  return items.filter((i) => {
    if (i.public) return true;
    if (!me) {
      // Signed out. When accounts are required only public pages show; otherwise (demo mode) the chain pages show too,
      // but never anything that needs an account or an administrator.
      if (requireAccount) return false;
      return !i.needsAccount && !i.roles && !String(i.capability || "").startsWith("admin:");
    }
    if (me.status === "suspended") return false;
    if (i.roles) return i.roles.includes(me.role);
    if (i.capability) {
      const c = policy.capabilities[i.capability];
      return !!c && c.roles.includes(me.role);
    }
    return true;
  });
}

module.exports = { visibleItems };
