# ClassTryout: project tree

Vehicle and licence registry on Ethereum (Sepolia first), with Firebase accounts, onboarding and ID confirmation.

| | |
|---|---|
| **Front end** | Next.js 14, strict TypeScript, web3.js v4 |
| **Contracts** | Solidity 0.8.x, OpenZeppelin 5.0.2 (Ownable, Pausable), deployed from Remix or Truffle |
| **Accounts** | Firebase Authentication only (email/password, GitHub, X) and Firestore |
| **Roles** | citizen, officer, admin, super_admin |
| **Last updated** | 2026-10-14 |

This file replaces `docs/PROJECT_TREE.md` and every per-folder listing. It was built from the real folder
listings of your machine, so files you have already removed are not shown.

**Status tags used below**

| Tag | Meaning |
|---|---|
| OK | Part of the project, in the right place |
| GENERATED | Written by a command. Never edit by hand |
| LOCAL | Yours only. Git-ignored or private |
| STRAY | In your folder but not part of the project. See [Still to clean up](#still-to-clean-up) |

---

## 1. At a glance

| Folder | What it holds |
|---|---|
| `contracts/` | The three Solidity contracts and their two interfaces |
| `migrations/` | Truffle deployment scripts (the Remix route does not use these) |
| `shared/` | One place that contracts, scripts, watcher and front end all read from |
| `utils/` | Browser-side helpers, including the contract loader (`contracts.ts`) |
| `components/` | React panels and the account components |
| `pages/` | Next.js pages and every `/api` route |
| `server/` | Server-only code: data layer, roles, SMS codes, ID checks |
| `notifier/` | The email watcher (plain Node, runs on its own) |
| `firebase/` | Firestore rules, indexes and the console steps |
| `scripts/` | Command-line tools: roles, ID review, checks, cleanup |
| `test/` and `e2e/` | Unit tests and optional browser tests |
| `styles/` | CSS modules |
| `docs/` | Documentation, including this file |

---

## 2. The tree

Names only. Every file is explained in section 3.

```
classtryout/
├── contracts/
│   ├── VehicleRegistry.sol
│   ├── RevocationManager.sol
│   ├── LicenseRegistry.sol
│   ├── IVehicleRegistry.sol
│   ├── IRevocationManager.sol
│   ├── 2_Owner.sol                     STRAY
│   ├── 3_Ballot.sol                    STRAY
│   └── Storage.sol                     STRAY
├── migrations/
│   ├── 2_deploy_vehicle_registry.js
│   ├── 3_deploy_revocation_manager.js
│   ├── 4_deploy_license_registry.js
│   ├── 2_deploy_vehicle_registration.js    STRAY
│   └── 3_deploy_vehicle_manager.js         STRAY
├── shared/
│   ├── chains.json
│   ├── contracts.json
│   ├── deployments.json
│   ├── deployments.local.json          LOCAL
│   ├── notifications.json
│   ├── rpc.js
│   ├── roles.json
│   ├── id-types.json
│   ├── onboarding.json
│   ├── abi/                            GENERATED
│   │   ├── VehicleRegistry.json  .ts
│   │   ├── RevocationManager.json  .ts
│   │   └── LicenseRegistry.json  .ts
│   └── locations/
│       ├── regions.json
│       └── districts.json
├── utils/
│   ├── contracts.ts
│   ├── networks.ts
│   ├── receipts.ts
│   ├── errors.ts
│   ├── auth.ts
│   ├── firebaseClient.ts
│   ├── api.ts
│   ├── accountTypes.ts
│   └── walletLink.ts
├── components/
│   ├── WalletBar.tsx
│   ├── VehicleRegistryPanel.tsx
│   ├── LicensePanel.tsx
│   ├── RevocationPanel.tsx
│   ├── VehicleHistory.tsx
│   ├── ReceiptCard.tsx
│   ├── TxLink.tsx
│   ├── AdminPanel.tsx
│   ├── NotifyPanel.tsx
│   ├── VehicleDemo.module.css.additions    STRAY
│   └── auth/
│       ├── AuthProvider.tsx
│       ├── AccountBar.tsx
│       ├── CapabilityGate.tsx
│       ├── IdStep.tsx
│       └── ui.tsx
├── pages/
│   ├── index.tsx
│   ├── _app.tsx
│   ├── signin.tsx
│   ├── onboarding.tsx
│   ├── account.tsx
│   ├── vehicle-demo.tsx
│   └── api/
│       ├── me/                 index.ts, notifications.ts
│       ├── onboarding/         consent.ts, profile.ts, address.ts, phone/start.ts, phone/confirm.ts
│       ├── identity/           index.ts
│       ├── locations/          suburbs.ts
│       ├── capability/         [name].ts
│       ├── wallet-link/        challenge.ts, confirm.ts, index.ts
│       └── admin/
│           ├── users/          index.ts, [uid]/role.ts, [uid]/status.ts
│           └── identity/       index.ts, [id]/review.ts, [id]/reveal.ts
├── server/
│   ├── env.js  config.js  crypto.js
│   ├── firebaseAdmin.js  auth.js  session.js  httpError.js
│   ├── store.js  users.js  roles.js
│   ├── locations.js  phone.js  otp.js
│   ├── rateLimit.js  audit.js
│   ├── links.js  challenge.js  apiHelpers.js
│   ├── identity/               index.js, checkers.js, worker.js
│   └── sms/                    index.js, mock.js, consoleProvider.js, http.js, arkesel.js, hubtel.js
├── notifier/
│   ├── index.js  watcher.js  resolve.js
│   ├── templates.js  mailer.js
│   ├── deployments.js  state.js
│   └── data/                   LOCAL
├── firebase/
│   ├── firestore.rules
│   ├── firestore.indexes.json
│   └── README.md
├── scripts/
│   ├── sync-contracts.js  record-deployment.js
│   ├── check-consistency.js  gen-real-structure.js
│   ├── cleanup-legacy.sh
│   └── set-role.js  review-id.js  id-maintenance.js
├── test/
│   ├── registry.test.js
│   ├── accounts/               accounts.test.js, helpers.js
│   ├── e2e.js                  STRAY?
│   └── final-page.png          STRAY?
├── e2e/
│   ├── README.md
│   ├── flow.e2e.js  multichain.e2e.js
│   ├── notify.e2e.js  notify-ui.e2e.js
│   └── accounts.e2e.js
├── styles/
│   ├── VehicleDemo.module.css
│   └── Account.module.css
├── docs/
│   ├── project-tree.md         (this file)
│   ├── ACCOUNTS.md
│   ├── database.md
│   ├── firebaserealstructure.txt   GENERATED
│   └── PROJECT_TREE.md         STRAY (replaced by this file)
├── contractresults/            YOURS: Remix and Etherscan receipts
├── _legacy/                    parked, not part of the build
├── build/contracts/            GENERATED, STRAY now (old Passchain artifacts)
├── .env.local                  LOCAL, secrets
├── .env.local.example
├── package.json  tsconfig.json  next-env.d.ts
├── truffle-config.js  truffle-config.sandbox.js
├── firebase.json
├── gitignore.additions.txt
├── README.md
└── final.png
```

---

## 3. Folder by folder

### contracts/

| File | What it does | Status |
|---|---|---|
| `VehicleRegistry.sol` | Vehicles by pseudonym. Ownable and Pausable. `removeVehicle`. Wired once to RevocationManager | OK |
| `RevocationManager.sol` | Reports, `processRevocation`, `reinstateVehicle`. Ownable and Pausable | OK |
| `LicenseRegistry.sol` | `issueLicense`, `revokeLicense`, `reinstateLicense`. Ownable and Pausable | OK |
| `IVehicleRegistry.sol` | Interface used by the other two. Never deployed | OK |
| `IRevocationManager.sol` | Interface used by the other two. Never deployed | OK |
| `2_Owner.sol`, `3_Ballot.sol`, `Storage.sol` | Remix starter examples. Move to `docs/remix-templates/` | STRAY |

OpenZeppelin is imported by package path from `node_modules`. No copy lives in this folder.

### migrations/

| File | What it does | Status |
|---|---|---|
| `2_deploy_vehicle_registry.js` | Deploys VehicleRegistry and records address and block | OK |
| `3_deploy_revocation_manager.js` | Deploys RevocationManager, wires the registry once, records address and block | OK |
| `4_deploy_license_registry.js` | Deploys LicenseRegistry with both addresses, records address and block | OK |
| `2_deploy_vehicle_registration.js` | Old duplicate "2_". Truffle would run it too | STRAY |
| `3_deploy_vehicle_manager.js` | Old duplicate "3_". Truffle would run it too | STRAY |

### shared/

| File | What it does | Status |
|---|---|---|
| `chains.json` | Every network: chain id, key, RPC, explorer, currency, Infura name, testnet flag | OK |
| `contracts.json` | Names of the three contracts the app uses (no addresses) | OK |
| `deployments.json` | Public-chain addresses, deploy block and tx hash. **Commit it.** Holds Sepolia (11155111) | OK |
| `deployments.local.json` | Ganache and private-chain addresses, regenerated by `yarn deploy:local` | LOCAL |
| `abi/*.json` and `abi/*.ts` | ABI as JSON and as a typed `as const` export, from `yarn contracts:compile` | GENERATED |
| `notifications.json` | Which contract event sends which email | OK |
| `rpc.js` | Which RPC URL to use per chain. Deploys and the watcher share it | OK |
| `roles.json` | The four roles, their capabilities, and the ID level each needs | OK |
| `id-types.json` | Accepted ID types, shape patterns, which checker, retention days | OK |
| `onboarding.json` | Steps, consent texts and versions, SMS code rules | OK |
| `locations/regions.json` | 16 regions | OK |
| `locations/districts.json` | 261 districts (MMDAs) with their towns | OK |

### utils/ (browser side)

| File | What it does |
|---|---|
| `contracts.ts` | **The contract loader.** Typed ABIs plus `shared/deployments.json` become contract objects. Also `connectWallet()`, `getContracts()`, `sendTx()`, `getContractStatuses()` |
| `networks.ts` | Network list from `shared/chains.json` |
| `receipts.ts` | Reads event history from the deploy block, in pages |
| `errors.ts` | Readable wording, including OpenZeppelin custom errors |
| `auth.ts` | The one place the app asks who is signed in (a Firebase ID token) |
| `firebaseClient.ts` | Firebase sign-in on the browser |
| `api.ts` | `fetch` with the token and typed errors |
| `accountTypes.ts` | The shape of `GET /api/me` |
| `walletLink.ts` | Browser side of the wallet-link API |

### components/

| File | What it does | Status |
|---|---|---|
| `WalletBar.tsx` | Network picker, "not deployed" banner, Admin badge | OK |
| `VehicleRegistryPanel.tsx` | Register, look up and remove vehicles | OK |
| `LicensePanel.tsx` | Issue a licence. Admin revoke and reinstate. Find by vehicle | OK |
| `RevocationPanel.tsx` | Report, process revocation, reinstate vehicle | OK |
| `VehicleHistory.tsx` | Event history from the deploy block, with explorer links | OK |
| `ReceiptCard.tsx` | Transaction receipt with explorer link | OK |
| `TxLink.tsx` | Tx hash to block explorer link | OK |
| `AdminPanel.tsx` | Owner and paused status, Pause and Resume | OK |
| `NotifyPanel.tsx` | Link or unlink this wallet for email notifications | OK |
| `VehicleDemo.module.css.additions` | CSS lines to merge into `styles/VehicleDemo.module.css`, then delete | STRAY |
| `auth/AuthProvider.tsx` | Who is signed in (Firebase) and the server's view of them | OK |
| `auth/AccountBar.tsx` | Top bar: name, role, account, sign out | OK |
| `auth/CapabilityGate.tsx` | Hides or locks a panel unless the account may use it | OK |
| `auth/IdStep.tsx` | Add, list and remove IDs | OK |
| `auth/ui.tsx` | `Field`, `Notice`, `safeNext` | OK |

### pages/

| Page | What it does |
|---|---|
| `index.tsx` | Redirects to `/vehicle-demo` |
| `_app.tsx` | Wraps every page in `AuthProvider` |
| `signin.tsx` | Sign in, create account, reset password, GitHub, X |
| `onboarding.tsx` | Agreements, about you, phone code, address, ID |
| `account.tsx` | Profile, role, capabilities, IDs, notification preferences |
| `vehicle-demo.tsx` | The main app: wallet, register, issue, revoke, gated by capability |

### pages/api/

| Route | What it does |
|---|---|
| `me/index.ts` | GET profile and onboarding state |
| `me/notifications.ts` | Notification preferences |
| `onboarding/consent.ts` | Record agreements (versioned) |
| `onboarding/profile.ts` | Name, date of birth, gender, nationality |
| `onboarding/address.ts` | Region, district, city, suburb |
| `onboarding/phone/start.ts` | Send a 6-digit code |
| `onboarding/phone/confirm.ts` | Check the code |
| `identity/index.ts` | Add, list and withdraw an ID |
| `locations/suburbs.ts` | Suburb suggestions per district |
| `capability/[name].ts` | 200 or 403 check before an action that matters |
| `wallet-link/challenge.ts` | Signed-message challenge |
| `wallet-link/confirm.ts` | Confirm the signature and link wallet to account |
| `wallet-link/index.ts` | List and unlink |
| `admin/users/index.ts` | List users (one filter group at a time) |
| `admin/users/[uid]/role.ts` | Change role. Never the last active super admin |
| `admin/users/[uid]/status.ts` | Suspend or reinstate |
| `admin/identity/index.ts` | ID review queue |
| `admin/identity/[id]/review.ts` | Verify or reject an ID |
| `admin/identity/[id]/reveal.ts` | Reveal a pending number (audit-logged, rate-limited) |

### server/ (never sent to the browser)

| File | What it does |
|---|---|
| `env.js` | `.env` loading and project root |
| `config.js` | Secrets and settings |
| `crypto.js` | HMAC, AES-GCM, random codes |
| `firebaseAdmin.js` | Admin SDK (v14 modular API), emulator aware |
| `auth.js` | ID-token check, including revocation |
| `session.js` | `withSession()`: token, profile, role and level gate, JSON errors |
| `httpError.js` | Typed errors |
| `store.js` | Data layer: Firestore, or a file store for tests that enforces the index rule |
| `users.js` | Profile, consents, address, onboarding, role and status changes, admin lists |
| `roles.js` | "Can this account do this?" (reads `shared/roles.json`) |
| `locations.js` | Region, district and suburb validation |
| `phone.js` | Ghana mobile numbers to `+233` |
| `otp.js` | SMS codes: limits, attempts, expiry, one number per account |
| `rateLimit.js` | Counters in Firestore |
| `audit.js` | Append-only audit log with secrets stripped |
| `links.js`, `challenge.js`, `apiHelpers.js` | Wallet-to-account links and their routes |
| `identity/index.js` | Submit, withdraw, review, reveal, purge |
| `identity/checkers.js` | Manual review. NIA is a placeholder, onboarding never depends on it |
| `identity/worker.js` | Automated checks with retry, then hands over to a human |
| `sms/index.js` | Provider-neutral entry point |
| `sms/mock.js`, `sms/consoleProvider.js` | Testing and development |
| `sms/http.js` | Generic HTTP provider |
| `sms/arkesel.js`, `sms/hubtel.js` | The two Ghana providers |

### notifier/ (run with `yarn notify`)

| File | What it does |
|---|---|
| `index.js` | Entry point: loop, `--once`, `--status` |
| `watcher.js` | Reads new events per chain. Idempotent, retries, waits for confirmations |
| `resolve.js` | Event to wallet to email, with readable names |
| `templates.js` | The emails (text and HTML) |
| `mailer.js` | SMTP via Nodemailer, or outbox and log for testing |
| `deployments.js` | Addresses and start block from `shared/deployments*.json` |
| `state.js` | Its memory (`notifier/data/state.json`) |
| `data/` | LOCAL: state, test outbox, dev accounts. Created on first run |

### firebase/, scripts/, test/, e2e/, styles/, docs/

| File | What it does | Status |
|---|---|---|
| `firebase/firestore.rules` | A browser may read only its own `users/{uid}`. Everything else is denied | OK |
| `firebase/firestore.indexes.json` | The 12 composite indexes the queries need | OK |
| `firebase/README.md` | Console steps, TTL, first admin, emulator, go-live checklist | OK |
| `scripts/sync-contracts.js` | Build output to `shared/abi` | OK |
| `scripts/record-deployment.js` | Used by the migrations to write `shared/deployments*.json` | OK |
| `scripts/check-consistency.js` | `yarn check`: fails if anything drifted apart | OK |
| `scripts/gen-real-structure.js` | Writes `docs/firebaserealstructure.txt` from the real code | OK |
| `scripts/cleanup-legacy.sh` | Moves old files to `_legacy/`. Dry run by default. Needs bash | OK |
| `scripts/set-role.js` | First super admin, change roles, `--confirm-identity`, `--list` | OK |
| `scripts/review-id.js` | Command-line ID review (list, show, verify, reject), audit-logged | OK |
| `scripts/id-maintenance.js` | Due automated ID checks and deletion of undecided ID numbers. Run hourly | OK |
| `test/registry.test.js` | 21 contract tests (`yarn contracts:test`, no chain needed) | OK |
| `test/accounts/accounts.test.js`, `helpers.js` | 27 account tests (`yarn test:accounts`) | OK |
| `test/e2e.js` | Old script. Truffle would try to run it | STRAY? |
| `test/final-page.png` | A screenshot, not a test | STRAY? |
| `e2e/flow.e2e.js`, `multichain.e2e.js` | Register, issue, revoke. Several networks | OK |
| `e2e/notify.e2e.js`, `notify-ui.e2e.js` | Watcher and API. The notification panel | OK |
| `e2e/accounts.e2e.js` | Sign-up to confirmed ID in a real browser, against the Auth emulator | OK |
| `styles/VehicleDemo.module.css`, `Account.module.css` | The two stylesheets | OK |
| `docs/ACCOUNTS.md` | Schema, roles, flows, API, indexes, commands, limits | OK |
| `docs/database.md` | The ClassTryout schema in tree style | OK |
| `docs/firebaserealstructure.txt` | Example documents for every collection | GENERATED |
| `docs/PROJECT_TREE.md` | Replaced by this file | STRAY |

### Other folders and root files

| Item | What it is | Status |
|---|---|---|
| `contractresults/` | Your Remix and Etherscan receipts from the Sepolia deployment | OK |
| `_legacy/` | Parked Passchain files and old migrations: `config/`, `context/`, `data/`, `services/`, `logger.ts`, `1_initial_migration.js`, `16_initial_migration.js` | OK |
| `build/contracts/` | Truffle output. Currently about 80 old Passchain artifacts | GENERATED, STRAY |
| `.env.local` | Secrets: deployer key, Firebase keys, app secrets. Never commit or share | LOCAL |
| `.env.local.example` | Template of every setting | OK |
| `package.json`, `tsconfig.json`, `next-env.d.ts` | Project configuration | OK |
| `truffle-config.js` | Networks from `shared/chains.json`, reads `.env.local` | OK |
| `truffle-config.sandbox.js` | Test-only variant from the build environment. Safe to delete | STRAY |
| `firebase.json` | Rules, indexes and emulator ports | OK |
| `gitignore.additions.txt` | Lines to copy into `.gitignore`, then delete the file | STRAY |
| `README.md`, `final.png` | Readme. A screenshot you can move to `docs/` | OK |

The root files were not in your listings, so they are shown as the pack ships them. Confirm with `dir` at the
project root.

---

## 4. Deployed contracts

Network: **Sepolia**, chain id `11155111`.

| Contract | Address | Block |
|---|---|---|
| VehicleRegistry | `0x0948161F56ce6Dc0450d1D3b901CdAcf5520d37D` | 11912889 |
| RevocationManager | `0x898226D7853EFa2dDB494eC990bEa1dD3B56d04a` | 11913096 |
| LicenseRegistry | `0xe7D5e4E17186cA637925B4aD280940893Fa9ddA6` | 11913169 |

| | |
|---|---|
| **Owner / admin wallet** | `0x7927E739C9B0b304610D4Ae35cBf5FDD0D5ad36A` |
| **Compiled with** | Remix, solc 0.8.37, default EVM version. The ABI is identical to the Truffle build |
| **Wiring** | `VehicleRegistry.setRevocationManager(<RevocationManager>)` must be called once. Check the `revocationManager()` getter |

---

## 5. Who reads what

| Thing | Single source | Read by |
|---|---|---|
| Contract behaviour | `contracts/*.sol` | Remix, `truffle compile`, tests |
| ABI | `shared/abi/` | `utils/contracts.ts`, `utils/receipts.ts`, `yarn check` |
| Networks | `shared/chains.json` | `truffle-config.js`, `utils/networks.ts`, `record-deployment.js` |
| Addresses and deploy block | `shared/deployments*.json` | `utils/contracts.ts` (so every component), `notifier/` |
| Admin and pause state | The contracts (`owner()`, `paused()`) | `AdminPanel`, `WalletBar` |
| Which event sends which email | `shared/notifications.json` | `notifier/`, `yarn check` |
| Who gets the email | Wallet link (`server/links.js`) to the Firebase verified email | `notifier/watcher.js` |
| RPC endpoint per chain | `shared/rpc.js` | `truffle-config.js`, `notifier/` |
| Roles and capabilities | `shared/roles.json` | `server/roles.js` (enforces), `CapabilityGate` (display) |
| Regions and districts | `shared/locations/*.json` | `server/locations.js`, onboarding form |
| ID types | `shared/id-types.json` | `server/identity/`, `IdStep` |
| Onboarding, consents, SMS rules | `shared/onboarding.json` | `server/users.js`, `server/otp.js`, onboarding page |
| Queries that need an index | The code's queries | `firebase/firestore.indexes.json` |

---

## Still to clean up

Run from the project root in PowerShell. Nothing is deleted: files move to `_legacy` or `docs`.

- [ ] Move the Remix starters out of `contracts/`
- [ ] Move the two old duplicate migrations to `_legacy/`
- [ ] Move `build/contracts` aside, then regenerate it
- [ ] Merge `components/VehicleDemo.module.css.additions` into the stylesheet, then delete it
- [ ] Decide about `test/e2e.js` and the two screenshots
- [ ] Delete `docs/PROJECT_TREE.md` (this file replaces it)

```powershell
mkdir docs\remix-templates -Force | Out-Null
move contracts\2_Owner.sol docs\remix-templates\
move contracts\3_Ballot.sol docs\remix-templates\
move contracts\Storage.sol docs\remix-templates\
move migrations\2_deploy_vehicle_registration.js _legacy\
move migrations\3_deploy_vehicle_manager.js _legacy\
move build\contracts _legacy\build-contracts-old
move docs\PROJECT_TREE.md _legacy\
```

Then regenerate the build and check everything:

```powershell
yarn contracts:compile
yarn check
```
