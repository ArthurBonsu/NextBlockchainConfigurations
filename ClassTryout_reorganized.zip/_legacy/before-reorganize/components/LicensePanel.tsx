import { friendlyError } from "../utils/errors";
import { useState } from "react";
import { getContracts, sendTx } from "../utils/contracts";
import { buildReceipt, Receipt } from "../utils/receipts";
import ReceiptCard from "./ReceiptCard";
import styles from "../styles/VehicleDemo.module.css";

type Status<T extends string> = { type: T; message: string };

interface LicenseInfo {
  vehiclePseudonym: string;
  owner: string;
  licenseType: string;
  issueTime: string;
  expiryTime: string;
  isActive: boolean;
  issued: boolean;
  isValid: boolean;
}

export default function LicensePanel() {
  const [licenseId, setLicenseId] = useState("");
  const [vehiclePseudonym, setVehiclePseudonym] = useState("");
  const [licenseType, setLicenseType] = useState("Standard");
  const [validityDays, setValidityDays] = useState("365");
  const [issueStatus, setIssueStatus] = useState<Status<"idle" | "pending" | "success" | "error">>({
    type: "idle",
    message: "",
  });
  const [receipt, setReceipt] = useState<Receipt | null>(null);

  const [lookupId, setLookupId] = useState("");
  const [lookupStatus, setLookupStatus] = useState<Status<"idle" | "pending" | "error">>({
    type: "idle",
    message: "",
  });
  const [licenseInfo, setLicenseInfo] = useState<LicenseInfo | null>(null);
  const [foundId, setFoundId] = useState("");

  const [byVehicle, setByVehicle] = useState("");
  const [byVehicleStatus, setByVehicleStatus] = useState<Status<"idle" | "pending" | "error">>({
    type: "idle",
    message: "",
  });

  const [adminLicenseId, setAdminLicenseId] = useState("");
  const [adminStatus, setAdminStatus] = useState<Status<"idle" | "pending" | "success" | "error">>({
    type: "idle",
    message: "",
  });

  async function handleIssue() {
    if (!licenseId.trim() || !vehiclePseudonym.trim() || !licenseType.trim()) return;
    setIssueStatus({ type: "pending", message: "Confirm the transaction in your wallet..." });
    setReceipt(null);
    try {
      const { license, account } = await getContracts();
      const id = licenseId.trim();

      const txReceipt = await sendTx(
        license.methods.issueLicense(id, vehiclePseudonym.trim(), licenseType.trim(), Number(validityDays) || 365),
        account
      );

      const eventValues = (txReceipt.events as any)?.LicenseIssued?.returnValues;
      if (eventValues) {
        setReceipt(
          buildReceipt(
            "License Issued",
            id,
            {
              vehicle: eventValues.vehiclePseudonym,
              owner: eventValues.owner,
              type: eventValues.licenseType,
              expires: new Date(Number(eventValues.expiryTime) * 1000).toLocaleString(),
            },
            txReceipt.transactionHash,
            txReceipt.blockNumber,
            eventValues.issueTime
          )
        );
      }

      setIssueStatus({ type: "success", message: `License "${id}" issued.` });
      setLicenseId("");
      setVehiclePseudonym("");
    } catch (err: any) {
      setIssueStatus({ type: "error", message: friendlyError(err) });
    }
  }

  async function handleLookup(idOverride?: string) {
    const rawId = typeof idOverride === "string" ? idOverride : lookupId;
    if (!rawId.trim()) return;
    setLookupStatus({ type: "pending", message: "Reading from chain..." });
    setLicenseInfo(null);
    try {
      const { license } = await getContracts();
      const id = rawId.trim();
      const lic: any = await license.methods.getLicense(id).call();
      setFoundId(id);

      if (!lic.issued) {
        setLookupStatus({ type: "idle", message: "" });
        setLicenseInfo({
          vehiclePseudonym: "",
          owner: "",
          licenseType: "",
          issueTime: "",
          expiryTime: "",
          isActive: false,
          issued: false,
          isValid: false,
        });
        return;
      }

      const isValid: boolean = await license.methods.isLicenseValid(id).call();

      setLicenseInfo({
        vehiclePseudonym: lic.vehiclePseudonym,
        owner: lic.owner,
        licenseType: lic.licenseType,
        issueTime: new Date(Number(lic.issueTime) * 1000).toLocaleString(),
        expiryTime: new Date(Number(lic.expiryTime) * 1000).toLocaleString(),
        isActive: lic.isActive,
        issued: lic.issued,
        isValid,
      });
      setLookupStatus({ type: "idle", message: "" });
    } catch (err: any) {
      setLookupStatus({ type: "error", message: friendlyError(err) });
    }
  }

  // Find the license currently attached to a vehicle, then show it.
  async function handleFindByVehicle() {
    if (!byVehicle.trim()) return;
    setByVehicleStatus({ type: "pending", message: "Reading from chain..." });
    try {
      const { license } = await getContracts();
      const id: string = await license.methods.getLicenseByVehicle(byVehicle.trim()).call();
      if (!id) {
        setLicenseInfo({ vehiclePseudonym: "", owner: "", licenseType: "", issueTime: "", expiryTime: "", isActive: false, issued: false, isValid: false });
        setByVehicleStatus({ type: "idle", message: "" });
        return;
      }
      setLookupId(id);
      setByVehicleStatus({ type: "idle", message: "" });
      await handleLookup(id);
    } catch (err: any) {
      setByVehicleStatus({ type: "error", message: friendlyError(err) });
    }
  }

  async function handleAdminLicense(action: "revokeLicense" | "reinstateLicense") {
    if (!adminLicenseId.trim()) return;
    const id = adminLicenseId.trim();
    setAdminStatus({ type: "pending", message: "Confirm the transaction in your wallet... (admin only)" });
    try {
      const { license, account } = await getContracts();
      await sendTx(license.methods[action](id), account);
      setAdminStatus({
        type: "success",
        message: action === "revokeLicense" ? `License "${id}" revoked.` : `License "${id}" reinstated.`,
      });
      if (lookupId.trim() === id) await handleLookup(id);
    } catch (err: any) {
      setAdminStatus({ type: "error", message: friendlyError(err) });
    }
  }

  return (
    <div className={styles.card}>
      <h2>License</h2>

      <div className={styles.section}>
        <label className={styles.label}>Issue a license</label>
        <div className={styles.stackedInputs}>
          <input
            className={styles.input}
            placeholder="License ID, e.g. lic-001"
            value={licenseId}
            onChange={(e) => setLicenseId(e.target.value)}
          />
          <input
            className={styles.input}
            placeholder="Vehicle pseudonym (must already be registered)"
            value={vehiclePseudonym}
            onChange={(e) => setVehiclePseudonym(e.target.value)}
          />
          <div className={styles.inputRow}>
            <input
              className={styles.input}
              placeholder="License type, e.g. Standard"
              value={licenseType}
              onChange={(e) => setLicenseType(e.target.value)}
            />
            <input
              className={styles.input}
              style={{ maxWidth: 110 }}
              type="number"
              placeholder="Days valid"
              value={validityDays}
              onChange={(e) => setValidityDays(e.target.value)}
            />
          </div>
          <button className={styles.button} onClick={handleIssue} disabled={issueStatus.type === "pending"}>
            Issue License
          </button>
        </div>
        {issueStatus.message && (
          <div
            className={
              issueStatus.type === "error"
                ? styles.errorText
                : issueStatus.type === "success"
                ? styles.successText
                : styles.subtle
            }
          >
            {issueStatus.message}
          </div>
        )}
        {receipt && <ReceiptCard receipt={receipt} />}
      </div>

      <div className={styles.section}>
        <label className={styles.label}>Look up a license</label>
        <div className={styles.inputRow}>
          <input
            className={styles.input}
            placeholder="License ID"
            value={lookupId}
            onChange={(e) => setLookupId(e.target.value)}
          />
          <button className={styles.buttonSecondary} onClick={() => handleLookup()}>
            Look Up
          </button>
        </div>
        <div className={styles.inputRow} style={{ marginTop: 8 }}>
          <input
            className={styles.input}
            placeholder="...or find by vehicle pseudonym"
            value={byVehicle}
            onChange={(e) => setByVehicle(e.target.value)}
          />
          <button className={styles.buttonSecondary} onClick={handleFindByVehicle}>
            Find
          </button>
        </div>
        {byVehicleStatus.message && (
          <div className={byVehicleStatus.type === "error" ? styles.errorText : styles.subtle}>{byVehicleStatus.message}</div>
        )}
        {lookupStatus.message && (
          <div className={lookupStatus.type === "error" ? styles.errorText : styles.subtle}>{lookupStatus.message}</div>
        )}
        {licenseInfo && (
          <div className={styles.resultBox}>
            {!licenseInfo.issued ? (
              <div className={styles.errorText}>No license with that ID.</div>
            ) : (
              <>
                <div>
                  <span className={styles.resultLabel}>License ID:</span> {foundId}
                </div>
                <div>
                  <span className={styles.resultLabel}>Vehicle:</span> {licenseInfo.vehiclePseudonym}
                </div>
                <div>
                  <span className={styles.resultLabel}>Type:</span> {licenseInfo.licenseType}
                </div>
                <div>
                  <span className={styles.resultLabel}>Issued:</span> {licenseInfo.issueTime}
                </div>
                <div>
                  <span className={styles.resultLabel}>Expires:</span> {licenseInfo.expiryTime}
                </div>
                <div>
                  <span className={styles.resultLabel}>Status:</span>{" "}
                  {licenseInfo.isValid ? (
                    <span className={styles.badgeActive}>Valid</span>
                  ) : (
                    <span className={styles.badgeRevoked}>
                      {!licenseInfo.isActive ? "Revoked" : "Expired or vehicle revoked"}
                    </span>
                  )}
                </div>
              </>
            )}
          </div>
        )}
      </div>
      <div className={styles.adminSection}>
        <div className={styles.adminLabel}>Admin actions</div>
        <div className={styles.subtle}>
          Only the admin wallet (the LicenseRegistry owner) can revoke or reinstate a license.
        </div>
        <div className={styles.section}>
          <label className={styles.label}>Revoke / reinstate a license</label>
          <input
            className={styles.input}
            style={{ width: "100%", boxSizing: "border-box", marginBottom: 8 }}
            placeholder="License ID to revoke or reinstate"
            value={adminLicenseId}
            onChange={(e) => setAdminLicenseId(e.target.value)}
          />
          <div className={styles.inputRow}>
            <button
              className={styles.buttonAdmin}
              onClick={() => handleAdminLicense("revokeLicense")}
              disabled={adminStatus.type === "pending"}
            >
              Revoke License
            </button>
            <button
              className={styles.buttonAdmin}
              onClick={() => handleAdminLicense("reinstateLicense")}
              disabled={adminStatus.type === "pending"}
            >
              Reinstate License
            </button>
          </div>
          {adminStatus.message && (
            <div
              className={
                adminStatus.type === "error"
                  ? styles.errorText
                  : adminStatus.type === "success"
                  ? styles.successText
                  : styles.subtle
              }
            >
              {adminStatus.message}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
