import { useCallback, useEffect, useState } from "react";
import { ContractStatus, getContracts, getContractStatuses, sendTx } from "../utils/contracts";
import { friendlyError } from "../utils/errors";
import styles from "../styles/VehicleDemo.module.css";

// Shows who controls each contract (OpenZeppelin Ownable) and whether it is paused (OpenZeppelin Pausable).
// The admin wallet can pause / resume each contract. Everyone else sees the status read-only.
export default function AdminPanel() {
  const [data, setData] = useState<{ account: string; isAdmin: boolean; statuses: ContractStatus[] } | null>(null);
  const [message, setMessage] = useState<{ type: "idle" | "pending" | "success" | "error"; text: string }>({ type: "idle", text: "" });

  const refresh = useCallback(async () => {
    try {
      const r = await getContractStatuses();
      setData({ account: r.account, isAdmin: r.isAdmin, statuses: r.statuses });
      setMessage((m) => (m.type === "error" ? { type: "idle", text: "" } : m));
    } catch (err: any) {
      setData(null);
      setMessage({ type: "error", text: friendlyError(err) });
    }
  }, []);

  useEffect(() => {
    refresh();
    const eth = typeof window !== "undefined" ? window.ethereum : undefined;
    eth?.on?.("accountsChanged", refresh);
    return () => eth?.removeListener?.("accountsChanged", refresh);
  }, [refresh]);

  async function toggle(s: ContractStatus) {
    const action = s.paused ? "unpause" : "pause";
    setMessage({ type: "pending", text: `Confirm in your wallet: ${action} ${s.name}...` });
    try {
      const { registry, revocation, license, account } = await getContracts();
      const contract = s.name === "VehicleRegistry" ? registry : s.name === "RevocationManager" ? revocation : license;
      await sendTx((contract as any).methods[action](), account);
      setMessage({ type: "success", text: `${s.name} ${s.paused ? "resumed" : "paused"}.` });
      await refresh();
    } catch (err: any) {
      setMessage({ type: "error", text: friendlyError(err) });
    }
  }

  const short = (a: string) => `${a.slice(0, 6)}...${a.slice(-4)}`;

  return (
    <div className={styles.card} style={{ gridColumn: "1 / -1" }}>
      <h2>
        Contract Control{" "}
        {data?.isAdmin && <span className={styles.badgeActive}>You are the admin</span>}
      </h2>
      <div className={styles.subtle}>
        Ownership and pausing come from OpenZeppelin&apos;s Ownable and Pausable. Pausing stops new registrations, reports and
        licenses; the admin can still process, revoke and reinstate.
      </div>

      {data && (
        <div className={styles.controlTable}>
          {data.statuses.map((s) => (
            <div key={s.name} className={styles.controlRow}>
              <div>
                <strong>{s.name}</strong>
                <div className={styles.subtle}>
                  {short(s.address)} · admin {short(s.owner)}
                </div>
              </div>
              <div className={styles.controlActions}>
                {s.paused ? <span className={styles.badgeRevoked}>Paused</span> : <span className={styles.badgeActive}>Running</span>}
                <button
                  className={styles.buttonAdmin}
                  disabled={!data.isAdmin || message.type === "pending"}
                  title={data.isAdmin ? "" : "Only the admin wallet can do this"}
                  onClick={() => toggle(s)}
                >
                  {s.paused ? "Resume" : "Pause"}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {message.text && (
        <div
          className={
            message.type === "error" ? styles.errorText : message.type === "success" ? styles.successText : styles.subtle
          }
        >
          {message.text}
        </div>
      )}
    </div>
  );
}
