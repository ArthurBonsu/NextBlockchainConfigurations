import { useEffect, useState } from "react";
import { explorerTxUrl } from "../utils/networks";

// Shows a transaction hash. On a chain with a block explorer (mainnet, L2s, testnets) the hash is a link to it;
// on a local chain it is plain text. The chain is read from the wallet, so this works wherever it is used.
export default function TxLink({ hash, className }: { hash: string; className?: string }) {
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    const eth = typeof window !== "undefined" ? window.ethereum : undefined;
    if (!eth) return;
    Promise.resolve(eth.request({ method: "eth_chainId" }))
      .then((id: string) => {
        if (!cancelled) setUrl(explorerTxUrl(parseInt(id, 16), hash));
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [hash]);

  return (
    <code className={className}>
      {url ? (
        <a href={url} target="_blank" rel="noopener noreferrer">
          {hash}
        </a>
      ) : (
        hash
      )}
    </code>
  );
}
