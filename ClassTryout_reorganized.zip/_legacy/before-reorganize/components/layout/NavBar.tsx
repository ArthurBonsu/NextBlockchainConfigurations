import Link from "next/link";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useAccount } from "../auth/AuthProvider";
import { REQUIRE_ACCOUNT } from "../auth/CapabilityGate";
import WalletBar from "../WalletBar";
import nav from "../../shared/nav.json";
import { visibleItems } from "../../shared/navigation";
import styles from "../../styles/Layout.module.css";

type Item = { href: string; label: string; group?: string };

// The top bar on every page. Which links show depends on the signed-in role (shared/nav.json decides; the server still
// enforces everything). "minimal" is the bar for sign-in and set-up: brand and account only, nothing to distract.
export default function NavBar({ variant = "app" }: { variant?: "app" | "minimal" }) {
  const router = useRouter();
  const { state, me, signOut } = useAccount();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [router.asPath]);

  const items = visibleItems(nav.items as any[], state === "ready" ? me : null, { requireAccount: REQUIRE_ACCOUNT }) as Item[];
  const main = items.filter((i) => !i.group);
  const admin = items.filter((i) => i.group === "admin");
  const isActive = (href: string) => router.pathname === href || router.pathname.startsWith(href + "/");
  const showNav = variant === "app";

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link href={me ? "/dashboard" : "/"} className={styles.brand}>
          <span className={styles.brandMark} aria-hidden="true">C</span>
          ClassTryout
        </Link>

        {showNav && (
          <button type="button" className={styles.burger} aria-expanded={open} aria-controls="main-nav" onClick={() => setOpen((o) => !o)}>
            {open ? "Close" : "Menu"}
          </button>
        )}

        {showNav && (
          <nav id="main-nav" aria-label="Main" className={`${styles.nav} ${open ? styles.navOpen : ""}`}>
            {main.map((i) => (
              <Link key={i.href} href={i.href} className={`${styles.link} ${isActive(i.href) ? styles.active : ""}`} aria-current={isActive(i.href) ? "page" : undefined}>
                {i.label}
              </Link>
            ))}
            {admin.length > 0 && (
              <details key={router.asPath} className={`${styles.menu} ${admin.some((i) => isActive(i.href)) ? styles.menuActive : ""}`}>
                <summary>Admin</summary>
                <div className={styles.menuList}>
                  {admin.map((i) => (
                    <Link key={i.href} href={i.href} className={`${styles.link} ${isActive(i.href) ? styles.active : ""}`} aria-current={isActive(i.href) ? "page" : undefined}>
                      {i.label}
                    </Link>
                  ))}
                </div>
              </details>
            )}
          </nav>
        )}

        <div className={styles.tools}>
          {showNav && <WalletBar />}
          {state !== "unavailable" && (
            <div className={styles.account}>
              {state === "loading" && <span aria-label="Loading account">…</span>}
              {state === "signedOut" && <Link href={`/signin?next=${encodeURIComponent(router.asPath === "/signin" ? "/dashboard" : router.asPath)}`} className={styles.link}>Sign in</Link>}
              {state === "ready" && me && (
                <>
                  <span className={styles.who} data-testid="bar-name">{me.profile.displayName || me.email || "Account"}</span>
                  <span className={styles.roleTag}>{me.role.replace("_", " ")}</span>
                  {!me.onboarding.complete && router.pathname !== "/onboarding" && <Link href="/onboarding" className={styles.setupLink}>Finish setup</Link>}
                  <Link href="/account" className={styles.link}>Account</Link>
                  <button type="button" className={styles.linkBtn} onClick={() => signOut().then(() => router.push("/"))}>Sign out</button>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
