import Head from "next/head";
import Link from "next/link";
import { useRouter } from "next/router";
import { ReactNode, useEffect } from "react";
import { useAccount } from "../auth/AuthProvider";
import NetworkBanner from "../NetworkBanner";
import NavBar from "./NavBar";
import styles from "../../styles/Layout.module.css";

const WHY: Record<string, string> = {
  onboarding: "Finish setting up your account first.",
  email_unverified: "Verify your email address first (check your inbox).",
  level: "This needs a confirmed ID. Add your ID on your account page; a reviewer confirms it.",
  role: "Your account role does not allow this.",
  suspended: "This account is suspended.",
};

type Props = {
  title: string;                       // browser tab title and, with `intro`, the page heading
  intro?: string;                      // one line under the heading (shows the heading when given)
  children: ReactNode;
  variant?: "app" | "minimal";         // minimal: brand + account only (sign-in, set-up)
  width?: "narrow" | "normal" | "full";
  chain?: boolean;                     // show the live-network / not-deployed warnings (pages that touch the blockchain)
  requireAccount?: boolean;            // signed-out people are sent to sign in, then back here
  capability?: string;                 // the page itself needs this capability (admin pages)
};

// Every page uses this: the bar, the container, the sign-in redirect and the "you may not use this page" message live here,
// so no page repeats them. The panels inside decide nothing about layout.
export default function Layout({ title, intro, children, variant = "app", width = "full", chain = false, requireAccount = false, capability }: Props) {
  const router = useRouter();
  const { state, me, error } = useAccount();
  const onboardingDone = !me || me.onboarding.complete;

  useEffect(() => {
    if (requireAccount && state === "signedOut") router.replace(`/signin?next=${encodeURIComponent(router.asPath)}`);
  }, [requireAccount, state, router]);
  useEffect(() => {
    if (requireAccount && state === "ready" && me && !me.onboarding.complete) router.replace(`/onboarding?next=${encodeURIComponent(router.asPath)}`);
  }, [requireAccount, state, me, router]);

  let body: ReactNode = children;
  if (requireAccount) {
    if (state === "unavailable") body = <div className={`${styles.notice} ${styles.noticeInfo}`}>Sign-in is not set up on this site yet. Set the NEXT_PUBLIC_FIREBASE_* values in .env.local.</div>;
    else if (state === "error") body = <div className={`${styles.notice} ${styles.noticeErr}`}>We could not load your account{error ? `: ${error}` : ""}. Reload the page.</div>;
    else if (state === "loading" || state === "signedOut" || !onboardingDone) body = <p className={styles.muted}>Loading…</p>;
    else if (capability && me) {
      const c = me.capabilities[capability];
      if (!c || !c.allowed) {
        const reason = (c && c.reason) || "role";
        body = (
          <div className={`${styles.notice} ${styles.noticeWarn}`} data-testid="page-locked">
            <strong>{title}</strong> is locked. {WHY[reason] || "Not allowed."}{" "}
            {(reason === "level" || reason === "email_unverified") && <Link href="/account">Open my account</Link>}
          </div>
        );
      }
    }
  }

  const widthClass = width === "narrow" ? styles.narrow : width === "normal" ? styles.normal : "";
  return (
    <>
      <Head><title>{`${title} · ClassTryout`}</title></Head>
      <div className={styles.shell}>
        <NavBar variant={variant} />
        <main className={`${styles.main} ${widthClass}`}>
          {chain && <NetworkBanner />}
          {intro && (
            <div className={styles.pageHead}>
              <h1>{title}</h1>
              <p>{intro}</p>
            </div>
          )}
          {body}
        </main>
      </div>
    </>
  );
}
