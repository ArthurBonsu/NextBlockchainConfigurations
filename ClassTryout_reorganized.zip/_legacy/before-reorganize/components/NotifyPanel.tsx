import { useCallback, useEffect, useState } from "react";
import { connectWallet } from "../utils/contracts";
import { friendlyError } from "../utils/errors";
import { AUTH_IS_DEV, DevIdentity, NotSignedInError, getDevIdentity, setDevIdentity } from "../utils/auth";
import { LinkedWallet, linkWallet, listLinkedWallets, unlinkWallet } from "../utils/walletLink";
import styles from "../styles/VehicleDemo.module.css";

// Lets a signed-in user link the connected wallet to their account, so the email-watcher knows where to send
// registration / revocation / reinstatement / license notices. Linking = signing one free message with the wallet.
export default function NotifyPanel() {
  const [wallets, setWallets] = useState<LinkedWallet[]>([]);
  const [account, setAccount] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ type: "idle" | "pending" | "success" | "error"; text: string }>({ type: "idle", text: "" });
  const [dev, setDev] = useState<DevIdentity>(getDevIdentity() || { uid: "", email: "", verified: true });

  const refresh = useCallback(async () => {
    try {
      const w = await connectWallet();
      setAccount(w.account);
      setWallets(await listLinkedWallets());
      setMessage((m) => (m.type === "error" ? { type: "idle", text: "" } : m));
    } catch (err: any) {
      setWallets([]);
      // "Not signed in" is a normal state, not an error to shout about.
      setMessage(err instanceof NotSignedInError ? { type: "idle", text: err.message } : { type: "error", text: friendlyError(err) });
    }
  }, []);

  useEffect(() => {
    if (!AUTH_IS_DEV) refresh();
    const eth = typeof window !== "undefined" ? window.ethereum : undefined;
    eth?.on?.("accountsChanged", refresh);
    return () => eth?.removeListener?.("accountsChanged", refresh);
  }, [refresh]);

  async function link() {
    setBusy(true);
    setMessage({ type: "pending", text: "Sign the message in your wallet (free, no transaction)..." });
    try {
      const w = await connectWallet();
      await linkWallet(w.web3, w.account);
      setMessage({ type: "success", text: "Wallet linked. You will get emails for this wallet's registrations, revocations and licenses." });
      await refresh();
    } catch (err: any) {
      setMessage({ type: "error", text: friendlyError(err) });
    }
    setBusy(false);
  }

  async function unlink(address: string) {
    setBusy(true);
    try {
      await unlinkWallet(address);
      setMessage({ type: "success", text: "Wallet unlinked. No more emails for it." });
      await refresh();
    } catch (err: any) {
      setMessage({ type: "error", text: friendlyError(err) });
    }
    setBusy(false);
  }

  const mine = wallets.some((w) => w.address.toLowerCase() === account.toLowerCase());
  const short = (a: string) => `${a.slice(0, 6)}...${a.slice(-4)}`;

  return (
    <div className={styles.card} style={{ gridColumn: "1 / -1" }}>
      <h2>Email notifications</h2>
      <div className={styles.subtle}>
        Link your wallet to your account and you get an email when you register, when your registration is revoked or
        reinstated, and when a license for your vehicle is issued, revoked or reinstated. Your email address is never
        written to the blockchain; only your account knows it, and only a verified email is used.
      </div>

      {AUTH_IS_DEV && (
        <div className={styles.subtle} style={{ marginTop: 12 }}>
          <strong>Test sign-in (local only).</strong> Real sign-in arrives with Firebase (Plan 2).
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 6 }}>
            <input className={styles.input} placeholder="test user id" value={dev.uid} onChange={(e) => setDev({ ...dev, uid: e.target.value })} />
            <input className={styles.input} placeholder="test email" value={dev.email} onChange={(e) => setDev({ ...dev, email: e.target.value })} />
            <label>
              <input type="checkbox" checked={dev.verified} onChange={(e) => setDev({ ...dev, verified: e.target.checked })} /> email verified
            </label>
            <button
              className={styles.buttonAdmin}
              onClick={() => {
                setDevIdentity(dev);
                refresh();
              }}
            >
              Use this account
            </button>
          </div>
        </div>
      )}

      <div style={{ marginTop: 12 }}>
        {wallets.length === 0 && <div className={styles.subtle}>No wallet linked to this account yet.</div>}
        {wallets.map((w) => (
          <div key={w.address} className={styles.controlRow}>
            <div>
              <strong>{short(w.address)}</strong>
              <div className={styles.subtle}>linked {new Date(w.linkedAt).toLocaleString()}</div>
            </div>
            <button className={styles.buttonAdmin} disabled={busy} onClick={() => unlink(w.address)}>
              Unlink
            </button>
          </div>
        ))}
      </div>

      <button className={styles.button} style={{ marginTop: 12 }} disabled={busy || mine || !account} onClick={link}>
        {mine ? "This wallet is linked" : "Link this wallet"}
      </button>

      {message.text && (
        <div className={message.type === "error" ? styles.errorText : message.type === "success" ? styles.successText : styles.subtle}>
          {message.text}
        </div>
      )}
    </div>
  );
}
