import { createContext, ReactNode, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { connectWallet, getContractStatuses, isDeployedOnChain } from "../../utils/contracts";
import { friendlyError } from "../../utils/errors";
import { isRealMoney, networkLabel, switchWalletNetwork } from "../../utils/networks";

// One place that knows about the connected wallet: which account, which network, whether it is the contracts' admin.
// The navigation bar, the network banners and the dashboard all read it from here, so they never disagree.
// (Each panel still calls getContracts() itself when it sends a transaction, exactly as before.)
type WalletCtx = {
  account: string | null;
  chainId: string;
  networkName: string;
  isAdmin: boolean;
  deployed: boolean;
  realMoney: boolean;
  error: string;
  switching: boolean;
  connect: () => Promise<void>;
  switchTo: (chainId: number) => Promise<void>;
};

const Ctx = createContext<WalletCtx>({
  account: null, chainId: "", networkName: "", isAdmin: false, deployed: true, realMoney: false, error: "", switching: false,
  connect: async () => {}, switchTo: async () => {},
});

export function WalletProvider({ children }: { children: ReactNode }) {
  const [account, setAccount] = useState<string | null>(null);
  const [chainId, setChainId] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const [error, setError] = useState("");
  const [switching, setSwitching] = useState(false);

  const readAdmin = useCallback(() => {
    // Is this wallet the admin (OpenZeppelin owner)? Skipped quietly if nothing is deployed on this chain.
    getContractStatuses().then((r) => setIsAdmin(r.isAdmin)).catch(() => setIsAdmin(false));
  }, []);

  const connect = useCallback(async () => {
    setError("");
    try {
      const { account: acct, chainId: cid } = await connectWallet();
      setAccount(acct);
      setChainId(cid);
      readAdmin();
    } catch (err: any) {
      setError(friendlyError(err));
    }
  }, [readAdmin]);

  const switchTo = useCallback(async (target: number) => {
    if (!target) return;
    setError("");
    setSwitching(true);
    try {
      await switchWalletNetwork(target);
      // The wallet fires "chainChanged", which reloads the page (handler below).
    } catch (err: any) {
      setError(friendlyError(err));
    } finally {
      setSwitching(false);
    }
  }, []);

  // Auto-connect if the wallet already authorised this site on a previous visit.
  // (eth_accounts never opens a popup; window.ethereum.selectedAddress is deprecated.)
  useEffect(() => {
    if (typeof window === "undefined" || !window.ethereum) return;
    window.ethereum
      .request({ method: "eth_accounts" })
      .then((accts: string[]) => {
        if (accts && accts.length > 0) connect();
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Keep this in sync with the wallet: switching network or account in MetaMask after connecting must update (or reload) the page.
  useEffect(() => {
    if (typeof window === "undefined" || !window.ethereum) return;
    // Contract addresses and anything already fetched are tied to the old chain. Reloading is the simplest clean reset,
    // and what MetaMask recommends.
    const onChain = () => window.location.reload();
    const onAccounts = (accounts: string[]) => {
      if (accounts.length === 0) {
        setAccount(null);
        setChainId("");
        setIsAdmin(false);
      } else {
        setAccount(accounts[0]);
        readAdmin();
      }
    };
    window.ethereum.on?.("chainChanged", onChain);
    window.ethereum.on?.("accountsChanged", onAccounts);
    return () => {
      window.ethereum?.removeListener?.("chainChanged", onChain);
      window.ethereum?.removeListener?.("accountsChanged", onAccounts);
    };
  }, [readAdmin]);

  const value = useMemo<WalletCtx>(
    () => ({
      account, chainId, isAdmin, error, switching, connect, switchTo,
      networkName: chainId ? networkLabel(chainId) : "",
      deployed: chainId ? isDeployedOnChain(chainId) : true,
      realMoney: chainId ? isRealMoney(chainId) : false,
    }),
    [account, chainId, isAdmin, error, switching, connect, switchTo]
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useWallet = () => useContext(Ctx);
