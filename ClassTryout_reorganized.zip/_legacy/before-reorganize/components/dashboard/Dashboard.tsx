import Link from "next/link";
import { useEffect, useState } from "react";
import { useAccount } from "../auth/AuthProvider";
import { useWallet } from "../wallet/WalletProvider";
import { listLinkedWallets } from "../../utils/walletLink";
import nav from "../../shared/nav.json";
import { buildJourney } from "../../shared/journey";
import { visibleItems } from "../../shared/navigation";
import { REQUIRE_ACCOUNT } from "../auth/CapabilityGate";
import styles from "../../styles/Layout.module.css";

type Step = { id: string; title: string; detail: string; status: "done" | "current" | "waiting" | "todo"; href?: string; action?: string; cta: string; optional?: boolean };
type NavItem = { href: string; label: string; blurb: string; capability?: string; roles?: string[] };

const WHY: Record<string, string> = {
  onboarding: "Finish setting up first",
  email_unverified: "Verify your email first",
  level: "Needs a confirmed ID",
  role: "Not for your role",
  suspended: "Account suspended",
};

// The page people land on after signing in. It answers one question: "what do I do now?" The answer comes from
// shared/journey.js (unit-tested); this file only draws it and wires the wallet button.
export default function Dashboard() {
  const { me, firebaseUser, refresh } = useAccount();
  const wallet = useWallet();
  const [linked, setLinked] = useState<boolean | null>(null);

  useEffect(() => {
    let alive = true;
    listLinkedWallets().then((w) => alive && setLinked(w.length > 0)).catch(() => alive && setLinked(null));
    return () => { alive = false; };
  }, []);

  // Coming back to this tab after using the email link or after a reviewer decided: pick up the change without a manual reload.
  async function recheck() {
    try {
      if (firebaseUser && me && me.email && !me.emailVerified) { await firebaseUser.reload(); await firebaseUser.getIdToken(true); }
      await refresh();
    } catch { /* offline: leave the screen as it is */ }
  }
  useEffect(() => {
    const onFocus = () => { if (document.visibilityState !== "hidden") recheck(); };
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onFocus);
    return () => { window.removeEventListener("focus", onFocus); document.removeEventListener("visibilitychange", onFocus); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [firebaseUser, me && me.emailVerified, me && me.email]);

  if (!me) return null;
  const journey = buildJourney({
    me,
    wallet: { connected: !!wallet.account, deployed: wallet.deployed, networkName: wallet.networkName },
    linked,
  }) as { steps: Step[]; next: Step | null };
  const name = me.profile.givenName || me.profile.displayName || me.email || "there";

  const tiles = (visibleItems(nav.items as any[], me, { requireAccount: REQUIRE_ACCOUNT }) as NavItem[]).filter((i) => i.href !== "/dashboard");

  function act(s: Step) {
    if (s.action === "connect") {
      if (!wallet.account) return wallet.connect();
      (document.querySelector("select[aria-label=Network]") as HTMLElement | null)?.focus();
    }
  }
  const cta = (s: Step, big: boolean) => {
    const cls = big ? styles.cta : `${styles.ctaGhost} ${styles.small}`;
    return s.href ? (
      <Link href={s.href} className={cls}>{s.cta}</Link>
    ) : (
      <button type="button" className={cls} onClick={() => act(s)}>{s.cta}</button>
    );
  };

  return (
    <div className={styles.stack}>
      <section className={`${styles.hero} ${journey.next ? styles.heroNext : ""}`} data-testid="next-step">
        <p className={styles.eyebrow}>Welcome, {name}</p>
        {journey.next ? (
          <>
            <h2 data-testid="next-title">{journey.next.status === "waiting" ? "Waiting: " : "Next: "}{journey.next.title}</h2>
            <p>{journey.next.detail}</p>
            {cta(journey.next, true)}
            {journey.next.id === "email" && <> <button type="button" className={styles.ctaGhost} onClick={recheck} data-testid="recheck">I have verified it</button></>}
            {journey.next.status === "waiting" && <> <button type="button" className={styles.ctaGhost} onClick={recheck} data-testid="recheck">Check again</button></>}
          </>
        ) : (
          <>
            <h2 data-testid="next-title">You are all set</h2>
            <p>Your account is complete and your wallet is connected. Pick what you want to do below.</p>
          </>
        )}
      </section>

      <div className={styles.twoCol}>
        <section className={styles.panel}>
          <h3>Your checklist</h3>
          <ol className={styles.steps} data-testid="checklist">
            {journey.steps.map((s) => (
              <li key={s.id} className={styles.stepRow} data-testid={`step-${s.id}`} data-status={s.status}>
                <span className={`${styles.dot} ${s.status === "done" ? styles.dotDone : s.status === "current" ? styles.dotCurrent : s.status === "waiting" ? styles.dotWaiting : ""}`} aria-hidden="true">
                  {s.status === "done" ? "✓" : ""}
                </span>
                <div className={styles.stepBody}>
                  <div className={styles.stepTitle}>{s.title}{s.optional && <span className={styles.optionalTag}>optional</span>}</div>
                  <div className={styles.stepDetail}>{s.detail}</div>
                </div>
                {s.status !== "done" && s.status !== "waiting" && <div className={styles.stepAct}>{cta(s, false)}</div>}
              </li>
            ))}
          </ol>
        </section>

        <section className={styles.panel}>
          <h3>Your account</h3>
          <dl style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: "6px 10px", fontSize: 14, margin: 0 }}>
            <dt style={{ color: "#6a7385" }}>Role</dt><dd style={{ margin: 0, textTransform: "capitalize" }}>{me.role.replace("_", " ")}</dd>
            <dt style={{ color: "#6a7385" }}>ID</dt><dd style={{ margin: 0 }}>{["No ID yet", "Added, awaiting review", "Confirmed"][me.identity.level]}</dd>
            <dt style={{ color: "#6a7385" }}>Phone</dt><dd style={{ margin: 0 }}>{me.phone.verified ? me.phone.masked : "Not verified"}</dd>
            <dt style={{ color: "#6a7385" }}>Wallet</dt><dd style={{ margin: 0 }}>{wallet.account ? `${wallet.account.slice(0, 6)}...${wallet.account.slice(-4)} on ${wallet.networkName}` : "Not connected"}</dd>
          </dl>
          <p style={{ marginTop: 14 }}><Link href="/account" className={styles.ctaGhost}>Manage my account</Link></p>
        </section>
      </div>

      <section>
        <h3 style={{ margin: "6px 0 12px", fontSize: 16 }}>What you can do</h3>
        <div className={styles.cards} data-testid="tiles">
          {tiles.map((t) => {
            const cap = t.capability ? me.capabilities[t.capability] : null;
            const locked = !!cap && !cap.allowed;
            const inner = (
              <>
                <span className={styles.tileTitle}>{t.label}</span>
                <span className={styles.tileText}>{t.blurb}</span>
                {locked ? <span className={styles.tileState}>{WHY[(cap && cap.reason) || "role"] || "Locked"}</span> : <span className={styles.tileOpen}>Open →</span>}
              </>
            );
            return (
              <Link key={t.href} href={t.href} className={`${styles.tile} ${locked ? styles.tileLocked : ""}`} data-testid={`tile-${t.href.slice(1).replace("/", "-")}`}>
                {inner}
              </Link>
            );
          })}
        </div>
      </section>
    </div>
  );
}
