import { ReactNode } from "react";
import styles from "../../styles/Account.module.css";

export function Field({ id, label, error, hint, children }: { id: string; label: string; error?: string; hint?: string; children: ReactNode }) {
  return (
    <div className={styles.field}>
      <label htmlFor={id}>{label}</label>
      {children}
      {hint && !error && <span className={styles.hint}>{hint}</span>}
      {error && <span className={styles.err} data-testid={`err-${id}`}>{error}</span>}
    </div>
  );
}

export function Notice({ kind, children, testid }: { kind: "err" | "ok" | "info"; children: ReactNode; testid?: string }) {
  const cls = kind === "err" ? styles.noticeErr : kind === "ok" ? styles.noticeOk : styles.noticeInfo;
  return (
    <div className={`${styles.notice} ${cls}`} role={kind === "err" ? "alert" : "status"} data-testid={testid}>
      {children}
    </div>
  );
}

export function safeNext(raw: unknown, fallback: string): string {
  const s = Array.isArray(raw) ? raw[0] : raw;
  return typeof s === "string" && s.startsWith("/") && !s.startsWith("//") && !s.includes("\\") ? s : fallback;
}
