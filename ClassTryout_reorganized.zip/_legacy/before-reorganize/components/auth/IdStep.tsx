import { FormEvent, useState } from "react";
import { api, ApiError } from "../../utils/api";
import type { IdDocument, Me } from "../../utils/accountTypes";
import idTypes from "../../shared/id-types.json";
import { Field, Notice } from "./ui";
import styles from "../../styles/Account.module.css";

const STATUS: Record<string, { text: string; cls: string }> = {
  pending_check: { text: "Being checked", cls: styles.badgeWarn },
  pending_review: { text: "Waiting for review", cls: styles.badgeWarn },
  submitted: { text: "Received", cls: styles.badgeWarn },
  verified: { text: "Confirmed", cls: styles.badgeOk },
  rejected: { text: "Not accepted", cls: styles.badgeBad },
  expired: { text: "Expired: add it again", cls: styles.badgeBad },
};

// Adding an ID never waits for any outside service: the person is at "ID given" straight away, and "confirmed" follows
// automatically (when an automated check is switched on and answers) or when a reviewer looks at it.
export default function IdStep({ me, onChanged }: { me: Me; onChanged: (m: Me) => void }) {
  const [type, setType] = useState("ghana_card");
  const [number, setNumber] = useState("");
  const [country, setCountry] = useState("");
  const [expiry, setExpiry] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [fields, setFields] = useState<Record<string, string>>({});
  const t = idTypes.types.find((x) => x.code === type)!;
  const docs: IdDocument[] = me.documents || [];

  async function add(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    setFields({});
    try {
      const r = await api<{ me: Me }>("/api/identity", { body: { type, number, country: t.country ? undefined : country, expiry: expiry || undefined } });
      onChanged(r.me);
      setNumber("");
      setExpiry("");
    } catch (err: any) {
      setError(err.message || "Could not add the ID.");
      if (err instanceof ApiError) setFields(err.fields);
    }
    setBusy(false);
  }
  async function remove(id: string) {
    setBusy(true);
    setError("");
    try {
      const r = await api<{ me: Me }>(`/api/identity?id=${encodeURIComponent(id)}`, { method: "DELETE" });
      onChanged(r.me);
    } catch (err: any) {
      setError(err.message);
    }
    setBusy(false);
  }

  return (
    <div data-testid="step-id">
      <h2>Identity document</h2>
      <p className={styles.muted}>
        Add a Ghana Card, passport, NHIS card or another government ID. You can finish setting up without it, but registering a vehicle or
        issuing a licence needs a confirmed ID. A reviewer confirms it; this never blocks you from using the rest of the app.
      </p>
      {docs.length > 0 && (
        <ul className={styles.list} data-testid="id-list" style={{ marginBottom: 16 }}>
          {docs.map((d) => {
            const s = STATUS[d.status] || { text: d.status, cls: "" };
            return (
              <li key={d.id}>
                <span>{d.label} <span className={styles.mono}>•••• {d.last4}</span>{d.note && d.status === "rejected" ? <em className={styles.hint}> {d.note}</em> : null}</span>
                <span style={{ display: "flex", gap: 10, alignItems: "center" }}>
                  <span className={`${styles.badge} ${s.cls}`} data-testid={`id-status-${d.id}`}>{s.text}</span>
                  {d.status !== "verified" && <button type="button" className={styles.linkBtn} onClick={() => remove(d.id)} disabled={busy}>Remove</button>}
                </span>
              </li>
            );
          })}
        </ul>
      )}
      {error && <Notice kind="err" testid="id-error">{error}</Notice>}
      <form onSubmit={add}>
        <Field id="idType" label="ID type" error={fields.type}>
          <select id="idType" value={type} onChange={(e) => setType(e.target.value)}>
            {idTypes.types.map((x) => <option key={x.code} value={x.code}>{x.label}</option>)}
          </select>
        </Field>
        <Field id="idNumber" label="ID number" error={fields.number} hint={t.example ? `For example ${t.example}` : undefined}>
          <input id="idNumber" value={number} onChange={(e) => setNumber(e.target.value)} autoComplete="off" spellCheck={false} />
        </Field>
        {!t.country && (
          <Field id="idCountry" label="Issuing country (two-letter code)" error={fields.country}>
            <input id="idCountry" value={country} onChange={(e) => setCountry(e.target.value)} maxLength={2} style={{ textTransform: "uppercase", width: 80 }} />
          </Field>
        )}
        {(t.needsExpiry || type !== "ghana_card") && (
          <Field id="idExpiry" label={t.needsExpiry ? "Expiry date" : "Expiry date (optional)"} error={fields.expiry}>
            <input id="idExpiry" type="date" value={expiry} onChange={(e) => setExpiry(e.target.value)} />
          </Field>
        )}
        <button className={styles.btn} disabled={busy || !number} data-testid="add-id">{busy ? "Adding…" : "Add ID"}</button>
      </form>
    </div>
  );
}
