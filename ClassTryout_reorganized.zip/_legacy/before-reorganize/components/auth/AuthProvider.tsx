import { createContext, ReactNode, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { onAuthStateChanged, signOut as fbSignOut, User } from "firebase/auth";
import { firebaseConfigured, getFirebaseAuth } from "../../utils/firebaseClient";
import { api, ApiError } from "../../utils/api";
import type { Me } from "../../utils/accountTypes";

// One place that knows who is signed in (Firebase) and what the server says about them (/api/me).
//   loading      checking Firebase / fetching the profile
//   signedOut    nobody signed in
//   ready        signed in and the profile is loaded
//   error        signed in but the server could not load the profile (message says why)
//   unavailable  this site has no Firebase sign-in configured (demo mode)
export type AuthState = "loading" | "signedOut" | "ready" | "error" | "unavailable";

type Ctx = {
  state: AuthState;
  firebaseUser: User | null;
  me: Me | null;
  error: string;
  refresh: () => Promise<Me | null>;
  setMe: (m: Me) => void;
  signOut: () => Promise<void>;
};

const AuthCtx = createContext<Ctx>({
  state: "loading", firebaseUser: null, me: null, error: "",
  refresh: async () => null, setMe: () => {}, signOut: async () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>(firebaseConfigured ? "loading" : "unavailable");
  const [firebaseUser, setUser] = useState<User | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [error, setError] = useState("");

  const load = useCallback(async (): Promise<Me | null> => {
    try {
      const r = await api<{ me: Me }>("/api/me");
      setMe(r.me);
      setError("");
      setState("ready");
      return r.me;
    } catch (e: any) {
      if (e instanceof ApiError && e.status === 401) {
        setMe(null);
        setState("signedOut");
      } else {
        setError(e && e.message ? e.message : "Could not load your account.");
        setState("error");
      }
      return null;
    }
  }, []);

  useEffect(() => {
    if (!firebaseConfigured) return;
    return onAuthStateChanged(getFirebaseAuth(), (u) => {
      setUser(u);
      if (!u) {
        setMe(null);
        setState("signedOut");
      } else {
        setState((s) => (s === "ready" ? s : "loading"));
        load();
      }
    });
  }, [load]);

  const signOut = useCallback(async () => {
    if (firebaseConfigured) await fbSignOut(getFirebaseAuth());
    setMe(null);
    setState(firebaseConfigured ? "signedOut" : "unavailable");
  }, []);

  const value = useMemo(() => ({ state, firebaseUser, me, error, refresh: load, setMe, signOut }), [state, firebaseUser, me, error, load, signOut]);
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}

export const useAccount = () => useContext(AuthCtx);
