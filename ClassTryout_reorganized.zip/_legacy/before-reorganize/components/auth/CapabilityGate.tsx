import Link from "next/link";
import { useRouter } from "next/router";
import { ReactNode } from "react";
import { useAccount } from "./AuthProvider";
import styles from "../../styles/Account.module.css";

// Hides an action unless the signed-in account may do it. This is a CONVENIENCE: the server checks again (/api/capability/<name>),
// and the smart contract itself is open, so anything important must call the server check first.
// Turned on with NEXT_PUBLIC_REQUIRE_ACCOUNT=true; otherwise the demo behaves as before and children always render.
export const REQUIRE_ACCOUNT = process.env.NEXT_PUBLIC_REQUIRE_ACCOUNT === "true";

const WHY: Record<string, string> = {
  onboarding: "Finish setting up your account first.",
  email_unverified: "Verify your email address first (check your inbox).",
  level: "This needs a confirmed ID. Add your ID on your account page; a reviewer confirms it.",
  role: "Your account role does not allow this.",
  suspended: "This account is suspended.",
};

export default function CapabilityGate({ capability, title, children }: { capability: string; title?: string; children: ReactNode }) {
  const { state, me } = useAccount();
  const router = useRouter();
  if (!REQUIRE_ACCOUNT) return <>{children}</>;
  const label = title || "This section";
  if (state === "loading") return <div className={styles.gate}>Checking your account…</div>;
  if (state !== "ready" || !me) {
    return (
      <div className={styles.gate}>
        <strong>{label}</strong> needs an account. <Link href={`/signin?next=${encodeURIComponent(router.asPath)}`}>Sign in or create one</Link>.
      </div>
    );
  }
  const c = me.capabilities[capability];
  if (c && c.allowed) return <>{children}</>;
  const reason = (c && c.reason) || "role";
  const href = reason === "onboarding" ? "/onboarding" : reason === "level" || reason === "email_unverified" ? "/account" : null;
  return (
    <div className={styles.gate}>
      <strong>{label}</strong> is locked. {WHY[reason] || "Not allowed."} {href && <Link href={href}>Open</Link>}
    </div>
  );
}
