import { useMemo } from "react";
import { isDeployedOnChain } from "../utils/contracts";
import { enabledNetworks, networkLabel } from "../utils/networks";
import { useWallet } from "./wallet/WalletProvider";
import styles from "../styles/Layout.module.css";

// The wallet control in the navigation bar: connect button, or network picker + address + Admin badge.
// All state lives in WalletProvider; this only draws it.
export default function WalletBar() {
  const { account, chainId, isAdmin, error, switching, connect, switchTo } = useWallet();
  const networks = useMemo(() => enabledNetworks(), []);
  const currentKnown = networks.some((n) => String(n.chainId) === chainId);

  const groups: { label: string; items: typeof networks }[] = [
    { label: "Testnets (free test ETH)", items: networks.filter((n) => n.testnet && n.kind !== "Local") },
    { label: "Layer 2 (low fees)", items: networks.filter((n) => !n.testnet && n.kind === "L2") },
    { label: "Ethereum mainnet (real ETH)", items: networks.filter((n) => !n.testnet && n.kind === "L1") },
    { label: "Other chains", items: networks.filter((n) => !n.testnet && n.kind === "Sidechain") },
    { label: "Local", items: networks.filter((n) => n.kind === "Local") },
  ].filter((g) => g.items.length > 0);

  return (
    <div className={styles.walletBar}>
      {account ? (
        <>
          <select
            className={styles.networkSelect}
            aria-label="Network"
            value={currentKnown ? chainId : ""}
            disabled={switching}
            onChange={(e) => e.target.value && String(e.target.value) !== chainId && switchTo(Number(e.target.value))}
          >
            {!currentKnown && <option value="">{networkLabel(chainId)} ({chainId})</option>}
            {groups.map((g) => (
              <optgroup key={g.label} label={g.label}>
                {g.items.map((n) => (
                  <option key={n.chainId} value={n.chainId}>
                    {n.name}
                    {isDeployedOnChain(n.chainId) ? "" : " — not deployed yet"}
                  </option>
                ))}
              </optgroup>
            ))}
          </select>
          <span className={styles.pill} title={account}>
            {account.slice(0, 6)}...{account.slice(-4)}
          </span>
          {isAdmin && <span className={styles.adminBadge}>Admin</span>}
        </>
      ) : (
        <button type="button" className={styles.walletBtn} onClick={connect}>
          Connect Wallet
        </button>
      )}
      {error && <span className={styles.walletErr} role="alert">{error}</span>}
    </div>
  );
}
