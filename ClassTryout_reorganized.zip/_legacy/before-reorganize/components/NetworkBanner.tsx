import { useWallet } from "./wallet/WalletProvider";
import styles from "../styles/Layout.module.css";

// The two warnings that matter before anyone sends a transaction: a live (real-money) network, and a network with no contracts.
export default function NetworkBanner() {
  const { account, chainId, networkName, realMoney, deployed } = useWallet();
  if (!account || !chainId) return null;
  return (
    <>
      {realMoney && (
        <div className={styles.bannerDanger}>
          You are on <strong>{networkName}</strong>, a live network. Transactions here spend real money and cannot be undone. Use a
          testnet for class demos.
        </div>
      )}
      {!deployed && (
        <div className={styles.bannerWarn}>
          The registry contracts are not deployed on <strong>{networkName}</strong> yet. Switch to a network marked as deployed, or
          run <code>truffle migrate --network &lt;name&gt;</code> first.
        </div>
      )}
    </>
  );
}
