import { useCallback, useEffect, useRef, useState } from "react";
import { api, ApiError } from "../../utils/api";
import styles from "../../styles/Layout.module.css";

type Doc = {
  id: string; uid: string; type: string; label: string; last4: string; country: string | null; expiry: string | null;
  status: string; createdAt: string; reviewedAt: string | null; note: string | null; checker?: any; attempts?: number;
};
type Revealed = { number: string; type: string; country: string | null; expiry: string | null; holder: { name: string | null; dob: string | null } };

const STATUS: { value: string; label: string }[] = [
  { value: "pending_review", label: "Waiting for a reviewer" },
  { value: "pending_check", label: "Being checked automatically" },
  { value: "verified", label: "Confirmed" },
  { value: "rejected", label: "Rejected" },
];
const SHOW_SECONDS = 30;

export default function IdReviewQueue() {
  const [status, setStatus] = useState("pending_review");
  const [docs, setDocs] = useState<Doc[]>([]);
  const [more, setMore] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [flash, setFlash] = useState("");
  const [busy, setBusy] = useState(false);
  const [shown, setShown] = useState<{ id: string; data: Revealed } | null>(null);
  const [deciding, setDeciding] = useState<{ id: string; decision: "verified" | "rejected" } | null>(null);
  const [note, setNote] = useState("");
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const hide = useCallback(() => { if (timer.current) clearTimeout(timer.current); timer.current = null; setShown(null); }, []);
  useEffect(() => hide, [hide]);

  const load = useCallback(async (append: boolean, current: Doc[], st: string) => {
    setLoading(true); setError("");
    try {
      const p = new URLSearchParams({ status: st, limit: "25" });
      if (append && current.length) p.set("before", current[current.length - 1].createdAt);
      const r = await api<{ documents: Doc[] }>(`/api/admin/identity?${p}`);
      setDocs(append ? [...current, ...r.documents] : r.documents);
      setMore(r.documents.length === 25);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Could not load the queue.");
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { hide(); setDeciding(null); load(false, [], status); }, [status, load, hide]);

  async function reveal(id: string) {
    setError(""); setFlash("");
    try {
      const data = await api<Revealed>(`/api/admin/identity/${id}/reveal`, { method: "POST", body: {} });
      if (timer.current) clearTimeout(timer.current);
      setShown({ id, data });
      timer.current = setTimeout(() => setShown(null), SHOW_SECONDS * 1000);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Could not show the number.");
    }
  }

  async function decide() {
    if (!deciding) return;
    setBusy(true); setError(""); setFlash("");
    try {
      await api(`/api/admin/identity/${deciding.id}/review`, { method: "POST", body: { decision: deciding.decision, note: note.trim() || undefined } });
      setFlash(deciding.decision === "verified" ? "ID confirmed. The person can now register vehicles." : "ID rejected. The person is told they can submit another.");
      hide(); setDeciding(null); setNote("");
      await load(false, [], status);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "That did not work.");
    } finally { setBusy(false); }
  }

  const reviewable = status === "pending_review";
  return (
    <section data-testid="id-queue">
      <div className={styles.filters}>
        <label>Show IDs that are
          <select aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)}>
            {STATUS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </label>
        <button className={styles.mini} onClick={() => load(false, [], status)} disabled={loading}>Refresh</button>
      </div>
      {flash && <div className={`${styles.notice} ${styles.noticeOk}`} role="status">{flash}</div>}
      {error && <div className={`${styles.notice} ${styles.noticeErr}`} role="alert">{error}</div>}

      <div className={styles.tableWrap}>
        <table className={styles.table}>
          <thead><tr><th>ID</th><th>Person</th><th>Details</th><th>Submitted</th><th>Actions</th></tr></thead>
          <tbody>
            {docs.map((d) => {
              const rev = shown && shown.id === d.id ? shown.data : null;
              const dec = deciding && deciding.id === d.id ? deciding : null;
              return (
                <tr key={d.id} data-testid={`doc-${d.id}`}>
                  <td>
                    <div className={styles.cellMain}>{d.label}</div>
                    <div className={styles.cellSub}>ending {d.last4}</div>
                  </td>
                  <td><div className={styles.cellSub}>Account</div><code>{d.uid.slice(0, 10)}…</code></td>
                  <td>
                    <div className={styles.cellSub}>{d.country ? `Country ${d.country}` : "Country not given"}</div>
                    <div className={styles.cellSub}>{d.expiry ? `Expires ${d.expiry}` : "No expiry date"}</div>
                    {d.attempts ? <div className={styles.cellSub}>{d.attempts} automatic check{d.attempts === 1 ? "" : "s"}</div> : null}
                    {d.note && <div className={styles.cellSub}>Note: {d.note}</div>}
                    {rev && (
                      <div className={styles.revealBox} data-testid="reveal-box">
                        <div>Number: {rev.number}</div>
                        <div>Name: {rev.holder.name || "—"} · Born: {rev.holder.dob || "—"}</div>
                        <div style={{ opacity: 0.7, fontSize: 12 }}>Hides itself after {SHOW_SECONDS} seconds. This look-up is recorded.</div>
                      </div>
                    )}
                  </td>
                  <td>{d.createdAt.slice(0, 16).replace("T", " ")}</td>
                  <td>
                    {reviewable ? (
                      <>
                        <div className={styles.rowActions}>
                          <button className={styles.mini} onClick={() => (rev ? hide() : reveal(d.id))}>{rev ? "Hide number" : "Show number"}</button>
                          <button className={`${styles.mini} ${styles.miniPrimary}`} onClick={() => { setDeciding({ id: d.id, decision: "verified" }); setNote(""); }}>Confirm</button>
                          <button className={`${styles.mini} ${styles.miniDanger}`} onClick={() => { setDeciding({ id: d.id, decision: "rejected" }); setNote(""); }}>Reject</button>
                        </div>
                        {dec && (
                          <div className={styles.inlineConfirm} data-testid="inline-confirm">
                            <span>{dec.decision === "verified" ? "Confirm that the number matches the card and holder?" : "Reject this ID?"}</span>
                            <input aria-label="Note (optional)" placeholder={dec.decision === "rejected" ? "Reason (the person sees it)" : "Note (optional)"} value={note} onChange={(e) => setNote(e.target.value)} maxLength={200} />
                            <button className={`${styles.mini} ${dec.decision === "verified" ? styles.miniPrimary : styles.miniDanger}`} disabled={busy} onClick={decide}>{dec.decision === "verified" ? "Yes, confirm" : "Yes, reject"}</button>
                            <button className={styles.mini} disabled={busy} onClick={() => setDeciding(null)}>Cancel</button>
                          </div>
                        )}
                      </>
                    ) : <span className={`${styles.badge} ${d.status === "verified" ? styles.badgeOk : d.status === "rejected" ? styles.badgeBad : ""}`}>{STATUS.find((s) => s.value === d.status)?.label || d.status}</span>}
                  </td>
                </tr>
              );
            })}
            {!docs.length && !loading && <tr><td colSpan={5} className={styles.empty}>{reviewable ? "Nothing is waiting for review." : "Nothing here."}</td></tr>}
          </tbody>
        </table>
      </div>
      {loading && <p className={styles.muted}>Loading…</p>}
      {more && !loading && <p><button className={styles.mini} onClick={() => load(true, docs, status)}>Load more</button></p>}
    </section>
  );
}
