import { useCallback, useEffect, useState } from "react";
import { useAccount } from "../auth/AuthProvider";
import { api, ApiError } from "../../utils/api";
import regions from "../../shared/locations/regions.json";
import roles from "../../shared/roles.json";
import styles from "../../styles/Layout.module.css";

type Row = {
  uid: string; email: string | null; role: string; status: string; createdAt: string;
  name?: string | null; phone?: string | null; region?: string | null; district?: string | null; suburb?: string | null;
  level: number; onboardingComplete: boolean;
};
type Group = "role" | "email" | "level" | "region";
type Pending = { uid: string; kind: "suspend" | "restore" | "role"; role?: string } | null;

const ROLE_LABEL: Record<string, string> = (roles as any).labels || {};
const roleName = (r: string) => ROLE_LABEL[r] || r;
const LEVEL = ["No ID", "ID given", "ID confirmed"];

// The server allows ONE filter group at a time (role/status, email, ID level, region); the screen mirrors that so nobody builds a filter the server refuses.
export default function UsersTable() {
  const { me } = useAccount();
  const can = (c: string) => !!(me && me.capabilities[c] && me.capabilities[c].allowed);
  const canStatus = can("admin:users:status");
  const canRole = can("admin:roles:assign");

  const [group, setGroup] = useState<Group>("role");
  const [role, setRole] = useState("");
  const [status, setStatus] = useState("");
  const [email, setEmail] = useState("");
  const [level, setLevel] = useState("");
  const [region, setRegion] = useState("");
  const [rows, setRows] = useState<Row[]>([]);
  const [more, setMore] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [flash, setFlash] = useState("");
  const [pending, setPending] = useState<Pending>(null);
  const [note, setNote] = useState("");
  const [newRole, setNewRole] = useState("");
  const [busy, setBusy] = useState(false);

  const query = useCallback((before?: string) => {
    const p = new URLSearchParams();
    if (group === "role") { if (role) p.set("role", role); if (status) p.set("status", status); }
    if (group === "email" && email.trim()) p.set("email", email.trim());
    if (group === "level" && level !== "") p.set("level", level);
    if (group === "region" && region) p.set("regionCode", region);
    if (before) p.set("before", before);
    p.set("limit", "25");
    return `/api/admin/users?${p.toString()}`;
  }, [group, role, status, email, level, region]);

  const load = useCallback(async (append = false) => {
    if ((group === "level" && level === "") || (group === "region" && !region) || (group === "email" && !email.trim())) { setRows([]); setMore(false); return; }
    setLoading(true); setError("");
    try {
      const before = append && rows.length ? rows[rows.length - 1].createdAt : undefined;
      const r = await api<{ users: Row[] }>(query(before));
      setRows(append ? [...rows, ...r.users] : r.users);
      setMore(r.users.length === 25 && group !== "email");
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Could not load users.");
    } finally { setLoading(false); }
  }, [query, rows, group, level, region, email]);

  useEffect(() => { load(false); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [group, role, status, level, region]);

  async function confirm() {
    if (!pending) return;
    setBusy(true); setError(""); setFlash("");
    try {
      if (pending.kind === "role") await api(`/api/admin/users/${pending.uid}/role`, { method: "POST", body: { role: pending.role } });
      else await api(`/api/admin/users/${pending.uid}/status`, { method: "POST", body: { status: pending.kind === "suspend" ? "suspended" : "active", note: note.trim() || undefined } });
      setFlash(pending.kind === "role" ? "Role changed." : pending.kind === "suspend" ? "Account suspended." : "Account restored.");
      setPending(null); setNote(""); setNewRole("");
      await load(false);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "That did not work.");
    } finally { setBusy(false); }
  }

  const roleList: string[] = (roles as any).roles;
  return (
    <section data-testid="users-table">
      <form className={styles.filters} onSubmit={(e) => { e.preventDefault(); load(false); }}>
        <label>
          Filter by
          <select aria-label="Filter by" value={group} onChange={(e) => setGroup(e.target.value as Group)}>
            <option value="role">Role and status</option>
            <option value="email">Email</option>
            <option value="level">ID level</option>
            <option value="region">Region</option>
          </select>
        </label>
        {group === "role" && (<>
          <label>Role
            <select aria-label="Role" value={role} onChange={(e) => setRole(e.target.value)}>
              <option value="">Any</option>
              {roleList.map((r) => <option key={r} value={r}>{roleName(r)}</option>)}
            </select>
          </label>
          <label>Status
            <select aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="">Any</option><option value="active">Active</option><option value="suspended">Suspended</option>
            </select>
          </label>
        </>)}
        {group === "email" && (
          <label>Exact email
            <input aria-label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@example.com" />
          </label>
        )}
        {group === "level" && (
          <label>ID level
            <select aria-label="ID level" value={level} onChange={(e) => setLevel(e.target.value)}>
              <option value="">Choose…</option>{LEVEL.map((l, i) => <option key={l} value={i}>{l}</option>)}
            </select>
          </label>
        )}
        {group === "region" && (
          <label>Region
            <select aria-label="Region" value={region} onChange={(e) => setRegion(e.target.value)}>
              <option value="">Choose…</option>{(regions as { code: string; name: string }[]).map((r) => <option key={r.code} value={r.code}>{r.name}</option>)}
            </select>
          </label>
        )}
        {group === "email" && <button type="submit" className={`${styles.mini} ${styles.miniPrimary}`}>Search</button>}
      </form>

      {flash && <div className={`${styles.notice} ${styles.noticeOk}`} role="status">{flash}</div>}
      {error && <div className={`${styles.notice} ${styles.noticeErr}`} role="alert">{error}</div>}

      <div className={styles.tableWrap}>
        <table className={styles.table}>
          <thead><tr><th>Person</th><th>Role</th><th>Status</th><th>ID</th><th>Where</th><th>Joined</th><th>Actions</th></tr></thead>
          <tbody>
            {rows.map((u) => {
              const mine = me && me.uid === u.uid;
              const open = pending && pending.uid === u.uid;
              return (
                <tr key={u.uid} data-testid={`user-${u.uid}`}>
                  <td>
                    <div className={styles.cellMain}>{u.name || "(no name yet)"}</div>
                    <div className={styles.cellSub}>{u.email || "no email"}{u.phone ? ` · ${u.phone}` : ""}</div>
                    {!u.onboardingComplete && <div className={styles.cellSub}>Set-up not finished</div>}
                  </td>
                  <td>{roleName(u.role)}</td>
                  <td><span className={`${styles.badge} ${u.status === "active" ? styles.badgeOk : styles.badgeBad}`}>{u.status === "active" ? "Active" : "Suspended"}</span></td>
                  <td><span className={`${styles.badge} ${u.level === 2 ? styles.badgeOk : u.level === 1 ? styles.badgeWarn : ""}`}>{LEVEL[u.level]}</span></td>
                  <td>{[u.suburb, u.district, u.region].filter(Boolean).join(", ") || "—"}</td>
                  <td>{u.createdAt.slice(0, 10)}</td>
                  <td>
                    {mine ? <span className={styles.cellSub}>This is you</span> : (
                      <>
                        <div className={styles.rowActions}>
                          {canStatus && (u.status === "active"
                            ? <button className={`${styles.mini} ${styles.miniDanger}`} onClick={() => { setPending({ uid: u.uid, kind: "suspend" }); setNote(""); }}>Suspend</button>
                            : <button className={styles.mini} onClick={() => { setPending({ uid: u.uid, kind: "restore" }); setNote(""); }}>Restore</button>)}
                          {canRole && <button className={styles.mini} onClick={() => { setPending({ uid: u.uid, kind: "role", role: u.role }); setNewRole(u.role); }}>Change role</button>}
                          {!canStatus && !canRole && <span className={styles.cellSub}>View only</span>}
                        </div>
                        {open && pending && (
                          <div className={styles.inlineConfirm} data-testid="inline-confirm">
                            {pending.kind === "role" ? (
                              <>
                                <select aria-label="New role" value={newRole} onChange={(e) => { setNewRole(e.target.value); setPending({ ...pending, role: e.target.value }); }}>
                                  {roleList.map((r) => <option key={r} value={r}>{roleName(r)}</option>)}
                                </select>
                                <button className={`${styles.mini} ${styles.miniPrimary}`} disabled={busy || newRole === u.role} onClick={confirm}>Save role</button>
                              </>
                            ) : (
                              <>
                                <span>{pending.kind === "suspend" ? "Suspend this account? They are signed out of everything." : "Restore this account?"}</span>
                                <input aria-label="Note (optional)" placeholder="Note (optional)" value={note} onChange={(e) => setNote(e.target.value)} maxLength={200} />
                                <button className={`${styles.mini} ${pending.kind === "suspend" ? styles.miniDanger : styles.miniPrimary}`} disabled={busy} onClick={confirm}>{pending.kind === "suspend" ? "Yes, suspend" : "Yes, restore"}</button>
                              </>
                            )}
                            <button className={styles.mini} disabled={busy} onClick={() => setPending(null)}>Cancel</button>
                          </div>
                        )}
                      </>
                    )}
                  </td>
                </tr>
              );
            })}
            {!rows.length && !loading && (
              <tr><td colSpan={7} className={styles.empty}>
                {group === "level" && level === "" ? "Choose an ID level." : group === "region" && !region ? "Choose a region." : group === "email" && !email.trim() ? "Type an email and press Search." : "No users match."}
              </td></tr>
            )}
          </tbody>
        </table>
      </div>
      {loading && <p className={styles.muted}>Loading…</p>}
      {more && !loading && <p><button className={styles.mini} onClick={() => load(true)}>Load more</button></p>}
    </section>
  );
}
