// Unit tests for the two pure functions behind the new navigation and the guided dashboard.
//   node --test test/accounts/journey.test.js
const test = require("node:test");
const assert = require("node:assert/strict");
const { buildJourney } = require("../../shared/journey.js");
const { visibleItems } = require("../../shared/navigation.js");
const nav = require("../../shared/nav.json");

const me = (over = {}) => ({
  email: "a@example.test", emailVerified: true, role: "citizen", status: "active",
  onboarding: { complete: true }, identity: { level: 2 }, ...over,
});
const W = { connected: true, deployed: true, networkName: "Sepolia" };
const ids = (r) => r.steps.map((s) => s.id);

test("journey: a brand-new account is sent to verify its email first", () => {
  const r = buildJourney({ me: me({ emailVerified: false, onboarding: { complete: false }, identity: { level: 0 } }), wallet: { connected: false }, linked: null });
  assert.deepEqual(ids(r), ["email", "setup", "id", "wallet", "link"]);
  assert.equal(r.next.id, "email");
  assert.equal(r.next.status, "current");
});

test("journey: an account without an email (X sign-in) has no email step", () => {
  const r = buildJourney({ me: me({ email: null, onboarding: { complete: false } }), wallet: W, linked: false });
  assert.ok(!ids(r).includes("email"));
  assert.equal(r.next.id, "setup");
});

test("journey: order is email -> set-up -> ID -> wallet", () => {
  let r = buildJourney({ me: me({ onboarding: { complete: false } }), wallet: W, linked: true });
  assert.equal(r.next.id, "setup");
  r = buildJourney({ me: me({ identity: { level: 0 } }), wallet: W, linked: true });
  assert.equal(r.next.id, "id");
  r = buildJourney({ me: me(), wallet: { connected: false }, linked: true });
  assert.equal(r.next.id, "wallet");
});

test("journey: an ID waiting for review shows 'waiting', still the next step", () => {
  const r = buildJourney({ me: me({ identity: { level: 1 } }), wallet: W, linked: true });
  assert.equal(r.next.id, "id");
  assert.equal(r.next.status, "waiting");
});

test("journey: connected to a network with no contracts is not 'done'", () => {
  const r = buildJourney({ me: me(), wallet: { connected: true, deployed: false, networkName: "Base" }, linked: true });
  assert.equal(r.next.id, "wallet");
  assert.match(r.next.detail, /no ClassTryout contracts/);
});

test("journey: the optional wallet-link step only becomes 'next' when everything else is done", () => {
  let r = buildJourney({ me: me(), wallet: W, linked: false });
  assert.equal(r.next.id, "link");
  r = buildJourney({ me: me(), wallet: W, linked: true });
  assert.equal(r.next, null);
  r = buildJourney({ me: me({ identity: { level: 0 } }), wallet: W, linked: false });
  assert.equal(r.next.id, "id", "a required step comes before the optional one");
});

test("journey: unknown link state (null) behaves like 'not linked'", () => {
  const r = buildJourney({ me: me(), wallet: W, linked: null });
  assert.equal(r.next.id, "link");
});

const hrefs = (items) => items.map((i) => i.href);

test("nav: a citizen sees vehicles, history and notifications but no officer or admin pages", () => {
  const h = hrefs(visibleItems(nav.items, me({ role: "citizen" }), { requireAccount: true }));
  assert.deepEqual(h, ["/dashboard", "/vehicles", "/history", "/notifications"]);
});

test("nav: an officer also sees licences and revocations, still no admin pages", () => {
  const h = hrefs(visibleItems(nav.items, me({ role: "officer" })));
  assert.ok(h.includes("/licences") && h.includes("/revocations"));
  assert.ok(!h.some((x) => x.startsWith("/admin")));
});

test("nav: an admin sees the admin pages; a super admin sees the same", () => {
  for (const role of ["admin", "super_admin"]) {
    const h = hrefs(visibleItems(nav.items, me({ role })));
    assert.ok(["/admin/users", "/admin/ids", "/admin/contracts"].every((x) => h.includes(x)), role);
  }
});

test("nav: signed out with accounts required sees only public pages", () => {
  assert.deepEqual(hrefs(visibleItems(nav.items, null, { requireAccount: true })), ["/history"]);
});

test("nav: signed out in demo mode sees the chain pages but never account or admin pages", () => {
  const h = hrefs(visibleItems(nav.items, null, { requireAccount: false }));
  assert.ok(h.includes("/vehicles") && h.includes("/history"));
  assert.ok(!h.includes("/dashboard") && !h.some((x) => x.startsWith("/admin")));
});

test("nav: a suspended account sees only public pages", () => {
  assert.deepEqual(hrefs(visibleItems(nav.items, me({ status: "suspended", role: "admin" }))), ["/history"]);
});
