// Shared set-up for the account tests: a throwaway file store, the mock SMS outbox, dev (fake-token) sign-in.
const fs = require("fs");
const os = require("os");
const path = require("path");

function setup(name) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), `ct-${name}-`));
  Object.assign(process.env, {
    NODE_ENV: "test",
    STORE_BACKEND: "file",
    STORE_FILE: path.join(dir, "store.json"),
    SMS_PROVIDER: "mock",
    SMS_OUTBOX_FILE: path.join(dir, "sms.jsonl"),
    NOTIFY_BACKEND: "dev",
  });
  return dir;
}

// A user as the server sees them after verifying a token.
const auth = (uid, email = `${uid}@example.com`, emailVerified = true) => ({ uid, email, emailVerified, provider: "password" });

// Reads the code out of the mock SMS outbox (the API never returns it).
function lastCode(phone) {
  const { lastTo } = require("../../server/sms/mock.js");
  const m = lastTo(phone);
  const hit = m && /(\d{6}) is your/.exec(m.text);
  return hit ? hit[1] : null;
}

const ADDRESS = { regionCode: "GAR", districtId: "GAR-accra", city: "Accra", suburb: "East Legon" };
const PROFILE = { givenName: "Ama", familyName: "Mensah", dob: "1995-04-12", gender: "female", nationality: "GH" };

async function complete(uid, phone = "0241234567") {
  const users = require("../../server/users.js");
  const otp = require("../../server/otp.js");
  await users.ensureUser(auth(uid));
  await users.saveConsents(uid, { terms: true, privacy: true, sms: true }, "1.2.3.4");
  await users.saveProfile(uid, PROFILE);
  await otp.startPhoneVerification(uid, phone, "1.2.3.4");
  await otp.confirmPhoneVerification(uid, lastCode("+233" + phone.replace(/^0/, "")), "1.2.3.4");
  await users.saveAddress(uid, ADDRESS);
}

module.exports = { setup, auth, lastCode, ADDRESS, PROFILE, complete };
