# ClassTryout: vehicle and license registry

Next.js + web3.js front end, three Solidity contracts built with OpenZeppelin, Truffle for compile / test / deploy.
Everything (contracts, migrations, scripts, components, pages) reads its ABI, networks and addresses from the `shared/`
folder, so there is exactly one place to change each thing. See `docs/project-tree.md` for the full tree.

## First time (also after pulling this pack)

```
npm install                          # installs Next, web3, Truffle, Ganache and OpenZeppelin 5.0.2
bash scripts/cleanup-legacy.sh       # dry run: shows which Passchain / old files would move out of the build path
bash scripts/cleanup-legacy.sh --apply
npm run contracts:compile            # compile + write shared/abi
npm run contracts:test               # 21 contract tests, no chain needed
npm run check                        # consistency check + TypeScript
```

## Every day

```
npm run chain                        # terminal 1: local chain (id 1337)
npm run deploy:local                 # terminal 2: deploy; addresses are recorded for you
npm run dev                          # open http://localhost:3000
```

After changing a `.sol` file: `npm run contracts:compile`, then redeploy. After deploying: restart `npm run dev`.

## Testnets and mainnets

`shared/chains.json` lists every network; `truffle-config.js` and the network picker are generated from it.

```
npx truffle migrate --network sepolia            # or baseSepolia, arbitrumSepolia, optimismSepolia, polygonAmoy
ALLOW_MAINNET_DEPLOY=yes npx truffle migrate --network base   # real money networks refuse to run without the flag
```

The migrations write the addresses and the deployment block to `shared/deployments.json`. **Commit that file**: it is how
the front end finds the contracts. A network with no entry is shown as "not deployed yet" in the picker.
Redeploying to a network that already ran older migrations: add `--reset`.

Secrets live in `.env.local` (see `.env.local.example`), read by Truffle only, never by the browser.

## OpenZeppelin: imported by link, not copied

```solidity
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";
```

That import line is the link. `npm install` fetches the library at the exact version pinned in `package.json` (5.0.2, which
targets Solidity ^0.8.20, matching the compiler here), so no OpenZeppelin source is stored in `contracts/`. A full
`https://github.com/...` URL import works in Remix only; Truffle cannot resolve URLs, so the check script rejects them.
To upgrade, change the pinned version, recompile, rerun the tests.

What the contracts now get from it:
- **Ownable**: the deployer is the admin. `admin()` is kept as an alias of `owner()`. Ownership can be transferred
  (`transferOwnership`) but not renounced, because a registry nobody can administer cannot be paused or repaired.
- **Pausable**: the admin can pause new registrations, reports and licenses. Processing, revoking and reinstating keep working
  while paused.
- Failures from these come back as custom errors (`OwnableUnauthorizedAccount`, `EnforcedPause`); the app turns them into plain
  sentences, so non-admin wallets and paused contracts are explained instead of showing a raw revert.

In the UI: an **Admin** badge beside the wallet when it owns a contract, and a **Contract Control** card showing each
contract's address, admin and Running / Paused state, with Pause / Resume for the admin.

## Email notifications

A small server-side program, the **watcher**, reads the contracts' events and emails the owner. It sends:

| Event on the chain | Email |
|---|---|
| `VehicleRegistered` | Registration confirmation |
| `VehicleRevoked` | Revocation notice (with the reason) |
| `VehicleReinstated` | Reinstatement notice |
| `LicenseIssued` | License issued (goes to the **vehicle's owner**, names the wallet that issued it) |
| `LicenseRevoked` / `LicenseReinstated` | License revoked / reinstated |

(`shared/notifications.json` is the list; `npm run check` fails if it names an event or argument the contracts do not have.)

**Where the address comes from.** Never from the chain: the chain is public. A signed-in user links a wallet to their account by
signing one free message (`pages/api/wallet-link/*`, the "Email notifications" card on the page). The server stores only
`wallet -> Firebase account`; the email is read from Firebase Auth when the mail is sent, and **only a verified email receives anything**.
Wallets that are not linked, or whose email is not verified, are skipped and the reason is recorded.

**Running it.**

```
npm run notify:status      what it watches, how many events it has handled, what is waiting to retry
npm run notify:once        one pass, then exit (run it from a scheduler / cron every minute or so)
npm run notify             keep running and check every NOTIFY_POLL_SECONDS
```

It needs to run somewhere that stays on (a small VM, Railway, Render, Fly.io...), with its `notifier/data/state.json` on a
persistent disk. That file is its memory (which block it has read to, which events it has handled), and holds no email addresses.
Vercel-style serverless hosting can serve the web app and the `/api/wallet-link` routes, but cannot run the watcher.

How it behaves: events are read once they are `NOTIFY_CONFIRMATIONS` blocks deep (default 5); each event is handled once;
a failed send is retried with growing delays (8 tries) without holding up newer events; events older than
`NOTIFY_MAX_AGE_HOURS` (72) are recorded but not emailed, so starting it on an old deployment does not mail people about
last month. Delivery is "at least once": if the program dies between sending and noting it down, that single email may repeat.
Someone who links their wallet **after** an event does not get a late email for it.

**What is real and what waits for Plan 2.** Built and tested here: the watcher, the six emails, the wallet-link API
(challenge, signature check, ownership, unlink), the Firestore + Firebase Admin code paths, the panel. Not yet possible:
signing in. `utils/auth.ts` is the single place the front end asks "who is signed in"; Plan 2 replaces its one function with
`getAuth().currentUser.getIdToken()` and nothing else changes. Until then `NEXT_PUBLIC_NOTIFY_BACKEND=dev` (and
`NOTIFY_BACKEND=dev` on the server) gives a test sign-in box and a local JSON file instead of Firebase; the server refuses
that mode when `NODE_ENV=production`.

Setup for real use: create a Firebase project, enable Authentication and Firestore, generate a service-account key, fill in the
`FIREBASE_*`, `WALLET_LINK_SECRET` and `EMAIL_*` values in `.env.local` (see `.env.local.example`), then start the watcher.
Gmail works with an **app password** (not your normal password); a transactional provider (SendGrid, Mailgun, Amazon SES) is
more reliable for a class. Firestore rules should deny all client access to `walletLinks`: only the server (Admin SDK) touches it.

Good to know: the contracts record a wallet address and a pseudonym, both public. The emails repeat only what is already on
the chain, plus the reason text the admin typed. `issueLicense` is open to any wallet, so anyone can cause a "license issued"
email to a vehicle's owner (the email names the issuing wallet); restricting issuing to approved wallets fixes this at the source.

## Accounts: sign-in, onboarding, roles (Plan A)

Firebase Authentication (email + password, GitHub, X) with a one-page onboarding: agreements, name and date of birth, a
verified Ghana mobile number (SMS code), address (region, district, city, suburb) and an optional ID (Ghana Card, passport, NHIS
and others). Roles are citizen, officer, admin, super admin; registering a vehicle or issuing a licence needs a **confirmed** ID.
Onboarding never waits for an outside ID service. Read `docs/database.md` (the whole schema as a tree), `docs/firebaserealstructure.txt` (real example documents), `docs/ACCOUNTS.md` (API, flows) and `firebase/README.md`
(console steps, first admin, go-live checklist).

```
npm run test:accounts                # account tests + dashboard/navigation logic tests, no network
npm run firebase:emulators           # (or: npx firebase-tools emulators:start --only auth --project demo-classtryout)
npm run test:accounts:e2e            # real browser: sign up -> onboarding -> reviewer confirms ID -> panels unlock
npm run accounts:set-role -- --email you@example.com --role super_admin --confirm-identity
```

The open class demo is unchanged until you set `NEXT_PUBLIC_REQUIRE_ACCOUNT=true`, which locks the registration, licence and revocation
panels behind sign-in, role and ID level. The smart contracts stay open to any wallet (so a direct contract call can bypass the app's gate;
the gate protects the app and what it records, not the chain).

## The pages and how people move through them

```
/            visitors: what this is and how it works.  Signed in: straight to /dashboard
/signin      create an account or sign in           ->  /onboarding (new accounts)  ->  /dashboard
/dashboard   "what do I do now?": next step, checklist (email, set-up, ID, wallet, optional wallet link), and what you can open
/vehicles    register and look up a vehicle         (needs a confirmed ID)
/licences    issue, look up, revoke a licence       (officers and above, confirmed ID)
/revocations report, process, reinstate             (officers and above, confirmed ID)
/history     on-chain history of any vehicle        (public)
/notifications   link a wallet for email notices
/account     profile, ID documents, preferences
/admin/users     find people, suspend or restore, change roles (super admin)
/admin/ids       review submitted IDs: show the number, confirm or reject
/admin/contracts who owns each contract, pause or resume (the owner wallet decides)
```

Every page is wrapped in `components/layout/Layout.tsx`, which gives it the top bar (`NavBar`), the sign-in redirect and the "locked" message.
The links in the bar come from `shared/nav.json` and depend on the signed-in role; the dashboard's checklist comes from `shared/journey.js`.
Both are plain functions with unit tests (`test/accounts/journey.test.js`). The server still enforces everything: hiding a link is a courtesy.
The wallet connection is shared by all pages through `components/wallet/WalletProvider.tsx`. `npm run check` fails if a link in
`shared/nav.json` points to a page that does not exist. `node e2e/navigation.e2e.js` walks the whole flow in a browser and saves screenshots.

## Keeping everything consistent

`npm run check` fails when any of these drift apart: the compiled contracts vs `shared/abi`; a component calling a contract
method or reading an event that does not exist; legacy imports (Passchain loader, raw `build/contracts`, Tatum); duplicate
migration numbers; URL imports or a copied OpenZeppelin in `contracts/`; a deployments entry that is not an address or is for an
unknown chain; `utils/networks.ts` keeping its own network list; and the email setup: every entry in `shared/notifications.json` must name a real event and argument, have a template and a handler, and the watcher may only call contract functions that exist. TypeScript (strict) checks argument counts and types
against the real ABI. `predev` / `prebuild` also make sure the generated files exist on a fresh clone.

## Cautions

- Educational demo, not audited. `issueLicense` is still open to any wallet and the reporter pseudonym is not tied to the
  sender; decide on those before real money.
- Contracts cannot be changed after deployment; the admin is the deploying wallet. Use a dedicated wallet.
- Each chain has its own separate registry: a vehicle registered on Base does not exist on Arbitrum.
- The old Sepolia contracts (the `0xF819...` / `0xb364...` pair) were built from the previous source and do not have
  `owner()` / `paused()`. Deploy the new set; the old addresses are no longer read anywhere.

## Verified here, and not

Verified: contracts compile with no warnings (paris EVM, no PUSH0); 21 contract tests; typed front end builds; 33 browser checks
(register, license, report, revoke, reinstate, history, admin badge, pause / resume, friendly errors) and 11 network-picker checks
against local chains; the consistency check catches seeded problems (method typo, legacy import, duplicate migration number, URL
import, unsynced ABI, hand-edited ABI, bad deployments entry, private network list).
Email feature: 22 checks against a local chain with a mock SMTP server (all six emails, skipped wallets, no repeats on a second run, retry after a mail-server outage, wallet-link API with real signatures, forged / foreign / unauthenticated requests refused) and 7 browser checks of the panel.
Accounts: 26 unit tests and 67 browser/API checks against the Firebase **Auth** emulator (sign-up, onboarding, SMS code limits, ID review, role change revoking the old session, suspension, one ID and one phone per account, secrets absent from responses and storage); the consistency check catches seeded problems (open rule, wrong district count, undocumented env variable).
Not verified: real MetaMask, live networks and RPCs (the sandbox cannot reach them), Remix, a real SMTP provider, **Firestore itself** (the emulator cannot be downloaded here, so the Firestore backend, the rules and the index file are written but unrun; a file-backed stand-in that enforces the index rule is what the tests used), a real SMS provider (Arkesel / Hubtel presets are unverified), and GitHub / X sign-in (need the real providers).
Fixed in this pack: `server/firebaseAdmin.js` used the old namespaced Firebase Admin API (`admin.auth()`), which firebase-admin v13+ removed, so the email feature's `firebase` backend would have failed on first real use. It never showed up in tests because they used the `dev` backend.
