# Accounts: sign-in, onboarding, roles, ID documents, phone verification

This is the Plan 2 / **Plan A** build. It adds people to ClassTryout: who they are, where they live (anywhere in Ghana), whether
their phone and ID are confirmed, and what each role may do. Plans B and C (see the end) build on it without changing it.

## Decisions this is built on

| Decision | What was chosen |
|---|---|
| Sign-in engine | **Firebase Authentication only** (email + password, GitHub, X). No NextAuth: two things owning the session is what clashed with Firebase before. |
| Where data lives | Firestore, written **only by the server** (Firebase Admin). Browsers can read one thing: their own `users/{uid}` document. |
| Roles | `citizen` (owner), `officer`, `admin`, `super_admin`. Set only by the server (script or, later, an invite). Never from a form. |
| Phone | **Mandatory**, verified with a one-time SMS code we generate and check ourselves. |
| ID | Ghana Card, passport, NHIS card, voter ID, SSNIT, other. **Never depends on an outside API**: the person is onboarded with or without it. |
| Level-2 (confirmed ID) | Needed to register a vehicle and to issue a licence. Enforced by the app and server, **not** the contract (the contract stays open). |
| Wallets | Independent of accounts. `issueLicense` is not limited to approved wallets; it produces the on-chain receipt as before. |

## The journey

```
/signin  (create account or sign in; email verification link is sent)
   |
/onboarding  one page, five steps, resumable:
   1 Agreements   terms, privacy (Act 843), SMS consent  -> versions + time recorded
   2 About you    first name, surname, date of birth (16+), gender, nationality
   3 Phone        +233 number -> SMS code (6 digits, 10 min, 5 tries, 60 s between sends)
   4 Address      region -> district -> city -> suburb (+ optional area, street, GhanaPostGPS, location)
   5 ID           optional at first: add an ID; it waits for a reviewer or an automated check
   |
/account     profile, role, what you can do, IDs, notification preferences
```

Steps 1-4 finish onboarding. Step 5 can be done later, but until an ID is **confirmed** (level 2) vehicle registration and licence
issuing stay locked.

### Identity levels

| Level | Meaning | How it is reached |
|---|---|---|
| 0 | No ID on file | start |
| 1 | An ID was added and its shape is valid, not confirmed | the moment an ID is added (never waits for anyone) |
| 2 | ID confirmed | a human reviewer confirms it, or an automated checker (NIA, later) does |

If an automated checker is down or has no access, the ID simply waits for a human. After 14 days an undecided ID number is deleted
and the account drops back to level 0/1: nobody is ever locked out of onboarding.

## Roles and capabilities

Defined in `shared/roles.json`; enforced in `server/roles.js`, called by every API route (`server/session.js`). The UI
(`CapabilityGate`) only hides things; the server always checks again.

| Capability | citizen | officer | admin | super_admin | Needs ID level |
|---|:-:|:-:|:-:|:-:|:-:|
| `account:use`, `wallet:link` | yes | yes | yes | yes | 0 |
| `vehicle:register` | yes | yes | yes | yes | 2 |
| `license:issue`, `license:revoke`, `vehicle:revoke` | | yes | yes | yes | 2 |
| `admin:users:read` | | | yes | yes | 1 |
| `admin:ids:review`, `admin:users:status` | | | yes | yes | 2 |
| `admin:roles:assign` | | | | yes | 2 |

On top of the role and level: the account must be active (not suspended), onboarding complete, and, if it has an email, the
email verified. The first super administrator is made from the command line (`npm run accounts:set-role`); a role change revokes
the person's sessions so it takes effect within minutes.

## Collections (Firestore)

Only the server writes any of these. "Browser" = what a signed-in browser may read through the Firestore SDK.

### `users` (key: Firebase uid). Browser: read own document only

| Field | Notes |
|---|---|
| `uid`, `email` (lower-case), `emailVerified`, `provider` | from the verified sign-in token, refreshed on each visit |
| `role`, `status` | `citizen/officer/admin/super_admin`, `active/suspended`. Server-set only |
| `profile` | `givenName, familyName, otherNames?, displayName, dob (YYYY-MM-DD), gender, nationality (ISO-2)` |
| `phone` | `{ verified, e164, last4, masked, verifiedAt }` (e164 is kept to send SMS) |
| `address` | `regionCode, regionName, districtId, districtName, city, cityKey, suburb, suburbKey, subarea?, subareaKey?, street?, gpsAddress?, lat?, lng?, placeId?, updatedAt` |
| `identity` | `{ level 0/1/2, types[], verifiedAt?, bootstrap? , updatedAt }` |
| `consents` | `{ terms, privacy, sms }` each `{ version, at, ipHash }` |
| `notifications` | `{ email, sms }` booleans |
| `onboarding.completedAt` | stamped the first time steps 1-4 are all done. Which step is next is **computed**, never stored |
| `createdAt, updatedAt, lastLoginAt, schemaVersion` | |

### `identityDocuments` (auto id). Browser: none

`uid, type, country, expiry?, last4, numberHmac, encNumber?, encExpiresAt?, status, checker, attempts, nextAttemptAt, reviewedBy?, reviewedAt?, note?, createdAt, updatedAt`.
`status`: `pending_check`, `pending_review`, `verified`, `rejected`, `expired`. The number is stored as an **HMAC** (keyed with `ID_HASH_PEPPER`)
plus the last four digits. The full number is kept **AES-256-GCM encrypted** (`encNumber`) only while the document waits for a
decision, then removed. Revealing it to a reviewer is audit-logged.

### `identityClaims` (key: HMAC of the ID). Browser: none

`{ uid, docId, type, createdAt }`. Created in the same transaction as the document, so **one ID can belong to one account**. A
rejected or withdrawn ID releases its claim.

### `phoneChallenges` (key: uid). Browser: none. TTL on `expireAt`

One live code per account: `{ uid, phone, codeHmac, attempts, status, createdAt, resendAfter, expireAt }`. The code is stored only as a keyed hash.

### `phoneClaims` (key: HMAC of the phone). Browser: none

`{ uid, claimedAt }`. One verified number per account.

### `locationSuggestions` (key: hash of district + suburbKey). Browser: none

`{ districtId, regionCode, suburb, suburbKey, city, count, createdAt, updatedAt }`. Suburbs people have entered, offered back as suggestions (most used first).

### `rateLimits` (key: hash + window). Browser: none. TTL on `expireAt`

`{ count, windowSeconds, createdAt, expireAt }`. Keys are hashed, so addresses and numbers are not stored.

### `auditLogs` (auto id, append only). Browser: none

`{ at, actor{uid,role}, action, target{type,id}, before, after, note, ip }`, with numbers, codes and hashes stripped. Actions written today:
`user.role`, `user.status`, `identity.submit|verified|rejected|reveal|bootstrap`, `phone.verified`.

### Existing / planned

`walletLinks` (key: wallet address; from the email feature, `{ uid, address, linkedAt }`) is unchanged. Planned for Plans B and C:
`notificationLog`, `invites`, `systemConfig`.

## Location model (the whole country)

16 regions and 261 districts (MMDAs) ship in `shared/locations/` (checked against the official counts by `npm run check`).
**City, suburb and area are free text**, because no list covers every neighbourhood and spellings differ. Each is stored with a
normalised key (`East  Legon` and `east legon` group together), and `locationSuggestions` offers what others typed.
GhanaPostGPS (`GA-543-1234`) and latitude/longitude (inside Ghana only) are optional.

## API

All routes need `Authorization: Bearer <Firebase ID token>`. Errors are `{ error, code, fields? }`.

| Route | Does |
|---|---|
| `GET /api/me` | profile, role, onboarding progress, capabilities, IDs (last 4), pending phone code. Creates the profile on first call |
| `POST /api/onboarding/consent` / `profile` / `address` | save a step (validated server side; role, level, status in the body are ignored) |
| `POST /api/onboarding/phone/start` / `confirm` | send / check the SMS code |
| `GET /api/locations/suburbs?districtId=` | suburb suggestions |
| `GET/POST/DELETE /api/identity` | list, add, withdraw (unconfirmed only) IDs |
| `POST /api/me/notifications` | email/SMS preferences |
| `GET /api/capability/<name>` | 200 or 403 `{ code }`: call before an action that matters |
| `GET /api/admin/users` | filter by role/status, region, district, ID level or email (one group at a time) |
| `POST /api/admin/users/<uid>/role` / `status` | assign role (super admin) / suspend or restore |
| `GET /api/admin/identity`, `POST /api/admin/identity/<id>/review`, `/reveal` | review queue, decide, see the number (logged) |
| `/api/wallet-link/*` | unchanged (email notifications) |

## Indexes and rules

`firebase/firestore.indexes.json` holds exactly the composite indexes the code's queries need (12). A single-field query or a query of
equality filters only needs none. The local test store **refuses** any query that would need an index missing from that file, so a
missing index shows up in tests, not in production. `firebase/firestore.rules` lets a signed-in user read their own `users/{uid}`
and denies everything else.

## SMS

`SMS_PROVIDER`: `mock` (tests), `console` (dev), `arkesel`, `hubtel`, `http` (any gateway). The Arkesel and Hubtel presets are written
from public descriptions and are **unverified**: check them against your account before relying on them. The sender name must be
at most 11 characters and usually needs registering with the provider (allow about two weeks).

## Commands

| Command | Does |
|---|---|
| `npm run test:accounts` | 26 unit tests (no network) |
| `npm run test:accounts:e2e` | browser test against the Firebase Auth emulator (see `e2e/README.md`) |
| `npm run accounts:set-role -- --email you@x.com --role super_admin --confirm-identity` | make the first administrator |
| `npm run accounts:review-id -- list` | review IDs from the command line |
| `npm run accounts:id-maintenance` | automated checks that are due + delete undecided ID numbers (run hourly once live) |
| `npm run check` | consistency check (locations, roles, indexes, rules, env, routes) + TypeScript |

## Not in Plan A (coming in B and C)

Plan B: a real SMS provider live, the NIA/aggregator check wired into the worker, SMS as a notification channel, the receipts mirror.
Plan C: invites for officers/admins, an admin screen for ID review and audit, account deletion/export (Act 843 rights), stricter limits.

## Known limits

- Firestore itself could not be run where this was built (the emulator download is blocked there). The Firestore backend, the
  rules and the index file are written carefully and the file store imitates the index rule, but **test them on the Firebase
  emulator or a test project before launch** (steps in `firebase/README.md`).
- GitHub and X sign-in buttons are wired but could not be exercised in the build environment (they need the real providers).
- "This number / this ID is already used by another account" tells a caller that the number or ID is registered somewhere. That is unavoidable if each can belong to one account only; it is rate-limited (per account, per number, per network), and the message never says whose it is.
- Account deletion and data export (rights under Act 843) are not built yet (Plan C). Until then handle such requests by hand: delete the `users` document, its `identityDocuments`, `identityClaims`, `phoneClaims`, `walletLinks` entries, and the Firebase Authentication user.
- The phone number is stored in readable form on the user's own document, because notifications need it. Everything else sensitive is hashed or encrypted.
