// Sends one email. NOTIFY_TRANSPORT:
//   smtp    (default) real delivery through EMAIL_SERVER_* (Gmail app password, SendGrid, Mailgun, Amazon SES, ...)
//   outbox  writes each email as a JSON file in notifier/data/outbox/ (local testing, nothing leaves the machine)
//   log     prints a one-line note only
const fs = require("fs");
const path = require("path");
const { root } = require("../server/env.js");

let transporter;

function smtp() {
  if (!transporter) {
    const nodemailer = require("nodemailer");
    const { EMAIL_SERVER_HOST, EMAIL_SERVER_PORT, EMAIL_SERVER_USER, EMAIL_SERVER_PASSWORD, EMAIL_SERVER_SECURE } = process.env;
    if (!EMAIL_SERVER_HOST) throw new Error("EMAIL_SERVER_HOST is not set. See .env.local.example (or use NOTIFY_TRANSPORT=outbox to test locally).");
    const port = Number(EMAIL_SERVER_PORT || 587);
    transporter = nodemailer.createTransport({
      host: EMAIL_SERVER_HOST,
      port,
      secure: EMAIL_SERVER_SECURE ? EMAIL_SERVER_SECURE === "true" : port === 465,
      auth: EMAIL_SERVER_USER ? { user: EMAIL_SERVER_USER, pass: EMAIL_SERVER_PASSWORD } : undefined,
      tls: process.env.EMAIL_SERVER_INSECURE_TLS === "true" ? { rejectUnauthorized: false } : undefined,
    });
  }
  return transporter;
}

async function send({ to, subject, text, html, key }) {
  const from = process.env.EMAIL_FROM || "ClassTryout <no-reply@localhost>";
  const mode = (process.env.NOTIFY_TRANSPORT || "smtp").toLowerCase();
  if (mode === "log") {
    console.log(`[mail:log] to=<hidden> subject="${subject}"`);
    return;
  }
  if (mode === "outbox") {
    const dir = path.join(root, "notifier", "data", "outbox");
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, key.replace(/[^a-zA-Z0-9._-]/g, "_") + ".json");
    fs.writeFileSync(file, JSON.stringify({ from, to, subject, text, html }, null, 2));
    return;
  }
  await smtp().sendMail({ from, to, subject, text, html, headers: { "X-ClassTryout-Event": key } });
}

module.exports = { send };
