// The watcher's memory, kept in one JSON file (NOTIFY_STATE_FILE, default notifier/data/state.json). It holds:
//   cursors      last block fully processed, per chain
//   events       one entry per event already handled (the idempotency record), WITHOUT any email address
//   pending      sends that failed and will be retried
//   owners       pseudonym -> owner wallet, learnt from VehicleRegistered events
//   licenses     hash of licenseId -> { id, vehicle }, learnt from LicenseIssued events
// It must survive restarts (put it on a persistent disk). Delete it to re-scan from the deploy block; already-sent
// emails would then be sent again, except those older than NOTIFY_MAX_AGE_HOURS.
const fs = require("fs");
const path = require("path");
const { root } = require("../server/env.js");

function stateFile() {
  return process.env.NOTIFY_STATE_FILE || path.join(root, "notifier", "data", "state.json");
}

function load() {
  try {
    const s = JSON.parse(fs.readFileSync(stateFile(), "utf8"));
    return { cursors: {}, events: {}, pending: {}, owners: {}, licenses: {}, ...s };
  } catch {
    return { cursors: {}, events: {}, pending: {}, owners: {}, licenses: {} };
  }
}

// Write to a temp file then rename, so a crash mid-write can never leave a half-written state file.
function save(state) {
  const file = stateFile();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(state, null, 2));
  fs.renameSync(tmp, file);
}

module.exports = { load, save, stateFile };
