#!/usr/bin/env node
// Email watcher. Run:
//   npm run notify         keep running and check every NOTIFY_POLL_SECONDS (default 20)
//   npm run notify:once    one pass, then exit (for a cron job)
//   npm run notify:status  show what the watcher knows, then exit
require("../server/env.js");
const { chains } = require("../shared/chains.json");
const { deploymentFor } = require("./deployments.js");
const state = require("./state.js");
const { tick } = require("./watcher.js");

const args = new Set(process.argv.slice(2));
const log = (m) => console.log(`${new Date().toISOString()} ${m}`);

function watchedChains() {
  const wanted = (process.env.NOTIFY_CHAINS || "").split(",").map((s) => s.trim()).filter(Boolean).map(Number);
  return chains.filter((c) => {
    if (wanted.length) return wanted.includes(c.chainId);
    if (c.kind === "Local") return process.env.NOTIFY_LOCAL === "true";
    return !!deploymentFor(c);
  });
}

function status() {
  const s = state.load();
  const counts = {};
  for (const e of Object.values(s.events)) counts[e.status] = (counts[e.status] || 0) + 1;
  console.log("State file:", state.stateFile());
  console.log("Backend:", process.env.NOTIFY_BACKEND || "firebase", "| transport:", process.env.NOTIFY_TRANSPORT || "smtp");
  console.log("Chains watched:", watchedChains().map((c) => `${c.name} (${c.chainId})`).join(", ") || "none");
  console.log("Cursors:", JSON.stringify(s.cursors));
  console.log("Events handled by outcome:", JSON.stringify(counts));
  console.log("Waiting to retry:", Object.keys(s.pending).length);
}

async function once() {
  const s = state.load();
  // A dry run must leave no trace: it would otherwise mark events "handled" and a real run would then skip them.
  const save = process.env.NOTIFY_DRY_RUN === "true" ? () => {} : () => state.save(s);
  for (const chain of watchedChains()) {
    try {
      const r = await tick(chain, s, save, log);
      if (r.skipped) log(`${chain.key}: ${r.skipped}`);
    } catch (e) {
      log(`${chain.key}: ${e.message}`); // one bad RPC must not stop the other chains
    }
  }
}

async function main() {
  if (args.has("--status")) return status();
  if (!watchedChains().length) {
    log("No chain to watch. Deploy the contracts first, or set NOTIFY_CHAINS (and NOTIFY_LOCAL=true for Ganache).");
    if (args.has("--once")) return;
  }
  if (args.has("--once")) return once();
  log(`Watching: ${watchedChains().map((c) => c.name).join(", ")}`);
  const every = Number(process.env.NOTIFY_POLL_SECONDS || 20) * 1000;
  for (;;) {
    await once();
    await new Promise((r) => setTimeout(r, every));
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
