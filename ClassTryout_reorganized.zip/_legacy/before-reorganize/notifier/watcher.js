// Reads new contract events from one chain and sends the emails in shared/notifications.json.
//
// Guarantees (and limits), so nobody is surprised:
//   - Each event is handled once: its key is chainId:txHash:logIndex, recorded in the state file.
//   - Delivery is "at least once": if the process dies between sending and recording, that one email may repeat.
//   - Events are only read once they are NOTIFY_CONFIRMATIONS blocks deep, so a reorganisation cannot cause a
//     notification about something that then vanishes.
//   - A failed send is retried with growing delays (up to 8 attempts), without blocking newer events.
//   - Events older than NOTIFY_MAX_AGE_HOURS (default 72) are recorded but not emailed, so starting the watcher on an
//     old deployment does not mail people about last month. 0 = no limit.
const Web3 = require("web3").Web3;
const { rpcUrl } = require("../shared/rpc.js");
const { notifications } = require("../shared/notifications.json");
const { deploymentFor } = require("./deployments.js");
const { resolve, learn } = require("./resolve.js");
const { templates } = require("./templates.js");
const mailer = require("./mailer.js");
const links = require("../server/links.js");

const ABIS = {
  VehicleRegistry: require("../shared/abi/VehicleRegistry.json"),
  RevocationManager: require("../shared/abi/RevocationManager.json"),
  LicenseRegistry: require("../shared/abi/LicenseRegistry.json"),
};
const MAX_ATTEMPTS = 8;
const short = (a) => `${String(a).slice(0, 6)}…${String(a).slice(-4)}`;
const num = (v) => Number(v);

// web3 returns BigInt for numbers; make everything plain strings so the state file and templates are simple.
function plainArgs(rv) {
  const out = {};
  for (const [k, v] of Object.entries(rv)) if (!/^\d+$/.test(k) && k !== "__length__") out[k] = typeof v === "bigint" ? v.toString() : v;
  return out;
}

async function deliver(chain, key, payload, state, log) {
  const who = await links.emailForWallet(payload.wallet);
  if (!who.email) return { status: `skipped:${who.reason}` };
  const msg = templates[payload.template](payload.data);
  if (process.env.NOTIFY_DRY_RUN === "true") {
    log(`[dry-run] would send "${msg.subject}" for wallet ${short(payload.wallet)}`);
    return { status: "dry-run" };
  }
  await mailer.send({ to: who.email, ...msg, key });
  return { status: "sent" };
}

async function handleEvent(ctx, ev, notif) {
  const { state, log } = ctx;
  const key = `${ctx.chain.chainId}:${ev.txHash}:${ev.logIndex}`;
  if (state.events[key]) return;

  await learn(ctx, ev);

  const maxAgeH = Number(process.env.NOTIFY_MAX_AGE_HOURS ?? 72);
  const ts = num(ev.args[notif.timestampArg]);
  if (maxAgeH > 0 && ts && Date.now() / 1000 - ts > maxAgeH * 3600) {
    state.events[key] = { status: "skipped:too-old", id: notif.id };
    return;
  }

  const r = await resolve(ctx, notif, ev);
  if (r.skip) {
    state.events[key] = { status: `skipped:${r.skip}`, id: notif.id };
    log(`${notif.id} ${short(ev.txHash)} skipped (${r.skip})`);
    return;
  }
  await attempt(ctx, key, { id: notif.id, wallet: r.wallet, template: r.template, data: r.data }, 0);
}

async function attempt(ctx, key, payload, attempts) {
  const { state, log } = ctx;
  try {
    const out = await deliver(ctx.chain, key, payload, state, log);
    state.events[key] = { status: out.status, id: payload.id, wallet: payload.wallet };
    delete state.pending[key];
    log(`${payload.id} -> wallet ${short(payload.wallet)}: ${out.status}`);
  } catch (e) {
    const n = attempts + 1;
    if (n >= MAX_ATTEMPTS) {
      state.events[key] = { status: "failed", id: payload.id, wallet: payload.wallet, error: String(e.message).slice(0, 200) };
      delete state.pending[key];
      log(`${payload.id} -> wallet ${short(payload.wallet)}: GAVE UP after ${n} attempts (${e.message})`);
    } else {
      const delaySec = Math.min(30 * 2 ** n, 3600);
      state.pending[key] = { payload, attempts: n, nextAt: Date.now() + delaySec * 1000, error: String(e.message).slice(0, 200) };
      log(`${payload.id} -> wallet ${short(payload.wallet)}: send failed (${e.message}); retry in ${delaySec}s`);
    }
  }
}

async function retryPending(ctx) {
  for (const [key, p] of Object.entries(ctx.state.pending)) {
    if (!key.startsWith(`${ctx.chain.chainId}:`) || p.nextAt > Date.now()) continue;
    await attempt(ctx, key, p.payload, p.attempts);
    ctx.save();
  }
}

// Read events in [from, to], halving the range when the RPC rejects it as too large.
async function readRange(ctx, from, to) {
  try {
    const all = [];
    for (const [name, contract] of Object.entries(ctx.contracts)) {
      const wanted = new Set(notifications.filter((n) => n.contract === name).map((n) => n.event));
      const evs = await contract.getPastEvents("allEvents", { fromBlock: from, toBlock: to });
      for (const e of evs) {
        if (!wanted.has(e.event)) continue;
        all.push({ event: e.event, args: plainArgs(e.returnValues), txHash: e.transactionHash, blockNumber: num(e.blockNumber), logIndex: num(e.logIndex) });
      }
    }
    return all.sort((x, y) => x.blockNumber - y.blockNumber || x.logIndex - y.logIndex);
  } catch (e) {
    if (to > from) {
      const mid = from + Math.floor((to - from) / 2);
      return [...(await readRange(ctx, from, mid)), ...(await readRange(ctx, mid + 1, to))];
    }
    throw e;
  }
}

// One pass over one chain. Safe to call repeatedly.
async function tick(chain, state, save, log) {
  const dep = deploymentFor(chain);
  if (!dep) return { skipped: "not deployed" };

  const web3 = new Web3(rpcUrl(chain));
  const actual = num(await web3.eth.getChainId());
  if (actual !== chain.chainId) throw new Error(`RPC for ${chain.key} reports chain ${actual}, expected ${chain.chainId}. Check RPC_URL_${chain.key.toUpperCase()}.`);

  const contracts = {};
  for (const name of Object.keys(ABIS)) contracts[name] = new web3.eth.Contract(ABIS[name], dep[name].address);
  const ctx = {
    web3, chain, state, save, log, contracts,
    c: { registry: contracts.VehicleRegistry, revocation: contracts.RevocationManager, license: contracts.LicenseRegistry },
  };

  const startBlock = Math.min(...Object.keys(ABIS).map((n) => num(dep[n].startBlock || 0)));
  const depKey = Object.keys(ABIS).map((n) => dep[n].address.toLowerCase()).join(",");
  const cid = String(chain.chainId);
  state.deployed = state.deployed || {};

  let cursor = state.cursors[cid];
  const head = num(await web3.eth.getBlockNumber());
  // New deployment on this chain (or a reset local chain): start again from its first block.
  if (cursor === undefined || state.deployed[cid] !== depKey || cursor > head) {
    if (cursor !== undefined) log(`chain ${chain.key}: deployment changed or chain was reset, rescanning from block ${startBlock}`);
    cursor = Math.max(startBlock - 1, -1);
    state.deployed[cid] = depKey;
    state.cursors[cid] = cursor;
  }

  const confirmations = chain.kind === "Local" ? 0 : Number(process.env.NOTIFY_CONFIRMATIONS ?? 5);
  const safeHead = head - confirmations;
  const maxRange = Number(process.env.NOTIFY_MAX_BLOCK_RANGE || 1000);
  let handled = 0;

  while (cursor < safeHead) {
    const from = cursor + 1;
    const to = Math.min(safeHead, from + maxRange - 1);
    for (const ev of await readRange(ctx, from, to)) {
      const notif = notifications.find((n) => n.event === ev.event);
      await handleEvent(ctx, ev, notif);
      handled++;
    }
    cursor = to;
    state.cursors[cid] = cursor;
    save();
  }
  await retryPending(ctx);
  save();
  return { head, cursor, handled };
}

module.exports = { tick };
