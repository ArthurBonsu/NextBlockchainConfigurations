// Finds the contract addresses (and the block to start scanning from) for a chain, from the same two files the
// front end reads: shared/deployments.json (public chains, keyed by chain id) and shared/deployments.local.json.
const fs = require("fs");
const path = require("path");
const { root } = require("../server/env.js");
const { contracts } = require("../shared/contracts.json");

function readJson(rel) {
  try {
    return JSON.parse(fs.readFileSync(path.join(root, rel), "utf8"));
  } catch {
    return {};
  }
}

const complete = (d) => (d && contracts.every((n) => d[n] && d[n].address) ? d : undefined);

function deploymentFor(chain) {
  const pub = complete(readJson("shared/deployments.json")[String(chain.chainId)]);
  if (pub) return pub;
  const local = readJson("shared/deployments.local.json");
  return complete(Object.values(local).find((d) => d && typeof d === "object" && d.chainId === chain.chainId));
}

module.exports = { deploymentFor };
