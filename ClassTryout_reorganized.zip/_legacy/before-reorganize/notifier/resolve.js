// Turns one decoded blockchain event into "who gets which email, with what details".
//
// Why this is not trivial: events carry what the contract chose to log.
//   - VehicleRegistered / LicenseIssued log `string indexed` fields, so the log holds only a hash of the pseudonym /
//     license id. We recover the readable text from the transaction input (which has the real arguments) and check
//     it against the hash, then fall back to reading the contract.
//   - LicenseIssued's `owner` is the wallet that SENT the issue transaction, not the vehicle's owner. The email goes
//     to the owner of the vehicle (looked up from the registry), and names the issuing wallet.
const abis = {
  VehicleRegistry: require("../shared/abi/VehicleRegistry.json"),
  LicenseRegistry: require("../shared/abi/LicenseRegistry.json"),
};
const ZERO = "0x0000000000000000000000000000000000000000";

// Decode the arguments of a transaction sent straight to one of our contracts. Returns null if it was not
// (e.g. it went through a multisig/contract wallet), in which case callers fall back to other sources.
async function txArgs(ctx, txHash, contractName, fnName) {
  try {
    const tx = await ctx.web3.eth.getTransaction(txHash);
    const fn = abis[contractName].find((x) => x.type === "function" && x.name === fnName);
    const selector = ctx.web3.eth.abi.encodeFunctionSignature(fn);
    const input = String(tx.input || tx.data || "");
    if (!input.startsWith(selector)) return null;
    return ctx.web3.eth.abi.decodeParameters(fn.inputs, "0x" + input.slice(10));
  } catch {
    return null;
  }
}

const hashOf = (ctx, s) => ctx.web3.utils.keccak256(s);
const matches = (ctx, text, hash) => typeof text === "string" && text.length > 0 && hashOf(ctx, text) === String(hash).toLowerCase();

async function ownerOfVehicle(ctx, pseudonym) {
  const known = ctx.state.owners[`${ctx.chain.chainId}:${pseudonym}`];
  if (known) return known;
  try {
    const v = await ctx.c.registry.methods.getVehicle(pseudonym).call();
    if (v.owner && v.owner !== ZERO) return v.owner;
  } catch {}
  return null;
}

// Learn readable names from events that carry them (called for every event, even ones we will not email about,
// so later events that only carry a hash can still be understood).
async function learn(ctx, ev) {
  const cid = ctx.chain.chainId;
  if (ev.event === "VehicleRegistered") {
    const p = await readPseudonym(ctx, ev);
    if (p) ctx.state.owners[`${cid}:${p}`] = ev.args.owner;
  }
  if (ev.event === "LicenseIssued") {
    const id = await readLicenseId(ctx, ev);
    if (id) ctx.state.licenses[`${cid}:${String(ev.args.licenseId).toLowerCase()}`] = { id, vehicle: ev.args.vehiclePseudonym };
  }
}

async function readPseudonym(ctx, ev) {
  const hash = ev.args.pseudonym;
  const fromTx = await txArgs(ctx, ev.txHash, "VehicleRegistry", "registerVehicle");
  if (fromTx && matches(ctx, fromTx._pseudonym, hash)) return fromTx._pseudonym;
  try {
    const current = await ctx.c.registry.methods.getPseudonymByOwner(ev.args.owner).call();
    if (matches(ctx, current, hash)) return current;
  } catch {}
  return null;
}

async function readLicenseId(ctx, ev) {
  const hash = ev.args.licenseId;
  const fn = { LicenseIssued: "issueLicense", LicenseRevoked: "revokeLicense", LicenseReinstated: "reinstateLicense" }[ev.event];
  const fromTx = await txArgs(ctx, ev.txHash, "LicenseRegistry", fn);
  if (fromTx && matches(ctx, fromTx._licenseId, hash)) return fromTx._licenseId;
  if (ev.args.vehiclePseudonym) {
    try {
      const latest = await ctx.c.license.methods.getLicenseByVehicle(ev.args.vehiclePseudonym).call();
      if (matches(ctx, latest, hash)) return latest;
    } catch {}
  }
  return null;
}

// -> { skip: "reason" } | { wallet, template, data }
async function resolve(ctx, notif, ev) {
  const a = ev.args;
  const base = { network: ctx.chain.name, explorerUrl: ctx.chain.explorer ? `${ctx.chain.explorer}/tx/${ev.txHash}` : "", appUrl: process.env.APP_URL || "" };

  switch (notif.id) {
    case "registration": {
      const pseudonym = (await readPseudonym(ctx, ev)) || "(see the transaction)";
      return { wallet: a.owner, template: "registration", data: { ...base, wallet: a.owner, pseudonym, timestamp: a.timestamp } };
    }
    case "revocation":
    case "reinstatement": {
      const wallet = await ownerOfVehicle(ctx, a.pseudonym);
      if (!wallet) return { skip: "owner-unknown" };
      return { wallet, template: notif.id, data: { ...base, wallet, pseudonym: a.pseudonym, reason: a.reason, timestamp: a.timestamp } };
    }
    case "licenseIssued": {
      const wallet = await ownerOfVehicle(ctx, a.vehiclePseudonym);
      if (!wallet) return { skip: "owner-unknown" };
      const licenseId = (await readLicenseId(ctx, ev)) || "";
      return { wallet, template: "licenseIssued", data: { ...base, wallet, pseudonym: a.vehiclePseudonym, licenseId, licenseType: a.licenseType, expiryTime: a.expiryTime, issuer: a.owner } };
    }
    case "licenseRevoked":
    case "licenseReinstated": {
      const cached = ctx.state.licenses[`${ctx.chain.chainId}:${String(a.licenseId).toLowerCase()}`];
      const licenseId = cached ? cached.id : await readLicenseId(ctx, ev);
      let vehicle = a.vehiclePseudonym || (cached && cached.vehicle);
      if (!vehicle && licenseId) {
        try {
          vehicle = (await ctx.c.license.methods.getLicense(licenseId).call()).vehiclePseudonym;
        } catch {}
      }
      if (!vehicle) return { skip: "license-unknown" };
      const wallet = await ownerOfVehicle(ctx, vehicle);
      if (!wallet) return { skip: "owner-unknown" };
      return { wallet, template: notif.id, data: { ...base, wallet, pseudonym: vehicle, licenseId: licenseId || "", timestamp: a.timestamp } };
    }
    default:
      return { skip: "no-handler" };
  }
}

module.exports = { resolve, learn };
