// Email wording. One function per template id in shared/notifications.json. Each returns { subject, text, html }.
// `d` always has: network (name), explorerUrl (may be ""), appUrl (may be ""), wallet, plus the fields used below.
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const when = (unix) => (unix ? new Date(Number(unix) * 1000).toUTCString() : "");

function layout(d, title, lines, footerNote) {
  const textLines = [...lines.map((l) => (Array.isArray(l) ? `${l[0]}: ${l[1]}` : l))];
  if (d.explorerUrl) textLines.push("", `Transaction: ${d.explorerUrl}`);
  if (d.appUrl) textLines.push(`Open ClassTryout: ${d.appUrl}`);
  textLines.push("", footerNote || "You get this email because your wallet is linked to your ClassTryout account. You can unlink it any time in the app.");

  const rows = lines
    .map((l) =>
      Array.isArray(l)
        ? `<tr><td style="padding:4px 12px 4px 0;color:#555">${esc(l[0])}</td><td style="padding:4px 0"><strong>${esc(l[1])}</strong></td></tr>`
        : ""
    )
    .join("");
  const intro = lines.filter((l) => !Array.isArray(l) && l !== "").map((l) => `<p style="margin:0 0 12px">${esc(l)}</p>`).join("");
  const html =
    `<div style="font-family:Arial,Helvetica,sans-serif;font-size:15px;color:#111;max-width:560px">` +
    `<h2 style="margin:0 0 16px">${esc(title)}</h2>${intro}<table style="border-collapse:collapse;margin:8px 0 16px">${rows}</table>` +
    (d.explorerUrl ? `<p style="margin:0 0 8px"><a href="${esc(d.explorerUrl)}">View the transaction</a></p>` : "") +
    (d.appUrl ? `<p style="margin:0 0 16px"><a href="${esc(d.appUrl)}">Open ClassTryout</a></p>` : "") +
    `<p style="margin:16px 0 0;color:#666;font-size:12px">${esc(footerNote || "You get this email because your wallet is linked to your ClassTryout account. You can unlink it any time in the app.")}</p></div>`;
  return { text: textLines.join("\n"), html };
}

const templates = {
  registration: (d) => ({
    subject: `Registration confirmed: ${d.pseudonym}`,
    ...layout(d, "Your vehicle registration is confirmed", [
      "Your registration was recorded on the blockchain.",
      "",
      ["Pseudonym", d.pseudonym],
      ["Wallet", d.wallet],
      ["Network", d.network],
      ["Registered", when(d.timestamp)],
    ]),
  }),
  revocation: (d) => ({
    subject: `Notice: your registration ${d.pseudonym} has been revoked`,
    ...layout(d, "Your registration has been revoked", [
      "The administrator has revoked this registration. Licenses tied to it are no longer valid while it is revoked.",
      "",
      ["Pseudonym", d.pseudonym],
      ["Reason", d.reason || "(none given)"],
      ["Network", d.network],
      ["Revoked", when(d.timestamp)],
    ], "If you think this is a mistake, contact the administrator. Records on the blockchain are public and permanent. You get this email because your wallet is linked to your ClassTryout account."),
  }),
  reinstatement: (d) => ({
    subject: `Good news: your registration ${d.pseudonym} has been reinstated`,
    ...layout(d, "Your registration has been reinstated", [
      "The administrator has lifted the revocation on this registration.",
      "",
      ["Pseudonym", d.pseudonym],
      ["Network", d.network],
      ["Reinstated", when(d.timestamp)],
    ]),
  }),
  licenseIssued: (d) => ({
    subject: `A license was issued for ${d.pseudonym}`,
    ...layout(d, "A license was issued for your vehicle", [
      "A license was recorded on the blockchain for your registration.",
      "",
      ["License", d.licenseId || "(see the transaction)"],
      ["Type", d.licenseType],
      ["Vehicle", d.pseudonym],
      ["Valid until", when(d.expiryTime)],
      ["Issued by wallet", d.issuer],
      ["Network", d.network],
    ], "If you did not expect this license, contact the administrator. You get this email because your wallet is linked to your ClassTryout account."),
  }),
  licenseRevoked: (d) => ({
    subject: `License ${d.licenseId || ""} has been revoked`.replace("  ", " "),
    ...layout(d, "Your license has been revoked", [
      "The administrator has revoked this license. It is not valid until it is reinstated.",
      "",
      ["License", d.licenseId || "(see the transaction)"],
      ["Vehicle", d.pseudonym],
      ["Network", d.network],
      ["Revoked", when(d.timestamp)],
    ]),
  }),
  licenseReinstated: (d) => ({
    subject: `License ${d.licenseId || ""} has been reinstated`.replace("  ", " "),
    ...layout(d, "Your license has been reinstated", [
      "The administrator has reinstated this license.",
      "",
      ["License", d.licenseId || "(see the transaction)"],
      ["Vehicle", d.pseudonym],
      ["Network", d.network],
      ["Reinstated", when(d.timestamp)],
    ]),
  }),
};

module.exports = { templates };
