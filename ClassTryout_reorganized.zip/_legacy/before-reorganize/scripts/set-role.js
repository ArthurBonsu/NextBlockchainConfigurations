#!/usr/bin/env node
// Give an account a role from the command line. This is how the FIRST super administrator is made (nobody can promote themselves
// through the app). Run it on a machine that has the server .env.local (Firebase Admin credentials).
//
//   node scripts/set-role.js --email you@example.com --role super_admin
//   node scripts/set-role.js --uid <firebase uid> --role officer
//   node scripts/set-role.js --email you@example.com --role super_admin --confirm-identity
//        (also marks their ID as confirmed: ONLY for the founding administrators whose ID you have seen in person,
//         because the first reviewer cannot be confirmed by anyone else. It is recorded in the audit log.)
//   node scripts/set-role.js --list                      show admins and officers
//
// The person must have signed in once (so their profile exists). Their sessions are revoked so the new role applies at once.
require("../server/env.js");
const { store } = require("../server/store.js");
const users = require("../server/users.js");
const { ROLES } = require("../server/roles.js");

function arg(name) {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 ? process.argv[i + 1] : undefined;
}

(async () => {
  if (process.argv.includes("--list")) {
    for (const role of ["super_admin", "admin", "officer"]) {
      for (const u of await users.listUsers({ role })) console.log(`${role.padEnd(12)} ${u.uid}  ${u.email || "(no email)"}  ${u.status}`);
    }
    return;
  }
  const role = arg("role");
  if (!ROLES.includes(role)) {
    console.error(`Usage: node scripts/set-role.js (--email <address> | --uid <uid>) --role <${ROLES.join("|")}>`);
    process.exit(2);
  }
  let uid = arg("uid");
  if (!uid && arg("email")) {
    const rows = await store().query("users", { where: [["email", "==", arg("email").toLowerCase()]], limit: 2 });
    if (rows.length !== 1) {
      console.error(rows.length ? "More than one account has that email; use --uid." : "No account has that email. Ask them to sign in once first.");
      process.exit(1);
    }
    uid = rows[0].uid;
  }
  if (!uid) {
    console.error("Give --email or --uid.");
    process.exit(2);
  }
  const u = await users.assignRole({ uid: "system", role: "system" }, uid, role, null);
  if (process.argv.includes("--confirm-identity")) {
    await users.bootstrapConfirmIdentity(uid, arg("note"));
    console.log("Identity marked confirmed (bootstrap, audit-logged).");
  }
  console.log(`OK: ${u.email || u.uid} is now ${u.role}. They must sign in again.`);
})().catch((e) => {
  console.error("Failed:", e.message);
  process.exit(1);
});
