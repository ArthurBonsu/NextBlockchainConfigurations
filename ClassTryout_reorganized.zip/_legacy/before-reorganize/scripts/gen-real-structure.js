#!/usr/bin/env node
// Writes docs/firebaserealstructure.txt: what REAL documents look like, in the same layout as the Firebase console's
// "field / value / (type)" listing. The documents are produced by running the actual server code (on the local file store)
// with made-up people, so the shapes cannot drift from the code. Hash and ciphertext values are genuine outputs of the code
// with throwaway development keys: they are examples, not anyone's data.
//
//   npm run docs:structure            rewrite docs/firebaserealstructure.txt
//   npm run docs:structure -- --check fail if a field the code writes is missing from docs/database.md
const fs = require("fs");
const os = require("os");
const path = require("path");

const root = path.resolve(__dirname, "..");
const dir = fs.mkdtempSync(path.join(os.tmpdir(), "ct-structure-"));
Object.assign(process.env, {
  NODE_ENV: "test", STORE_BACKEND: "file", STORE_FILE: path.join(dir, "store.json"),
  SMS_PROVIDER: "mock", SMS_OUTBOX_FILE: path.join(dir, "sms.jsonl"), NOTIFY_BACKEND: "dev", PROJECT_ROOT: root,
});
delete process.env.ID_HASH_PEPPER; delete process.env.OTP_SECRET; delete process.env.ID_ENC_KEY;
const origWarn = console.warn; console.warn = () => {};

const h = require(path.join(root, "test/accounts/helpers.js"));
const users = require(path.join(root, "server/users.js"));
const otp = require(path.join(root, "server/otp.js"));
const identity = require(path.join(root, "server/identity/index.js"));
const { store } = require(path.join(root, "server/store.js"));
const { hit } = require(path.join(root, "server/rateLimit.js"));

// ---- a small, believable scenario -----------------------------------------------------------------------------------
async function scenario() {
  const SYSTEM = { uid: "system", role: "system" };
  const mk = async (uid, email, phone) => { await h.complete(uid, phone); await store().update("users", uid, { email }); };

  await mk("uid_EXAMPLE_citizen", "ama.mensah@example.test", "0241234567");
  await users.saveNotificationPrefs("uid_EXAMPLE_citizen", { sms: false });
  const d1 = await identity.submitDocument("uid_EXAMPLE_citizen", { type: "ghana_card", number: "GHA-123456789-0" }, "203.0.113.7");

  await mk("uid_EXAMPLE_admin", "kwame.admin@example.test", "0551234567");
  await users.assignRole(SYSTEM, "uid_EXAMPLE_admin", "super_admin", null);
  await users.bootstrapConfirmIdentity("uid_EXAMPLE_admin", "Confirmed in person");
  const admin = await users.requireUser("uid_EXAMPLE_admin");
  await identity.decide({ docId: d1.id, decision: "verified", by: { uid: admin.uid, role: admin.role }, note: "Matches card", checker: "manual" });

  await mk("uid_EXAMPLE_officer", "yaw.officer@example.test", "0261234567");
  await users.assignRole(admin, "uid_EXAMPLE_officer", "officer", "203.0.113.9");
  const exp = new Date(Date.now() + 4 * 365 * 864e5).toISOString().slice(0, 10);
  await identity.submitDocument("uid_EXAMPLE_officer", { type: "passport", number: "G1234567", country: "GH", expiry: exp }); // still pending: shows encNumber

  // someone part-way through onboarding: a live phone code and no ID
  await users.ensureUser(h.auth("uid_EXAMPLE_newcomer", "efua.new@example.test", false));
  await users.saveConsents("uid_EXAMPLE_newcomer", { terms: true, privacy: true, sms: true }, "198.51.100.4");
  await otp.startPhoneVerification("uid_EXAMPLE_newcomer", "0201234567", "198.51.100.4");

  await users.saveAddress("uid_EXAMPLE_officer", { regionCode: "ASH", districtId: "ASH-kumasi", city: "Kumasi", suburb: "Adum", subarea: "Near the market", gpsAddress: "AK-039-5028", lat: 6.6885, lng: -1.6244 });
  await hit("otp:ip:198.51.100.4", 20, 3600);
  await store().set("walletLinks", "0x90f8bf6a479f320ead074411a4b0e7944ea8c9c1", { uid: "uid_EXAMPLE_citizen", address: "0x90f8bf6a479f320ead074411a4b0e7944ea8c9c1", linkedAt: new Date().toISOString() });
}

// ---- rendering (same layout as the Firebase console listing) ---------------------------------------------------
const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
function ts(iso) {
  const d = new Date(iso);
  let hr = d.getUTCHours();
  const ap = hr >= 12 ? "PM" : "AM";
  hr = hr % 12 || 12;
  const p = (n) => String(n).padStart(2, "0");
  return `${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()} at ${hr}:${p(d.getUTCMinutes())}:${p(d.getUTCSeconds())} ${ap} UTC+0`;
}
const TIMESTAMP_FIELDS = new Set(["expireAt"]); // the only field stored as a real Firestore Timestamp; every other time is an ISO string

function render(key, v, out, topLevel = false) {
  if (v === null) return out.push(key, "null", "(null)", "", "");
  if (Array.isArray(v)) {
    out.push("", key, "(array)", "", "");
    v.forEach((x, i) => render(String(i), x, out));
    return;
  }
  if (typeof v === "object") {
    out.push("", key, "(map)", "", "");
    for (const k of Object.keys(v).sort()) render(k, v[k], out);
    return;
  }
  if (typeof v === "boolean") return out.push(key, String(v), "(boolean)", "", "");
  if (typeof v === "number") return out.push(key, String(v), Number.isInteger(v) ? "(int64)" : "(double)", "", "");
  if (TIMESTAMP_FIELDS.has(key) && typeof v === "string") return out.push(key, ts(v), "(timestamp)", "", "");
  return out.push(key, JSON.stringify(v), "(string)", "", "");
}

const ORDER = ["users", "identityDocuments", "identityClaims", "phoneChallenges", "phoneClaims", "locationSuggestions", "rateLimits", "auditLogs", "walletLinks"];
// the order in which collections are explained; the example for each is one real document

function fieldPaths(v, prefix = "", acc = new Set()) {
  if (v && typeof v === "object" && !Array.isArray(v)) for (const [k, x] of Object.entries(v)) { acc.add(k); fieldPaths(x, prefix + k + ".", acc); }
  return acc;
}

(async () => {
  await scenario();
  const db = JSON.parse(fs.readFileSync(process.env.STORE_FILE, "utf8"));
  const out = [];
  out.push("[Real structure of the ClassTryout Firestore database: one real document per collection, produced by running the actual code",
    " with made-up people (names, numbers and ids are examples). Layout follows the Firebase console listing: field, value, (type).",
    " Every time is an ISO-8601 STRING except `expireAt`, a real Timestamp used by the TTL clean-up. Hash and ciphertext values are",
    " genuine outputs of the code with throwaway development keys. Regenerate with:  npm run docs:structure ]", "");
  const seen = {};
  for (const col of ORDER) {
    const docs = db[col] || {};
    const ids = Object.keys(docs);
    if (!ids.length) continue;
    // choose a representative document per collection
    let id = ids[0];
    if (col === "users") id = "uid_EXAMPLE_citizen";
    if (col === "identityDocuments") id = ids.find((i) => docs[i].status === "pending_review") || id;
    if (col === "auditLogs") id = ids.find((i) => docs[i].action === "user.role") || id;
    const doc = docs[id];
    seen[col] = fieldPaths(doc);
    out.push(`${col}: `, `(document id: ${col === "users" || col === "phoneChallenges" ? id : id.length > 40 ? id.slice(0, 12) + "…" : id})`, "");
    for (const k of Object.keys(doc).sort()) render(k, doc[k], out, true);
    out.push("");
    if (col === "identityDocuments") {
      // a confirmed one, to show the number is gone after the decision
      const v = ids.find((i) => docs[i].status === "verified");
      if (v) { out.push("identityDocuments (after confirmation): ", `(document id: ${v})`, ""); for (const k of Object.keys(docs[v]).sort()) render(k, docs[v][k], out, true); out.push(""); fieldPaths(docs[v]).forEach((f) => seen[col].add(f)); }
    }
    // every document of the collection counts for the "is it documented" check, not only the one printed
    for (const other of Object.values(docs)) fieldPaths(other).forEach((f) => seen[col].add(f));
  }
  const text = out.join("\n").replace(/\n{4,}/g, "\n\n\n");

  if (process.argv.includes("--check")) {
    const md = fs.readFileSync(path.join(root, "docs/database.md"), "utf8");
    const missing = [];
    for (const [col, fields] of Object.entries(seen)) {
      const i = md.indexOf(`📁 ${col}/`);
      if (i < 0) { missing.push(`${col} (collection not in docs/database.md)`); continue; }
      const nx = [md.indexOf("\n├── 📁", i + 10), md.indexOf("\n└── 📁", i + 10)].filter((n) => n > 0);
      const next = nx.length ? Math.min(...nx) : -1;
      const section = md.slice(i, next < 0 ? undefined : next);
      for (const f of fields) if (!new RegExp(`[├└│ ]\\s*${f.replace(/[$]/g, "\\$")}\\??:`).test(section) && !section.includes(`${f}:`)) missing.push(`${col}.${f}`);
    }
    console.warn = origWarn;
    if (missing.length) { console.error("docs/database.md is missing fields the code writes:\n - " + missing.join("\n - ")); process.exit(1); }
    console.log(`docs/database.md covers every field the code wrote in the sample (${Object.keys(seen).length} collections).`);
    return;
  }
  fs.writeFileSync(path.join(root, "docs/firebaserealstructure.txt"), text + "\n");
  console.warn = origWarn;
  console.log(`Wrote docs/firebaserealstructure.txt (${text.split("\n").length} lines, ${Object.keys(seen).length} collections).`);
})().catch((e) => { console.error(e); process.exit(1); });
