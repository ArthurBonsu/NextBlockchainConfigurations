#!/usr/bin/env node
// Run on a schedule (hourly is plenty): automated ID checks that are due, then delete ID numbers nobody decided on in time.
//   node scripts/id-maintenance.js           both
//   node scripts/id-maintenance.js --purge   only the purge
// With no automated checker switched on (ID_CHECK_NIA unset) the first step does nothing and every ID waits for a human.
require("../server/env.js");
const { processDue } = require("../server/identity/worker.js");
const { purgeExpired } = require("../server/identity/index.js");

(async () => {
  if (!process.argv.includes("--purge")) console.log("checks:", JSON.stringify(await processDue()));
  console.log("purged:", await purgeExpired());
})().catch((e) => { console.error("Failed:", e.message); process.exit(1); });
