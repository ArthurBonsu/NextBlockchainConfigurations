#!/usr/bin/env node
// Command-line ID review, for the early days before an admin screen exists (the same checks as the API: audit-logged).
//   node scripts/review-id.js list [--status pending_review]
//   node scripts/review-id.js show   <docId> --as <your admin uid>      (decrypts the number; this is logged)
//   node scripts/review-id.js verify <docId> --as <your admin uid> [--note "text"]
//   node scripts/review-id.js reject <docId> --as <your admin uid> [--note "text"]
require("../server/env.js");
const idn = require("../server/identity/index.js");
const users = require("../server/users.js");
const roles = require("../server/roles.js");
const { onboardingState } = require("../server/users.js");

const [cmd, docId] = process.argv.slice(2);
const arg = (n) => { const i = process.argv.indexOf(`--${n}`); return i > -1 ? process.argv[i + 1] : undefined; };

async function reviewer() {
  const uid = arg("as");
  if (!uid) throw new Error("Add --as <your admin uid> so the decision is attributed to you.");
  const u = await users.requireUser(uid);
  const r = roles.check(u, "admin:ids:review", { onboardingComplete: onboardingState(u).complete });
  if (!r.allowed) throw new Error(`Account ${uid} may not review IDs (${r.reason}).`);
  return { uid: u.uid, role: u.role };
}

(async () => {
  if (cmd === "list") {
    const rows = await idn.reviewQueue({ status: arg("status") || "pending_review" });
    if (!rows.length) console.log("Nothing waiting.");
    for (const d of rows) console.log(`${d.id}  ${d.type.padEnd(11)} ••••${d.last4}  owner ${d.uid}  ${d.createdAt}`);
  } else if (cmd === "show") {
    const r = await idn.revealNumber(await reviewer(), docId, null);
    console.log(JSON.stringify(r, null, 2));
  } else if (cmd === "verify" || cmd === "reject") {
    await idn.decide({ docId, decision: cmd === "verify" ? "verified" : "rejected", by: await reviewer(), note: arg("note"), checker: "manual" });
    console.log(`OK: ${docId} ${cmd === "verify" ? "confirmed" : "rejected"}.`);
  } else {
    console.error("Commands: list | show <id> | verify <id> | reject <id>   (see the comment at the top of this file)");
    process.exit(2);
  }
})().catch((e) => { console.error("Failed:", e.message); process.exit(1); });
