#!/usr/bin/env node
// "Does everything pull the same thing?" Run with:  npm run check
//
// Fails (exit 1) when the contracts, ABIs, migrations, deployments, chains and front end have drifted apart.
const fs = require("fs");
const path = require("path");
const { abiFiles, normalizeAbi } = require("./sync-contracts.js");

const root = path.resolve(__dirname, "..");
const rel = (p) => path.relative(root, p).split(path.sep).join("/");
const read = (p) => fs.readFileSync(p, "utf8");
const exists = (p) => fs.existsSync(p);
const readJson = (p) => JSON.parse(read(p));
const errors = [];
const warnings = [];
const fail = (msg) => errors.push(msg);
const warn = (msg) => warnings.push(msg);

function walk(dir, exts, out = []) {
  if (!exists(dir)) return out;
  for (const name of fs.readdirSync(dir)) {
    if (name === "node_modules" || name === ".next" || name === "build") continue;
    const p = path.join(dir, name);
    const st = fs.statSync(p);
    if (st.isDirectory()) walk(p, exts, out);
    else if (exts.some((e) => name.endsWith(e))) out.push(p);
  }
  return out;
}

const { contracts } = readJson(path.join(root, "shared/contracts.json"));
const { chains } = readJson(path.join(root, "shared/chains.json"));

// ---- 1. chains.json ----------------------------------------------------------------------------------
{
  const ids = new Set();
  const keys = new Set();
  for (const c of chains) {
    if (ids.has(c.chainId)) fail(`shared/chains.json: duplicate chainId ${c.chainId}`);
    if (keys.has(c.key)) fail(`shared/chains.json: duplicate key "${c.key}"`);
    ids.add(c.chainId);
    keys.add(c.key);
    for (const f of ["chainId", "key", "name", "kind", "testnet", "rpcUrls", "currency"]) {
      if (c[f] === undefined) fail(`shared/chains.json: ${c.key || c.chainId} is missing "${f}"`);
    }
  }
}

// ---- 2. ABIs: present, in sync with each other, and in sync with the compiled contracts ----------------
const abis = {};
for (const name of contracts) {
  const j = path.join(root, "shared/abi", `${name}.json`);
  const t = path.join(root, "shared/abi", `${name}.ts`);
  if (!exists(j) || !exists(t)) {
    fail(`ABI for ${name} is missing in shared/abi/. Run: npm run contracts:compile`);
    continue;
  }
  const abi = readJson(j);
  abis[name] = abi;
  const expected = abiFiles(name, abi);
  if (read(t) !== expected.ts) fail(`shared/abi/${name}.ts does not match ${name}.json. Run: npm run contracts:sync`);
  if (!exists(path.join(root, "contracts", `${name}.sol`))) fail(`contracts/${name}.sol is listed in shared/contracts.json but does not exist`);

  const artifact = path.join(root, "build/contracts", `${name}.json`);
  if (exists(artifact)) {
    if (JSON.stringify(normalizeAbi(readJson(artifact).abi)) !== JSON.stringify(abi)) {
      fail(`${name}: the compiled contract differs from shared/abi/${name}.json (Solidity changed, ABI not synced). Run: npm run contracts:compile`);
    }
  } else {
    warn(`build/contracts/${name}.json not found: skipped the "compiled vs shared ABI" check (run truffle compile to include it)`);
  }
}

const methodsOf = (name) => new Set((abis[name] || []).filter((x) => x.type === "function").map((x) => x.name));
const eventsOf = (name) => new Set((abis[name] || []).filter((x) => x.type === "event").map((x) => x.name));
const allEvents = new Set(Object.keys(abis).flatMap((n) => [...eventsOf(n)]));

// ---- 3. Front end only uses methods and events that exist ---------------------------------------------
const variableToContract = { registry: "VehicleRegistry", revocation: "RevocationManager", license: "LicenseRegistry" };
const appFiles = [
  ...walk(path.join(root, "components"), [".ts", ".tsx"]),
  ...walk(path.join(root, "pages"), [".ts", ".tsx"]),
  ...walk(path.join(root, "utils"), [".ts", ".tsx"]),
  // the email watcher and its helpers read the same ABIs, so they are held to the same rules
  ...walk(path.join(root, "notifier"), [".js"]),
  ...walk(path.join(root, "server"), [".js"]),
];
for (const file of appFiles) {
  const src = read(file);
  for (const m of src.matchAll(/\b(registry|revocation|license)\.methods\.(\w+)\s*\(/g)) {
    const [, v, fn] = m;
    if (!methodsOf(variableToContract[v]).has(fn)) fail(`${rel(file)}: calls ${v}.methods.${fn}() but ${variableToContract[v]} has no such function`);
  }
  for (const m of src.matchAll(/\b(registry|revocation|license)\.methods\[\s*(\w+)\s*\]/g)) {
    // dynamic call such as license.methods[action]; the typed ABI (tsc) checks it
    void m;
  }
  for (const m of src.matchAll(/\b(registry|revocation|license)\.getPastEvents\(\s*["'](\w+)["']/g)) {
    const [, v, ev] = m;
    if (!eventsOf(variableToContract[v]).has(ev)) fail(`${rel(file)}: reads event ${ev} from ${variableToContract[v]}, which does not emit it`);
  }
  for (const m of src.matchAll(/\.events(?:\s+as\s+any\))?\??\.(\w+)/g)) {
    if (!allEvents.has(m[1])) fail(`${rel(file)}: uses receipt event "${m[1]}" which no contract emits`);
  }
}

// ---- 4. Nothing imports legacy / unrelated code or raw build output ---------------------------------------
const banned = [
  [/contract-loader/, "contract-loader belongs to the Passchain project; use utils/contracts.ts"],
  [/contract_addresses/, "contract_addresses.json belongs to the Passchain project; addresses come from shared/deployments.json"],
  [/sequence_abi/, "sequence_abi.json belongs to the Passchain project"],
  [/from\s+["'][^"']*\/build\/contracts/, "import from shared/abi, not from build/contracts"],
  [/require\(\s*["'][^"']*\/build\/contracts/, "import from shared/abi, not from build/contracts"],
  [/tatum/i, "Tatum code is unrelated to this project"],
];
for (const file of [...appFiles, ...walk(path.join(root, "scripts"), [".js"]).filter((f) => !f.endsWith("check-consistency.js")), ...walk(path.join(root, "migrations"), [".js"])]) {
  const src = read(file);
  for (const [re, why] of banned) if (re.test(src)) fail(`${rel(file)}: ${why}`);
}

// ---- 5. Solidity: OpenZeppelin by package path, relative imports resolve ---------------------------------
for (const file of walk(path.join(root, "contracts"), [".sol"])) {
  const src = read(file);
  for (const m of src.matchAll(/import\s+(?:[^"']*from\s+)?["']([^"']+)["']/g)) {
    const spec = m[1];
    if (/^https?:/.test(spec)) fail(`${rel(file)}: URL import "${spec}" does not work with Truffle; use the package path "@openzeppelin/contracts/..."`);
    else if (spec.startsWith("./") || spec.startsWith("../")) {
      if (!exists(path.resolve(path.dirname(file), spec))) fail(`${rel(file)}: imports ${spec}, which does not exist`);
    } else if (spec.startsWith("@openzeppelin/")) {
      if (!exists(path.join(root, "node_modules", spec))) warn(`${rel(file)}: ${spec} not found in node_modules (run npm install)`);
    }
  }
}
if (exists(path.join(root, "contracts/openzeppelin")) || exists(path.join(root, "contracts/@openzeppelin"))) {
  fail("contracts/ contains a copy of OpenZeppelin. Delete it and import by package path (npm install @openzeppelin/contracts).");
}
{
  const pkg = readJson(path.join(root, "package.json"));
  const v = (pkg.devDependencies || {})["@openzeppelin/contracts"] || (pkg.dependencies || {})["@openzeppelin/contracts"];
  if (!v) fail("package.json does not list @openzeppelin/contracts");
  else if (/^[\^~]/.test(v)) warn(`@openzeppelin/contracts is "${v}"; pin an exact version so the compiled bytecode is reproducible`);
}

// ---- 6. Migrations: unique numbers, only known contracts ----------------------------------------------
{
  const dir = path.join(root, "migrations");
  const seen = {};
  for (const f of exists(dir) ? fs.readdirSync(dir).filter((n) => n.endsWith(".js")) : []) {
    const n = parseInt(f, 10);
    if (Number.isNaN(n)) fail(`migrations/${f}: file name must start with a number`);
    if (seen[n]) fail(`migrations/${f} and migrations/${seen[n]} share the number ${n}; Truffle would run both`);
    seen[n] = f;
    for (const m of read(path.join(dir, f)).matchAll(/artifacts\.require\(\s*["'](\w+)["']/g)) {
      if (!exists(path.join(root, "contracts", `${m[1]}.sol`)) && !/Migrations/.test(m[1])) fail(`migrations/${f}: requires ${m[1]}, which has no contracts/${m[1]}.sol`);
    }
  }
  for (const name of contracts) {
    const deploys = Object.values(seen).some((f) => read(path.join(dir, f)).includes(`contractName: "${name}"`));
    if (!deploys) fail(`no migration records a deployment of ${name} (call record-deployment in its migration)`);
  }
}

// ---- 7. Deployments --------------------------------------------------------------------------------------
{
  const checkFile = (file, isPublic) => {
    const p = path.join(root, "shared", file);
    if (!exists(p)) return;
    const data = readJson(p);
    for (const [key, entry] of Object.entries(data)) {
      if (key.startsWith("_")) continue;
      if (isPublic && !chains.some((c) => String(c.chainId) === key && c.kind !== "Local")) fail(`shared/${file}: chain id ${key} is not a public chain in shared/chains.json`);
      for (const name of contracts) {
        const e = entry[name];
        if (!e) fail(`shared/${file}[${key}]: no entry for ${name} (deploy all contracts to each chain)`);
        else if (!/^0x[0-9a-fA-F]{40}$/.test(e.address || "")) fail(`shared/${file}[${key}].${name}: "${e.address}" is not an address`);
        else if (!Number.isInteger(e.startBlock)) fail(`shared/${file}[${key}].${name}: missing startBlock`);
      }
    }
  };
  checkFile("deployments.json", true);
  checkFile("deployments.local.json", false);
}

// ---- 8. App-side network list reads shared/chains.json (no second copy) -------------------------------------
{
  const f = path.join(root, "utils/networks.ts");
  if (exists(f) && !/import\s+\w+\s+from\s+["'][^"']*shared\/chains\.json["']/.test(read(f))) fail("utils/networks.ts must import shared/chains.json instead of keeping its own list");
}

// ---- 9. Email notifications: manifest <-> ABI <-> templates <-> resolver -------------------------------------
{
  const f = path.join(root, "shared/notifications.json");
  if (exists(f)) {
    const { notifications } = readJson(f);
    const ids = new Set();
    const resolverSrc = exists(path.join(root, "notifier/resolve.js")) ? read(path.join(root, "notifier/resolve.js")) : "";
    const templateSrc = exists(path.join(root, "notifier/templates.js")) ? read(path.join(root, "notifier/templates.js")) : "";
    for (const n of notifications) {
      if (ids.has(n.id)) fail(`shared/notifications.json: duplicate id "${n.id}"`);
      ids.add(n.id);
      if (!contracts.includes(n.contract)) { fail(`shared/notifications.json[${n.id}]: unknown contract ${n.contract}`); continue; }
      const ev = (abis[n.contract] || []).find((x) => x.type === "event" && x.name === n.event);
      if (!ev) { fail(`shared/notifications.json[${n.id}]: ${n.contract} has no event ${n.event}`); continue; }
      if (!ev.inputs.some((i) => i.name === n.timestampArg)) fail(`shared/notifications.json[${n.id}]: ${n.event} has no argument "${n.timestampArg}"`);
      if (!new RegExp(`case\\s+"${n.id}"`).test(resolverSrc)) fail(`notifier/resolve.js has no handler for "${n.id}"`);
      if (!new RegExp(`\\b${n.id}\\s*:`).test(templateSrc)) fail(`notifier/templates.js has no template "${n.id}"`);
    }
    // event arguments the resolver reads (a.something) must exist on some event
    const argNames = new Set(Object.values(abis).flatMap((abi) => abi.filter((x) => x.type === "event").flatMap((x) => x.inputs.map((i) => i.name))));
    for (const m of resolverSrc.matchAll(/\ba\.(\w+)/g)) if (!argNames.has(m[1])) fail(`notifier/resolve.js reads event argument "${m[1]}", which no event has`);
    // transactions the resolver decodes must be real functions
    for (const m of resolverSrc.matchAll(/txArgs\(\s*ctx\s*,\s*[\w.]+\s*,\s*"(\w+)"\s*,\s*"(\w+)"/g)) {
      if (!methodsOf(m[1]).has(m[2])) fail(`notifier/resolve.js decodes ${m[1]}.${m[2]}(), which does not exist`);
    }
    for (const m of resolverSrc.matchAll(/:\s*"((?:issue|revoke|reinstate)License)"/g)) {
      if (!methodsOf("LicenseRegistry").has(m[1])) fail(`notifier/resolve.js decodes LicenseRegistry.${m[1]}(), which does not exist`);
    }
  }
}

// ---- 10. Accounts: locations, roles, ID types, indexes, rules, env, API routes --------------------------------
{
  const EXPECTED_DISTRICTS = { AHA: 6, ASH: 43, BON: 12, BOE: 11, CEN: 22, EAS: 33, GAR: 29, NES: 6, NOR: 16, OTI: 9, SAV: 7, UPE: 15, UPW: 11, VOL: 18, WES: 14, WNO: 9 };
  const regions = readJson(path.join(root, "shared/locations/regions.json"));
  const districts = readJson(path.join(root, "shared/locations/districts.json"));
  if (regions.length !== 16) fail(`shared/locations/regions.json: expected 16 regions, found ${regions.length}`);
  if (districts.length !== 261) fail(`shared/locations/districts.json: expected 261 districts, found ${districts.length}`);
  const dIds = new Set();
  for (const d of districts) {
    if (dIds.has(d.id)) fail(`districts.json: duplicate id ${d.id}`);
    dIds.add(d.id);
    if (!regions.some((r) => r.code === d.region)) fail(`districts.json: ${d.id} has unknown region ${d.region}`);
  }
  for (const [code, n] of Object.entries(EXPECTED_DISTRICTS)) {
    const got = districts.filter((d) => d.region === code).length;
    if (got !== n) fail(`districts.json: region ${code} has ${got} districts, expected ${n}`);
  }

  const roles = readJson(path.join(root, "shared/roles.json"));
  for (const [cap, c] of Object.entries(roles.capabilities)) {
    for (const r of c.roles) if (!roles.roles.includes(r)) fail(`shared/roles.json: ${cap} names unknown role "${r}"`);
    if (![0, 1, 2].includes(c.minLevel)) fail(`shared/roles.json: ${cap} minLevel must be 0, 1 or 2`);
  }
  // every capability used in code exists
  for (const f of [...walk(path.join(root, "pages"), [".ts", ".tsx"]), ...walk(path.join(root, "components"), [".tsx"]), ...walk(path.join(root, "server"), [".js"])]) {
    for (const m of read(f).matchAll(/capability(?:=|:\s*)"([a-z_]+:[a-z_:]+)"/g)) {
      if (!roles.capabilities[m[1]]) fail(`${rel(f)} uses unknown capability "${m[1]}"`);
    }
  }

  const idt = readJson(path.join(root, "shared/id-types.json"));
  for (const t of idt.types) {
    const re = new RegExp(t.pattern);
    if (t.example && !re.test(t.example)) fail(`shared/id-types.json: example for ${t.code} does not match its own pattern`);
    if (!["nia", "manual"].includes(t.checker)) fail(`shared/id-types.json: ${t.code} has unknown checker "${t.checker}"`);
  }

  const onb = readJson(path.join(root, "shared/onboarding.json"));
  for (const s of [...onb.requiredToFinish, ...onb.optionalButRecommended]) if (!onb.steps.includes(s)) fail(`shared/onboarding.json: unknown step "${s}"`);
  if (onb.otp.resendSeconds >= onb.otp.ttlSeconds) fail("shared/onboarding.json: otp.resendSeconds must be shorter than otp.ttlSeconds");

  // firebase/ files
  const idx = readJson(path.join(root, "firebase/firestore.indexes.json"));
  const seen = new Set();
  for (const i of idx.indexes) {
    const key = i.collectionGroup + ":" + i.fields.map((f) => f.fieldPath + (f.order || "")).join(",");
    if (seen.has(key)) fail(`firestore.indexes.json: duplicate index ${key}`);
    seen.add(key);
    if (i.fields.length < 2) fail(`firestore.indexes.json: ${i.collectionGroup} index has fewer than 2 fields (single-field indexes are automatic)`);
  }
  const rules = read(path.join(root, "firebase/firestore.rules"));
  if (/if\s+true/.test(rules)) fail("firebase/firestore.rules: contains 'if true' (an open rule)");
  if (!/match \/\{document=\*\*\}[\s\S]*if false/.test(rules)) fail("firebase/firestore.rules: missing the final deny-all rule");
  if (/<<<<<<<|>>>>>>>|=======/.test(rules) || /<<<<<<<|>>>>>>>/.test(read(path.join(root, "firebase/firestore.indexes.json")))) fail("firebase/: merge-conflict markers found");

  // every collection the server touches is either server-only in the rules or is the one readable collection
  const cols = new Set();
  for (const f of walk(path.join(root, "server"), [".js"])) {
    for (const m of read(f).matchAll(/(?:tx\.|s\.|store\(\)\.)(?:get|set|create|update|delete|add|query)\(\s*"(\w+)"/g)) cols.add(m[1]);
  }
  const documented = read(path.join(root, "docs/ACCOUNTS.md"));
  const dbDoc = read(path.join(root, "docs/database.md"));
  for (const c of cols) {
    if (!documented.includes("`" + c + "`")) fail(`docs/ACCOUNTS.md does not describe the collection "${c}"`);
    if (!dbDoc.includes("📁 " + c + "/")) fail(`docs/database.md has no tree for the collection "${c}"`);
  }
  // the 12 composite indexes are listed in docs/database.md
  if (!/exactly these 12/.test(dbDoc) || JSON.parse(read(path.join(root, "firebase/firestore.indexes.json"))).indexes.length !== 12) fail("docs/database.md says 12 indexes but firebase/firestore.indexes.json differs");

  // every environment variable the server reads is explained in .env.local.example
  const example = read(path.join(root, ".env.local.example"));
  const skip = new Set(["NODE_ENV", "PROJECT_ROOT", "HOME", "FIRESTORE_INDEXES_FILE", "STORE_ENFORCE_INDEXES", "STORE_FILE", "SMS_OUTBOX_FILE", "SMS_MOCK_FAIL", "GOOGLE_APPLICATION_CREDENTIALS", "DEV_LINKS_FILE"]);
  for (const f of walk(path.join(root, "server"), [".js"])) {
    for (const m of read(f).matchAll(/process\.env\.([A-Z][A-Z0-9_]+)/g)) {
      if (!skip.has(m[1]) && !new RegExp("^\\s*#?\\s*" + m[1] + "\\s*=", "m").test(example)) fail(`${rel(f)} reads ${m[1]}, which is not in .env.local.example`);
    }
  }
  // no secret behind a NEXT_PUBLIC_ name
  for (const m of example.matchAll(/NEXT_PUBLIC_[A-Z0-9_]*(SECRET|PEPPER|PRIVATE|PASSWORD|TOKEN)[A-Z0-9_]*/g)) fail(`.env.local.example: ${m[0]} would be shipped to every browser`);

  // navigation: every link in shared/nav.json is a real page, and names real capabilities and roles
  {
    const navJson = JSON.parse(read(path.join(root, "shared/nav.json")));
    const rolesJson = JSON.parse(read(path.join(root, "shared/roles.json")));
    for (const it of navJson.items) {
      const file = path.join(root, "pages", it.href.replace(/^\//, "") + ".tsx");
      if (!fs.existsSync(file)) fail(`shared/nav.json links to ${it.href}, but pages${it.href}.tsx does not exist`);
      if (it.capability && !rolesJson.capabilities[it.capability]) fail(`shared/nav.json: ${it.href} names the unknown capability "${it.capability}"`);
      for (const r of it.roles || []) if (!rolesJson.roles.includes(r)) fail(`shared/nav.json: ${it.href} names the unknown role "${r}"`);
      if (!it.public && !it.capability && !it.roles) fail(`shared/nav.json: ${it.href} has no capability, roles or public flag`);
    }
  }

  // every API route under pages/api/{me,onboarding,identity,admin,capability,locations} goes through withSession
  for (const f of walk(path.join(root, "pages/api"), [".ts"])) {
    const r = rel(f);
    if (r.startsWith("pages/api/wallet-link")) continue;
    if (!/withSession\(/.test(read(f))) fail(`${r} does not use withSession (every account route must verify the signed-in user)`);
    if (/\.role\s*=|body\.role|req\.body\)?\.uid/.test(read(f)) && !r.includes("/admin/")) fail(`${r} reads a role or uid from the request body`);
  }
}

for (const w of warnings) console.log("warning:", w);
if (errors.length) {
  console.error(`\n${errors.length} consistency problem(s):`);
  for (const e of errors) console.error(" -", e);
  process.exit(1);
}
console.log(`Consistency check passed (${contracts.length} contracts, ${chains.length} chains, ${appFiles.length} app files).`);
