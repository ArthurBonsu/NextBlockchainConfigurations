// Called by the migrations. Records where a contract was deployed so the app can find it.
//
// - Public chains (listed in shared/chains.json, not "Local") go to shared/deployments.json,
//   keyed by chain id. Commit that file: it is how the front end learns the addresses.
// - Anything else (Ganache, any private chain) goes to shared/deployments.local.json, keyed by
//   network id. That file is git-ignored, because local addresses change every time you reset.
//
// Each entry also stores the deployment block, so the history page only scans from there
// instead of from block 0 (which public RPCs reject on long-running chains).
const fs = require("fs");
const path = require("path");

const sharedDir = path.resolve(__dirname, "..", "shared");
const { chains } = JSON.parse(fs.readFileSync(path.join(sharedDir, "chains.json"), "utf8"));

function readJson(file, fallback) {
  return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, "utf8")) : fallback;
}

// Pass `contractClass` (the artifacts.require(...) result) so the deployment transaction can be looked up, and
// `blockBefore` (web3.eth.getBlockNumber() read just before deploying) as a safe fallback: the contract cannot
// have been deployed in an earlier block, so scanning from there never misses an event.
module.exports = async function recordDeployment({ web3, networkId, contractName, instance, contractClass, blockBefore }) {
  const chainId = Number(await web3.eth.getChainId());
  const net = contractClass && contractClass.networks && contractClass.networks[String(networkId)];
  const txHash = instance.transactionHash || (net && net.transactionHash) || null;
  let startBlock = Number(blockBefore || 0);
  if (txHash) {
    const receipt = await web3.eth.getTransactionReceipt(txHash);
    if (receipt) startBlock = Number(receipt.blockNumber);
  }

  const known = chains.find((c) => c.chainId === chainId && c.kind !== "Local");
  const file = path.join(sharedDir, known ? "deployments.json" : "deployments.local.json");
  const key = String(known ? chainId : networkId);

  const all = readJson(file, {});
  const entry = all[key] || {};
  entry.chainId = chainId;
  entry.networkId = String(networkId);
  entry[contractName] = { address: instance.address, txHash: txHash || null, startBlock };
  entry.updatedAt = new Date().toISOString();
  all[key] = entry;

  fs.writeFileSync(file, JSON.stringify(all, null, 2) + "\n");
  console.log(`   > recorded ${contractName} for ${known ? known.name : "local chain " + key} in ${path.basename(file)} (block ${startBlock})`);
};
