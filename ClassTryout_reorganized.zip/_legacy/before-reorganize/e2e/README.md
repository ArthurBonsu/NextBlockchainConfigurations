# Browser tests (optional)

These drive the built app in Chromium with a stand-in wallet (no MetaMask needed) against local chains.
They are not part of `npm run check`; run them before a demo or a release.

```
npm i -D playwright            # once
npm run chain                  # terminal 1: local chain on 7545 (chain id 1337)
npm run deploy:local           # terminal 2: deploy and record addresses
NEXT_PUBLIC_SHOW_LOCAL=true npm run build && npx next start -p 3100
node e2e/flow.e2e.js           # register, license, report, revoke, reinstate, history, admin, pause
```

`flow.e2e.js` needs a fresh chain each run (vehicle names are reused). `multichain.e2e.js` additionally needs two
more local chains (ports 7546 with chain id 8453, and 7547 with chain id 42161) with the contracts deployed to 7546; it
exercises the network picker. Set `CHROMIUM_PATH` if Playwright cannot find a browser.

## Email notifications

```
npm i -D smtp-server mailparser    # already in package.json devDependencies
node e2e/notify.e2e.js             # needs the local chain + deployed contracts; starts its own mock mail server (port 2525)
```

Add the wallet-link API checks by starting a dev server with the same links file and passing its address:

```
NOTIFY_BACKEND=dev WALLET_LINK_SECRET=0123456789abcdef0123 DEV_LINKS_FILE=/tmp/links.json npx next dev -p 3100
BASE_URL=http://127.0.0.1:3100 DEV_LINKS_FILE=/tmp/links.json node e2e/notify.e2e.js
```

`notify-ui.e2e.js` drives the "Email notifications" panel (start the dev server with `NEXT_PUBLIC_NOTIFY_BACKEND=dev` as
well). Use a fresh chain for each run of `notify.e2e.js`; it expects exactly the emails it causes.

## Accounts (sign-in, onboarding, roles)

```
npx firebase-tools emulators:start --only auth --project demo-classtryout     # terminal 1
node e2e/accounts.e2e.js                                                       # terminal 2: starts its own Next dev server on 3200
```

It uses the Auth emulator for real tokens and a local file store instead of Firestore, and a mock SMS provider whose outbox the test
reads (the API never returns the code). It needs no chain. Set `CHROMIUM_PATH` if Playwright cannot find a browser.
