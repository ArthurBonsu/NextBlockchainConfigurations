// Email-notification test. Needs a local chain with the contracts deployed (see e2e/README.md):
//   npm run chain            (terminal 1)     npm run deploy:local   (terminal 2)
//   node e2e/notify.e2e.js                    (a fresh chain each run keeps the counts exact)
// Optional: BASE_URL=http://127.0.0.1:3100 also tests the wallet-link API with real signatures. Start the server with the same
// DEV_LINKS_FILE as this test: NOTIFY_BACKEND=dev WALLET_LINK_SECRET=<16+ chars> DEV_LINKS_FILE=/tmp/links.json npx next dev -p 3100
//
// It starts a mock SMTP server, links wallets, performs every on-chain action that should send an email, runs the real
// watcher (`node notifier/index.js --once`) and checks what arrived. Nothing leaves your machine.
const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawn } = require("child_process");
const { Web3 } = require("web3");
const { SMTPServer } = require("smtp-server");
const { simpleParser } = require("mailparser");

const root = path.resolve(__dirname, "..");
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "ct-notify-"));
const RPC = process.env.RPC_URL || "http://127.0.0.1:7545";
const BASE_URL = process.env.BASE_URL;
const SMTP_PORT = Number(process.env.TEST_SMTP_PORT || 2525);
const SUF = Date.now().toString(36).slice(-4);

let pass = 0;
let fail = 0;
const check = (name, ok, extra = "") => {
  (ok ? pass++ : fail++, console.log(`${ok ? "PASS" : "FAIL"}  ${name}${ok ? "" : "  " + extra}`));
};

// ---- mock SMTP ------------------------------------------------------------------------------------------
const inbox = [];
let smtp;
function startSmtp() {
  return new Promise((resolve) => {
    smtp = new SMTPServer({
      authOptional: true,
      disabledCommands: ["STARTTLS"],
      onData(stream, session, cb) {
        simpleParser(stream).then((m) => {
          inbox.push({ to: m.to.value[0].address, subject: m.subject, text: m.text, html: m.html });
          cb();
        });
      },
    });
    smtp.listen(SMTP_PORT, "127.0.0.1", resolve);
  });
}
const stopSmtp = () => new Promise((r) => smtp.close(r));

// ---- watcher runner ---------------------------------------------------------------------------------------
const env = {
  ...process.env,
  NOTIFY_BACKEND: "dev",
  NOTIFY_TRANSPORT: "smtp",
  NOTIFY_LOCAL: "true",
  NOTIFY_CHAINS: "1337",
  NOTIFY_STATE_FILE: path.join(tmp, "state.json"),
  DEV_LINKS_FILE: process.env.DEV_LINKS_FILE || path.join(tmp, "links.json"),
  EMAIL_SERVER_HOST: "127.0.0.1",
  EMAIL_SERVER_PORT: String(SMTP_PORT),
  EMAIL_FROM: "ClassTryout <test@example.test>",
  APP_URL: "http://localhost:3000",
  NODE_ENV: "development",
};
// Async on purpose: the mock SMTP server lives in this process, so blocking here would deadlock the delivery.
function runWatcher() {
  return new Promise((resolve) => {
    const child = spawn(process.execPath, ["notifier/index.js", "--once"], { cwd: root, env });
    let out = "";
    child.stdout.on("data", (d) => (out += d));
    child.stderr.on("data", (d) => (out += d));
    child.on("close", (code) => {
      if (code !== 0) console.log(out);
      resolve(out);
    });
  });
}
const state = () => JSON.parse(fs.readFileSync(env.NOTIFY_STATE_FILE, "utf8"));

// ---- chain helpers ------------------------------------------------------------------------------------------
const web3 = new Web3(RPC);
const dep = Object.values(JSON.parse(fs.readFileSync(path.join(root, "shared/deployments.local.json"), "utf8"))).find((d) => d && d.chainId === 1337);
const abi = (n) => JSON.parse(fs.readFileSync(path.join(root, `shared/abi/${n}.json`), "utf8"));
const registry = new web3.eth.Contract(abi("VehicleRegistry"), dep.VehicleRegistry.address);
const revocation = new web3.eth.Contract(abi("RevocationManager"), dep.RevocationManager.address);
const license = new web3.eth.Contract(abi("LicenseRegistry"), dep.LicenseRegistry.address);
const send = async (m, from) => m.send({ from, gas: (await m.estimateGas({ from })) * 2n });

async function link(uid, email, verified, wallet) {
  const token = `dev:${uid}:${email}:${verified ? 1 : 0}`;
  if (BASE_URL) {
    const h = { "content-type": "application/json", authorization: `Bearer ${token}` };
    const c = await fetch(`${BASE_URL}/api/wallet-link/challenge`, { method: "POST", headers: h, body: JSON.stringify({ address: wallet }) });
    const cj = await c.json();
    if (!verified) return { status: c.status, body: cj };
    const signed = await web3.eth.sign(web3.utils.utf8ToHex(cj.message), wallet); // eth_sign adds the same EIP-191 prefix as MetaMask's personal_sign
    const signature = typeof signed === "string" ? signed : signed.signature;
    const ok = await fetch(`${BASE_URL}/api/wallet-link/confirm`, { method: "POST", headers: h, body: JSON.stringify({ ...cj, signature }) });
    return { status: ok.status, body: await ok.json(), challenge: cj, signature, headers: h };
  }
  process.env.NOTIFY_BACKEND = "dev";
  process.env.DEV_LINKS_FILE = env.DEV_LINKS_FILE;
  await require("../server/links.js").saveLink(wallet, { uid, email, emailVerified: verified });
  return { status: 200, body: { linked: true } };
}

(async () => {
  const [admin, owner, other, issuer, unverified] = await web3.eth.getAccounts();
  const P1 = `anna-${SUF}`, P2 = `ben-${SUF}`, P3 = `cara-${SUF}`;
  const LIC = `LIC-${SUF}`;

  await startSmtp();

  // ---- link wallets --------------------------------------------------------------------------------------
  const l1 = await link("user-anna", "anna@example.test", true, owner);
  check("wallet link accepted (owner -> anna@example.test)", l1.status === 200 && l1.body.linked === true, JSON.stringify(l1.body));
  const l3 = await link("user-cara", "cara@example.test", false, unverified);
  if (BASE_URL) check("unverified email cannot start a wallet link (403)", l3.status === 403, JSON.stringify(l3));
  // An account whose email is (or became) unverified while its wallet is linked: written straight to the link file.
  process.env.NOTIFY_BACKEND = "dev";
  process.env.DEV_LINKS_FILE = env.DEV_LINKS_FILE;
  await require("../server/links.js").saveLink(unverified, { uid: "user-cara", email: "cara@example.test", emailVerified: false });

  if (BASE_URL) {
    const bad = await fetch(`${BASE_URL}/api/wallet-link/confirm`, { method: "POST", headers: l1.headers, body: JSON.stringify({ ...l1.challenge, address: other, signature: l1.signature }) });
    check("link with someone else's address is rejected", bad.status === 400);
    const noauth = await fetch(`${BASE_URL}/api/wallet-link`, { method: "GET" });
    check("API without sign-in is rejected (401)", noauth.status === 401);
    const wrongUser = await fetch(`${BASE_URL}/api/wallet-link/confirm`, { method: "POST", headers: { ...l1.headers, authorization: "Bearer dev:user-mallory:m@example.test:1" }, body: JSON.stringify({ ...l1.challenge, signature: l1.signature }) });
    check("a signature challenge cannot be used by another account", wrongUser.status === 400);
    const list = await (await fetch(`${BASE_URL}/api/wallet-link`, { headers: l1.headers })).json();
    check("GET lists the linked wallet", list.wallets.length === 1 && list.wallets[0].address === owner.toLowerCase());
  }

  // ---- on-chain actions ----------------------------------------------------------------------------------
  await send(registry.methods.registerVehicle(P1), owner);            // -> registration email to anna
  await send(registry.methods.registerVehicle(P2), other);            // other wallet is not linked -> skipped
  await send(registry.methods.registerVehicle(P3), unverified);       // linked but email not verified -> skipped
  await send(license.methods.issueLicense(LIC, P1, "Class B", 365), issuer);  // issued by a DIFFERENT wallet -> email goes to owner
  await send(license.methods.revokeLicense(LIC), admin);              // -> licenseRevoked
  await send(license.methods.reinstateLicense(LIC), admin);           // -> licenseReinstated
  const reportId = await revocation.methods.submitRevocationReport(P1, P2, "Ran a red light").call({ from: other });
  await send(revocation.methods.submitRevocationReport(P1, P2, "Ran a red light"), other); // report alone: no email
  await send(revocation.methods.processRevocation(reportId), admin);  // -> revocation
  await send(revocation.methods.reinstateVehicle(P1), admin);         // -> reinstatement

  // ---- first pass ----------------------------------------------------------------------------------------
  await runWatcher();
  const to = inbox.filter((m) => m.to === "anna@example.test");
  const bySubject = (re) => to.filter((m) => re.test(m.subject));
  check("exactly 6 emails to anna (4 kinds, license x3)", inbox.length === 6 && to.length === 6, `inbox=${inbox.length} ${JSON.stringify(inbox.map((m) => m.subject))}`);
  check("registration confirmation, with readable pseudonym", bySubject(/Registration confirmed/).length === 1 && bySubject(/Registration confirmed/)[0].subject.includes(P1));
  check("license issued email goes to the vehicle OWNER, names the issuer wallet", (() => { const m = bySubject(/A license was issued/)[0]; return m && m.text.includes(issuer) && m.text.includes(LIC); })());
  check("license id is readable, not a hash", to.every((m) => !/0x[0-9a-f]{64}/i.test(m.text)));
  check("license revoked email", bySubject(new RegExp(`License ${LIC} has been revoked`)).length === 1);
  check("license reinstated email", bySubject(new RegExp(`License ${LIC} has been reinstated`)).length === 1);
  check("vehicle revocation notice includes the reason", (() => { const m = bySubject(/has been revoked/).find((x) => x.subject.includes(P1) && !x.subject.includes(LIC)); return m && m.text.includes("Ran a red light"); })());
  check("vehicle reinstatement notice", bySubject(/reinstated/).some((m) => m.subject.includes(P1) && !m.subject.includes(LIC)));
  check("report submission alone sends nothing", !inbox.some((m) => /report/i.test(m.subject)));
  check("unlinked / unverified wallets get nothing", !inbox.some((m) => m.to === "cara@example.test" || /ben-/.test(m.subject + m.text)));
  check("HTML part present and escaped", to.every((m) => typeof m.html === "string" && m.html.includes("<table")));
  const st = state();
  const outcomes = Object.values(st.events).map((e) => e.status);
  check("skips are recorded with a reason", outcomes.includes("skipped:not-linked") && outcomes.includes("skipped:email-not-verified"), JSON.stringify(outcomes));
  check("state file never contains an email address", !fs.readFileSync(env.NOTIFY_STATE_FILE, "utf8").includes("@example.test"));

  // ---- idempotency ---------------------------------------------------------------------------------------
  const before = inbox.length;
  await runWatcher();
  check("second run sends nothing again", inbox.length === before);

  // ---- SMTP outage and retry ----------------------------------------------------------------------------
  await stopSmtp();
  const P4 = `dora-${SUF}`;
  await send(registry.methods.registerVehicle(P4), owner);
  await runWatcher();
  check("failed send is queued for retry, not lost", Object.keys(state().pending).length === 1);
  await startSmtp();
  const s = state();
  for (const p of Object.values(s.pending)) p.nextAt = 0;
  fs.writeFileSync(env.NOTIFY_STATE_FILE, JSON.stringify(s));
  await runWatcher();
  check("retry delivers once the mail server is back", inbox.length === before + 1 && inbox[inbox.length - 1].subject.includes(P4) && Object.keys(state().pending).length === 0);

  await stopSmtp();
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
