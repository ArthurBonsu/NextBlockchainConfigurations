const { chromium } = require("playwright");
const RPC = "http://127.0.0.1:7545";
const BASE = process.env.BASE_URL || "http://localhost:3100";
// each panel now lives on its own page
const ROUTE = { "Vehicle Registry": "/vehicles", "License": "/licences", "Revocation": "/revocations", "On-Chain History": "/history", "Contract Control": "/admin/contracts" };
let id = 1;
async function rpc(method, params=[]) {
  const r = await fetch(RPC,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({jsonrpc:"2.0",id:id++,method,params})});
  return r.json();
}
(async () => {
  const accts = (await rpc("eth_accounts")).result;
  const [admin, user1] = accts;
  const browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
  const page = await browser.newPage({ viewport:{width:1200,height:1800}});
  const txLog = [];
  const consoleErrs = [];
  page.on("console", m => { if (m.type()==="error") consoleErrs.push(m.text()); });
  page.on("pageerror", e => consoleErrs.push("PAGEERROR "+e.message));
  await page.exposeFunction("__rpc", async (method, params) => {
    if (method === "eth_sendTransaction" && !params[0].gas) {
      // behave like MetaMask: estimate gas (+20%) when the dapp does not set it
      const est = await rpc("eth_estimateGas", [params[0]]);
      if (est.error) return est;
      params[0].gas = "0x" + Math.ceil(parseInt(est.result,16)*1.2).toString(16);
    }
    const res = await rpc(method, params);
    if (method === "eth_sendTransaction") {
      txLog.push({ gasLimit: params[0].gas, hash: res.result, err: res.error?.message });
    }
    return res;
  });
  await page.addInitScript(({admin}) => {
    window.__acct = window.name && window.name.startsWith('0x') ? window.name : admin;
    const listeners = {};
    window.ethereum = {
      isMetaMask: true,
      get selectedAddress(){ return window.__acct; },
      on(ev, fn){ (listeners[ev] ||= []).push(fn); },
      removeListener(){},
      async request({method, params}) {
        if (method === "eth_requestAccounts" || method === "eth_accounts") return [window.__acct];
        if (method === "wallet_switchEthereumChain") return null;
        const res = await window.__rpc(method, params || []);
        if (res.error) { const e = new Error(res.error.message); e.code = res.error.code; e.data = res.error.data; throw e; }
        return res.result;
      },
      sendAsync(payload, cb){ this.request(payload).then(r=>cb(null,{id:payload.id,jsonrpc:"2.0",result:r}),cb); },
      send(payload, cb){ return this.sendAsync(payload, cb); },
    };
  }, {admin});

  const results = [];
  async function step(name, fn) {
    try { const out = await fn(); results.push({name, ok:true, out}); console.log("OK  ", name, out ?? ""); }
    catch(e){ results.push({name, ok:false, err:e.message}); console.log("FAIL", name, "-", e.message.split("\n")[0]); }
  }
  const bar = () => page.locator("div[class*=walletBar]");
  const btn = (n) => page.getByRole("button", {name:n, exact:true});
  const card = (h) => page.locator("div[class*=card]").filter({has: page.getByRole("heading",{name:h})});
  async function waitMsg(scope, re, ms=15000) {
    await page.waitForFunction(([sel,reSrc]) => {
      return [...document.querySelectorAll("div")].some(d => d.children.length===0 && new RegExp(reSrc,"i").test(d.textContent||""));
    }, [null, re.source], {timeout: ms});
  }
  async function text(h) { return (await card(h).innerText()).replace(/\n+/g," | "); }
  async function lastTxGas() { const t = txLog[txLog.length-1]; return t; }
  async function gasUsed(hash){ const r=(await rpc("eth_getTransactionReceipt",[hash])).result; return r? {used:parseInt(r.gasUsed,16), status:r.status}:null; }

  await page.goto(BASE + "/");
  await step("home page loads and the old demo address forwards to /vehicles", async()=>{ await page.goto(BASE + "/vehicle-demo"); await page.waitForURL("**/vehicles"); return page.url(); });
  await step("auto-connect or connect wallet", async()=>{
    await page.waitForTimeout(1500);
    if (await btn("Connect Wallet").count()) { await btn("Connect Wallet").click(); }
    await page.waitForFunction(()=>/0x[0-9a-fA-F]{4}\.\.\.[0-9a-fA-F]{4}/.test(document.body.innerText),{timeout:10000});
    return (await page.locator("div[class*=walletBar]").innerText()).replace(/\n+/g," | ");
  });

  async function sendStep(name, h, fill, clickName, okRe, extra) {
    await step(name, async()=>{
      for (const [ph,val] of fill) await card(h).getByPlaceholder(ph,{exact:false}).first().fill(val);
      const before = txLog.length;
      await card(h).getByRole("button",{name:clickName,exact:true}).click();
      await page.waitForTimeout(2500);
      const t = await text(h);
      const tx = txLog[txLog.length-1];
      const g = tx && txLog.length>before ? await gasUsed(tx.hash) : null;
      const info = (txLog.length>before? `gasLimit=${parseInt(tx.gas||tx.gasLimit)} used=${g?.used} status=${g?.status}`:"no tx");
      if (okRe && !okRe.test(t)) throw new Error("unexpected text: "+t.slice(0,400)+" ["+info+"]");
      return info + " :: " + t.slice(0,260);
    });
  }

  const R="Revocation", L="License", V="Vehicle Registry";
  const ph=(h,p,exact=false)=>card(h).getByPlaceholder(p,{exact});
  async function click(h,n){ await card(h).getByRole("button",{name:n,exact:true}).click(); }
  async function info(h,before){ const t=txLog[txLog.length-1]; const g=(t&&txLog.length>before&&t.hash)?await gasUsed(t.hash):null; return (txLog.length>before?`gasLimit=${parseInt(t.gas||t.gasLimit)} used=${g?.used} status=${g?.status}`:"no tx"); }
  async function act(name,h,fill,btnName,re,wait=2500){
    await step(name, async()=>{ await page.goto(BASE + ROUTE[h]); await page.waitForFunction(()=>/0x[0-9a-fA-F]{4}\.\.\./.test(document.body.innerText),{timeout:10000}); for(const [p,v,n] of fill) await (n!==undefined? ph(h,p,true).nth(n) : ph(h,p,p==='License ID'||p==='Report ID'||p==='Vehicle pseudonym')).first().fill(v); const b=txLog.length; await click(h,btnName); await page.waitForTimeout(wait); const t=await text(h); const i=await info(h,b); if(re&&!re.test(t)) throw new Error("unexpected: "+t.slice(0,500)+" ["+i+"]"); return i+" :: "+t.slice(0,420); });
  }
  const sw = (a)=>page.evaluate(x=>{window.__acct=x;window.name=x;},a);

  await act("register car-001",V,[["Vehicle pseudonym, e.g.","car-001"]],"Register",/registered on-chain/i);
  await sw(user1);
  await act("register car-002 (as 2nd wallet)",V,[["Vehicle pseudonym, e.g.","car-002"]],"Register",/registered on-chain/i);
  await act("register car-001 again (dup, expect clean error)",V,[["Vehicle pseudonym, e.g.","car-001"]],"Register",/already|exists|registered/i);
  await act("lookup car-001",V,[["Vehicle pseudonym to check","car-001"]],"Look Up",/car-001|owner|active/i,1500);
  await sw(admin);
  await act("issue license short",L,[["License ID, e.g.","lic-001"],["Vehicle pseudonym (must","car-001"],["License type","Standard"],["Days valid","365"]],"Issue License",/lic-001|issued/i);
  await act("issue license LONG strings",L,[["License ID, e.g.","license-2026-ghana-dvla-0000000001"],["Vehicle pseudonym (must","car-002"],["License type","Commercial Heavy Goods Vehicle Category C+E (international)"],["Days valid","1825"]],"Issue License",/./);
  await act("issue license for unregistered vehicle (expect error)",L,[["License ID, e.g.","lic-x"],["Vehicle pseudonym (must","ghost"],["License type","Standard"],["Days valid","30"]],"Issue License",/./);
  await act("lookup lic-001",L,[["License ID","lic-001"]],"Look Up",/lic-001|valid|active/i,1500);
  await sw(user1);
  await act("report car-001 (as user1/car-002)",R,[["Offender pseudonym","car-001"],["Reporter pseudonym","car-002"],["Reason","Speeding"]],"Submit Report",/report/i);
  await act("get report 1",R,[["Report ID","1"]],"Get Report",/car-001|speeding/i,1500);
  await act("process report 1 as NON-admin (expect clean error)",R,[["Report ID","1",1]],"Process",/./);
  await sw(admin);
  await act("process report 1 as admin",R,[["Report ID","1",1]],"Process",/revok/i);
  await act("lookup car-001 after revoke",V,[["Vehicle pseudonym to check","car-001"]],"Look Up",/revok/i,1500);
  await act("lookup lic-001 after revoke",L,[["License ID","lic-001"]],"Look Up",/./,1500);
  await act("reinstate car-001 (admin)",R,[["Vehicle pseudonym","car-001"]],"Reinstate",/reinstat/i);
  await act("lookup lic-001 after reinstate",L,[["License ID","lic-001"]],"Look Up",/./,1500);
  await act("find license by vehicle car-001",L,[["...or find by vehicle","car-001"]],"Find",/lic-001/,2500);
  await act("revoke license lic-001 (admin)",L,[["License ID to revoke","lic-001"]],"Revoke License",/revoked/i);
  await act("lookup lic-001 -> Revoked",L,[["License ID","lic-001"]],"Look Up",/Status: Revoked/i,1500);
  await sw(user1);
  await act("reinstate license as NON-admin (expect clean error)",L,[["License ID to revoke","lic-001"]],"Reinstate License",/Only the admin wallet can do this/);
  await sw(admin);
  await act("reinstate license lic-001 (admin)",L,[["License ID to revoke","lic-001"]],"Reinstate License",/reinstated/i);
  await act("lookup lic-001 -> Valid",L,[["License ID","lic-001"]],"Look Up",/Status: Valid/i,1500);
  await step("history car-001 full", async()=>{ await page.goto(BASE + ROUTE["On-Chain History"]); await page.waitForTimeout(1500); await card("On-Chain History").getByPlaceholder("Vehicle pseudonym").fill("car-001"); await click("On-Chain History","Load Timeline"); await page.waitForTimeout(3500); const t=await text("On-Chain History"); const miss=["Vehicle Registered","License Issued","Revocation Report Submitted","Vehicle Revoked","Vehicle Reinstated","License Revoked","License Reinstated"].filter(k=>!t.includes(k)); if(miss.length) throw new Error("missing "+miss.join(",")+" :: "+t.slice(0,900)); return "all 7 event types present"; });

  // ---- OpenZeppelin Ownable / Pausable surfaces ----
  const CC = "Contract Control";
  await sw(admin);
  await step("admin wallet sees the Admin badge", async()=>{ await page.goto(BASE + ROUTE["Contract Control"]); await page.waitForFunction(()=>/0x[0-9a-fA-F]{4}\.\.\./.test(document.body.innerText),{timeout:10000}); await page.waitForTimeout(1500); const t=(await bar().innerText()); if(!/\bAdmin\b/.test(t)) throw new Error(t); return "badge shown"; });
  await sw(user1);
  await step("non-admin wallet has no Admin badge and a disabled Pause button", async()=>{ await page.goto(BASE + ROUTE["Contract Control"]); await page.waitForTimeout(2500); const t=(await bar().innerText()); if(/\bAdmin\b/.test(t)) throw new Error("badge wrongly shown: "+t); const dis = await card(CC).getByRole("button",{name:"Pause",exact:true}).first().isDisabled(); if(!dis) throw new Error("Pause enabled for non-admin"); return "no badge, Pause disabled"; });
  await sw(admin);
  await step("Contract Control lists 3 contracts, all Running", async()=>{ await page.goto(BASE + ROUTE["Contract Control"]); await page.waitForTimeout(2500); const t=await text(CC); for (const n of ["VehicleRegistry","RevocationManager","LicenseRegistry"]) if(!t.includes(n)) throw new Error("missing "+n+": "+t); if((t.match(/Running/g)||[]).length!==3) throw new Error(t); return "3 running"; });
  await step("admin pauses VehicleRegistry", async()=>{ await card(CC).getByRole("button",{name:"Pause",exact:true}).first().click(); await page.waitForTimeout(3000); const t=await text(CC); if(!/VehicleRegistry paused/.test(t)||!/Paused/.test(t)) throw new Error(t); return "paused"; });
  await sw(user1);
  await act("register while paused -> friendly paused message",V,[["Vehicle pseudonym, e.g.","car-paused"]],"Register",/paused by the admin/i);
  await sw(admin);
  await step("admin resumes VehicleRegistry", async()=>{ await page.goto(BASE + ROUTE["Contract Control"]); await page.waitForTimeout(2500); await card(CC).getByRole("button",{name:"Resume",exact:true}).first().click(); await page.waitForTimeout(3000); const t=await text(CC); if(!/VehicleRegistry resumed/.test(t)) throw new Error(t); return "resumed"; });
  await sw(user1);
  await act("register works again after resume",V,[["Vehicle pseudonym, e.g.","car-after-pause"]],"Register",/registered on-chain/i);
  await step("history car-001", async()=>{ await page.goto(BASE + ROUTE["On-Chain History"]); await page.waitForTimeout(1500); await card("On-Chain History").getByPlaceholder("Vehicle pseudonym").fill("car-001"); await click("On-Chain History","Load Timeline"); await page.waitForTimeout(3000); return (await text("On-Chain History")).slice(0,1500); });
  await page.screenshot({path:"final.png",fullPage:true});
  await browser.close();
  console.log("\nTX LOG", JSON.stringify(txLog.map(t=>({gas:t.gas||t.gasLimit,err:t.err})),null,0));
  console.log("CONSOLE ERRORS", consoleErrs.slice(0,10));
})().catch(e=>{console.error("FATAL",e);process.exit(1)});
