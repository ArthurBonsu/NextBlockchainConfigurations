// End-to-end test of sign-in, onboarding, roles and ID review, in a real browser against the Firebase AUTH EMULATOR.
// (Firestore is replaced by the file store, because the Firestore emulator is not available everywhere: see firebase/README.md.)
//
// Needs:  the Auth emulator running:   npx firebase-tools emulators:start --only auth --project demo-classtryout
// Run:    node e2e/accounts.e2e.js          (starts its own Next dev server on port 3200 and stops it at the end)
const { chromium } = require("playwright");
const { spawn, spawnSync } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");

const ROOT = path.resolve(__dirname, "..");
const PORT = process.env.E2E_PORT || "3200";
const BASE = `http://127.0.0.1:${PORT}`;
const EMU = process.env.AUTH_EMU || "http://127.0.0.1:9099";
const PROJECT = "demo-classtryout";
const dir = fs.mkdtempSync(path.join(os.tmpdir(), "ct-acc-e2e-"));
const ENV = {
  STORE_BACKEND: "file", STORE_FILE: path.join(dir, "store.json"),
  SMS_PROVIDER: "mock", SMS_OUTBOX_FILE: path.join(dir, "sms.jsonl"),
  NOTIFY_BACKEND: "firebase", FIREBASE_PROJECT_ID: PROJECT, FIREBASE_AUTH_EMULATOR_HOST: EMU.replace("http://", ""),
  WALLET_LINK_SECRET: "e2e-secret-e2e-secret",
  NEXT_PUBLIC_FIREBASE_API_KEY: "fake-key", NEXT_PUBLIC_FIREBASE_PROJECT_ID: PROJECT, NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN: "localhost",
  NEXT_PUBLIC_FIREBASE_APP_ID: "1:1:web:1", NEXT_PUBLIC_FIREBASE_AUTH_EMULATOR: EMU, NEXT_PUBLIC_REQUIRE_ACCOUNT: "true",
  ID_HASH_PEPPER: "e2e-pepper-e2e-pepper-e2e", OTP_SECRET: "e2e-otp-secret-e2e-otp", TRUST_PROXY: "true",
};
Object.assign(process.env, { SMS_OUTBOX_FILE: ENV.SMS_OUTBOX_FILE });

let pass = 0, fail = 0;
const check = (n, ok, x = "") => (ok ? pass++ : fail++, console.log(`${ok ? "PASS" : "FAIL"}  ${n}${ok ? "" : "  " + x}`));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---- helpers --------------------------------------------------------------------------------------------
async function emu(pathname, body) {
  const r = await fetch(`${EMU}/identitytoolkit.googleapis.com/v1/${pathname}?key=fake-key`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  return r.json();
}
const signUp = (email, password) => emu("accounts:signUp", { email, password, returnSecureToken: true });
const signIn = (email, password) => emu("accounts:signInWithPassword", { email, password, returnSecureToken: true });
async function verifyEmailInEmulator(email, idToken) {
  if (idToken) await emu("accounts:sendOobCode", { requestType: "VERIFY_EMAIL", idToken });
  const r = await (await fetch(`${EMU}/emulator/v1/projects/${PROJECT}/oobCodes`)).json();
  const code = (r.oobCodes || []).filter((c) => c.email === email && c.requestType === "VERIFY_EMAIL").pop();
  if (!code) throw new Error("no verification code in emulator for " + email);
  await emu("accounts:update", { oobCode: code.oobCode });
}
async function call(token, method, url, body) {
  const r = await fetch(BASE + url, { method, headers: { ...(token ? { authorization: `Bearer ${token}` } : {}), "content-type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  let j = null;
  try { j = await r.json(); } catch {}
  return { status: r.status, body: j, headers: r.headers };
}
function lastCode(phone) {
  const { lastTo } = require("../server/sms/mock.js");
  const m = lastTo(phone);
  return m && /(\d{6}) is your/.exec(m.text)[1];
}
async function completeViaApi(token, phone) {
  await call(token, "POST", "/api/onboarding/consent", { terms: true, privacy: true, sms: true });
  await call(token, "POST", "/api/onboarding/profile", { givenName: "Kwame", familyName: "Admin", dob: "1980-01-01", gender: "male", nationality: "GH" });
  await call(token, "POST", "/api/onboarding/phone/start", { phone });
  const e164 = "+233" + phone.replace(/^0/, "");
  const r = await call(token, "POST", "/api/onboarding/phone/confirm", { code: lastCode(e164) });
  await call(token, "POST", "/api/onboarding/address", { regionCode: "ASH", districtId: "ASH-kumasi", city: "Kumasi", suburb: "Adum" });
  return r;
}
async function waitFor(fn, ms = 90000) {
  const t = Date.now();
  for (;;) {
    try { if (await fn()) return; } catch {}
    if (Date.now() - t > ms) throw new Error("timed out waiting for the dev server");
    await sleep(700);
  }
}

(async () => {
  // emulator reachable?
  try { await fetch(EMU); } catch { console.error("Auth emulator not running at " + EMU); process.exit(2); }

  const server = spawn("npx", ["next", "dev", "-p", PORT, "-H", "127.0.0.1"], { cwd: ROOT, env: { ...process.env, ...ENV, NODE_ENV: "development" }, stdio: ["ignore", "pipe", "pipe"], detached: true });
  let serverLog = "";
  server.stdout.on("data", (d) => (serverLog += d));
  server.stderr.on("data", (d) => (serverLog += d));
  const stop = () => { try { process.kill(-server.pid); } catch {} try { server.kill("SIGTERM"); } catch {} };
  process.on("exit", stop);

  const suffix = Date.now().toString(36);
  const citizenEmail = `ama.${suffix}@example.test`;
  const adminEmail = `admin.${suffix}@example.test`;
  const PASSWORD = "correct horse battery";
  let browser;
  try {
    await waitFor(async () => (await fetch(BASE + "/api/me")).status === 401);
    check("server up; /api/me without a token is 401", true);

    // ---------- API security basics ----------
    const noTok = await call(null, "GET", "/api/me");
    check("no token -> 401", noTok.status === 401 && noTok.body.code === "unauthenticated");
    const junk = await call("not-a-token", "GET", "/api/me");
    check("garbage token -> 401", junk.status === 401);
    const wrongMethod = await call("x", "DELETE", "/api/onboarding/profile");
    check("wrong method -> 405", wrongMethod.status === 405);

    // ---------- UI: sign up and onboard a citizen ----------
    browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
    const page = await browser.newPage({ viewport: { width: 1100, height: 1400 } });
    const errs = [];
    page.on("pageerror", (e) => errs.push(e.message));
    page.on("console", (m) => { if (m.type() === "error" && !/Failed to load resource|favicon|net::ERR/.test(m.text())) errs.push(m.text()); });

    await page.goto(BASE + "/vehicles");
    await page.getByText(/needs an account/).first().waitFor({ timeout: 60000 });
    check("signed out: the vehicles page asks for an account", (await page.getByText(/needs an account/).count()) >= 1);
    await page.goto(BASE + "/dashboard");
    await page.waitForURL(/\/signin\?next=%2Fdashboard/, { timeout: 30000 });
    check("signed out: the dashboard sends you to sign in and remembers where you were going", true);
    await page.goto(BASE + "/admin/users");
    await page.waitForURL(/\/signin\?next=%2Fadmin%2Fusers/, { timeout: 30000 });
    check("signed out: admin pages send you to sign in", true);

    await page.goto(BASE + "/signin");
    await page.getByTestId("tab-up").click();
    await page.fill("#email", citizenEmail);
    await page.fill("#password", "short");
    await page.fill("#confirm", "short");
    await page.getByTestId("submit").click();
    check("short password refused with a message", await page.getByTestId("auth-error").isVisible());
    await page.fill("#password", PASSWORD);
    await page.fill("#confirm", PASSWORD + "x");
    await page.getByTestId("submit").click();
    check("mismatched passwords refused", /do not match/.test(await page.getByTestId("auth-error").innerText()));
    await page.fill("#confirm", PASSWORD);
    await page.getByTestId("submit").click();
    await page.waitForURL(/\/onboarding/, { timeout: 30000 });
    check("sign-up lands on onboarding", true);
    await page.getByTestId("verify-email").waitFor({ timeout: 15000 });
    check("unverified email banner shown", true);

    // consent
    await page.getByTestId("step-consent").waitFor();
    check("save disabled until all agreements ticked", await page.getByTestId("save-consent").isDisabled());
    for (const k of ["terms", "privacy", "sms"]) await page.getByTestId(`consent-${k}`).check();
    await page.getByTestId("save-consent").click();

    // profile
    await page.getByTestId("step-profile").waitFor();
    await page.fill("#givenName", "Ama");
    await page.fill("#familyName", "Mensah");
    await page.fill("#dob", "2015-05-05");
    await page.selectOption("#gender", "female");
    await page.getByTestId("save-profile").click();
    await page.getByTestId("err-dob").waitFor();
    check("under-age date of birth refused with field error", /At least/.test(await page.getByTestId("err-dob").innerText()));
    await page.fill("#dob", "1995-04-12");
    await page.getByTestId("save-profile").click();

    // phone
    await page.getByTestId("step-phone").waitFor();
    await page.fill("#phone", "12345");
    await page.getByTestId("send-code").click();
    await page.getByTestId("phone-error").waitFor();
    check("non-Ghana number refused", /Ghana mobile/.test(await page.getByTestId("phone-error").innerText()));
    await page.fill("#phone", "024 123 4567");
    await page.getByTestId("send-code").click();
    await page.getByTestId("code-sent").waitFor();
    check("code-sent notice masks the number", /\+233•+4567/.test(await page.getByTestId("code-sent").innerText()));
    const code = lastCode("+233241234567");
    check("SMS reached the (mock) provider with a 6-digit code", /^\d{6}$/.test(code || ""));
    check("code is not present anywhere in the page", !(await page.content()).includes(code));
    await page.fill("#code", code === "000000" ? "111111" : "000000");
    await page.getByTestId("confirm-code").click();
    await page.getByTestId("code-error").waitFor();
    check("wrong code refused, tries counted", /4 tries left/.test(await page.getByTestId("code-error").innerText()));
    await page.fill("#code", code);
    await page.getByTestId("confirm-code").click();

    // address (region -> district -> city -> suburb)
    await page.getByTestId("step-address").waitFor();
    check("district list disabled until a region is chosen", await page.locator("#districtId").isDisabled());
    await page.selectOption("#regionCode", "GAR");
    check("district list now holds Greater Accra's 29 districts", (await page.locator("#districtId option").count()) === 30);
    await page.getByTestId("save-address").click();
    await page.getByTestId("err-districtId").waitFor();
    check("missing district/city/suburb refused", true);
    await page.selectOption("#districtId", "GAR-accra");
    await page.fill("#city", "Accra");
    await page.fill("#suburb", "East Legon");
    await page.fill("#gpsAddress", "ga-543-1234x");
    await page.getByTestId("save-address").click();
    await page.getByTestId("err-gpsAddress").waitFor();
    check("bad GhanaPostGPS refused", true);
    await page.fill("#gpsAddress", "ga-543-1234");
    await page.getByTestId("save-address").click();

    await page.getByTestId("onboarding-complete").waitFor();
    check("onboarding complete without any ID", true);
    await page.screenshot({ path: path.join(dir, "onboarding-done.png") });

    // ID step is optional: add a Ghana Card
    await page.getByTestId("pill-id").click();
    await page.fill("#idNumber", "GHA-12345-0");
    await page.getByTestId("add-id").click();
    await page.getByTestId("err-idNumber").waitFor();
    check("malformed Ghana Card refused", true);
    await page.fill("#idNumber", "gha 555123789 0");
    await page.getByTestId("add-id").click();
    await page.getByTestId("id-list").waitFor();
    check("ID added; shown as waiting for review", /Waiting for review/.test(await page.getByTestId("id-list").innerText()) && /7890/.test(await page.getByTestId("id-list").innerText()));
    check("full ID number is not on the page", !(await page.locator("body").innerText()).includes("555123789"));

    // account page
    await page.goto(BASE + "/account");
    await page.getByTestId("id-level").waitFor();
    check("account page: level 1", /Level 1/.test(await page.getByTestId("id-level").innerText()));
    check("address shows suburb, district, region", /East Legon.*Accra.*Greater Accra Region/.test(await page.getByTestId("address").innerText()));
    check("vehicle:register is blocked (email not verified yet)", /Verify email/.test(await page.getByTestId("cap-vehicle:register").innerText()));
    check("licence issuing is not for a citizen", /Not for your role/.test(await page.getByTestId("cap-license:issue").innerText()));
    await page.getByTestId("pref-sms").uncheck();
    await page.reload();
    await page.getByTestId("pref-sms").waitFor();
    check("notification preference persisted", !(await page.getByTestId("pref-sms").isChecked()));

    // gate on the demo page
    await page.goto(BASE + "/vehicles");
    await page.getByText(/is locked/).first().waitFor({ timeout: 20000 });
    check("vehicles page is locked for this account", true);
    await page.goto(BASE + "/licences");
    await page.getByText(/is locked/).first().waitFor({ timeout: 20000 });
    check("licences page is locked for this account", true);
    await page.goto(BASE + "/admin/users");
    await page.getByTestId("page-locked").waitFor({ timeout: 20000 });
    check("a citizen who opens an admin page is told it is locked (and the Admin menu is not offered)", (await page.getByText("Admin", { exact: true }).count()) === 0);

    // ---------- API: citizen cannot do admin things; role is not settable ----------
    const cit = await signIn(citizenEmail, PASSWORD);
    const me0 = await call(cit.idToken, "GET", "/api/me");
    check("/api/me: citizen, level 1, onboarding complete", me0.body.me.role === "citizen" && me0.body.me.identity.level === 1 && me0.body.me.onboarding.complete);
    check("/api/me exposes no hashes, encrypted numbers or full phone", !/Hmac|encNumber|e164|\+233241234567|GHA-?123456789/.test(JSON.stringify(me0.body)));
    const tryAdmin = await call(cit.idToken, "GET", "/api/admin/users");
    check("citizen -> admin API is 403 role", tryAdmin.status === 403 && tryAdmin.body.code === "role");
    const tryRole = await call(cit.idToken, "POST", `/api/admin/users/${cit.localId}/role`, { role: "super_admin" });
    check("citizen cannot promote self (403)", tryRole.status === 403);
    const sneak = await call(cit.idToken, "POST", "/api/onboarding/profile", { givenName: "Ama", familyName: "Mensah", dob: "1995-04-12", gender: "female", role: "super_admin", identity: { level: 2 } });
    const me1 = await call(cit.idToken, "GET", "/api/me");
    check("role/level in a request body are ignored", sneak.status === 200 && me1.body.me.role === "citizen" && me1.body.me.identity.level === 1);
    const capNo = await call(cit.idToken, "GET", "/api/capability/vehicle:register");
    check("capability endpoint: 403 (email not verified)", capNo.status === 403 && capNo.body.code === "email_unverified");
    check("unknown capability refused", (await call(cit.idToken, "GET", "/api/capability/nope")).status === 403);

    // ---------- admin: bootstrap, review the citizen's ID ----------
    const adm = await signUp(adminEmail, PASSWORD);
    await verifyEmailInEmulator(adminEmail, adm.idToken);
    await completeViaApi(adm.idToken, "0551234567");
    await sleep(1200); // Firebase compares token issue time and revocation time in whole seconds
    const sr = spawnSync("node", ["scripts/set-role.js", "--email", adminEmail, "--role", "super_admin", "--confirm-identity"], { cwd: ROOT, env: { ...process.env, ...ENV, NODE_ENV: "development" }, encoding: "utf8" });
    check("set-role script promotes the founding admin", sr.status === 0 && /super_admin/.test(sr.stdout), sr.stdout + sr.stderr);
    const stale = await call(adm.idToken, "GET", "/api/me");
    check("role change revokes the old session token (401)", stale.status === 401, JSON.stringify(stale.body));
    const adm2 = await signIn(adminEmail, PASSWORD);
    const adminMe = await call(adm2.idToken, "GET", "/api/me");
    check("after signing in again the admin has the new role at level 2", adminMe.body.me.role === "super_admin" && adminMe.body.me.identity.level === 2, JSON.stringify(adminMe.body).slice(0, 300));

    const list = await call(adm2.idToken, "GET", "/api/admin/users?role=citizen&status=active");
    check("admin lists citizens", list.status === 200 && list.body.users.some((u) => u.email === citizenEmail));
    const byReg = await call(adm2.idToken, "GET", "/api/admin/users?regionCode=GAR");
    check("admin lists users by region", byReg.status === 200 && byReg.body.users.some((u) => u.email === citizenEmail));
    const bad = await call(adm2.idToken, "GET", "/api/admin/users?role=citizen&regionCode=GAR");
    check("two filter groups at once -> 422", bad.status === 422);
    const q = await call(adm2.idToken, "GET", "/api/admin/identity");
    const doc = q.body.documents.find((d) => d.uid === cit.localId);
    check("review queue contains the citizen's ID (last 4 only)", !!doc && doc.last4 === "7890" && !JSON.stringify(q.body).includes("555123789"));
    const rev = await call(adm2.idToken, "POST", `/api/admin/identity/${doc.id}/reveal`);
    check("reviewer can reveal the number (logged)", rev.status === 200 && rev.body.number === "GHA-555123789-0" && rev.body.holder.name === "Ama Mensah");
    const own = await call(cit.idToken, "POST", `/api/admin/identity/${doc.id}/review`, { decision: "verified" });
    check("citizen cannot review", own.status === 403);

    // the email is still unverified: an ID alone is not enough
    const ver = await call(adm2.idToken, "POST", `/api/admin/identity/${doc.id}/review`, { decision: "verified", note: "Matches card" });
    check("reviewer confirms the ID", ver.status === 200);
    const cit2 = await signIn(citizenEmail, PASSWORD);
    const capEmail = await call(cit2.idToken, "GET", "/api/capability/vehicle:register");
    check("level 2 but email unverified -> still refused (email_unverified)", capEmail.status === 403 && capEmail.body.code === "email_unverified", JSON.stringify(capEmail.body));
    await verifyEmailInEmulator(citizenEmail);

    // UI: the citizen refreshes and the gate opens
    await page.goto(BASE + "/account");
    await page.getByTestId("id-level").waitFor();
    await page.getByRole("button", { name: "I have verified" }).click().catch(() => {});
    await page.waitForFunction(() => !document.querySelector('[data-testid="verify-email"]'), null, { timeout: 15000 }).catch(() => {});
    await page.reload();
    await page.getByTestId("cap-vehicle:register").waitFor();
    check("account page: level 2 and vehicle registration allowed", /Level 2/.test(await page.getByTestId("id-level").innerText()) && /Allowed/.test(await page.getByTestId("cap-vehicle:register").innerText()));
    await page.goto(BASE + "/vehicles");
    await page.waitForSelector("text=Register a vehicle", { timeout: 20000 }).catch(() => {});
    const capOk = await call((await signIn(citizenEmail, PASSWORD)).idToken, "GET", "/api/capability/vehicle:register");
    check("capability endpoint now 200", capOk.status === 200);
    await page.screenshot({ path: path.join(dir, "demo-unlocked.png") });

    // the email-notification wallet link works with a REAL Firebase token (it only ever ran with fake dev tokens before)
    const WALLET = "0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1";
    const wl = await call((await signIn(citizenEmail, PASSWORD)).idToken, "POST", "/api/wallet-link/challenge", { address: WALLET });
    check("wallet-link challenge accepts a real Firebase token (verified email)", wl.status === 200 && /ClassTryout/i.test(JSON.stringify(wl.body)) && !!wl.body.message, JSON.stringify(wl));
    const wlAnon = await call("junk", "POST", "/api/wallet-link/challenge", { address: WALLET });
    check("wallet-link challenge rejects a bad token", wlAnon.status === 401);

    // after confirmation the name is locked
    const lock = await call(cit2.idToken, "POST", "/api/onboarding/profile", { givenName: "Someone", familyName: "Else", dob: "1990-01-01", gender: "male" });
    check("confirmed ID locks name and date of birth (409)", lock.status === 409 && lock.body.code === "locked");

    // another account cannot reuse the same Ghana Card
    const thief = await signUp(`thief.${suffix}@example.test`, PASSWORD);
    await completeViaApi(thief.idToken, "0261234567");
    await verifyEmailInEmulator(`thief.${suffix}@example.test`, thief.idToken);
    const thief2 = await signIn(`thief.${suffix}@example.test`, PASSWORD);
    const capLevel = await call(thief2.idToken, "GET", "/api/capability/vehicle:register");
    check("verified email but no confirmed ID -> 403 level", capLevel.status === 403 && capLevel.body.code === "level", JSON.stringify(capLevel.body));
    const dup = await call(thief2.idToken, "POST", "/api/identity", { type: "ghana_card", number: "GHA-555123789-0" });
    check("same Ghana Card on a second account -> 409", dup.status === 409 && dup.body.code === "id_in_use");

    // suspension
    const susp = await call(adm2.idToken, "POST", `/api/admin/users/${thief.localId}/status`, { status: "suspended", note: "e2e" });
    check("admin suspends an account", susp.status === 200);
    const gone = await call(thief.idToken, "GET", "/api/me");
    check("suspended account: old token is revoked / refused", gone.status === 401 || gone.status === 403, JSON.stringify(gone.body));
    const again = await signIn(`thief.${suffix}@example.test`, PASSWORD);
    const gone2 = await call(again.idToken, "GET", "/api/me");
    check("suspended account: fresh sign-in still refused (403 suspended)", gone2.status === 403 && gone2.body.code === "suspended");

    // phone number cannot be taken by a second account
    const p2 = await signUp(`dup.${suffix}@example.test`, PASSWORD);
    await call(p2.idToken, "POST", "/api/onboarding/consent", { terms: true, privacy: true, sms: true });
    const dupPhone = await call(p2.idToken, "POST", "/api/onboarding/phone/start", { phone: "0241234567" });
    check("verified phone cannot be claimed by another account (409)", dupPhone.status === 409 && dupPhone.body.code === "phone_in_use");

    // audit trail exists
    const store = JSON.parse(fs.readFileSync(ENV.STORE_FILE, "utf8"));
    const actions = Object.values(store.auditLogs || {}).map((a) => a.action);
    check("audit log has role, bootstrap, reveal, verify, suspend entries", ["user.role", "identity.bootstrap", "identity.reveal", "identity.verified", "user.status"].every((a) => actions.includes(a)), actions.join(","));
    const blob = JSON.stringify(store);
    check("store never holds a full ID number in clear (only hash, last 4, and the encrypted copy while pending)", !/GHA-?555123789-?0/.test(blob) && !/555123789/.test(blob));
    check("phone claims are keyed by hash, not by number", Object.keys(store.phoneClaims || {}).every((k) => /^[0-9a-f]{64}$/.test(k)) && Object.keys(store.identityClaims || {}).every((k) => /^[0-9a-f]{64}$/.test(k)));

    // sign out
    await page.goto(BASE + "/account");
    await page.getByRole("button", { name: "Sign out" }).click();
    await page.waitForFunction(() => !document.querySelector("button") || ![...document.querySelectorAll("button")].some((b) => b.textContent === "Sign out"), null, { timeout: 20000 });
    await page.goto(BASE + "/signin");
    check("sign out works", true);
    await page.fill("#email", citizenEmail);
    await page.fill("#password", "wrong password here");
    await page.getByTestId("submit").click();
    await page.getByTestId("auth-error").waitFor();
    check("wrong password: generic message", /do not match/.test(await page.getByTestId("auth-error").innerText()));
    await page.fill("#password", PASSWORD);
    await page.getByTestId("submit").click();
    await page.waitForURL(/\/dashboard/, { timeout: 30000 });
    check("sign back in lands on the dashboard", true);

    // mobile layout
    const mobile = await browser.newPage({ viewport: { width: 375, height: 800 } });
    await mobile.goto(BASE + "/signin");
    const overflow = await mobile.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
    check("sign-in has no horizontal scroll at 375px", !overflow);
    await mobile.screenshot({ path: path.join(dir, "signin-mobile.png") });

    check("no page errors in the browser", errs.length === 0, errs.slice(0, 3).join(" | "));
  } catch (e) {
    fail++;
    console.log("FAIL  test crashed: " + (e && e.stack ? e.stack : e));
    console.log("--- server log tail ---\n" + serverLog.slice(-2500));
  } finally {
    if (browser) await browser.close();
    stop();
  }
  console.log(`\n${pass} passed, ${fail} failed   (screenshots in ${dir})`);
  process.exit(fail ? 1 : 0);
})();
