const { chromium } = require("playwright");
const PORTS = { 1337: 7545, 5777: 7545, 8453: 7546, 42161: 7547 };
let id = 1;
async function rpc(port, method, params=[]) {
  const r = await fetch(`http://127.0.0.1:${port}`,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({jsonrpc:"2.0",id:id++,method,params})});
  return r.json();
}
const BASE = process.env.BASE_URL || "http://localhost:3100";
const SUF = Date.now().toString(36).slice(-4);
const CAR_A="car-A-"+SUF, CAR_B="car-B-"+SUF, CAR_C="car-C-"+SUF;
(async () => {
  const browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
  const page = await browser.newPage({ viewport:{width:1200,height:1400}});
  const added = [];
  const errs = [];
  page.on("pageerror", e => errs.push(e.message));
  await page.exposeFunction("__rpc", async (chain, method, params) => {
    const port = PORTS[chain];
    if (!port) return { error:{ code:-32000, message:"no node for chain "+chain } };
    if (method === "eth_sendTransaction" && !params[0].gas) {
      const est = await rpc(port,"eth_estimateGas",[params[0]]);
      if (est.error) return est;
      params[0].gas = "0x"+Math.ceil(parseInt(est.result,16)*1.2).toString(16);
    }
    return rpc(port, method, params);
  });
  await page.exposeFunction("__noteAdd", (p)=>{ added.push(p); });
  const A = (await rpc(7545,"eth_accounts")).result[0];
  await page.addInitScript(({A}) => {
    // state persisted across reloads in window.name
    let st; try { st = JSON.parse(window.name); } catch(e) {}
    if (!st || !st.chain) { st = { chain: 1337, known: [1337, 8453], rejectNext: false }; window.name = JSON.stringify(st); }
    const save = () => { window.name = JSON.stringify(st); };
    const listeners = {};
    const fire = (ev, arg) => (listeners[ev]||[]).forEach(f=>f(arg));
    window.__setReject = (v)=>{ st.rejectNext = v; save(); };
    window.ethereum = {
      isMetaMask: true,
      on(ev, fn){ (listeners[ev] ||= []).push(fn); },
      removeListener(){},
      async request({method, params}) {
        if (method === "eth_requestAccounts" || method === "eth_accounts") return [A];
        if (method === "wallet_switchEthereumChain") {
          if (st.rejectNext) { st.rejectNext=false; save(); const e=new Error("User rejected the request."); e.code=4001; throw e; }
          const cid = parseInt(params[0].chainId,16);
          if (!st.known.includes(cid)) { const e=new Error("Unrecognized chain ID. Try adding the chain using wallet_addEthereumChain first."); e.code=4902; throw e; }
          st.chain = cid; save(); fire("chainChanged", params[0].chainId); return null;
        }
        if (method === "wallet_addEthereumChain") {
          await window.__noteAdd(params[0]);
          const cid = parseInt(params[0].chainId,16);
          st.known.push(cid); st.chain = cid; save(); fire("chainChanged", params[0].chainId); return null;
        }
        const res = await window.__rpc(st.chain, method, params || []);
        if (res.error) { const e = new Error(res.error.message); e.code = res.error.code; throw e; }
        return res.result;
      },
    };
  }, {A});

  const results = []; 
  async function step(name, fn) { try { const o = await fn(); results.push(1); console.log("OK  ", name, o??""); } catch(e){ results.push(0); console.log("FAIL", name, "-", e.message.split("\n")[0].slice(0,400)); } }
  const bar = () => page.locator("div[class*=walletBar]");
  const sel = () => page.locator("select[aria-label=Network]");
  async function ready(){ await page.waitForFunction(()=>!!document.querySelector("select[aria-label=Network]"),{timeout:15000}); }
  const vcard = ()=> page.locator("div[class*=card]").filter({has: page.getByRole("heading",{name:"Vehicle Registry"})});
  const body = async()=> (await page.locator("main").innerText()).replace(/\n+/g," | ");

  await page.goto(BASE + "/vehicles");
  await step("auto-connect shows network picker on Ganache", async()=>{ await ready(); const v = await sel().inputValue(); if (v!=="1337") throw new Error("selected="+v); const t=await body(); if (/live network|not deployed on/.test(t)) throw new Error("unexpected banner: "+t.slice(0,300)); return "selected 1337, no banners"; });
  await step("picker lists groups and marks undeployed chains", async()=>{
    const opts = await sel().locator("option").allInnerTexts(); const groups = await sel().locator("optgroup").evaluateAll(g=>g.map(x=>x.label));
    const need = ["Ethereum Mainnet — not deployed yet","Arbitrum One — not deployed yet","OP Mainnet — not deployed yet","Arbitrum Sepolia — not deployed yet","Polygon PoS — not deployed yet"];
    for (const n of need) if(!opts.includes(n)) throw new Error("missing option "+n+" in "+JSON.stringify(opts));
    if (!opts.includes("Base")) throw new Error("Base should be marked deployed: "+JSON.stringify(opts));
    if (!opts.includes("Sepolia")) throw new Error("Sepolia (deployed through Remix, recorded in shared/deployments.json) should be marked deployed: "+JSON.stringify(opts));
    return groups.join(" / ");
  });
  await step("register car-A on local chain (1337)", async()=>{
    await page.getByPlaceholder("Vehicle pseudonym, e.g.",{exact:false}).fill(CAR_A);
    await page.getByRole("button",{name:"Register",exact:true}).click(); await page.waitForTimeout(2500);
    const t=await body(); if(!/registered on-chain/i.test(t)) throw new Error(t.slice(0,300)); return "registered";
  });
  await step("switch to Base (known to wallet) via picker -> reload, red live-network banner", async()=>{
    await sel().selectOption("8453"); await page.waitForTimeout(1500); await ready();
    const v = await sel().inputValue(); if (v!=="8453") throw new Error("selected="+v);
    const t = await body(); if(!/Base, a live network/.test(t)) throw new Error("no danger banner: "+t.slice(0,300));
    if (/not deployed on/.test(t)) throw new Error("wrongly says not deployed");
    return "selected 8453 + danger banner";
  });
  await step("state is separate per chain: car-A not registered on Base", async()=>{
    await page.getByPlaceholder("Vehicle pseudonym to check").fill(CAR_A); await vcard().getByRole("button",{name:"Look Up",exact:true}).click(); await page.waitForTimeout(1500);
    const t=await body(); if(!/Not registered/i.test(t)) throw new Error(t.slice(0,300)); return "Not registered on Base";
  });
  await step("register car-B on Base works (uses Base addresses)", async()=>{
    await page.getByPlaceholder("Vehicle pseudonym, e.g.",{exact:false}).fill(CAR_B);
    await page.getByRole("button",{name:"Register",exact:true}).click(); await page.waitForTimeout(2500);
    const t=await body(); if(!/registered on-chain/i.test(t)) throw new Error(t.slice(0,300)); return "registered on 8453";
  });
  await step("switch to Arbitrum One (unknown to wallet) -> addEthereumChain params correct", async()=>{
    await sel().selectOption("42161"); await page.waitForTimeout(2000); await ready();
    if (added.length!==1) throw new Error("addEthereumChain calls: "+added.length);
    const p = added[0];
    const ok = p.chainId==="0xa4b1" && p.chainName==="Arbitrum One" && p.rpcUrls[0]==="https://arb1.arbitrum.io/rpc" && p.nativeCurrency.symbol==="ETH" && p.blockExplorerUrls[0]==="https://arbiscan.io";
    if(!ok) throw new Error(JSON.stringify(p));
    return JSON.stringify(p);
  });
  await step("on Arbitrum (no deployment): amber 'not deployed' + red banner", async()=>{
    const t=await body(); if(!/not deployed on Arbitrum One/.test(t)||!/Arbitrum One, a live network/.test(t)) throw new Error(t.slice(0,400)); return "both banners";
  });
  await step("register on undeployed chain -> clear error, no crash", async()=>{
    await page.getByPlaceholder("Vehicle pseudonym, e.g.",{exact:false}).fill(CAR_C);
    await page.getByRole("button",{name:"Register",exact:true}).click(); await page.waitForTimeout(2000);
    const t=await body(); if(!/not deployed on Arbitrum One \(chain 42161/.test(t)) throw new Error(t.slice(0,400)); return "clear message";
  });
  await step("wallet rejects network switch -> friendly message", async()=>{
    await page.evaluate(()=>window.__setReject(true));
    await sel().selectOption("8453"); await page.waitForTimeout(1200);
    const t=(await page.locator("header").innerText()).replace(/\n+/g," | "); if(!/rejected the request in your wallet/.test(t)) throw new Error(t.slice(0,300)); return "friendly";
  });
  await step("switch back to Ganache; first vehicle still there", async()=>{
    await sel().selectOption("1337"); await page.waitForTimeout(1500); await ready();
    await page.getByPlaceholder("Vehicle pseudonym to check").fill(CAR_A); await vcard().getByRole("button",{name:"Look Up",exact:true}).click(); await page.waitForTimeout(1500);
    const t=await body(); if(!/Status: Active/.test(t)) throw new Error(t.slice(0,300)); return "car-A Active on 1337";
  });
  await page.screenshot({path:"multichain.png", fullPage:true});
  console.log("page errors:", errs);
  console.log(results.filter(Boolean).length+"/"+results.length+" passed");
  await browser.close();
})();
