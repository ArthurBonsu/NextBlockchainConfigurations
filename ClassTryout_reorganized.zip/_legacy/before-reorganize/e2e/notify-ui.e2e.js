// Browser test for the "Email notifications" panel, in test-sign-in mode. Needs (see e2e/README.md):
//   a local chain with contracts deployed, and a dev server started like this:
//   NEXT_PUBLIC_NOTIFY_BACKEND=dev NEXT_PUBLIC_SHOW_LOCAL=true NOTIFY_BACKEND=dev WALLET_LINK_SECRET=<16+ chars> \
//     DEV_LINKS_FILE=/tmp/ui-links.json npx next dev -p 3100
//   node e2e/notify-ui.e2e.js
const { chromium } = require("playwright");
const RPC = "http://127.0.0.1:7545";
const BASE = process.env.BASE_URL || "http://127.0.0.1:3100";
let id = 1;
const rpc = async (method, params = []) => (await (await fetch(RPC, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: id++, method, params }) })).json());
let pass = 0, fail = 0;
const check = (n, ok, x = "") => (ok ? pass++ : fail++, console.log(`${ok ? "PASS" : "FAIL"}  ${n}${ok ? "" : "  " + x}`));

(async () => {
  const A = (await rpc("eth_accounts")).result[5];
  const browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
  const page = await browser.newPage({ viewport: { width: 1200, height: 1600 } });
  const errs = [];
  page.on("pageerror", (e) => errs.push(e.message));
  await page.exposeFunction("__rpc", async (method, params) => rpc(method, params));
  await page.addInitScript(({ A }) => {
    window.ethereum = {
      isMetaMask: true,
      on() {}, removeListener() {},
      async request({ method, params }) {
        if (method === "eth_requestAccounts" || method === "eth_accounts") return [A];
        // MetaMask's personal_sign(message, address) is eth_sign(address, message) on Ganache (same EIP-191 prefix)
        const r = method === "personal_sign" ? await window.__rpc("eth_sign", [params[1], params[0]]) : await window.__rpc(method, params || []);
        if (r.error) { const e = new Error(r.error.message); e.code = r.error.code; throw e; }
        return r.result;
      },
    };
  }, { A });

  await page.goto(BASE + "/notifications");
  const card = page.locator("div", { has: page.locator("h2", { hasText: "Email notifications" }) }).last();
  await card.waitFor();
  check("panel shows, nothing linked", await page.getByText("No wallet linked to this account yet.").isVisible());

  await page.getByPlaceholder("test user id").fill("ui-user");
  await page.getByPlaceholder("test email").fill("ui@example.test");
  await page.getByRole("button", { name: "Use this account" }).click();
  await page.getByRole("button", { name: "Link this wallet" }).click();
  await page.getByText("Wallet linked.").waitFor({ timeout: 15000 });
  check("link flow signs a message and succeeds", true);
  check("wallet now listed and button disabled", (await page.getByRole("button", { name: "This wallet is linked" }).isDisabled()) && (await page.getByText(A.slice(0, 6)).count()) > 0);

  await page.reload();
  await page.getByPlaceholder("test user id").fill("ui-user");
  await page.getByPlaceholder("test email").fill("ui@example.test");
  await page.getByRole("button", { name: "Use this account" }).click();
  await page.getByText("This wallet is linked").waitFor({ timeout: 10000 });
  check("link survives a reload (stored on the server)", true);

  await page.getByRole("button", { name: "Unlink" }).click();
  await page.getByText("Wallet unlinked.").waitFor({ timeout: 10000 });
  check("unlink works", await page.getByRole("button", { name: "Link this wallet" }).isEnabled());

  // unverified email: server refuses and the panel says why
  await page.getByPlaceholder("test user id").fill("ui-user2");
  await page.getByPlaceholder("test email").fill("u2@example.test");
  await page.getByLabel("email verified").uncheck();
  await page.getByRole("button", { name: "Use this account" }).click();
  await page.getByRole("button", { name: "Link this wallet" }).click();
  await page.getByText(/Verify your email address first/).waitFor({ timeout: 10000 });
  check("unverified email is refused with a clear message", true);

  check("no page errors", errs.length === 0, errs.join("; "));
  console.log(`\n${pass} passed, ${fail} failed`);
  await browser.close();
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
