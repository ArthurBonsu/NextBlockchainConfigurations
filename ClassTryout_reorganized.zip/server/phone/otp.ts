// server/phone/otp.ts
// Phone verification with one-time codes.
// WE make and check the codes. The SMS provider only carries the message, so changing provider never changes how it works.
//
//   phoneChallenges/{uid}        one live challenge per account (asking again replaces it)
//                                { uid, phone (E.164), codeHmac, attempts, status, createdAt, resendAfter, expireAt }
//   phoneClaims/{hmac(phone)}    one verified phone per account: { uid, claimedAt }
//
// Protections: agreements first; send limits per phone, per account and per IP; 60 seconds between sends;
// 5 wrong guesses lock the code; codes expire after 10 minutes; codes are kept only as a keyed hash;
// the code is never returned by the API and never logged.

import onboarding from '../../shared/onboarding.json';
import { store, nowIso } from '../database';
import { bad, conflict, tooMany, forbidden, HttpError } from '../errors';
import { hmac, otpHmac, safeEqualHex, randomCode, hit, audit } from '../security';
import { sendSms } from '../sms';
import { requireUser, touchOnboarding } from '../users';
import type { UserDoc } from '../users';
import { normaliseGhPhone, last4, mask } from './phone';

const settings = onboarding.otp;

export function phoneClaimId(e164: string): string {
  return hmac('phone', e164);
}

// ---------------------------------------------------------------- asking for a code
async function checkPersonMayAskForCode(user: UserDoc, phone: string): Promise<void> {
  if (user.status === 'suspended') throw forbidden('This account is suspended.', 'suspended');

  const smsAgreement = user.consents && user.consents.sms;

  if (!(smsAgreement && smsAgreement.version === onboarding.consents.sms.version)) {
    throw forbidden('Accept the SMS agreement first.', 'consent_required');
  }

  if (user.phone && user.phone.verified && user.phone.e164 === phone) {
    throw conflict('This number is already verified on your account.', 'already_verified');
  }

  // Did someone else already verify this number?
  const claim = await store().get('phoneClaims', phoneClaimId(phone));

  if (claim && claim.uid !== user.uid) throw conflict('This number is already used by another account.', 'phone_in_use');
}

// Wait between sends. This is checked before the counters, so an impatient double-click does not use up the daily allowance.
async function checkNotTooSoon(uid: string, phone: string): Promise<void> {
  const existing = await store().get('phoneChallenges', uid);

  if (existing && existing.phone === phone && existing.resendAfter > nowIso()) {
    const wait = Math.max(1, Math.ceil((Date.parse(existing.resendAfter) - Date.now()) / 1000));

    throw tooMany(`Please wait ${wait} seconds before asking for another code.`, wait);
  }
}

async function countThisSend(uid: string, phone: string, ip?: string | null): Promise<void> {
  await hit(`otp:phone:${phone}`, settings.maxSendsPerPhonePerDay, 86400, 'Too many codes sent to this number today. Try again tomorrow.');
  await hit(`otp:uid:${uid}`, settings.maxSendsPerUidPerDay, 86400, 'Too many codes requested today. Try again tomorrow.');

  if (ip) await hit(`otp:ip:${ip}`, settings.maxSendsPerIpPerHour, 3600, 'Too many requests from this network. Try again later.');
}

export async function startPhoneVerification(uid: string, rawPhone: unknown, ip?: string | null) {
  const phone = normaliseGhPhone(rawPhone);
  const user = await requireUser(uid);

  await checkPersonMayAskForCode(user, phone);
  await checkNotTooSoon(uid, phone);
  await countThisSend(uid, phone, ip);

  const code = randomCode(settings.length);
  const now = Date.now();

  await store().set('phoneChallenges', uid, {
    uid,
    phone,
    codeHmac: otpHmac(uid, phone, code),
    attempts: 0,
    status: 'pending',
    createdAt: new Date(now).toISOString(),
    resendAfter: new Date(now + settings.resendSeconds * 1000).toISOString(),
    expireAt: new Date(now + settings.ttlSeconds * 1000).toISOString(),
  });

  try {
    const minutes = Math.round(settings.ttlSeconds / 60);

    await sendSms({ to: phone, text: `${code} is your ClassTryout code. It expires in ${minutes} minutes. Do not share it.` });
  } catch (error: any) {
    await store().delete('phoneChallenges', uid);
    console.error('[otp] SMS send failed:', error && error.message); // the message only: never the code or the number

    throw new HttpError(502, 'We could not send the SMS right now. Try again in a few minutes.', 'sms_failed');
  }

  return { sentTo: mask(phone), expiresInSeconds: settings.ttlSeconds, resendInSeconds: settings.resendSeconds };
}

// ---------------------------------------------------------------- checking the code
// Inside the transaction we cannot throw for a wrong code (the wrong-attempt count must still be saved),
// so the steps return { error } and the error is thrown after the transaction.
type ConfirmResult = { error: HttpError } | { ok: true };

export async function confirmPhoneVerification(uid: string, rawCode: unknown, ip?: string | null): Promise<UserDoc> {
  const code = String(rawCode || '').replace(/\s/g, '');

  if (!new RegExp(`^[0-9]{${settings.length}}$`).test(code)) {
    throw bad(`Enter the ${settings.length}-digit code.`, { code: 'Check the code.' });
  }

  await hit(`otp:confirm:${uid}`, 30, 3600, 'Too many attempts. Try again later.');

  const result = await store().transaction<ConfirmResult>(async (tx) => {
    const challenge = await tx.get('phoneChallenges', uid);
    const user = (await tx.get('users', uid)) as UserDoc;

    if (!challenge || challenge.status !== 'pending') return { error: new HttpError(410, 'Ask for a new code.', 'no_challenge') };

    if (challenge.expireAt <= nowIso()) return { error: new HttpError(410, 'That code has expired. Ask for a new one.', 'expired') };

    if (challenge.attempts >= settings.maxAttempts) {
      return { error: new HttpError(429, 'Too many wrong codes. Ask for a new code.', 'locked') };
    }

    const isRight = safeEqualHex(challenge.codeHmac, otpHmac(uid, challenge.phone, code));

    if (!isRight) {
      await tx.update('phoneChallenges', uid, { attempts: challenge.attempts + 1 });

      const triesLeft = settings.maxAttempts - challenge.attempts - 1;
      const message =
        triesLeft > 0 ? `That code is not right. ${triesLeft} ${triesLeft === 1 ? 'try' : 'tries'} left.` : 'Too many wrong codes. Ask for a new code.';

      return { error: new HttpError(422, message, triesLeft > 0 ? 'wrong_code' : 'locked', { fields: { code: 'Not right.' } }) };
    }

    const claimId = phoneClaimId(challenge.phone);
    const claim = await tx.get('phoneClaims', claimId);

    if (claim && claim.uid !== uid) return { error: new HttpError(409, 'This number is already used by another account.', 'phone_in_use') };

    const hadAnotherNumber = user.phone && user.phone.verified && user.phone.e164 && user.phone.e164 !== challenge.phone;
    const oldClaimId = hadAnotherNumber ? phoneClaimId(user.phone.e164 as string) : null;

    await tx.set('phoneClaims', claimId, { uid, claimedAt: nowIso() });

    if (oldClaimId) await tx.delete('phoneClaims', oldClaimId); // free the number the person is moving away from

    const now = nowIso();

    await tx.update(
      'users',
      uid,
      touchOnboarding(user, {
        phone: { e164: challenge.phone, last4: last4(challenge.phone), masked: mask(challenge.phone), verified: true, verifiedAt: now },
        updatedAt: now,
      })
    );

    await tx.delete('phoneChallenges', uid);

    return { ok: true };
  });

  if ('error' in result) throw result.error;

  await audit({ actor: { uid, role: 'self' }, action: 'phone.verified', target: { type: 'user', id: uid }, ip });

  return requireUser(uid);
}
