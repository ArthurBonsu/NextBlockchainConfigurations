// server/phone/phone.ts
// Ghana mobile numbers. We turn them into E.164 form (+233XXXXXXXXX) and check only the shape.
// We do NOT work out the network from the prefix: people keep their number when they change network,
// so the prefix says nothing reliable about who carries the SMS.

import { bad } from '../errors';

// 9 digits after +233, starting with 2 or 5 (020/023/024/025/026/027/028/029 and 050/053/054/055/056/057/059).
const GHANA_MOBILE = /^[25][0-9]{8}$/;

export function normaliseGhPhone(input: unknown): string {
  let digits = String(input || '').replace(/[\s().-]/g, '');

  if (!digits) throw bad('Enter your mobile number.', { phone: 'Required.' });

  if (digits.startsWith('+')) digits = digits.slice(1);
  if (digits.startsWith('00')) digits = digits.slice(2);

  if (digits.startsWith('233')) {
    digits = digits.slice(3);
  } else if (digits.startsWith('0')) {
    digits = digits.slice(1);
  }

  if (!/^[0-9]+$/.test(digits) || !GHANA_MOBILE.test(digits)) {
    throw bad('Enter a Ghana mobile number, for example 024 123 4567 or +233 24 123 4567.', { phone: 'Not a Ghana mobile number.' });
  }

  return '+233' + digits;
}

export function last4(e164: string): string {
  return e164.slice(-4);
}

// +233241234567 becomes +233•••••4567
export function mask(e164: string): string {
  return e164.replace(/^(\+233)\d{5}(\d{4})$/, '$1•••••$2');
}
