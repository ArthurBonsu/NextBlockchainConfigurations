// server/security/rateLimit.ts
// Fixed-window counters kept in the database (collection "rateLimits"), so the limits hold across serverless instances.
// Keys are hashed before they are stored, so IP addresses and phone numbers are not written in the clear.

import { store, nowIso } from '../database';
import { tooMany } from '../errors';
import { sha256 } from './crypto';

// hit('otp:phone:+233...', 5, 86400) throws a 429 error when more than 5 hits happen within a day.
export async function hit(key: string, limit: number, windowSeconds: number, message?: string) {
  const now = Date.now();
  const bucket = Math.floor(now / (windowSeconds * 1000));
  const id = sha256(`${key}|${windowSeconds}`).slice(0, 40) + '-' + bucket;
  const resetAt = (bucket + 1) * windowSeconds * 1000;

  const count = await store().transaction(async (tx) => {
    const current = await tx.get('rateLimits', id);
    const newCount = (current ? current.count : 0) + 1;

    await tx.set('rateLimits', id, {
      count: newCount,
      windowSeconds,
      createdAt: current ? current.createdAt : nowIso(),
      expireAt: new Date(resetAt + 3600_000).toISOString(),
    });

    return newCount;
  });

  if (count > limit) {
    const retryAfter = Math.max(1, Math.ceil((resetAt - now) / 1000));

    throw tooMany(message || 'Too many attempts. Please wait and try again.', retryAfter);
  }

  return { count, remaining: limit - count };
}
