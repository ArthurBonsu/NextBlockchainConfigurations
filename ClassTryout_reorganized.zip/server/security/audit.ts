// server/security/audit.ts
// An append-only record of who did what to whom.
// It is written for every role change, ID decision, status change and ID-number reveal.
// Secrets and ID or phone numbers are removed before anything is written.

import { store, nowIso } from '../database';

const SENSITIVE_FIELD = /(number|secret|token|hash|hmac|password|pepper|e164|^enc|otp|phone|apikey|api_key)/i;

export function redact(value: any, depth = 0): any {
  if (value === null || value === undefined) return value;

  if (Array.isArray(value)) return depth > 3 ? '[...]' : value.map((item) => redact(item, depth + 1));

  if (typeof value === 'object') {
    if (depth > 3) return '[...]';

    const out: Record<string, any> = {};

    for (const [key, inner] of Object.entries(value)) {
      out[key] = SENSITIVE_FIELD.test(key) ? '[removed]' : redact(inner, depth + 1);
    }

    return out;
  }

  if (typeof value === 'string' && value.length > 300) return value.slice(0, 300) + '...';

  return value;
}

export interface Actor {
  uid: string;
  role?: string | null; // 'system' for scripts, 'self' when a person changes their own data
}

export interface AuditEntry {
  actor: Actor;
  action: string; // for example 'user.role'
  target?: { type: string; id: string };
  before?: unknown;
  after?: unknown;
  note?: string;
  ip?: string | null;
}

export async function audit(entry: AuditEntry): Promise<string> {
  const row = {
    at: nowIso(),
    actor: { uid: entry.actor.uid, role: entry.actor.role || null },
    action: entry.action,
    target: entry.target || null,
    before: entry.before === undefined ? null : redact(entry.before),
    after: entry.after === undefined ? null : redact(entry.after),
    note: entry.note ? String(entry.note).slice(0, 500) : null,
    ip: entry.ip || null,
  };

  return store().add('auditLogs', row);
}
