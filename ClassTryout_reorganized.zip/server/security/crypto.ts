// server/security/crypto.ts
// Small crypto helpers. No ID number or code is ever stored in plain text.

import crypto from 'crypto';
import { secret, encKey } from '../config';

// A keyed hash. The label makes the same value hash differently for different purposes.
export function hmac(label: string, value: string): string {
  return crypto.createHmac('sha256', secret('ID_HASH_PEPPER')).update(`${label}:${value}`).digest('hex');
}

// The hash we keep for a one-time SMS code. The code itself is never kept.
export function otpHmac(uid: string, phone: string, code: string): string {
  return crypto.createHmac('sha256', secret('OTP_SECRET')).update(`otp:${uid}:${phone}:${code}`).digest('hex');
}

// Compares two hex strings in constant time, so the time taken does not give the answer away.
export function safeEqualHex(a: string, b: string): boolean {
  const first = Buffer.from(String(a), 'hex');
  const second = Buffer.from(String(b), 'hex');

  return first.length === second.length && first.length > 0 && crypto.timingSafeEqual(first, second);
}

// AES-256-GCM. The result looks like "v1.<iv>.<tag>.<ciphertext>" (base64url).
export function encrypt(plain: string, aad = ''): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', encKey(), iv);

  if (aad) cipher.setAAD(Buffer.from(aad));

  const encrypted = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);

  return ['v1', iv.toString('base64url'), cipher.getAuthTag().toString('base64url'), encrypted.toString('base64url')].join('.');
}

export function decrypt(blob: string, aad = ''): string {
  const [version, iv, tag, encrypted] = String(blob).split('.');

  if (version !== 'v1' || !iv || !tag || !encrypted) throw new Error('Unreadable encrypted value.');

  const decipher = crypto.createDecipheriv('aes-256-gcm', encKey(), Buffer.from(iv, 'base64url'));

  if (aad) decipher.setAAD(Buffer.from(aad));

  decipher.setAuthTag(Buffer.from(tag, 'base64url'));

  return Buffer.concat([decipher.update(Buffer.from(encrypted, 'base64url')), decipher.final()]).toString('utf8');
}

// A random number code like "482913". Every digit is equally likely.
export function randomCode(length = 6): string {
  let code = '';

  while (code.length < length) code += String(crypto.randomInt(0, 10));

  return code;
}

export function sha256(value: unknown): string {
  return crypto.createHash('sha256').update(String(value)).digest('hex');
}
