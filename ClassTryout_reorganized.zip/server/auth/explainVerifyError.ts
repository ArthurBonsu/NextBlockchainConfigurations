// server/auth/explainVerifyError.ts
// Turns what firebase-admin throws when it checks a token into something a person can act on.

import { AuthError, SetupError } from './authErrors';

const WRONG_PROJECT = /incorrect "aud"|incorrect "iss"/i;
const EXPECTED_VERSUS_GOT = /Expected "([^"]+)" but got "([^"]+)"/;
const CLOCK_WRONG = /used too early|Token used too early/i;

// The server could not talk to Google with its service account: a bad key, a wrong email, or no internet.
const CANNOT_REACH_GOOGLE =
  /credential|private key|\bPEM\b|DECODER|invalid_grant|invalid_client|Could not load the default|ENOTFOUND|ETIMEDOUT|ECONNREFUSED|EAI_AGAIN|fetch failed|getaddrinfo/i;

const NETWORK_CODES = ['app/invalid-credential', 'auth/internal-error', 'app/network-error', 'auth/network-error'];

export function explainVerifyError(error: any): AuthError | SetupError {
  const code = String((error && error.code) || '');
  const message = String((error && error.message) || '');

  if (code === 'auth/id-token-expired') {
    return new AuthError('Your sign-in has expired. Sign in again.', 'token_expired');
  }

  if (code === 'auth/id-token-revoked' || code === 'auth/user-token-expired') {
    return new AuthError('Your sessions were ended (for example because your role changed). Sign in again.', 'token_revoked');
  }

  if (code === 'auth/user-disabled') return new AuthError('This account has been disabled.', 'user_disabled');

  if (code === 'auth/user-not-found') return new AuthError('This account no longer exists. Create it again.', 'user_missing');

  // The token was made by a different Firebase project than the one the server's service account belongs to.
  if (WRONG_PROJECT.test(message)) {
    const projects = EXPECTED_VERSUS_GOT.exec(message);
    const detail = projects ? ` The server expects project "${projects[1]}" but the sign-in page used "${projects[2]}".` : '';

    return new SetupError(
      'The site\'s server and the sign-in page use different Firebase projects.' +
        detail +
        ' Make FIREBASE_PROJECT_ID and NEXT_PUBLIC_FIREBASE_PROJECT_ID the same, use the service account of that project, then restart the site.',
      'project_mismatch'
    );
  }

  if (CLOCK_WRONG.test(message)) {
    return new AuthError(
      'The clock on this computer or the server is wrong (Firebase says your sign-in is from the future). Turn on automatic date and time, then sign in again.',
      'clock_skew'
    );
  }

  if (CANNOT_REACH_GOOGLE.test(message) || NETWORK_CODES.includes(code)) {
    return new SetupError(
      'The server could not reach Firebase with its service account (' +
        message.slice(0, 160) +
        '). Check FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL and FIREBASE_PRIVATE_KEY in .env.local, and that this computer is online. Open /setup-check for a step-by-step check.',
      'admin_credentials'
    );
  }

  return new AuthError('Your sign-in could not be verified. Sign in again.', 'invalid_token');
}
