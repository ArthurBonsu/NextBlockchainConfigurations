// server/auth/setupErrors.ts
// Recognises the errors that mean "the site is set up wrongly" (not "the person did something wrong") and says what to fix.
// Used by the API front door (session.ts) and by the set-up check (setupCheck.ts).
//
// The message is shown to whoever runs the site, so it names the Firebase console step.
// It never contains a secret: only the error text Google itself returned, cut short.

export interface KnownSetupProblem {
  code: string;
  message: string;
}

const FIRESTORE_NOT_CREATED = /^5 NOT_FOUND|NOT_FOUND: The database .* does not exist|database \(default\) does not exist/i;
const FIRESTORE_DENIED = /PERMISSION_DENIED|Cloud Firestore API has not been used|SERVICE_DISABLED/i;
const BAD_KEY =
  /UNAUTHENTICATED|Failed to parse private key|DECODER routines|invalid_grant|invalid_client|Could not load the default credentials|private_key|\bPEM\b/i;
const OFFLINE = /ENOTFOUND|ETIMEDOUT|ECONNREFUSED|EAI_AGAIN|DEADLINE_EXCEEDED|UNAVAILABLE|fetch failed|getaddrinfo/i;

export function classify(error: any): KnownSetupProblem | null {
  const message = String((error && error.message) || '');
  const code = error && error.code;
  const short = message.replace(/\s+/g, ' ').slice(0, 200);

  if (error && error.name === 'SetupError') return { message: error.message, code: error.code || 'server_setup' };

  // The Cloud Firestore database was never created (gRPC 5 NOT_FOUND), or the wrong product was created (Realtime Database).
  if (code === 5 || FIRESTORE_NOT_CREATED.test(message)) {
    return {
      code: 'firestore_missing',
      message:
        'The Cloud Firestore database does not exist in this Firebase project yet. In the Firebase console open Build > Firestore Database > Create database ' +
        '(this is NOT the same product as Realtime Database). Pick production mode and a region, wait a minute, then try again.',
    };
  }

  // Permission denied (gRPC 7), or the Firestore API is switched off.
  if (code === 7 || FIRESTORE_DENIED.test(message)) {
    return {
      code: 'firestore_denied',
      message:
        'Firestore refused the server (' +
        short +
        '). Make sure the Cloud Firestore API is on for the project, and that FIREBASE_CLIENT_EMAIL is the service account of the same project as FIREBASE_PROJECT_ID.',
    };
  }

  // A bad key or the wrong account (gRPC 16 UNAUTHENTICATED, or the private key could not be read).
  if (code === 16 || BAD_KEY.test(message)) {
    return {
      code: 'admin_credentials',
      message:
        "The server's Firebase service account could not sign in (" +
        short +
        '). Re-copy FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL and FIREBASE_PRIVATE_KEY from the downloaded JSON key file into .env.local, keeping the \\n sequences, then restart the site.',
    };
  }

  if (OFFLINE.test(message) || code === 14 || code === 4) {
    return {
      code: 'server_offline',
      message: 'The server could not reach Firebase (' + short + '). Check the internet connection of the computer running the site.',
    };
  }

  if (/Firebase Admin is not configured/i.test(message)) return { message, code: 'admin_missing' };

  return null;
}
