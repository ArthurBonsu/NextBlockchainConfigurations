// server/auth/session.ts
// The front door of every account API route.
//
//   export default withSession(['GET', 'POST'], async (req, res, ctx) => { ... }, { capability: 'vehicle:register' });
//
// ctx = { auth, user, ip, can(capability) }
//
//   1. checks the Firebase ID token (and, by default, that the person's sessions were not ended)
//   2. loads the user's document, or creates it the first time
//   3. refuses suspended accounts
//   4. if `capability` is given: checks role, set-up, email and ID level. This is done on the server because the screen's gate is only a convenience.
//
// Errors become JSON: { error, code, fields? } with the right status.
// Server set-up problems are status 500 and say what to fix.

import type { NextApiRequest, NextApiResponse } from 'next';
import { StoreError } from '../database';
import { HttpError, forbidden } from '../errors';
import { ensureUser, onboardingState } from '../users';
import type { UserDoc } from '../users';
import { AuthError } from './authErrors';
import { classify } from './setupErrors';
import * as roles from './roles';
import { verifyBearer } from './verifyBearer';
import type { AuthenticatedUser } from './verifyBearer';

export interface SessionContext {
  auth: AuthenticatedUser;
  user: UserDoc;
  ip: string | null;
  onboardingComplete: boolean;
  can: (capability: string) => roles.CapabilityResult;
}

export type SessionHandler = (req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => unknown | Promise<unknown>;

export interface SessionOptions {
  capability?: string; // the action this route needs, for example 'vehicle:register'
  checkRevoked?: boolean; // default true
  allowSuspended?: boolean;
}

// The caller's IP address. Behind a proxy it is in x-forwarded-for. Set TRUST_PROXY=false if there is no proxy.
export function clientIp(req: NextApiRequest): string | null {
  const trustProxy = String(process.env.TRUST_PROXY || 'true').toLowerCase() !== 'false';

  if (trustProxy) {
    const forwarded = req.headers['x-forwarded-for'];

    if (forwarded) return String(Array.isArray(forwarded) ? forwarded[0] : forwarded).split(',')[0].trim().slice(0, 64);

    const real = req.headers['x-real-ip'];

    if (real) return String(real).slice(0, 64);
  }

  return (req.socket && req.socket.remoteAddress) || null;
}

const SET_UP_WORDS =
  /not configured|STORE_BACKEND|SMS_PROVIDER|ID_ENC_KEY|ID_HASH_PEPPER|OTP_SECRET|WALLET_LINK_SECRET|composite index/i;

export function sendError(res: NextApiResponse, error: any) {
  if (error instanceof AuthError) {
    return res.status(401).json({ error: error.message, code: error.code || 'unauthenticated' });
  }

  if (error instanceof HttpError) {
    if (error.extra && error.extra.retryAfter) res.setHeader('Retry-After', String(error.extra.retryAfter));

    return res.status(error.status).json({ error: error.message, code: error.code, ...(error.extra || {}) });
  }

  const message = (error && error.message) || 'Something went wrong.';
  const knownProblem = classify(error);

  if (knownProblem) {
    console.error('[api] set-up problem (' + knownProblem.code + '):', String(message).slice(0, 300));

    return res.status(500).json({ error: knownProblem.message, code: knownProblem.code, setup: true });
  }

  if (SET_UP_WORDS.test(message) || error instanceof StoreError) {
    return res.status(500).json({ error: message, code: 'server_setup' });
  }

  console.error('[api] unexpected error:', message);

  return res.status(500).json({ error: 'Something went wrong on our side. Try again.', code: 'internal' });
}

export function withSession(methods: string[], handler: SessionHandler, options: SessionOptions = {}) {
  return async (req: NextApiRequest, res: NextApiResponse) => {
    res.setHeader('Cache-Control', 'no-store');

    if (!methods.includes(req.method as string)) {
      res.setHeader('Allow', methods.join(', '));

      return res.status(405).json({ error: 'Method not allowed.', code: 'method' });
    }

    try {
      const auth = await verifyBearer(req.headers.authorization, { checkRevoked: options.checkRevoked !== false });
      const user = await ensureUser(auth);

      if (user.status === 'suspended' && !options.allowSuspended) throw forbidden('This account is suspended.', 'suspended');

      const onboardingComplete = onboardingState(user).complete;

      const ctx: SessionContext = {
        auth,
        user,
        ip: clientIp(req),
        onboardingComplete,
        can: (capability) => roles.check(user, capability, { onboardingComplete }),
      };

      if (options.capability) {
        const result = ctx.can(options.capability);

        if (!result.allowed) {
          throw forbidden(roles.REASONS[result.reason as string] || 'Not allowed.', result.reason, { need: result.need });
        }
      }

      return await handler(req, res, ctx);
    } catch (error) {
      return sendError(res, error);
    }
  };
}
