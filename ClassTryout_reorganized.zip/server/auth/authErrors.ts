// server/auth/authErrors.ts
// Two kinds of sign-in problem, and they must not be mixed up:
//
//   AuthError   the PERSON must sign in again           (HTTP 401)
//   SetupError  the SITE is set up wrongly, signing in again will not help  (HTTP 500)

export class AuthError extends Error {
  code: string;

  constructor(message: string, code?: string) {
    super(message);

    this.name = 'AuthError';
    this.code = code || 'unauthenticated';
  }
}

export class SetupError extends Error {
  code: string;

  constructor(message: string, code?: string) {
    super(message);

    this.name = 'SetupError';
    this.code = code || 'server_setup';
  }
}
