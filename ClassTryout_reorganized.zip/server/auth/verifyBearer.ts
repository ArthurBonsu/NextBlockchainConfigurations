// server/auth/verifyBearer.ts
// Finds out who is signed in from the header "Authorization: Bearer <Firebase ID token>".
//
//   firebase backend  real checking with Firebase Admin (signature and expiry; revocation only when checkRevoked is on)
//   dev backend       the token is "dev:<uid>:<email>:<1|0 verified>". Local testing only, refused in production.

import { getAdmin } from '../firebase';
import { AuthError } from './authErrors';
import { explainVerifyError } from './explainVerifyError';

export interface AuthenticatedUser {
  uid: string;
  email?: string;
  emailVerified: boolean;
  provider: string; // for example 'google.com', 'password', 'github.com', 'twitter.com'
  name?: string;
}

function verifyDevToken(token: string): AuthenticatedUser {
  if (process.env.NODE_ENV === 'production') throw new AuthError('NOTIFY_BACKEND=dev is refused in production.');

  const [tag, uid, email, verified] = token.split(':');

  if (tag !== 'dev' || !uid) throw new AuthError('Invalid dev token.');

  return { uid, email: email || undefined, emailVerified: verified === '1', provider: 'dev', name: undefined };
}

export async function verifyBearer(header: string | undefined, options: { checkRevoked?: boolean } = {}): Promise<AuthenticatedUser> {
  const match = /^Bearer\s+(.+)$/i.exec(header || '');

  if (!match) throw new AuthError('Sign in first (missing Authorization header).');

  const token = match[1].trim();
  const backend = (process.env.NOTIFY_BACKEND || 'firebase').toLowerCase();

  if (backend === 'dev') return verifyDevToken(token);

  const admin = getAdmin(); // throws "Firebase Admin is not configured": a set-up problem, not a bad token

  try {
    // checkRevoked asks Firebase whether this person's sessions were ended (done when a role changes). One extra network call.
    const decoded = await admin.auth().verifyIdToken(token, options.checkRevoked ?? false);

    return {
      uid: decoded.uid,
      email: decoded.email,
      emailVerified: !!decoded.email_verified,
      provider: (decoded.firebase && decoded.firebase.sign_in_provider) || 'unknown',
      name: decoded.name,
    };
  } catch (error) {
    throw explainVerifyError(error);
  }
}
