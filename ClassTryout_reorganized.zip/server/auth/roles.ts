// server/auth/roles.ts
// "Can this account do this?" One function that the API and the screens both rely on.
// The rules are data, kept in shared/roles.json.

import policy from '../../shared/roles.json';

export { policy };

export const ROLES: string[] = policy.roles;

export function isRole(role: string): boolean {
  return ROLES.includes(role);
}

// The parts of a user document that the rules look at.
export interface RuleSubject {
  role?: string;
  status?: string;
  email?: string | null;
  emailVerified?: boolean;
  identity?: { level?: number };
}

export type DeniedReason = 'unknown_capability' | 'suspended' | 'role' | 'onboarding' | 'email_unverified' | 'level';

export interface CapabilityResult {
  allowed: boolean;
  reason?: DeniedReason;
  need?: { roles?: string[]; level?: number; have?: number };
}

type CapabilityRule = { roles: string[]; minLevel: number };

export function check(user: RuleSubject | null | undefined, capability: string, context: { onboardingComplete: boolean }): CapabilityResult {
  const rule = (policy.capabilities as Record<string, CapabilityRule>)[capability];

  if (!rule) return { allowed: false, reason: 'unknown_capability' };
  if (!user) return { allowed: false, reason: 'role', need: { roles: rule.roles } };
  if (user.status === 'suspended') return { allowed: false, reason: 'suspended' };
  if (!rule.roles.includes(user.role as string)) return { allowed: false, reason: 'role', need: { roles: rule.roles } };

  const needsFullAccount = capability !== 'account:use';

  if (needsFullAccount && !context.onboardingComplete) return { allowed: false, reason: 'onboarding' };
  if (needsFullAccount && user.email && user.emailVerified === false) return { allowed: false, reason: 'email_unverified' };

  const level = (user.identity && user.identity.level) || 0;

  if (level < rule.minLevel) return { allowed: false, reason: 'level', need: { level: rule.minLevel, have: level } };

  return { allowed: true };
}

// The result for every capability, for the "What you can do" list.
export function all(user: RuleSubject, context: { onboardingComplete: boolean }): Record<string, CapabilityResult> {
  const results: Record<string, CapabilityResult> = {};

  for (const name of Object.keys(policy.capabilities)) results[name] = check(user, name, context);

  return results;
}

// The sentence shown for each reason an action is refused.
export const REASONS: Record<string, string> = {
  suspended: 'This account is suspended.',
  role: 'Your role does not allow this.',
  onboarding: 'Finish setting up your account first.',
  email_unverified: 'Verify your email address first.',
  level: 'This needs a confirmed ID. Add your ID and wait for it to be confirmed.',
  unknown_capability: 'Unknown action.',
};
