// server/auth/setupCheck.ts
// The sign-in set-up check. It looks at the settings and talks to Firebase, then reports what works and what to fix.
// It never returns a secret or a value from .env.local. Only yes or no, and the public project id.

import crypto from 'crypto';
import { getAdmin } from '../firebase';
import { classify } from './setupErrors';

export type CheckStatus = 'ok' | 'fail' | 'warn' | 'skip';

export interface SetupCheckItem {
  id: string;
  label: string;
  status: CheckStatus;
  detail: string;
  fix: string;
}

export interface SetupCheckReport {
  ok: boolean;
  failed: number;
  projectId: string | null;
  emulator: boolean;
  checks: SetupCheckItem[];
}

const CLIENT_VARS = [
  'NEXT_PUBLIC_FIREBASE_API_KEY',
  'NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN',
  'NEXT_PUBLIC_FIREBASE_PROJECT_ID',
  'NEXT_PUBLIC_FIREBASE_APP_ID',
];

const ADMIN_VARS = ['FIREBASE_PROJECT_ID', 'FIREBASE_CLIENT_EMAIL', 'FIREBASE_PRIVATE_KEY'];

function item(id: string, label: string, status: CheckStatus, detail = '', fix = ''): SetupCheckItem {
  return { id, label, status, detail, fix };
}

function withTimeout<T>(promise: Promise<T>, milliseconds: number, what: string): Promise<T> {
  const timeout = new Promise<never>((_, reject) => {
    setTimeout(() => reject(new Error(`${what} did not answer within ${milliseconds / 1000} seconds (is this computer online?)`)), milliseconds);
  });

  return Promise.race([promise, timeout]);
}

function isEmpty(name: string): boolean {
  return !String(process.env[name] || '').trim();
}

// ---------------------------------------------------------------- the individual checks
function checkClientSettings(): SetupCheckItem {
  const label = 'Sign-in page settings (NEXT_PUBLIC_FIREBASE_*)';
  const missing = CLIENT_VARS.filter(isEmpty);

  if (missing.length === 0) return item('client-config', label, 'ok', 'All four values are present.');

  return item(
    'client-config',
    label,
    'fail',
    'Missing: ' + missing.join(', '),
    'Firebase console > Project settings > General > Your apps > Web app > SDK setup and configuration. Copy the four values into .env.local, then RESTART the site (Next.js reads .env.local only at start).'
  );
}

function checkServerSettings(emulator: boolean, adminProject: string): { result: SetupCheckItem; usable: boolean } {
  const label = 'Server service account (FIREBASE_*)';
  const hasKeyFile = !!process.env.GOOGLE_APPLICATION_CREDENTIALS;
  const missing = ADMIN_VARS.filter(isEmpty);
  const usable = emulator ? !!adminProject : hasKeyFile || missing.length === 0;

  if (usable) {
    return { usable, result: item('admin-config', label, 'ok', emulator ? 'Using the local emulator (no key needed).' : 'All three values are present.') };
  }

  return {
    usable,
    result: item(
      'admin-config',
      label,
      'fail',
      'Missing: ' + missing.join(', '),
      'Firebase console > Project settings > Service accounts > Generate new private key. Copy project_id, client_email and private_key from the JSON file into .env.local, then restart the site.'
    ),
  };
}

function checkSameProject(clientProject: string, adminProject: string): SetupCheckItem {
  const label = 'Page and server use the same Firebase project';

  if (clientProject === adminProject) return item('same-project', label, 'ok', `Both use "${clientProject}".`);

  return item(
    'same-project',
    label,
    'fail',
    `The page uses "${clientProject}" but the server uses "${adminProject}".`,
    'This is the most common reason sign-in seems to work and then fails. Use values from ONE Firebase project, then restart.'
  );
}

function checkPrivateKey(): SetupCheckItem {
  const label = 'Private key can be read';
  const key = String(process.env.FIREBASE_PRIVATE_KEY).replace(/\\n/g, '\n').replace(/^"|"$/g, '');

  try {
    crypto.createPrivateKey(key);

    return item('private-key', label, 'ok', 'The key is a valid private key.');
  } catch {
    const hasBeginLine = key.includes('BEGIN PRIVATE KEY');

    return item(
      'private-key',
      label,
      'fail',
      'FIREBASE_PRIVATE_KEY is not a valid private key' + (hasBeginLine ? '.' : ' (the BEGIN/END lines are missing).'),
      'Copy the whole private_key value, from "-----BEGIN PRIVATE KEY-----" to "-----END PRIVATE KEY-----\\n", keep the \\n sequences, and put it in double quotes on ONE line in .env.local.'
    );
  }
}

function checkServiceAccountEmail(adminProject: string): SetupCheckItem | null {
  const email = String(process.env.FIREBASE_CLIENT_EMAIL || '');

  if (!email || !adminProject || email.endsWith('@' + adminProject + '.iam.gserviceaccount.com')) return null;

  return item(
    'email-project',
    'Service account belongs to the project',
    'warn',
    `FIREBASE_CLIENT_EMAIL does not end with @${adminProject}.iam.gserviceaccount.com.`,
    'Make sure the key file you copied from belongs to the project in FIREBASE_PROJECT_ID.'
  );
}

async function checkAuthentication(admin: ReturnType<typeof getAdmin>): Promise<SetupCheckItem> {
  const label = 'Server can reach Firebase Authentication';

  try {
    await withTimeout(admin.auth().listUsers(1), 10000, 'Firebase Authentication');

    return item('auth-reach', label, 'ok', 'The service account is accepted.');
  } catch (error: any) {
    const known = classify(error);

    return item(
      'auth-reach',
      label,
      'fail',
      known ? known.message : String(error.message).slice(0, 200),
      "If it says the API is disabled, open Google Cloud console > APIs & Services and enable 'Identity Toolkit API' for this project."
    );
  }
}

async function checkFirestore(admin: ReturnType<typeof getAdmin>): Promise<SetupCheckItem> {
  const label = 'Cloud Firestore database exists and answers';

  if ((process.env.STORE_BACKEND || 'firestore').toLowerCase() === 'file') {
    return item('firestore-reach', label, 'skip', 'STORE_BACKEND=file (local test store).');
  }

  try {
    await withTimeout(admin.firestore().collection('_setupcheck').limit(1).get(), 12000, 'Cloud Firestore');

    return item('firestore-reach', label, 'ok', 'The database answered.');
  } catch (error: any) {
    const known = classify(error);

    return item('firestore-reach', label, 'fail', known ? known.message : String(error.message).slice(0, 200), "Firebase console > Build > Firestore Database > Create database. (Not 'Realtime Database'.)");
  }
}

// ---------------------------------------------------------------- the whole check
export async function runSetupCheck(): Promise<SetupCheckReport> {
  const emulator = !!process.env.FIREBASE_AUTH_EMULATOR_HOST;
  const clientProject = String(process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || '').trim();
  const adminProject = String(process.env.FIREBASE_PROJECT_ID || '').trim();

  const checks: SetupCheckItem[] = [];

  checks.push(checkClientSettings());

  const server = checkServerSettings(emulator, adminProject);

  checks.push(server.result);

  if (clientProject && adminProject) checks.push(checkSameProject(clientProject, adminProject));

  let keyIsUnreadable = false;

  if (!emulator && String(process.env.FIREBASE_PRIVATE_KEY || '').trim()) {
    const keyCheck = checkPrivateKey();

    keyIsUnreadable = keyCheck.status === 'fail';
    checks.push(keyCheck);

    const emailCheck = checkServiceAccountEmail(adminProject);

    if (emailCheck) checks.push(emailCheck);
  }

  // Talk to Firebase only when the settings above are usable.
  if (!server.usable || keyIsUnreadable) {
    checks.push(item('auth-reach', 'Server can reach Firebase Authentication', 'skip', 'Fix the items above first.'));
    checks.push(item('firestore-reach', 'Cloud Firestore database exists and answers', 'skip', 'Fix the items above first.'));
  } else {
    let admin: ReturnType<typeof getAdmin> | null = null;

    try {
      admin = getAdmin();
    } catch (error: any) {
      checks.push(item('auth-reach', 'Server can reach Firebase Authentication', 'fail', String(error.message).slice(0, 200), 'Check the service account values.'));
    }

    if (admin) {
      checks.push(await checkAuthentication(admin));
      checks.push(await checkFirestore(admin));
    }
  }

  const failed = checks.filter((check) => check.status === 'fail').length;

  return { ok: failed === 0, failed, projectId: clientProject || adminProject || null, emulator, checks };
}
