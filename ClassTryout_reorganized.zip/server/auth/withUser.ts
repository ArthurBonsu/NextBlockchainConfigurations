// server/auth/withUser.ts
// A lighter front door for the three wallet-link routes: it only finds out who is signed in.
// It checks the method, finds the user, and turns thrown errors into JSON.

import type { NextApiRequest, NextApiResponse } from 'next';
import { AuthError } from './authErrors';
import { verifyBearer } from './verifyBearer';
import type { AuthenticatedUser } from './verifyBearer';

export type UserHandler = (req: NextApiRequest, res: NextApiResponse, user: AuthenticatedUser) => unknown | Promise<unknown>;

export function withUser(methods: string[], handler: UserHandler) {
  return async (req: NextApiRequest, res: NextApiResponse) => {
    res.setHeader('Cache-Control', 'no-store');

    if (!methods.includes(req.method as string)) {
      res.setHeader('Allow', methods.join(', '));

      return res.status(405).json({ error: 'Method not allowed.' });
    }

    try {
      const user = await verifyBearer(req.headers.authorization);

      return await handler(req, res, user);
    } catch (error: any) {
      if (error instanceof AuthError) return res.status(401).json({ error: error.message });

      const message = error && error.message ? error.message : 'Something went wrong.';
      const isSetupProblem = /not configured|WALLET_LINK_SECRET/.test(message);

      // Set-up problems are for the person running the site to fix, so they are shown. Everything else is a plain 400.
      return res.status(isSetupProblem ? 500 : 400).json({ error: message });
    }
  };
}
