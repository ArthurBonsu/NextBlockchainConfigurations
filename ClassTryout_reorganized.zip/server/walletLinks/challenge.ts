// server/walletLinks/challenge.ts
// A challenge the person signs with their wallet to prove they own it.
// The server signs (uid, address, nonce, expiry) with WALLET_LINK_SECRET, so nothing has to be stored
// between "give me a challenge" and "here is the signature".

import crypto from 'crypto';
import { normalizeAddress } from './links';

const TEN_MINUTES = 10 * 60 * 1000;

interface ChallengeFields {
  uid: string;
  address: string;
  nonce: string;
  issuedAt: string;
  expiresAt: string;
}

export interface Challenge {
  address: string;
  nonce: string;
  issuedAt: string;
  expiresAt: string;
  mac: string;
  message: string;
}

function linkSecret(): string {
  const value = process.env.WALLET_LINK_SECRET;

  if (!value || value.length < 16) {
    throw new Error(
      'WALLET_LINK_SECRET is not set (min 16 characters). Generate one: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"'
    );
  }

  return value;
}

// The text the wallet shows to the person when they sign.
function messageFor(fields: ChallengeFields): string {
  return [
    'ClassTryout: link this wallet to my account',
    '',
    `Wallet: ${fields.address}`,
    `Account: ${fields.uid}`,
    `Nonce: ${fields.nonce}`,
    `Issued: ${fields.issuedAt}`,
    `Expires: ${fields.expiresAt}`,
    '',
    'Signing this message costs no gas. It only proves I control this wallet.',
  ].join('\n');
}

function macFor(fields: ChallengeFields): string {
  const text = [fields.uid, fields.address, fields.nonce, fields.expiresAt].join('|');

  return crypto.createHmac('sha256', linkSecret()).update(text).digest('hex');
}

export function createChallenge(uid: string, address: string): Challenge {
  const normalized = normalizeAddress(address);
  const now = Date.now();

  const fields: ChallengeFields = {
    uid,
    address: normalized,
    nonce: crypto.randomBytes(16).toString('hex'),
    issuedAt: new Date(now).toISOString(),
    expiresAt: new Date(now + TEN_MINUTES).toISOString(),
  };

  return {
    address: normalized,
    nonce: fields.nonce,
    issuedAt: fields.issuedAt,
    expiresAt: fields.expiresAt,
    mac: macFor(fields),
    message: messageFor(fields),
  };
}

export interface SignedChallenge {
  address: string;
  nonce: string;
  issuedAt: string;
  expiresAt: string;
  mac: string;
}

// Returns the message that must have been signed, or throws.
export function checkChallenge(uid: string, given: SignedChallenge): string {
  const fields: ChallengeFields = {
    uid,
    address: normalizeAddress(given.address),
    nonce: given.nonce,
    issuedAt: given.issuedAt,
    expiresAt: given.expiresAt,
  };

  const givenMac = Buffer.from(String(given.mac || ''), 'hex');
  const expectedMac = Buffer.from(macFor(fields), 'hex');

  if (givenMac.length !== expectedMac.length || !crypto.timingSafeEqual(givenMac, expectedMac)) {
    throw new Error('This link request was not issued to your account. Start again.');
  }

  if (Date.now() > Date.parse(given.expiresAt)) throw new Error('This link request expired. Start again.');

  return messageFor(fields);
}
