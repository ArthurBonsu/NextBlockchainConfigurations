// server/walletLinks/links.ts
// Wallet <-> account links.
// The email address NEVER goes on the chain and is never stored here. We keep only: wallet address -> Firebase uid.
// The email is looked up from Firebase Auth when a message is sent, so a changed or unverified email is always respected.
//
// NOTIFY_BACKEND picks where the links live:
//   firebase  (the default)  Firestore collection "walletLinks"; the verified email comes from Firebase Auth
//   dev                      a local JSON file with a fake account. Local testing only.

import fs from 'fs';
import path from 'path';
import { root } from '../config';
import { getAdmin } from '../firebase';

const COLLECTION = 'walletLinks';

export interface WalletLink {
  address: string;
  linkedAt: string;
}

interface StoredLink extends WalletLink {
  uid: string;
  email?: string;
  emailVerified?: boolean;
}

export interface LinkingAccount {
  uid: string;
  email?: string; // used by the dev backend only
  emailVerified?: boolean;
}

// Why an email could not be found for a wallet.
export type NoEmailReason = 'not-linked' | 'no-email' | 'email-not-verified' | 'account-disabled';

export type EmailLookup = { email: string; uid: string } | { reason: NoEmailReason };

function backend(): string {
  return (process.env.NOTIFY_BACKEND || 'firebase').toLowerCase();
}

export function normalizeAddress(address: unknown): string {
  if (!/^0x[0-9a-fA-F]{40}$/.test(String(address || ''))) throw new Error('Not a valid wallet address.');

  return String(address).toLowerCase();
}

function assertBackendIsAllowed(): void {
  if (backend() === 'dev' && process.env.NODE_ENV === 'production') {
    throw new Error('NOTIFY_BACKEND=dev is for local testing only and is refused when NODE_ENV=production.');
  }
}

// ---------------------------------------------------------------- dev backend (a JSON file)
type DevFile = { links: Record<string, StoredLink> };

function devFile(): string {
  return process.env.DEV_LINKS_FILE || path.join(root, 'notifier', 'data', 'dev-links.json');
}

function readDevFile(): DevFile {
  try {
    return JSON.parse(fs.readFileSync(devFile(), 'utf8'));
  } catch {
    return { links: {} };
  }
}

function writeDevFile(data: DevFile): void {
  fs.mkdirSync(path.dirname(devFile()), { recursive: true });
  fs.writeFileSync(devFile(), JSON.stringify(data, null, 2));
}

// ---------------------------------------------------------------- the four operations
export async function saveLink(address: string, account: LinkingAccount) {
  assertBackendIsAllowed();

  const key = normalizeAddress(address);
  const record = { uid: account.uid, address: key, linkedAt: new Date().toISOString() };

  if (backend() === 'dev') {
    const data = readDevFile();

    data.links[key] = { ...record, email: account.email, emailVerified: !!account.emailVerified };
    writeDevFile(data);
  } else {
    // The signature proves control of the wallet, so the newest proof wins. A person who switches account just links again.
    await getAdmin().firestore().collection(COLLECTION).doc(key).set(record);
  }

  return record;
}

export async function listLinks(uid: string): Promise<WalletLink[]> {
  assertBackendIsAllowed();

  if (backend() === 'dev') {
    return Object.values(readDevFile().links)
      .filter((link) => link.uid === uid)
      .map(({ address, linkedAt }) => ({ address, linkedAt }));
  }

  const snapshot = await getAdmin().firestore().collection(COLLECTION).where('uid', '==', uid).get();

  return snapshot.docs.map((doc) => ({ address: doc.data().address, linkedAt: doc.data().linkedAt }));
}

export async function removeLink(address: string, uid: string): Promise<boolean> {
  assertBackendIsAllowed();

  const key = normalizeAddress(address);

  if (backend() === 'dev') {
    const data = readDevFile();

    if (data.links[key] && data.links[key].uid === uid) {
      delete data.links[key];
      writeDevFile(data);

      return true;
    }

    return false;
  }

  const reference = getAdmin().firestore().collection(COLLECTION).doc(key);
  const snapshot = await reference.get();

  if (!snapshot.exists || snapshot.data()?.uid !== uid) return false;

  await reference.delete();

  return true;
}

// Finds the email to notify for a wallet: { email, uid }, or { reason } when there is none.
export async function emailForWallet(address: string): Promise<EmailLookup> {
  assertBackendIsAllowed();

  const key = normalizeAddress(address);

  if (backend() === 'dev') {
    const link = readDevFile().links[key];

    if (!link) return { reason: 'not-linked' };
    if (!link.email) return { reason: 'no-email' };
    if (!link.emailVerified) return { reason: 'email-not-verified' };

    return { email: link.email, uid: link.uid };
  }

  const admin = getAdmin();
  const snapshot = await admin.firestore().collection(COLLECTION).doc(key).get();

  if (!snapshot.exists) return { reason: 'not-linked' };

  const uid = snapshot.data()?.uid as string;
  let user;

  try {
    user = await admin.auth().getUser(uid);
  } catch (error: any) {
    if (error && error.code === 'auth/user-not-found') return { reason: 'not-linked' };

    throw error;
  }

  if (user.disabled) return { reason: 'account-disabled' };
  if (!user.email) return { reason: 'no-email' };
  if (!user.emailVerified) return { reason: 'email-not-verified' };

  return { email: user.email, uid };
}
