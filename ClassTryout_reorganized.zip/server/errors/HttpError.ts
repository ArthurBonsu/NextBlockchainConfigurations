// server/errors/HttpError.ts
// An error that knows its HTTP status.
// `code` is a stable machine-readable word the screen can switch on, for example "rate_limited".

export interface HttpErrorExtra {
  fields?: Record<string, string>; // messages for single form fields
  retryAfter?: number; // seconds
  need?: unknown; // what a forbidden action would have needed
}

export class HttpError extends Error {
  status: number;
  code: string;
  extra?: HttpErrorExtra;

  constructor(status: number, message: string, code?: string, extra?: HttpErrorExtra) {
    super(message);

    this.name = 'HttpError';
    this.status = status;
    this.code = code || 'error';
    this.extra = extra || undefined;
  }
}

// Short ways to make the common errors.

export function bad(message: string, fields?: Record<string, string>): HttpError {
  return new HttpError(422, message, 'invalid', fields ? { fields } : undefined);
}

export function forbidden(message: string, code?: string, extra?: HttpErrorExtra): HttpError {
  return new HttpError(403, message, code || 'forbidden', extra);
}

export function conflict(message: string, code?: string): HttpError {
  return new HttpError(409, message, code || 'conflict');
}

export function tooMany(message: string, retryAfter: number): HttpError {
  return new HttpError(429, message, 'rate_limited', { retryAfter });
}

export function notFound(message: string): HttpError {
  return new HttpError(404, message, 'not_found');
}
