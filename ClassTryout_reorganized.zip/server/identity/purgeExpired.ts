// server/identity/purgeExpired.ts
// Housekeeping: a number nobody decided on within the keeping time is deleted, and its document is marked "expired".

import { store, REMOVE } from '../database';
import { PENDING, levelFrom } from './documentView';

export async function purgeExpired(now = new Date()): Promise<number> {
  const cutoff = now.toISOString();
  let purged = 0;

  for (const status of PENDING) {
    const rows = await store().query('identityDocuments', { where: [['status', '==', status]], orderBy: [['createdAt', 'desc']], limit: 500 });

    for (const doc of rows) {
      if (!(doc.encExpiresAt && doc.encExpiresAt <= cutoff)) continue;

      await store().update('identityDocuments', doc.id, {
        status: 'expired',
        encNumber: REMOVE,
        encExpiresAt: REMOVE,
        nextAttemptAt: null,
        updatedAt: cutoff,
      });

      await store().delete('identityClaims', doc.numberHmac);

      const mine = await store().query('identityDocuments', { where: [['uid', '==', doc.uid]], orderBy: [['createdAt', 'desc']], limit: 20 });
      const level = levelFrom(mine.map((other) => (other.id === doc.id ? { ...other, status: 'expired' } : other)));

      await store().update('users', doc.uid, { 'identity.level': level, updatedAt: cutoff });

      purged++;
    }
  }

  return purged;
}
