// server/identity/checkers.ts
// Automated ID checkers. A checker NEVER sits inside the sign-up request:
//
//   submit  ->  document saved (level 1)  ->  status pending_check or pending_review  ->  a worker or a person decides later.
//
// If a checker is down, slow or switched off, the person is already at level 1 and the document waits for a human.
//
// A checker has a name, enabled(), and check({ type, number, profile }) which answers one of:
//   { outcome: 'verified' }
//   { outcome: 'rejected', reason }      the authority said the ID does not match
//   { outcome: 'unavailable', reason }   an outage, a timeout or no access (the worker tries again, then hands over to a human)
//
// "nia" (Ghana Card, National Identification Authority) is a placeholder until you have NIA's (or an approved partner's) API access.
// Nothing here calls NIA yet. With ID_CHECK_NIA unset, every Ghana Card goes to a human reviewer.

import idTypes from '../../shared/id-types.json';
import type { IdType } from './idRules';

export type CheckOutcome =
  | { outcome: 'verified' }
  | { outcome: 'rejected'; reason?: string }
  | { outcome: 'unavailable'; reason?: string };

export interface IdChecker {
  name: string;
  enabled: () => boolean;
  check: (input: { type: string; number: string; profile: Record<string, any> }) => Promise<CheckOutcome>;
}

const nia: IdChecker = {
  name: 'nia',
  enabled: () => /^(1|true|on|yes)$/i.test(process.env.ID_CHECK_NIA || ''),
  async check() {
    return { outcome: 'unavailable', reason: 'NIA integration is not connected yet.' };
  },
};

const manual: IdChecker = {
  name: 'manual',
  enabled: () => true,
  async check() {
    return { outcome: 'unavailable', reason: 'manual review only' };
  },
};

export const REGISTRY: Record<string, IdChecker> = { nia, manual };

// Which route a new document takes: an automated checker when one is switched on for this type, otherwise a human.
export function routeFor(typeCode: string): { checker: string; status: 'pending_check' | 'pending_review' } {
  const type = (idTypes.types as IdType[]).find((item) => item.code === typeCode);
  const checker = type && type.checker ? REGISTRY[type.checker] : undefined;

  if (checker && checker.name !== 'manual' && checker.enabled()) return { checker: checker.name, status: 'pending_check' };

  return { checker: 'manual', status: 'pending_review' };
}

export function getChecker(name: string): IdChecker | null {
  return REGISTRY[name] || null;
}
