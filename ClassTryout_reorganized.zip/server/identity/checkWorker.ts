// server/identity/checkWorker.ts
// The automated-check worker. It is safe to run at any time, and only touches documents in "pending_check".
//
//   verified      level 2
//   rejected      kept for a human to look at (a mismatch can be a typo or an NIA data error, so we never reject automatically)
//   unavailable   try again later with longer waits. After the keeping time, the document goes to a human reviewer.
//
// Nothing here can stop anyone using the app: people are at level 1 from the moment they submit.

import { store, nowIso } from '../database';
import { decrypt } from '../security';
import { REGISTRY } from './checkers';
import type { CheckOutcome, IdChecker } from './checkers';
import { decide } from './decide';

const SYSTEM = { uid: 'system', role: 'system' };
const GIVE_UP_AFTER_ATTEMPTS = 12;

async function askChecker(checker: IdChecker | undefined, doc: Record<string, any>): Promise<CheckOutcome> {
  try {
    if (!checker || !checker.enabled()) return { outcome: 'unavailable', reason: 'checker off' };

    const owner = await store().get('users', doc.uid);

    return await checker.check({
      type: doc.type,
      number: decrypt(doc.encNumber, `idnum:${doc.uid}`),
      profile: (owner && owner.profile) || {},
    });
  } catch (error: any) {
    return { outcome: 'unavailable', reason: String(error && error.message).slice(0, 100) };
  }
}

export async function processDue({
  now = new Date(),
  registry = REGISTRY,
  limit = 50,
}: { now?: Date; registry?: Record<string, IdChecker>; limit?: number } = {}) {
  const nowText = now.toISOString();

  const due = await store().query('identityDocuments', {
    where: [
      ['status', '==', 'pending_check'],
      ['nextAttemptAt', '<=', nowText],
    ],
    orderBy: [['nextAttemptAt', 'asc']],
    limit,
  });

  const counts = { checked: 0, verified: 0, toReview: 0, retry: 0 };

  for (const doc of due) {
    counts.checked++;

    const answer = await askChecker(registry[doc.checker], doc);

    if (answer.outcome === 'verified') {
      await decide({ docId: doc.id, decision: 'verified', by: SYSTEM, checker: doc.checker, note: 'Confirmed automatically.' });
      counts.verified++;
      continue;
    }

    if (answer.outcome === 'rejected') {
      await store().update('identityDocuments', doc.id, {
        status: 'pending_review',
        checker: 'manual',
        note: `Automated check did not match: ${String(answer.reason || '').slice(0, 120)}`,
        nextAttemptAt: null,
        updatedAt: nowIso(),
      });
      counts.toReview++;
      continue;
    }

    const attempts = (doc.attempts || 0) + 1;
    const keepingTimeIsOver = doc.encExpiresAt && doc.encExpiresAt <= nowText;

    if (keepingTimeIsOver || attempts >= GIVE_UP_AFTER_ATTEMPTS) {
      await store().update('identityDocuments', doc.id, {
        status: 'pending_review',
        checker: 'manual',
        attempts,
        nextAttemptAt: null,
        updatedAt: nowIso(),
      });
      counts.toReview++;
    } else {
      const waitMinutes = Math.min(15 * 2 ** (attempts - 1), 24 * 60);

      await store().update('identityDocuments', doc.id, {
        attempts,
        nextAttemptAt: new Date(now.getTime() + waitMinutes * 60000).toISOString(),
        updatedAt: nowIso(),
      });
      counts.retry++;
    }
  }

  return counts;
}
