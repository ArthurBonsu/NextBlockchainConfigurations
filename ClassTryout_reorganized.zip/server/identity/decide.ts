// server/identity/decide.ts
// A decision on one ID: confirmed or rejected. Made by a human reviewer, or by the automated check worker.

import { store, nowIso, REMOVE } from '../database';
import { bad, conflict, forbidden, notFound } from '../errors';
import { audit } from '../security';
import type { Actor } from '../security';
import { PENDING, levelFrom } from './documentView';

export interface Decision {
  docId: string;
  decision: 'verified' | 'rejected';
  by: Actor;
  note?: string;
  checker?: string;
  ip?: string | null;
}

export async function decide({ docId, decision, by, note, checker, ip }: Decision) {
  if (!['verified', 'rejected'].includes(decision)) throw bad('Decision must be verified or rejected.');

  let target = { uid: '', type: '' };

  await store().transaction(async (tx) => {
    const doc = await tx.get('identityDocuments', docId);

    if (!doc) throw notFound('ID not found.');
    if (!PENDING.includes(doc.status)) throw conflict('That ID has already been decided.', 'decided');
    if (by.uid === doc.uid) throw forbidden('You cannot review your own ID.', 'self');

    const mine = await tx.query('identityDocuments', { where: [['uid', '==', doc.uid]], orderBy: [['createdAt', 'desc']], limit: 20 });
    const now = nowIso();
    const documentAfter = { ...doc, status: decision };

    await tx.update('identityDocuments', docId, {
      status: decision,
      reviewedBy: by.uid,
      reviewedAt: now,
      note: note ? String(note).slice(0, 300) : null,
      checker: checker || doc.checker,
      encNumber: REMOVE, // the full number is no longer needed
      encExpiresAt: REMOVE,
      nextAttemptAt: null,
      updatedAt: now,
    });

    // A rejected ID frees its number, so the person can fix a typo and send it again.
    if (decision === 'rejected') await tx.delete('identityClaims', doc.numberHmac);

    const level = levelFrom(mine.map((other) => (other.id === docId ? documentAfter : other)));
    const patch: Record<string, unknown> = { 'identity.level': level, 'identity.updatedAt': now, updatedAt: now };

    if (decision === 'verified') patch['identity.verifiedAt'] = now;

    await tx.update('users', doc.uid, patch);

    target = { uid: doc.uid, type: doc.type };
  });

  await audit({
    actor: by,
    action: `identity.${decision}`,
    target: { type: 'identityDocument', id: docId },
    after: { owner: target.uid, type: target.type, checker: checker || 'manual' },
    note,
    ip,
  });

  return { docId, decision };
}
