// server/identity/documentView.ts
// How an ID document looks to the person (never the number, only the last 4 digits), and what ID level a set of documents gives.

import { store } from '../database';
import { typeOf } from './idRules';

export const PENDING = ['pending_check', 'pending_review', 'submitted'];

export function docView(doc: Record<string, any>) {
  const type = typeOf(doc.type);

  return {
    id: doc.id as string,
    type: doc.type as string,
    label: type ? type.label : (doc.type as string),
    last4: doc.last4 as string,
    country: doc.country || null,
    expiry: doc.expiry || null,
    status: doc.status as string,
    createdAt: doc.createdAt as string,
    reviewedAt: doc.reviewedAt || null,
    note: doc.status === 'rejected' ? doc.note || null : null,
  };
}

export async function listMyDocuments(uid: string) {
  const rows = await store().query('identityDocuments', {
    where: [['uid', '==', uid]],
    orderBy: [['createdAt', 'desc']],
    limit: 20,
  });

  return rows.map(docView);
}

// The ID level from a person's documents: 2 when one is confirmed, 1 when one is waiting, otherwise 0.
// It is called inside transactions, with the documents already read.
export function levelFrom(docs: Record<string, any>[]): 0 | 1 | 2 {
  if (docs.some((doc) => doc.status === 'verified')) return 2;
  if (docs.some((doc) => doc.status !== 'rejected' && doc.status !== 'expired')) return 1;

  return 0;
}
