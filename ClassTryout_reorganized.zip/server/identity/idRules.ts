// server/identity/idRules.ts
// What counts as a valid ID: the types, the number format and the expiry date. The list of types is in shared/id-types.json.

import idTypes from '../../shared/id-types.json';
import { bad } from '../errors';

export interface IdType {
  code: string;
  label: string;
  country?: string | null;
  pattern: string;
  example?: string;
  needsExpiry?: boolean;
  checker?: string;
}

const TYPES = idTypes.types as IdType[];

export const ONE_DAY = 86400_000;

export function typeOf(code: string): IdType | undefined {
  return TYPES.find((type) => type.code === code);
}

// The standard form: upper case, no spaces or hyphens. So "gha-123456789-0" and "GHA1234567890" are the same ID.
export function canonical(typeCode: string, raw: unknown): { display: string; key: string } {
  const type = typeOf(typeCode);

  if (!type) throw bad('Choose an ID type.', { type: 'Choose a type.' });

  const text = String(raw || '').toUpperCase().trim();

  if (typeCode === 'ghana_card') {
    const flat = text.replace(/[\s-]/g, '');
    const match = /^GHA([0-9]{9})([0-9])$/.exec(flat);

    if (!match) throw bad(`A Ghana Card number looks like ${type.example}.`, { number: 'Check the number.' });

    return { display: `GHA-${match[1]}-${match[2]}`, key: flat };
  }

  if (!new RegExp(type.pattern).test(text)) {
    const example = type.example ? ' Example: ' + type.example : '';

    throw bad(`That does not look like a valid ${type.label} number.${example}`, { number: 'Check the number.' });
  }

  return { display: text, key: text.replace(/[\s/-]/g, '') };
}

export function validExpiry(type: IdType, raw: unknown): string | null {
  const text = String(raw || '').trim();

  if (!text) {
    if (type.needsExpiry) throw bad('Enter the expiry date shown on the ID.', { expiry: 'Required.' });

    return null;
  }

  const date = new Date(text + 'T00:00:00Z');
  const isRealDate = /^\d{4}-\d{2}-\d{2}$/.test(text) && !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === text;

  if (!isRealDate) throw bad('Enter a real expiry date.', { expiry: 'Not a real date.' });

  if (date.getTime() < Date.now() - ONE_DAY) throw bad('That ID has expired.', { expiry: 'Expired.' });
  if (date.getTime() > Date.now() + 25 * 365 * ONE_DAY) throw bad('Check the expiry date.', { expiry: 'Too far ahead.' });

  return text;
}

export const retryDays: number = idTypes.retryDays;
export const knownStatuses: string[] = idTypes.statuses;
