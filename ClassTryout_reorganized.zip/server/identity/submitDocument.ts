// server/identity/submitDocument.ts
// Identity documents.
//
//   identityDocuments/{id}   one per submitted ID. The number is kept as a keyed hash (plus the last 4 digits to show).
//                            The full number is kept ENCRYPTED only while a check or review is pending, then it is deleted.
//   identityClaims/{hmac}    { uid, docId }, created in the same transaction: one ID can belong to one account only.
//
// users/{uid}.identity.level:  0 none | 1 ID given, format valid, not confirmed | 2 confirmed (automated check or a human reviewer)

import { store, nowIso } from '../database';
import { bad, conflict, forbidden, notFound } from '../errors';
import { hmac, encrypt, hit, audit } from '../security';
import { canonical, typeOf, validExpiry, retryDays, ONE_DAY } from './idRules';
import { routeFor } from './checkers';
import { docView, levelFrom } from './documentView';

const AT_MOST_FIVE_IDS = 5;

function countedDocuments(documents: Record<string, any>[]) {
  return documents.filter((doc) => doc.status !== 'rejected' && doc.status !== 'expired');
}

export async function submitDocument(uid: string, body: any, ip?: string | null) {
  const answers = body || {};
  const type = typeOf(answers.type);

  if (!type) throw bad('Choose an ID type.', { type: 'Choose a type.' });

  const number = canonical(answers.type, answers.number);

  // A passport (for example) has no fixed country, so the person says which country issued it.
  let country = type.country as string | null | undefined;

  if (!country) {
    country = String(answers.country || '').toUpperCase();

    if (!/^[A-Z]{2}$/.test(country)) throw bad('Choose the country that issued this ID.', { country: 'Required.' });
  }

  const expiry = validExpiry(type, answers.expiry);

  await hit(`id:uid:${uid}`, 10, 86400, 'You have submitted too many IDs today. Try again tomorrow.');

  if (ip) await hit(`id:ip:${ip}`, 40, 3600, 'Too many requests from this network. Try again later.');

  const claimId = hmac('id', `${answers.type}:${country}:${number.key}`);
  const route = routeFor(answers.type);
  const now = nowIso();

  let docId = '';

  await store().transaction(async (tx) => {
    const user = await tx.get('users', uid);

    if (!user) throw notFound('Account not found.');
    if (user.status === 'suspended') throw forbidden('This account is suspended.', 'suspended');

    const claim = await tx.get('identityClaims', claimId);

    if (claim && claim.uid !== uid) {
      throw conflict('This ID is already linked to another account. If you think this is a mistake, contact support.', 'id_in_use');
    }

    if (claim) {
      const previous = await tx.get('identityDocuments', claim.docId);

      if (previous && previous.status !== 'rejected' && previous.status !== 'expired') {
        throw conflict('You have already added this ID.', 'already_added');
      }
    }

    const mine = await tx.query('identityDocuments', { where: [['uid', '==', uid]], orderBy: [['createdAt', 'desc']], limit: 20 });

    if (countedDocuments(mine).length >= AT_MOST_FIVE_IDS) throw conflict('You can have at most 5 IDs on file.', 'too_many');

    docId = await tx.add('identityDocuments', {
      uid,
      type: answers.type,
      country,
      expiry,
      last4: number.key.slice(-4),
      numberHmac: claimId,
      encNumber: encrypt(number.display, `idnum:${uid}`),
      encExpiresAt: new Date(Date.now() + retryDays * ONE_DAY).toISOString(),
      status: route.status,
      checker: route.checker,
      attempts: 0,
      nextAttemptAt: route.status === 'pending_check' ? now : null,
      createdAt: now,
      updatedAt: now,
    });

    await tx.set('identityClaims', claimId, { uid, docId, type: answers.type, createdAt: now });

    const types = [...new Set([...(user.identity.types || []), answers.type])];

    await tx.update('users', uid, {
      'identity.level': Math.max(1, (user.identity && user.identity.level) || 0),
      'identity.types': types,
      'identity.updatedAt': now,
      updatedAt: now,
    });
  });

  await audit({
    actor: { uid, role: 'self' },
    action: 'identity.submit',
    target: { type: 'identityDocument', id: docId },
    after: { type: answers.type, status: route.status, checker: route.checker },
    ip,
  });

  const saved = await store().get('identityDocuments', docId);

  return docView({ id: docId, ...saved });
}

// A person withdraws an ID that is not confirmed yet (a typo, the wrong ID).
// A confirmed ID can only be changed by an administrator.
export async function withdrawDocument(uid: string, docId: string): Promise<void> {
  await store().transaction(async (tx) => {
    const doc = await tx.get('identityDocuments', docId);

    if (!doc || doc.uid !== uid) throw notFound('ID not found.');
    if (doc.status === 'verified') throw conflict('A confirmed ID cannot be removed. Contact support.', 'confirmed');

    const mine = await tx.query('identityDocuments', { where: [['uid', '==', uid]], orderBy: [['createdAt', 'desc']], limit: 20 });
    const others = mine.filter((other) => other.id !== docId);

    await tx.delete('identityClaims', doc.numberHmac);
    await tx.delete('identityDocuments', docId);

    await tx.update('users', uid, {
      'identity.level': levelFrom(others),
      'identity.types': [...new Set(others.map((other) => other.type))],
      'identity.updatedAt': nowIso(),
      updatedAt: nowIso(),
    });
  });
}
