// server/identity/reviewQueue.ts
// What a reviewer sees: the list of IDs waiting, and the full number of one ID (to compare with the card).

import { store } from '../database';
import type { Where } from '../database';
import { bad, conflict, notFound } from '../errors';
import { audit, decrypt, hit } from '../security';
import type { Actor } from '../security';
import { knownStatuses } from './idRules';
import { docView } from './documentView';

export async function reviewQueue({ status = 'pending_review', before, limit = 25 }: { status?: string; before?: string; limit?: number | string } = {}) {
  if (!knownStatuses.includes(status)) throw bad('Unknown status.');

  const where: Where[] = [['status', '==', status]];

  if (before) where.push(['createdAt', '<', String(before)]);

  const rows = await store().query('identityDocuments', {
    where,
    orderBy: [['createdAt', 'desc']],
    limit: Math.min(Math.max(+limit || 25, 1), 100),
  });

  return rows.map((doc) => ({ ...docView(doc), uid: doc.uid as string, checker: doc.checker as string, attempts: doc.attempts as number }));
}

// A reviewer needs the number to compare it with the card. Every look is written to the audit log and rate limited.
export async function revealNumber(actor: Actor, docId: string, ip?: string | null) {
  await hit(`id:reveal:${actor.uid}`, 60, 3600, 'Too many ID look-ups. Try again later.');

  const doc = await store().get('identityDocuments', docId);

  if (!doc) throw notFound('ID not found.');
  if (!doc.encNumber) throw conflict('The number was removed after the decision.', 'removed');

  const owner = await store().get('users', doc.uid);
  const number = decrypt(doc.encNumber, `idnum:${doc.uid}`);

  await audit({ actor, action: 'identity.reveal', target: { type: 'identityDocument', id: docId }, ip });

  const profile = (owner && owner.profile) || {};

  return {
    number,
    type: doc.type as string,
    country: doc.country as string | null,
    expiry: doc.expiry as string | null,
    holder: { name: profile.displayName || null, dob: profile.dob || null },
  };
}
