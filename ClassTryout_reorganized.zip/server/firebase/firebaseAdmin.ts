// server/firebase/firebaseAdmin.ts
// Firebase Admin (server only). The credentials come from the environment and never reach the browser.
//
//   FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY   (from a service-account JSON file)
//   or GOOGLE_APPLICATION_CREDENTIALS pointing at that JSON file.
//
// Local testing: FIREBASE_AUTH_EMULATOR_HOST + FIREBASE_PROJECT_ID (no credentials; refused when NODE_ENV=production).
//
// firebase-admin v13+ has no old-style API (admin.auth(), admin.firestore()), only the imports below.
// getAdmin() returns a small object so the rest of the code can write getAdmin().auth(), .firestore() and .FieldValue.

import { initializeApp, cert, applicationDefault, getApps } from 'firebase-admin/app';
import type { App } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import type { Auth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import type { Firestore } from 'firebase-admin/firestore';

export interface AdminFacade {
  app: App;
  auth: () => Auth;
  firestore: () => Firestore;
  FieldValue: typeof FieldValue;
}

const NOT_CONFIGURED_MESSAGE =
  'Firebase Admin is not configured. Set FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL and FIREBASE_PRIVATE_KEY ' +
  '(or GOOGLE_APPLICATION_CREDENTIALS) in .env.local. See .env.local.example.';

function createApp(): App {
  const { FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY } = process.env;

  if (getApps().length) return getApps()[0];

  const usingEmulator = process.env.FIREBASE_AUTH_EMULATOR_HOST && FIREBASE_PROJECT_ID && process.env.NODE_ENV !== 'production';

  if (usingEmulator) return initializeApp({ projectId: FIREBASE_PROJECT_ID });

  if (FIREBASE_PROJECT_ID && FIREBASE_CLIENT_EMAIL && FIREBASE_PRIVATE_KEY) {
    return initializeApp({
      credential: cert({
        projectId: FIREBASE_PROJECT_ID,
        clientEmail: FIREBASE_CLIENT_EMAIL,
        // .env files store the key with a literal "\n". Firebase needs real new lines.
        privateKey: FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
      }),
    });
  }

  if (process.env.GOOGLE_APPLICATION_CREDENTIALS) {
    return initializeApp({ credential: applicationDefault() });
  }

  throw new Error(NOT_CONFIGURED_MESSAGE);
}

let facade: AdminFacade | undefined;

export function getAdmin(): AdminFacade {
  if (facade) return facade;

  const app = createApp();

  facade = {
    app,
    auth: () => getAuth(app),
    firestore: () => getFirestore(app),
    FieldValue,
  };

  return facade;
}
