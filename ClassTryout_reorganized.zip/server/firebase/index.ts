export { getAdmin } from './firebaseAdmin';
export type { AdminFacade } from './firebaseAdmin';
