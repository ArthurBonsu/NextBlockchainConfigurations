// server/sms/consoleProvider.ts
// Prints the message in the terminal instead of sending it. Never used in production.

import type { SmsMessage, SmsProvider } from './smsTypes';

export const consoleProvider: SmsProvider = {
  async send({ to, text }: SmsMessage) {
    console.log(`[sms:console] to ${to}: ${text}`);

    return { id: 'console' };
  },
};
