// server/sms/httpProvider.ts
// A generic HTTP SMS provider, for any gateway that accepts a JSON POST or a GET with query parameters.
//
//   SMS_HTTP_URL       the address. In GET mode, {to} {text} {from} are replaced (URL-encoded) in the address.
//   SMS_HTTP_METHOD    POST (the default) or GET
//   SMS_HTTP_HEADERS   a JSON object of headers, for example {"Authorization":"Bearer ..."}   (a secret: keep it in .env.local)
//   SMS_HTTP_BODY      the JSON for POST, for example {"sender":"{from}","to":"{to}","message":"{text}"}
//   SMS_SENDER_ID      the sender name (at most 11 characters, registered with the provider)
//
// Success is any 2xx answer. The answer's body is never logged, because it can echo secrets.

import type { SmsMessage, SmsProvider } from './smsTypes';

type Encoder = (value: string) => string;

const DEFAULT_BODY = '{"sender":"{from}","recipient":"{to}","message":"{text}"}';

export const httpProvider: SmsProvider = {
  async send({ to, text }: SmsMessage) {
    const url = process.env.SMS_HTTP_URL;

    if (!url) throw new Error('SMS_HTTP_URL is not configured.');

    const method = (process.env.SMS_HTTP_METHOD || 'POST').toUpperCase();
    const from = process.env.SMS_SENDER_ID || '';
    const headers = process.env.SMS_HTTP_HEADERS ? JSON.parse(process.env.SMS_HTTP_HEADERS) : {};

    const fill = (template: string, encode: Encoder) =>
      template.replace(/\{to\}/g, encode(to)).replace(/\{text\}/g, encode(text)).replace(/\{from\}/g, encode(from));

    let response: Response;

    if (method === 'GET') {
      response = await fetch(fill(url, encodeURIComponent), { method: 'GET', headers });
    } else {
      const template = process.env.SMS_HTTP_BODY || DEFAULT_BODY;
      const body = fill(template, (value) => JSON.stringify(value).slice(1, -1)); // escape for JSON

      response = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body });
    }

    if (!response.ok) throw new Error(`SMS provider answered HTTP ${response.status}.`);

    return { id: null };
  },
};
