// server/sms/mockProvider.ts
// A test provider: adds each message as one JSON line to SMS_OUTBOX_FILE (default .data/sms-outbox.jsonl).

import fs from 'fs';
import path from 'path';
import { root } from '../config';
import type { SmsMessage, SmsProvider } from './smsTypes';

export function outboxFile(): string {
  return process.env.SMS_OUTBOX_FILE || path.join(root, '.data', 'sms-outbox.jsonl');
}

export const mockProvider: SmsProvider = {
  async send({ to, text }: SmsMessage) {
    if (process.env.SMS_MOCK_FAIL === '1') throw new Error('mock provider told to fail');

    fs.mkdirSync(path.dirname(outboxFile()), { recursive: true });

    const id = 'mock-' + Date.now() + '-' + Math.random().toString(16).slice(2, 8);
    const line = JSON.stringify({ id, to, text, at: new Date().toISOString() });

    fs.appendFileSync(outboxFile(), line + '\n');

    return { id };
  },
};

// For tests: the latest message sent to a number.
export function lastTo(to: string): { id: string; to: string; text: string; at: string } | null {
  try {
    const rows = fs
      .readFileSync(outboxFile(), 'utf8')
      .split('\n')
      .filter(Boolean)
      .map((line) => JSON.parse(line));

    return rows.reverse().find((row) => row.to === to) || null;
  } catch {
    return null;
  }
}
