// server/sms/smsTypes.ts
// Every SMS provider is one file that sends a message: send({ to, text }).

export interface SmsMessage {
  to: string; // E.164, for example +233241234567
  text: string;
}

export interface SmsProvider {
  send(message: SmsMessage): Promise<{ id: string | null }>;
}
