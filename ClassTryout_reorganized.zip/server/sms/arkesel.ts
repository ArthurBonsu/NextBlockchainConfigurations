// server/sms/arkesel.ts
// Arkesel v2 preset.
// UNVERIFIED: written from the public description of the API. Check the endpoint, the field names and the sender-ID rules
// against Arkesel's current documentation (and your account) before going live.
//   ARKESEL_API_KEY, SMS_SENDER_ID

import type { SmsMessage, SmsProvider } from './smsTypes';

export const arkesel: SmsProvider = {
  async send({ to, text }: SmsMessage) {
    const key = process.env.ARKESEL_API_KEY;

    if (!key) throw new Error('ARKESEL_API_KEY is not configured.');

    const response = await fetch('https://sms.arkesel.com/api/v2/sms/send', {
      method: 'POST',
      headers: { 'api-key': key, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sender: process.env.SMS_SENDER_ID || 'ClassTryout',
        message: text,
        recipients: [to.replace(/^\+/, '')],
      }),
    });

    if (!response.ok) throw new Error(`Arkesel answered HTTP ${response.status}.`);

    return { id: null };
  },
};
