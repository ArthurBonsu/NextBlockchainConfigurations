// server/sms/sendSms.ts
// Sending a text message, whatever the provider. Choose it with SMS_PROVIDER:
//
//   mock      writes each message to a local file (SMS_OUTBOX_FILE). For tests and local work. Refused in production.
//   console   prints the message. Never in production.
//   http      any provider with a simple JSON or GET API, set up with the SMS_HTTP_* variables (see httpProvider.ts)
//   arkesel   a preset for Arkesel's v2 API    (UNVERIFIED against the live docs: check before relying on it)
//   hubtel    a preset for Hubtel's messaging API    (UNVERIFIED against the live docs: check before relying on it)
//
// Adding a provider = one file that has send({ to, text }), and one line in PROVIDERS below.
// Our own code, not the provider, makes and checks the one-time codes, so changing provider never changes how codes behave.

import { isProd } from '../config';
import { arkesel } from './arkesel';
import { consoleProvider } from './consoleProvider';
import { hubtel } from './hubtel';
import { httpProvider } from './httpProvider';
import { mockProvider } from './mockProvider';
import type { SmsProvider } from './smsTypes';

const PROVIDERS: Record<string, SmsProvider> = {
  mock: mockProvider,
  console: consoleProvider,
  http: httpProvider,
  arkesel,
  hubtel,
};

export function providerName(): string {
  return (process.env.SMS_PROVIDER || (isProd() ? '' : 'mock')).toLowerCase();
}

function getProvider(): { name: string; provider: SmsProvider } {
  const name = providerName();

  if (!name) throw new Error('SMS_PROVIDER is not configured. Set it in .env.local (see .env.local.example).');

  if (isProd() && (name === 'mock' || name === 'console')) throw new Error(`SMS_PROVIDER=${name} is refused in production.`);

  if (!PROVIDERS[name]) throw new Error(`Unknown SMS_PROVIDER "${name}" (${Object.keys(PROVIDERS).join(', ')}).`);

  return { name, provider: PROVIDERS[name] };
}

// `to` is in E.164 form, like "+233241234567". Throws when sending fails. The caller decides what to tell the person.
export async function sendSms({ to, text }: { to: string; text: string }) {
  if (!/^\+[1-9][0-9]{7,14}$/.test(to)) throw new Error('Invalid recipient.');

  const { name, provider } = getProvider();
  const result = await provider.send({ to, text: String(text).slice(0, 480) });

  return { provider: name, id: (result && result.id) || null };
}
