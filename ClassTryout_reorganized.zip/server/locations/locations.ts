// server/locations/locations.ts
// Ghana's places: 16 regions > 261 districts (MMDAs) > city or town > suburb > optional sub-area.
//
// Regions and districts come from shared/locations/*.json (scripts/checkConsistency.ts compares the counts to the official list).
// Cities, suburbs and sub-areas are free text on purpose: no list covers every neighbourhood, and people spell them differently.
// We keep a NORMALISED KEY next to each, so "East Legon", "east  legon" and "E. Legon" group together.

import regions from '../../shared/locations/regions.json';
import districts from '../../shared/locations/districts.json';
import { bad } from '../errors';

export { regions, districts };

export const regionByCode = new Map(regions.map((region) => [region.code, region]));
export const districtById = new Map(districts.map((district) => [district.id, district]));

// A GhanaPostGPS address: 2-3 letters, 3-4 digits, then 4 digits. For example GA-543-1234.
export const GPS = /^[A-Z]{2,3}-[0-9]{3,4}-[0-9]{4}$/;

export function clean(text: unknown): string {
  return String(text == null ? '' : text).normalize('NFKC').replace(/\s+/g, ' ').trim();
}

// "East  Legon (Ext.)" becomes "east legon ext"
export function normKey(text: unknown): string {
  return clean(text)
    .toLowerCase()
    .replace(/\bext(ension)?\b\.?/g, 'ext')
    .replace(/[^\p{L}\p{N} ]/gu, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function validPlace(label: string, value: unknown, options: { required?: boolean; max?: number } = {}): string {
  const max = options.max ?? 80;
  const text = clean(value);
  const fieldName = label.toLowerCase();

  if (!text) {
    if (options.required) throw bad(`${label} is required.`, { [fieldName]: 'Required.' });

    return '';
  }

  if (text.length > max || text.length < 2) {
    throw bad(`${label} must be 2-${max} characters.`, { [fieldName]: 'Check this.' });
  }

  if (!/^[\p{L}\p{N} .,'’()/&-]+$/u.test(text)) {
    throw bad(`${label} has characters we do not accept.`, { [fieldName]: "Letters, numbers and . , ' ( ) / & - only." });
  }

  return text;
}

export interface StoredAddress {
  regionCode: string;
  regionName: string;
  districtId: string;
  districtName: string;
  city: string;
  cityKey: string;
  suburb: string;
  suburbKey: string;
  subarea?: string;
  subareaKey?: string;
  street?: string;
  gpsAddress?: string;
  lat?: number;
  lng?: number;
  placeId?: string;
  updatedAt?: string;
}

function checkRegionAndDistrict(body: Record<string, any>) {
  const region = regionByCode.get(String(body.regionCode || ''));

  if (!region) throw bad('Choose your region.', { regionCode: 'Choose a region.' });

  const district = districtById.get(String(body.districtId || ''));

  if (!district) throw bad('Choose your district.', { districtId: 'Choose a district.' });

  if (district.region !== region.code) {
    throw bad('That district is not in the region you chose.', { districtId: 'Not in this region.' });
  }

  return { region, district };
}

// Ghana sits roughly between 4.5-11.5 N and 3.5 W-1.5 E.
function checkMapPosition(body: Record<string, any>): { lat: number; lng: number } | null {
  const hasPosition = body.lat !== undefined && body.lat !== null && body.lat !== '';

  if (!hasPosition) return null;

  const lat = Number(body.lat);
  const lng = Number(body.lng);

  if (!(lat >= 4 && lat <= 12 && lng >= -4 && lng <= 2)) throw bad('That location is outside Ghana.', { lat: 'Outside Ghana.' });

  return { lat: Math.round(lat * 1e6) / 1e6, lng: Math.round(lng * 1e6) / 1e6 };
}

// Returns the address that is saved on the user, or throws a 422 error.
export function validateAddress(input: unknown): StoredAddress {
  const body = (input || {}) as Record<string, any>;
  const { region, district } = checkRegionAndDistrict(body);

  const city = validPlace('City', body.city, { required: true });
  const suburb = validPlace('Suburb', body.suburb, { required: true });
  const subarea = validPlace('Sub-area', body.subarea, { max: 100 });
  const street = validPlace('Street', body.street, { max: 120 });

  const gpsAddress = clean(body.gpsAddress).toUpperCase();

  if (gpsAddress && !GPS.test(gpsAddress)) throw bad('GhanaPostGPS looks like GA-543-1234.', { gpsAddress: 'Check the format.' });

  const address: StoredAddress = {
    regionCode: region.code,
    regionName: region.name,
    districtId: district.id,
    districtName: district.name,
    city,
    cityKey: normKey(city),
    suburb,
    suburbKey: normKey(suburb),
  };

  if (subarea) {
    address.subarea = subarea;
    address.subareaKey = normKey(subarea);
  }

  if (street) address.street = street;
  if (gpsAddress) address.gpsAddress = gpsAddress;

  const position = checkMapPosition(body);

  if (position) {
    address.lat = position.lat;
    address.lng = position.lng;
  }

  if (body.placeId) address.placeId = clean(body.placeId).slice(0, 200);

  return address;
}
