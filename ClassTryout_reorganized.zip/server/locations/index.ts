export { regions, districts, regionByCode, districtById, normKey, validateAddress, clean, GPS } from './locations';
export type { StoredAddress } from './locations';
