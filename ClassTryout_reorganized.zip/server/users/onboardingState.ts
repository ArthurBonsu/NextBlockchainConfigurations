// server/users/onboardingState.ts
// Which set-up steps are done. It is worked out from the data each time and never stored, so it cannot drift.

import onboarding from '../../shared/onboarding.json';
import { nowIso } from '../database';
import type { UserDoc } from './userTypes';

type ConsentVersions = Record<string, { version: string }>;

export function stepsDone(user: Partial<UserDoc>): Record<string, boolean> {
  const consents = user.consents || {};
  const profile = user.profile || {};
  const address: Partial<NonNullable<UserDoc['address']>> = user.address || {};
  const required = onboarding.consents as ConsentVersions;

  return {
    consent: Object.keys(required).every((key) => consents[key] && consents[key].version === required[key].version),
    profile: !!(profile.givenName && profile.familyName && profile.dob && profile.gender),
    phone: !!(user.phone && user.phone.verified),
    address: !!(address.regionCode && address.districtId && address.city && address.suburb),
    id: ((user.identity && user.identity.level) || 0) >= 1,
  };
}

export function onboardingState(user: Partial<UserDoc>) {
  const done = stepsDone(user);
  const required = onboarding.requiredToFinish;

  const complete = required.every((step) => done[step]);

  // The next step is the first unfinished REQUIRED step, then the first unfinished step of any kind.
  const next =
    onboarding.steps.find((step) => !done[step] && required.includes(step)) || onboarding.steps.find((step) => !done[step]) || null;

  return {
    steps: onboarding.steps,
    done,
    complete,
    next,
    required,
    optional: onboarding.optionalButRecommended,
  };
}

// When the last required step is saved, stamp the moment on the user document (only the first time).
export function touchOnboarding(user: UserDoc, patch: Record<string, unknown>): Record<string, unknown> {
  const afterPatch = { ...user, ...patch } as UserDoc;

  if (onboardingState(afterPatch).complete && !(user.onboarding && user.onboarding.completedAt)) {
    patch['onboarding.completedAt'] = nowIso();
  }

  return patch;
}
