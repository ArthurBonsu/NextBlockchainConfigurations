// server/users/userTypes.ts
// The user document stored in the database at users/{uid}. The document id IS the Firebase uid.
// What the browser receives is a smaller version of this (see userView.ts and types/account.types.ts).

import type { StoredAddress } from '../locations';

export interface UserDoc {
  uid: string;
  email: string | null;
  emailVerified: boolean;
  provider: string;
  role: string;
  status: 'active' | 'suspended';
  createdAt: string;
  updatedAt: string;
  lastLoginAt: string;
  profile: {
    givenName?: string;
    familyName?: string;
    otherNames?: string;
    displayName?: string;
    dob?: string;
    gender?: string;
    nationality?: string;
  };
  phone: {
    verified: boolean;
    e164?: string;
    last4?: string;
    masked?: string;
    verifiedAt?: string;
  };
  address: StoredAddress | null;
  identity: {
    level: number; // 0 no ID, 1 ID added, 2 ID confirmed
    types: string[];
    verifiedAt?: string;
    bootstrap?: boolean;
  };
  consents: Record<string, { version: string; at: string; ipHash?: string | null }>;
  notifications: { email: boolean; sms: boolean };
  onboarding: { completedAt: string | null };
  schemaVersion: number;
}
