// server/users/onboardingSteps.ts
// Saving what the person enters on each set-up screen: agreements, name, address, notification choices.
// (The phone step is in server/phone/ because it sends SMS.)

import onboarding from '../../shared/onboarding.json';
import { store, nowIso } from '../database';
import { bad, conflict, notFound } from '../errors';
import { sha256 } from '../security';
import { validateAddress, clean } from '../locations';
import { requireUser } from './loadUser';
import { touchOnboarding } from './onboardingState';
import type { UserDoc } from './userTypes';

// A name starts with a letter and may hold letters, spaces and . ' ’ -
const NAME = /^[\p{L}][\p{L} .'’-]{0,59}$/u;

type ConsentDefinitions = Record<string, { version: string }>;

// ---------------------------------------------------------------- 1. agreements
export async function saveConsents(uid: string, body: any, ip?: string | null): Promise<UserDoc> {
  const answers = body || {};
  const definitions = onboarding.consents as ConsentDefinitions;

  const notAccepted = Object.keys(definitions).filter((key) => answers[key] !== true);

  if (notAccepted.length) {
    throw bad('Please accept all three agreements to continue.', Object.fromEntries(notAccepted.map((key) => [key, 'Required.'])));
  }

  const user = await requireUser(uid);
  const at = nowIso();
  const ipHash = ip ? sha256('ip:' + ip).slice(0, 16) : null;

  const patch: Record<string, unknown> = {};

  for (const [key, definition] of Object.entries(definitions)) {
    const alreadyAccepted = user.consents && user.consents[key] && user.consents[key].version === definition.version;

    if (!alreadyAccepted) patch[`consents.${key}`] = { version: definition.version, at, ipHash };
  }

  if (Object.keys(patch).length === 0) return user;

  patch.updatedAt = at;
  await store().update('users', uid, touchOnboarding(user, patch));

  return requireUser(uid);
}

// ---------------------------------------------------------------- 2. about you
function validDateOfBirth(text: unknown): string {
  const value = String(text || '');

  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw bad('Enter your date of birth.', { dob: 'Use the date picker.' });

  const date = new Date(value + 'T00:00:00Z');

  if (Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== value) {
    throw bad('That date does not exist.', { dob: 'Not a real date.' });
  }

  const now = new Date();
  let age = now.getUTCFullYear() - date.getUTCFullYear();

  const birthdayNotYetThisYear =
    now.getUTCMonth() < date.getUTCMonth() || (now.getUTCMonth() === date.getUTCMonth() && now.getUTCDate() < date.getUTCDate());

  if (birthdayNotYetThisYear) age--;

  if (age < onboarding.minAge) throw bad(`You must be at least ${onboarding.minAge} to register.`, { dob: `At least ${onboarding.minAge}.` });
  if (age > 120) throw bad('Check your date of birth.', { dob: 'Check this.' });

  return value;
}

function checkNames(answers: Record<string, any>): void {
  const problems: Record<string, string> = {};

  for (const [key, label] of [
    ['givenName', 'First name'],
    ['familyName', 'Surname'],
  ]) {
    if (!NAME.test(clean(answers[key]))) problems[key] = `${label}: letters, spaces and . ' - only.`;
  }

  const otherNames = clean(answers.otherNames);

  if (otherNames && !NAME.test(otherNames)) problems.otherNames = "Letters, spaces and . ' - only.";

  if (Object.keys(problems).length) throw bad('Check your name.', problems);
}

export async function saveProfile(uid: string, body: any): Promise<UserDoc> {
  const answers = body || {};
  const user = await requireUser(uid);

  if (user.identity && user.identity.level >= 2) {
    throw conflict('Your name and date of birth are locked because your ID is confirmed. Contact support to correct them.', 'locked');
  }

  checkNames(answers);

  const dob = validDateOfBirth(answers.dob);

  if (!onboarding.genders.includes(answers.gender)) throw bad('Choose an option for gender.', { gender: 'Choose one.' });

  const nationality = String(answers.nationality || 'GH').toUpperCase();

  if (!/^[A-Z]{2}$/.test(nationality)) throw bad('Choose your nationality.', { nationality: 'Two-letter country code.' });

  const otherNames = clean(answers.otherNames);

  const profile: UserDoc['profile'] = {
    givenName: clean(answers.givenName),
    familyName: clean(answers.familyName),
    dob,
    gender: answers.gender,
    nationality,
  };

  if (otherNames) profile.otherNames = otherNames;

  profile.displayName = [profile.givenName, profile.familyName].join(' ');

  await store().update('users', uid, touchOnboarding(user, { profile, updatedAt: nowIso() }));

  return requireUser(uid);
}

// ---------------------------------------------------------------- 4. address
// One suggestion per (district, suburb). It counts how many people chose it, so the most used suburbs come first.
function suggestionId(districtId: string, suburbKey: string): string {
  return sha256(`${districtId}|${suburbKey}`).slice(0, 32);
}

export async function saveAddress(uid: string, body: unknown): Promise<UserDoc> {
  const address = validateAddress(body);

  address.updatedAt = nowIso();

  await store().transaction(async (tx) => {
    const user = (await tx.get('users', uid)) as UserDoc | null;

    if (!user) throw notFound('Account not found.');

    const id = suggestionId(address.districtId, address.suburbKey);
    const suggestion = await tx.get('locationSuggestions', id);

    const sameSuburbAsBefore =
      user.address && user.address.districtId === address.districtId && user.address.suburbKey === address.suburbKey;

    await tx.update('users', uid, touchOnboarding(user, { address, updatedAt: address.updatedAt }));

    if (!sameSuburbAsBefore) {
      await tx.set('locationSuggestions', id, {
        districtId: address.districtId,
        regionCode: address.regionCode,
        suburb: suggestion ? suggestion.suburb : address.suburb,
        suburbKey: address.suburbKey,
        city: suggestion ? suggestion.city : address.city,
        count: (suggestion ? suggestion.count : 0) + 1,
        createdAt: suggestion ? suggestion.createdAt : address.updatedAt,
        updatedAt: address.updatedAt,
      });
    }
  });

  return requireUser(uid);
}

export async function suburbSuggestions(districtId: string) {
  if (!districtId) throw bad('districtId is required.', { districtId: 'Required.' });

  const rows = await store().query('locationSuggestions', {
    where: [['districtId', '==', String(districtId)]],
    orderBy: [['count', 'desc']],
    limit: 50,
  });

  return rows.map((row) => ({ suburb: row.suburb, city: row.city, count: row.count }));
}

// ---------------------------------------------------------------- notification choices
export async function saveNotificationPrefs(uid: string, body: any): Promise<UserDoc> {
  const answers = body || {};
  const user = await requireUser(uid);

  const patch: Record<string, unknown> = { updatedAt: nowIso() };

  if (typeof answers.email === 'boolean') patch['notifications.email'] = answers.email;
  if (typeof answers.sms === 'boolean') patch['notifications.sms'] = answers.sms;

  await store().update('users', user.uid, patch);

  return requireUser(uid);
}
