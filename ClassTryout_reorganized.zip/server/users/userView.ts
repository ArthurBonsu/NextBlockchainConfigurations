// server/users/userView.ts
// What the browser is allowed to know about the signed-in person. No hashes, no internal fields.

import * as roles from '../auth/roles';
import { onboardingState } from './onboardingState';
import type { UserDoc } from './userTypes';

export function view(user: UserDoc, extra: Record<string, unknown> = {}) {
  const onboarding = onboardingState(user);
  const phone = user.phone && user.phone.verified
    ? { verified: true, masked: user.phone.masked, verifiedAt: user.phone.verifiedAt }
    : { verified: false };

  return {
    uid: user.uid,
    email: user.email,
    emailVerified: user.emailVerified,
    provider: user.provider,
    role: user.role,
    status: user.status,
    profile: user.profile || {},
    phone,
    address: user.address || null,
    identity: {
      level: (user.identity && user.identity.level) || 0,
      types: (user.identity && user.identity.types) || [],
    },
    consents: Object.fromEntries(Object.entries(user.consents || {}).map(([key, value]) => [key, { version: value.version, at: value.at }])),
    notifications: user.notifications,
    onboarding,
    capabilities: roles.all(user, { onboardingComplete: onboarding.complete }),
    createdAt: user.createdAt,
    ...extra,
  };
}
