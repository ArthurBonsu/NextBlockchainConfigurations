// server/users/loadUser.ts
// Finding a user's document, and creating it the first time that person is seen.

import { store, nowIso } from '../database';
import { notFound } from '../errors';
import type { AuthenticatedUser } from '../auth/verifyBearer';
import type { UserDoc } from './userTypes';

function newUserDocument(auth: AuthenticatedUser): UserDoc {
  const now = nowIso();

  return {
    uid: auth.uid,
    email: auth.email ? auth.email.toLowerCase() : null,
    emailVerified: !!auth.emailVerified,
    provider: auth.provider || 'unknown',
    role: 'citizen',
    status: 'active',
    createdAt: now,
    updatedAt: now,
    lastLoginAt: now,
    profile: {},
    phone: { verified: false },
    address: null,
    identity: { level: 0, types: [] },
    consents: {},
    notifications: { email: true, sms: true },
    onboarding: { completedAt: null },
    schemaVersion: 1,
  };
}

const ONE_HOUR = 3600_000;

// Called on every request that needs the profile.
// The first time a uid is seen it creates the document. After that it keeps email, verified flag and last login up to date.
export async function ensureUser(auth: AuthenticatedUser): Promise<UserDoc> {
  const db = store();
  const existing = (await db.get('users', auth.uid)) as UserDoc | null;

  if (!existing) {
    try {
      await db.create('users', auth.uid, newUserDocument(auth));
    } catch (error: any) {
      // Two first requests arrived together and the other one won. That is fine.
      if (!(error && error.code === 'already-exists')) throw error;
    }

    return (await db.get('users', auth.uid)) as UserDoc;
  }

  const patch: Record<string, unknown> = {};
  const emailNow = auth.email ? auth.email.toLowerCase() : null;

  if (emailNow !== existing.email) patch.email = emailNow;
  if (!!auth.emailVerified !== !!existing.emailVerified) patch.emailVerified = !!auth.emailVerified;

  const lastLoginIsOld = !existing.lastLoginAt || Date.now() - Date.parse(existing.lastLoginAt) > ONE_HOUR;

  if (lastLoginIsOld) patch.lastLoginAt = nowIso();

  if (Object.keys(patch).length === 0) return existing;

  patch.updatedAt = nowIso();
  await db.update('users', auth.uid, patch);

  return { ...existing, ...patch } as UserDoc;
}

export async function requireUser(uid: string): Promise<UserDoc> {
  const user = (await store().get('users', uid)) as UserDoc | null;

  if (!user) throw notFound('Account not found.');

  return user;
}
