// server/users/roleAndStatus.ts
// Administrator actions on an account: change its role, suspend or restore it, confirm an ID in person.
// Every one of them is written to the audit log.

import * as roles from '../auth/roles';
import { getAdmin } from '../firebase';
import { store, nowIso } from '../database';
import { bad, forbidden, conflict } from '../errors';
import { audit } from '../security';
import type { Actor } from '../security';
import { requireUser } from './loadUser';
import type { UserDoc } from './userTypes';

function usingDevBackend(): boolean {
  return (process.env.NOTIFY_BACKEND || 'firebase').toLowerCase() === 'dev';
}

// Runs a Firebase Admin action. When Firebase Admin is not set up (tests), the action is skipped quietly.
async function withFirebaseAdmin(action: (admin: ReturnType<typeof getAdmin>) => Promise<unknown>): Promise<void> {
  if (usingDevBackend()) return;

  try {
    await action(getAdmin());
  } catch (error: any) {
    if (/not configured/i.test(String(error && error.message))) return;

    throw error;
  }
}

// Ends all the person's sessions, so a changed role or a suspension takes effect within minutes, not hours.
async function revokeSessions(uid: string): Promise<void> {
  await withFirebaseAdmin((admin) => admin.auth().revokeRefreshTokens(uid));
}

async function setClaims(uid: string, role: string): Promise<void> {
  await withFirebaseAdmin((admin) => admin.auth().setCustomUserClaims(uid, { role }));
}

// actor is the user document of whoever is acting, or { uid: 'system', role: 'system' } when a script does it.
export async function assignRole(actor: Actor, targetUid: string, role: string, ip?: string | null): Promise<UserDoc> {
  if (!roles.isRole(role)) throw bad(`Role must be one of: ${roles.ROLES.join(', ')}.`, { role: 'Unknown role.' });

  const db = store();
  const target = await requireUser(targetUid);

  if (actor.uid === targetUid && actor.uid !== 'system') throw forbidden('You cannot change your own role.', 'self');

  if (target.role === 'super_admin' && role !== 'super_admin') {
    // One OTHER super administrator who is not suspended must remain. A suspended one cannot sign in, so it does not count.
    const supers = await db.query('users', { where: [['role', '==', 'super_admin']], limit: 100 });
    const otherActiveSupers = supers.filter((other) => other.uid !== targetUid && other.status !== 'suspended');

    if (!otherActiveSupers.length) {
      throw conflict('That would leave no active super administrator. Promote and sign in the replacement first.', 'last_super_admin');
    }
  }

  if (target.role === role) return target;

  await db.update('users', targetUid, { role, updatedAt: nowIso() });
  await setClaims(targetUid, role);
  await revokeSessions(targetUid);

  await audit({ actor, action: 'user.role', target: { type: 'user', id: targetUid }, before: { role: target.role }, after: { role }, ip });

  return requireUser(targetUid);
}

export async function setStatus(actor: Actor, targetUid: string, status: string, note?: string, ip?: string | null): Promise<UserDoc> {
  if (!['active', 'suspended'].includes(status)) throw bad('Status must be active or suspended.', { status: 'Unknown status.' });

  const target = await requireUser(targetUid);

  if (actor.uid === targetUid) throw forbidden('You cannot change your own status.', 'self');

  if (target.role === 'super_admin' && actor.role !== 'super_admin') {
    throw forbidden('Only a super administrator can suspend a super administrator.', 'role');
  }

  if (target.status === status) return target;

  await store().update('users', targetUid, { status, updatedAt: nowIso() });

  if (status === 'suspended') await revokeSessions(targetUid);

  await audit({ actor, action: 'user.status', target: { type: 'user', id: targetUid }, before: { status: target.status }, after: { status }, note, ip });

  return requireUser(targetUid);
}

// For founding administrators only. The very first reviewer cannot be confirmed by anyone else, so a person with server
// access, who has seen the ID in real life, marks them confirmed from the command line. It is always audit-logged.
export async function bootstrapConfirmIdentity(uid: string, note?: string): Promise<void> {
  const user = await requireUser(uid);
  const now = nowIso();

  await store().update('users', uid, {
    'identity.level': 2,
    'identity.verifiedAt': now,
    'identity.bootstrap': true,
    updatedAt: now,
  });

  await audit({
    actor: { uid: 'system', role: 'system' },
    action: 'identity.bootstrap',
    target: { type: 'user', id: uid },
    before: { level: (user.identity && user.identity.level) || 0 },
    after: { level: 2 },
    note: note || 'Confirmed in person by server operator',
  });
}
