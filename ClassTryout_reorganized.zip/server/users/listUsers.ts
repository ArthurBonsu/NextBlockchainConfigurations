// server/users/listUsers.ts
// The administrator's list of people.
// Only ONE filter group is allowed at a time. That keeps the number of database indexes small and known
// (see firebase/firestore.indexes.json).

import { store } from '../database';
import type { Where } from '../database';
import { bad } from '../errors';
import type { UserDoc } from './userTypes';

export interface UserListFilters {
  role?: string;
  status?: string;
  regionCode?: string;
  districtId?: string;
  level?: string | number;
  email?: string;
  before?: string;
  limit?: string | number;
}

function filtersFromQuery(q: UserListFilters) {
  const where: Where[] = [];
  const groups: string[] = [];

  if (q.role || q.status) {
    groups.push('role/status');

    if (q.role) where.push(['role', '==', String(q.role)]);
    if (q.status) where.push(['status', '==', String(q.status)]);
  }

  if (q.regionCode) {
    groups.push('region');
    where.push(['address.regionCode', '==', String(q.regionCode)]);
  }

  if (q.districtId) {
    groups.push('district');
    where.push(['address.districtId', '==', String(q.districtId)]);
  }

  if (q.level !== undefined && q.level !== '') {
    groups.push('level');
    where.push(['identity.level', '==', Number(q.level)]);
  }

  if (q.email) {
    groups.push('email');
    where.push(['email', '==', String(q.email).toLowerCase()]);
  }

  return { where, groups };
}

export async function listUsers(q: UserListFilters = {}) {
  const { where, groups } = filtersFromQuery(q);

  if (groups.length > 1) throw bad('Use one filter group at a time: role/status, region, district, ID level or email.');

  // "before" is the paging marker: the oldest createdAt on the page before.
  if (q.before && !q.email) where.push(['createdAt', '<', String(q.before)]);

  const limit = Math.min(Math.max(parseInt(String(q.limit), 10) || 25, 1), 100);
  const orderBy: [string, 'asc' | 'desc'][] = q.email ? [] : [['createdAt', 'desc']];

  const rows = (await store().query('users', { where, orderBy, limit })) as unknown as (UserDoc & { id: string })[];

  return rows.map((user) => ({
    uid: user.uid,
    email: user.email,
    role: user.role,
    status: user.status,
    createdAt: user.createdAt,
    name: user.profile && user.profile.displayName,
    phone: user.phone && user.phone.verified ? user.phone.masked : null,
    region: user.address && user.address.regionName,
    district: user.address && user.address.districtName,
    suburb: user.address && user.address.suburb,
    level: (user.identity && user.identity.level) || 0,
    onboardingComplete: !!(user.onboarding && user.onboarding.completedAt),
  }));
}
