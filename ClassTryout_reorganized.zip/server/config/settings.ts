// server/config/settings.ts
// Settings read from the environment, in one place. Server only.
//
// Secrets (never NEXT_PUBLIC_, never committed):
//   ID_HASH_PEPPER   secret used to HMAC ID numbers and phone numbers (so a leaked database cannot be brute-forced)
//   ID_ENC_KEY       32-byte key (64 hex characters or base64) that encrypts an ID number while a check is pending
//   OTP_SECRET       secret used to HMAC one-time SMS codes
//
// Outside production a throwaway value is used (with one warning) so local work and tests run without setup.
// In production a missing secret is an error, never a silent default.

import crypto from 'crypto';

export function isProd(): boolean {
  return process.env.NODE_ENV === 'production';
}

let warnedAboutThrowawaySecrets = false;

function throwawaySecret(name: string): string {
  if (!warnedAboutThrowawaySecrets) {
    warnedAboutThrowawaySecrets = true;
    console.warn(`[config] ${name} (and other secrets) not set: using throwaway development values. Never do this in production.`);
  }

  return crypto.createHash('sha256').update('classtryout-dev-only:' + name).digest('hex');
}

export function secret(name: string, options: { minLength?: number } = {}): string {
  const minLength = options.minLength ?? 16;
  const value = process.env[name];

  if (value && value.length >= minLength) return value;

  if (isProd()) {
    throw new Error(`${name} is not configured (at least ${minLength} characters). See .env.local.example.`);
  }

  return throwawaySecret(name);
}

// The 32-byte key that encrypts ID numbers. Written as 64 hex characters or as base64.
export function encKey(): Buffer {
  const value = process.env.ID_ENC_KEY;

  if (value) {
    const looksLikeHex = /^[0-9a-fA-F]{64}$/.test(value);
    const bytes = looksLikeHex ? Buffer.from(value, 'hex') : Buffer.from(value, 'base64');

    if (bytes.length !== 32) {
      throw new Error('ID_ENC_KEY must be 32 bytes (64 hex characters, or base64 of 32 bytes).');
    }

    return bytes;
  }

  if (isProd()) throw new Error('ID_ENC_KEY is not configured. See .env.local.example.');

  return crypto.createHash('sha256').update('classtryout-dev-only:ID_ENC_KEY').digest();
}

// "true", "1", "yes" and "on" mean yes. An empty value gives the default.
export function bool(value: string | undefined, defaultValue = false): boolean {
  if (value === undefined || value === '') return defaultValue;

  return /^(1|true|yes|on)$/i.test(String(value));
}
