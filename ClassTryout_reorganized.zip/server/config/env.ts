// server/config/env.ts
// Loads .env.local, then .env (the first file that sets a variable wins). These are the same two files truffle-config.js reads.
// Next.js loads them by itself. This file is for plain Node programs: the notifier and the scripts.

import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

// The project folder. Under Next.js the server code is bundled, so __dirname points into .next/.
// So we use the working directory (Next, the notifier and the scripts all start in the project folder)
// and fall back to the position of this file.
function findProjectRoot(): string {
  if (process.env.PROJECT_ROOT) return process.env.PROJECT_ROOT;

  const workingDirectoryIsProject = fs.existsSync(path.join(process.cwd(), 'shared', 'roles.json'));

  if (workingDirectoryIsProject) return process.cwd();

  return path.resolve(__dirname, '..', '..');
}

export const root = findProjectRoot();

for (const fileName of ['.env.local', '.env']) {
  const filePath = path.join(root, fileName);

  if (fs.existsSync(filePath)) dotenv.config({ path: filePath });
}
