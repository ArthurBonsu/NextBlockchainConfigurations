// server/database/store.ts
// store() gives the rest of the server one small database object, so no other file touches Firestore directly.
//
// STORE_BACKEND picks where the data lives:
//   firestore  (the default)  Cloud Firestore
//   file                      a local JSON file, for tests and offline work. Refused when NODE_ENV=production.

import { FileStore } from './FileStore';
import { FirestoreStore } from './FirestoreStore';
import type { Database } from './types';

function chosenBackend(): string {
  return (process.env.STORE_BACKEND || 'firestore').toLowerCase();
}

let instance: Database | undefined;
let instanceKind: string | undefined;

export function store(): Database {
  const kind = chosenBackend();

  if (kind === 'file' && process.env.NODE_ENV === 'production') {
    throw new Error('STORE_BACKEND=file is for local testing only and is refused when NODE_ENV=production.');
  }

  if (kind !== 'file' && kind !== 'firestore') {
    throw new Error(`Unknown STORE_BACKEND "${kind}" (use firestore or file).`);
  }

  if (!instance || instanceKind !== kind) {
    instance = kind === 'file' ? new FileStore() : new FirestoreStore();
    instanceKind = kind;
  }

  return instance;
}

export function nowIso(): string {
  return new Date().toISOString();
}
