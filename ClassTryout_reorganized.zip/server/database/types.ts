// server/database/types.ts
// The shapes the rest of the server uses to talk to the database.
//
// The database holds "collections" (like "users") of "documents". A document is a plain object.
// Times are ISO strings, for example "2026-10-23T09:30:00.000Z".

export type Doc = Record<string, any>;

// A filter: [field, operator, value], for example ['role', '==', 'admin'].
export type WhereOperator = '==' | '!=' | '<' | '<=' | '>' | '>=' | 'in' | 'array-contains' | 'array-contains-any';
export type Where = [string, WhereOperator, unknown];

// A sort: [field, direction], for example ['createdAt', 'desc'].
export type OrderBy = [string, ('asc' | 'desc')?];

export interface Query {
  where?: Where[];
  orderBy?: OrderBy[];
  limit?: number;
}

// A row from a query: the document plus its id.
export type Row = Doc & { id: string };

// What you can do to the database, inside or outside a transaction.
export interface DatabaseOperations {
  get(collection: string, id: string): Promise<Doc | null>;
  create(collection: string, id: string, data: Doc): Promise<void>; // fails if it already exists
  set(collection: string, id: string, data: Doc): Promise<void>; // replaces
  update(collection: string, id: string, patch: Doc): Promise<void>; // changes only the given fields
  delete(collection: string, id: string): Promise<void>;
  add(collection: string, data: Doc): Promise<string>; // makes up an id and returns it
  query(collection: string, query?: Query): Promise<Row[]>;
}

export interface Database extends DatabaseOperations {
  // Runs the steps together: either all of them are saved, or none of them.
  transaction<T>(steps: (operations: DatabaseOperations) => Promise<T>): Promise<T>;
}

// Put this as the value in an update to delete that field.
export const REMOVE = Symbol('remove-field');

export class StoreError extends Error {
  code?: string;

  constructor(message: string, code?: string) {
    super(message);

    this.name = 'StoreError';
    this.code = code;
  }
}
