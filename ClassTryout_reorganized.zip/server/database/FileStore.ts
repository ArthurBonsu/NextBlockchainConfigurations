// server/database/FileStore.ts
// A database kept in one local JSON file. For tests and offline work. Refused when NODE_ENV=production.

import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { root } from '../config';
import { applyUpdate, clone, getPath } from './fieldPaths';
import { assertIndex } from './indexCheck';
import { StoreError } from './types';
import type { Database, DatabaseOperations, Doc, Query, Row, Where } from './types';

type FileContents = Record<string, Record<string, Doc>>;

// Sorting: missing values come first.
function compare(a: any, b: any): number {
  if (a === b) return 0;
  if (a === undefined || a === null) return -1;
  if (b === undefined || b === null) return 1;

  return a < b ? -1 : 1;
}

function matches(doc: Doc, [field, operator, value]: Where): boolean {
  const found = getPath(doc, field);

  switch (operator) {
    case '==':
      return found === value;
    case '!=':
      return found !== undefined && found !== value;
    case '<':
      return found !== undefined && found < (value as any);
    case '<=':
      return found !== undefined && found <= (value as any);
    case '>':
      return found !== undefined && found > (value as any);
    case '>=':
      return found !== undefined && found >= (value as any);
    case 'in':
      return Array.isArray(value) && value.includes(found);
    case 'array-contains':
      return Array.isArray(found) && found.includes(value);
    default:
      throw new StoreError(`Unsupported operator ${operator}`);
  }
}

export class FileStore implements Database {
  private queue: Promise<unknown> = Promise.resolve();

  private file(): string {
    return process.env.STORE_FILE || path.join(root, '.data', 'dev-store.json');
  }

  private read(): FileContents {
    try {
      return JSON.parse(fs.readFileSync(this.file(), 'utf8'));
    } catch {
      return {};
    }
  }

  private write(contents: FileContents): void {
    fs.mkdirSync(path.dirname(this.file()), { recursive: true });
    fs.writeFileSync(this.file(), JSON.stringify(contents, null, 1));
  }

  // One operation at a time, so two requests cannot mix up a read-then-write.
  private lock<T>(work: () => Promise<T>): Promise<T> {
    const run = this.queue.then(work, work);

    this.queue = run.catch(() => {});

    return run;
  }

  private operations(contents: FileContents, markChanged: () => void): DatabaseOperations {
    const collection = (name: string) => (contents[name] = contents[name] || {});

    return {
      get: async (c, id) => clone(collection(c)[id]) || null,

      create: async (c, id, data) => {
        if (collection(c)[id]) throw new StoreError(`${c}/${id} already exists`, 'already-exists');

        collection(c)[id] = clone(data);
        markChanged();
      },

      set: async (c, id, data) => {
        collection(c)[id] = clone(data);
        markChanged();
      },

      update: async (c, id, patch) => {
        if (!collection(c)[id]) throw new StoreError(`${c}/${id} does not exist`, 'not-found');

        collection(c)[id] = applyUpdate(collection(c)[id], patch);
        markChanged();
      },

      delete: async (c, id) => {
        delete collection(c)[id];
        markChanged();
      },

      add: async (c, data) => {
        const id = crypto.randomBytes(10).toString('hex');

        collection(c)[id] = clone(data);
        markChanged();

        return id;
      },

      query: async (c, query: Query = {}) => {
        assertIndex(c, query);

        let rows: Row[] = Object.entries(collection(c)).map(([id, doc]) => ({ id, ...clone(doc) }));

        for (const filter of query.where || []) rows = rows.filter((row) => matches(row, filter));

        // Sort by the last field first, so the first field wins in the end.
        for (const [field, direction] of [...(query.orderBy || [])].reverse()) {
          const sign = direction === 'desc' ? -1 : 1;

          rows.sort((a, b) => sign * compare(getPath(a, field), getPath(b, field)));
        }

        if (query.limit) rows = rows.slice(0, query.limit);

        return rows;
      },
    };
  }

  private async single<T>(work: (operations: DatabaseOperations) => Promise<T>): Promise<T> {
    return this.lock(async () => {
      const contents = this.read();
      let changed = false;

      const result = await work(this.operations(contents, () => (changed = true)));

      if (changed) this.write(contents);

      return result;
    });
  }

  // Writes are kept only if the steps finish without an error.
  async transaction<T>(steps: (operations: DatabaseOperations) => Promise<T>): Promise<T> {
    return this.single(async (operations) => {
      const before = clone(this.read());

      try {
        return await steps(operations);
      } catch (error) {
        this.write(before); // undo whatever was written before the failure
        throw error;
      }
    });
  }

  get(c: string, id: string) {
    return this.single((o) => o.get(c, id));
  }

  create(c: string, id: string, data: Doc) {
    return this.single((o) => o.create(c, id, data));
  }

  set(c: string, id: string, data: Doc) {
    return this.single((o) => o.set(c, id, data));
  }

  update(c: string, id: string, patch: Doc) {
    return this.single((o) => o.update(c, id, patch));
  }

  delete(c: string, id: string) {
    return this.single((o) => o.delete(c, id));
  }

  add(c: string, data: Doc) {
    return this.single((o) => o.add(c, data));
  }

  query(c: string, query?: Query) {
    return this.single((o) => o.query(c, query));
  }
}
