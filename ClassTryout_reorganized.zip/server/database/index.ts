export { store, nowIso } from './store';
export { REMOVE, StoreError } from './types';
export type { Database, DatabaseOperations, Doc, Query, Row, Where, OrderBy } from './types';
export { requiredIndex, indexMatches } from './indexCheck';
export { getPath, applyUpdate } from './fieldPaths';
