// server/database/indexCheck.ts
// The local test database pretends to be Firestore closely enough to catch the mistakes that hurt.
// One of them: a query that needs a composite index fails here unless firebase/firestore.indexes.json lists that index.

import fs from 'fs';
import path from 'path';
import { root } from '../config';
import { StoreError } from './types';
import type { Query, Where } from './types';

interface IndexField {
  fieldPath: string;
  order?: string;
  arrayConfig?: string;
}

interface IndexDefinition {
  collectionGroup: string;
  fields: IndexField[];
}

export interface NeededIndex {
  collection: string;
  lead: string[]; // fields compared with ==
  tail: [string, string][]; // fields sorted or compared with a range, in order
}

let cachedIndexes: IndexDefinition[] | undefined;

function loadIndexes(): IndexDefinition[] {
  if (cachedIndexes) return cachedIndexes;

  const file = process.env.FIRESTORE_INDEXES_FILE || path.join(root, 'firebase', 'firestore.indexes.json');

  try {
    cachedIndexes = JSON.parse(fs.readFileSync(file, 'utf8')).indexes || [];
  } catch {
    cachedIndexes = [];
  }

  return cachedIndexes as IndexDefinition[];
}

const EQUALITY_OPERATORS = new Set(['==', 'in', 'array-contains', 'array-contains-any']);

// The composite index a query would need. Returns null when Firestore can answer it from its automatic one-field indexes.
export function requiredIndex(collection: string, query: Query): NeededIndex | null {
  const where: Where[] = query.where || [];
  const order = query.orderBy || [];

  const equalityFields = [...new Set(where.filter((w) => w[1] === '==').map((w) => w[0]))];
  const rangeFields = [...new Set(where.filter((w) => !EQUALITY_OPERATORS.has(w[1])).map((w) => w[0]))];
  const orderFields = order.map((o) => o[0]);
  const allFields = new Set([...where.map((w) => w[0]), ...orderFields]);

  if (allFields.size <= 1 && order.length <= 1) return null;
  if (!order.length && !rangeFields.length) return null; // only == filters: Firestore merges its one-field indexes

  const tail: [string, string][] = [];

  for (const field of rangeFields) {
    if (!tail.some((t) => t[0] === field)) {
      tail.push([field, order.find((o) => o[0] === field)?.[1] || 'asc']);
    }
  }

  for (const o of order) {
    if (!tail.some((t) => t[0] === o[0])) tail.push([o[0], o[1] || 'asc']);
  }

  const lead = equalityFields.filter((field) => !tail.some((t) => t[0] === field));

  return { collection, lead, tail };
}

export function indexMatches(index: IndexDefinition, needed: NeededIndex): boolean {
  if (index.collectionGroup !== needed.collection) return false;

  const fields = index.fields.map((f) => [f.fieldPath, f.order === 'DESCENDING' ? 'desc' : f.order === 'ASCENDING' ? 'asc' : f.arrayConfig]);

  if (fields.length !== needed.lead.length + needed.tail.length) return false;

  const leadFields = fields.slice(0, needed.lead.length).map((f) => f[0]).sort();

  if (JSON.stringify(leadFields) !== JSON.stringify([...needed.lead].sort())) return false;

  const tailFields = fields.slice(needed.lead.length);

  return needed.tail.every((t, i) => tailFields[i][0] === t[0] && tailFields[i][1] === (t[1] || 'asc'));
}

export function assertIndex(collection: string, query: Query): void {
  if (String(process.env.STORE_ENFORCE_INDEXES || 'true').toLowerCase() === 'false') return;

  const needed = requiredIndex(collection, query);

  if (!needed) return;
  if (loadIndexes().some((index) => indexMatches(index, needed))) return;

  const description = [
    ...needed.lead.map((field) => `${field} ASC`),
    ...needed.tail.map((t) => `${t[0]} ${String(t[1]).toUpperCase()}`),
  ].join(', ');

  throw new StoreError(
    `This query needs a composite index on ${collection} (${description}). Add it to firebase/firestore.indexes.json.`,
    'failed-precondition'
  );
}
