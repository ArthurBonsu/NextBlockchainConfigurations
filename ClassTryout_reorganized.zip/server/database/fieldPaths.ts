// server/database/fieldPaths.ts
// Reading and changing nested fields with dotted names, the way Firestore does: "identity.level".

import { REMOVE } from './types';
import type { Doc } from './types';

export function clone<T>(value: T): T {
  if (value === undefined) return value;

  return JSON.parse(JSON.stringify(value));
}

export function getPath(object: any, path: string): any {
  let current = object;

  for (const key of path.split('.')) {
    if (current === null || typeof current !== 'object') return undefined;

    current = current[key];
  }

  return current;
}

function setPath(object: any, path: string, value: unknown): void {
  const keys = path.split('.');
  let current = object;

  for (let i = 0; i < keys.length - 1; i++) {
    const key = keys[i];

    if (current[key] === null || typeof current[key] !== 'object') current[key] = {};

    current = current[key];
  }

  const lastKey = keys[keys.length - 1];

  if (value === REMOVE) {
    delete current[lastKey];
  } else {
    current[lastKey] = value;
  }
}

// Returns a copy of the document with every field in the patch applied.
export function applyUpdate(doc: Doc | undefined, patch: Doc): Doc {
  const copy: Doc = clone(doc) || {};

  for (const [path, value] of Object.entries(patch)) {
    const newValue = value === undefined || value === REMOVE ? REMOVE : clone(value);

    setPath(copy, path, newValue);
  }

  return copy;
}
