// server/database/FirestoreStore.ts
// The real database: Cloud Firestore, through the Firebase Admin SDK.
// Browsers cannot write to it (the security rules deny them). Only this server code writes.
//
// Times are ISO strings everywhere, except "expireAt": it is saved as a real date so a Firestore TTL rule can delete the
// document when it is old, and it is turned back into an ISO string when read.

import type { Firestore, Query as FirestoreQuery } from 'firebase-admin/firestore';
import { getAdmin } from '../firebase';
import { REMOVE, StoreError } from './types';
import type { Database, DatabaseOperations, Doc, Query, Row } from './types';

type FieldValueClass = ReturnType<typeof getAdmin>['FieldValue'];

function toFirestore(data: Doc): Doc {
  const out: Doc = {};

  for (const [key, value] of Object.entries(data)) {
    out[key] = key === 'expireAt' && typeof value === 'string' ? new Date(value) : value;
  }

  return out;
}

function patchToFirestore(patch: Doc, FieldValue: FieldValueClass): Doc {
  const out: Doc = {};

  for (const [key, value] of Object.entries(patch)) {
    if (value === REMOVE || value === undefined) {
      out[key] = FieldValue.delete();
    } else if (key === 'expireAt' && typeof value === 'string') {
      out[key] = new Date(value);
    } else {
      out[key] = value;
    }
  }

  return out;
}

function fromFirestore(data: Doc | undefined): Doc | null {
  if (!data) return null;

  const out = { ...data };

  if (out.expireAt && typeof out.expireAt.toDate === 'function') out.expireAt = out.expireAt.toDate().toISOString();

  return out;
}

// Adds the filters, sorting and limit of a query to a Firestore collection reference.
function buildQuery(collection: FirestoreQuery, query: Query): FirestoreQuery {
  let ref = collection;

  for (const [field, operator, value] of query.where || []) ref = ref.where(field, operator, value);
  for (const [field, direction] of query.orderBy || []) ref = ref.orderBy(field, direction || 'asc');

  if (query.limit) ref = ref.limit(query.limit);

  return ref;
}

export class FirestoreStore implements Database {
  private admin() {
    return getAdmin();
  }

  private db(): Firestore {
    return this.admin().firestore();
  }

  async get(c: string, id: string) {
    const snapshot = await this.db().collection(c).doc(id).get();

    return snapshot.exists ? fromFirestore(snapshot.data()) : null;
  }

  async create(c: string, id: string, data: Doc) {
    try {
      await this.db().collection(c).doc(id).create(toFirestore(data));
    } catch (error: any) {
      if (error && (error.code === 6 || /already exists/i.test(error.message))) {
        throw new StoreError(`${c}/${id} already exists`, 'already-exists');
      }

      throw error;
    }
  }

  async set(c: string, id: string, data: Doc) {
    await this.db().collection(c).doc(id).set(toFirestore(data));
  }

  async update(c: string, id: string, patch: Doc) {
    await this.db().collection(c).doc(id).update(patchToFirestore(patch, this.admin().FieldValue));
  }

  async delete(c: string, id: string) {
    await this.db().collection(c).doc(id).delete();
  }

  async add(c: string, data: Doc) {
    const reference = await this.db().collection(c).add(toFirestore(data));

    return reference.id;
  }

  async query(c: string, query: Query = {}) {
    const snapshot = await buildQuery(this.db().collection(c), query).get();

    return snapshot.docs.map((doc) => ({ id: doc.id, ...fromFirestore(doc.data()) })) as Row[];
  }

  // Firestore needs every read in a transaction to come before the first write. The code in this project follows that rule.
  async transaction<T>(steps: (operations: DatabaseOperations) => Promise<T>): Promise<T> {
    const db = this.db();
    const FieldValue = this.admin().FieldValue;

    return db.runTransaction(async (tx) => {
      const ref = (c: string, id: string) => db.collection(c).doc(id);

      return steps({
        get: async (c, id) => {
          const snapshot = await tx.get(ref(c, id));

          return snapshot.exists ? fromFirestore(snapshot.data()) : null;
        },

        create: async (c, id, data) => void tx.create(ref(c, id), toFirestore(data)),
        set: async (c, id, data) => void tx.set(ref(c, id), toFirestore(data)),
        update: async (c, id, patch) => void tx.update(ref(c, id), patchToFirestore(patch, FieldValue)),
        delete: async (c, id) => void tx.delete(ref(c, id)),

        add: async (c, data) => {
          const newRef = db.collection(c).doc();

          tx.set(newRef, toFirestore(data));

          return newRef.id;
        },

        query: async (c, query: Query = {}) => {
          const snapshot = await tx.get(buildQuery(db.collection(c), query));

          return snapshot.docs.map((doc) => ({ id: doc.id, ...fromFirestore(doc.data()) })) as Row[];
        },
      });
    });
  }
}
