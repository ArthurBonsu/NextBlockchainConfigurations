// Browser test: what a person SEES when the site is set up wrongly. Before this, a rejected sign-in looked like nothing happened.
// Starts the site three times with three different settings, against the Firebase AUTH emulator. It also checks that the
// Google / GitHub / X buttons are there and that a provider that fails shows a message instead of doing nothing.
//
//   yarn firebase:emulators           (terminal 1)
//   yarn test:signin-problems:e2e     (terminal 2)

import type { Browser, Page } from 'playwright';
import { check, sleep, waitFor, finish, emulatorIsRunning, EMULATOR_URL, PROJECT_ID, startDevServer, launchBrowser } from './helpers';
import type { DevServer } from './helpers';

const PORT = process.env.E2E_PORT || '3210';
const BASE = `http://127.0.0.1:${PORT}`;
const GOOD = { FIREBASE_PROJECT_ID: PROJECT_ID, FIREBASE_AUTH_EMULATOR_HOST: EMULATOR_URL.replace('http://', '') };
const NO_ADMIN_SETTINGS = ['FIREBASE_PROJECT_ID', 'FIREBASE_CLIENT_EMAIL', 'FIREBASE_PRIVATE_KEY', 'FIREBASE_AUTH_EMULATOR_HOST', 'GOOGLE_APPLICATION_CREDENTIALS'];

function startSite(extra: Record<string, string>, drop: string[] = []): DevServer {
  return startDevServer('problems', PORT, { extra, drop });
}

async function stopSite(site: DevServer): Promise<void> {
  site.stop();
  await sleep(1500);
}

async function signUpInBrowser(page: Page, email: string): Promise<void> {
  await page.goto(BASE + '/signin');
  await page.getByTestId('tab-up').click();
  await page.getByLabel('Email').fill(email);
  await page.getByLabel('Password', { exact: true }).fill('correct horse battery');
  await page.getByLabel('Repeat password').fill('correct horse battery');
  await page.getByTestId('submit').click();
}

// The three provider buttons exist and are clickable.
async function checkProviderButtons(page: Page): Promise<void> {
  await page.goto(BASE + '/signin');

  for (const kind of ['google', 'github', 'twitter']) {
    await page.getByTestId(kind).waitFor({ timeout: 30000 });
    check(`sign-in page has a ${kind} button`, await page.getByTestId(kind).isEnabled());
  }
}

// The Auth emulator opens a fake identity-provider window instead of the real one. Click through it as a person would.
async function signInWithEmulatedProvider(page: Page, kind: string): Promise<void> {
  await page.goto(BASE + '/signin');
  await page.getByTestId(kind).waitFor({ timeout: 30000 });

  const popupPromise = page.waitForEvent('popup', { timeout: 30000 });
  await page.getByTestId(kind).click();

  const popup = await popupPromise;
  await popup.getByText('Add new account').click({ timeout: 30000 });
  await popup.getByRole('button', { name: /auto-generate user information/i }).click({ timeout: 30000 });
  await popup.getByRole('button', { name: /sign in with/i }).click({ timeout: 30000 });
}

async function main(): Promise<void> {
  if (!(await emulatorIsRunning())) {
    console.error('Auth emulator not running at ' + EMULATOR_URL);
    process.exit(2);
  }

  await fetch(`${EMULATOR_URL}/emulator/v1/projects/${PROJECT_ID}/accounts`, { method: 'DELETE' });

  const browser: Browser = await launchBrowser();
  const suffix = Date.now().toString(36);
  const pageErrors: string[] = [];
  let site: DevServer | undefined;
  try {
    // ---------- 1. the server uses a DIFFERENT Firebase project than the page ----------------------------------------------
    site = startSite({ ...GOOD, FIREBASE_PROJECT_ID: "some-other-project" });
    await waitFor(async () => (await fetch(BASE + "/api/me")).status >= 400);
    const page = await browser.newPage();
    page.on("pageerror", (error) => pageErrors.push(error.message));
    await signUpInBrowser(page, `mismatch.${suffix}@example.test`);
    await page.getByTestId("account-problem").waitFor({ timeout: 60000 });
    const text1 = await page.getByTestId("account-problem-text").innerText();
    check("wrong project: the sign-in page SHOWS the problem (not a silent bounce)", /different Firebase projects/.test(text1), text1);
    check("wrong project: names both project ids", /some-other-project/.test(text1) && /demo-classtryout/.test(text1), text1);
    check("wrong project: stays on the sign-in page and offers the set-up check", page.url().includes("/signin") && (await page.getByTestId("account-setupcheck").count()) === 1);
    await page.getByTestId("account-setupcheck").click();
    await page.waitForURL(/\/setup-check/);
    await page.locator('[data-check="same-project"]').waitFor({ timeout: 60000 });
    check("wrong project: the set-up check marks the project mismatch", (await page.locator('[data-check="same-project"]').getAttribute("data-status")) === "fail");
    check("wrong project: the set-up check says how many things to fix", /to fix/.test(await page.getByTestId("check-summary").innerText()));
    // sign out button from the problem box works
    await page.goto(BASE + "/signin");
    await page.getByTestId("account-problem").waitFor({ timeout: 60000 });
    await page.getByTestId("account-signout").click();
    await page.getByTestId("account-problem").waitFor({ state: "detached", timeout: 30000 });
    check("wrong project: Sign out clears the problem", true);
    await checkProviderButtons(page);
    await page.close();
    await stopSite(site);

    // ---------- 2. the server has no Firebase Admin settings at all ---------------------------------------------------------
    site = startSite({}, NO_ADMIN_SETTINGS);
    await waitFor(async () => (await fetch(BASE + "/api/me")).status >= 400);
    const page2 = await browser.newPage();
    page2.on("pageerror", (error) => pageErrors.push(error.message));
    await signUpInBrowser(page2, `noadmin.${suffix}@example.test`);
    await page2.getByTestId("account-problem").waitFor({ timeout: 60000 });
    const text2 = await page2.getByTestId("account-problem-text").innerText();
    check("no admin settings: says Firebase Admin is not configured and names the variables", /not configured/.test(text2) && /FIREBASE_PROJECT_ID/.test(text2), text2);
    await page2.goto(BASE + "/setup-check");
    await page2.locator('[data-check="admin-config"]').waitFor({ timeout: 60000 });
    check("no admin settings: the set-up check flags the service account", (await page2.locator('[data-check="admin-config"]').getAttribute("data-status")) === "fail");
    check("no admin settings: the set-up check skips Firestore instead of crashing", (await page2.locator('[data-check="firestore-reach"]').getAttribute("data-status")) === "skip");
    await page2.close();
    await stopSite(site);

    // ---------- 3. everything right: sign-up works, check is green, an expired token is refreshed ---------------------------
    site = startSite(GOOD);
    await waitFor(async () => (await fetch(BASE + "/api/me")).status === 401);
    const page3 = await browser.newPage();
    page3.on("pageerror", (error) => pageErrors.push(error.message));
    await page3.goto(BASE + "/setup-check");
    await page3.getByTestId("check-summary").waitFor({ timeout: 60000 });
    await page3.waitForFunction(() => document.querySelectorAll("[data-check]").length >= 5, null, { timeout: 60000 });
    const summary = await page3.getByTestId("check-summary").innerText();
    check("good set-up: the check is green", /looks right/.test(summary), summary + " | " + (await page3.getByTestId("check-list").innerText()));
    check("good set-up: the browser check reaches Authentication", (await page3.locator('[data-check="browser-auth"]').getAttribute("data-status")) === "ok");
    await signUpInBrowser(page3, `fine.${suffix}@example.test`);
    await page3.waitForURL(/\/onboarding/, { timeout: 60000 });
    check("good set-up: sign-up lands on the set-up page", true);
    check("good set-up: no problem box", (await page3.getByTestId("account-problem").count()) === 0);
    await page3.close();

    // a provider button never does nothing: it opens the provider's window, or says why it could not
    const buttonContext = await browser.newContext();
    const buttonPage = await buttonContext.newPage();
    buttonPage.on('pageerror', (error) => pageErrors.push(error.message));
    await buttonPage.goto(BASE + '/signin');
    await buttonPage.getByTestId('github').click();
    await Promise.race([
      buttonPage.waitForEvent('popup', { timeout: 30000 }),
      buttonPage.getByTestId('auth-error').waitFor({ timeout: 30000 }),
    ]);
    check('github button: opens the provider window or shows a message (never silent)', true);
    await buttonContext.close();

    // Optional, needs internet: Firebase's popup code loads a script from Google, so this cannot run in an offline sandbox.
    // Each button then signs a new person in through the emulator's fake provider window.
    if (process.env.E2E_PROVIDER_POPUPS === 'on') {
      for (const kind of ['google', 'github', 'twitter']) {
        const providerContext = await browser.newContext();
        const providerPage = await providerContext.newPage();
        providerPage.on('pageerror', (error) => pageErrors.push(error.message));
        await signInWithEmulatedProvider(providerPage, kind);
        await providerPage.waitForURL(/\/onboarding/, { timeout: 60000 });
        check(`${kind} button: signs a new person in and lands on the set-up page`, true);
        await providerContext.close();
      }
    }

    // wrong password still gives the plain message (fresh browser context = nobody signed in)
    const ctx4 = await browser.newContext();
    const page4 = await ctx4.newPage();
    page4.on("pageerror", (error) => pageErrors.push(error.message));
    await page4.goto(BASE + "/signin");
    await page4.getByLabel("Email").fill(`fine.${suffix}@example.test`);
    await page4.getByLabel("Password", { exact: true }).fill("wrong wrong wrong");
    await page4.getByTestId("submit").click();
    await page4.getByTestId("auth-error").waitFor({ timeout: 30000 });
    check("good set-up: wrong password shows the plain message", /do not match/.test(await page4.getByTestId("auth-error").innerText()));
    await ctx4.close();

    // the server says the token expired on the first try: the page fetches a fresh token and asks again by itself
    const ctx5 = await browser.newContext();
    const page5 = await ctx5.newPage();
    page5.on("pageerror", (error) => pageErrors.push(error.message));
    let meCalls = 0;
    await page5.route("**/api/me", async (route) => {
      meCalls++;
      if (meCalls === 1) return route.fulfill({ status: 401, contentType: "application/json", body: JSON.stringify({ error: "Your sign-in has expired. Sign in again.", code: "token_expired" }) });
      return route.continue();
    });
    await page5.goto(BASE + "/signin");
    await page5.getByLabel("Email").fill(`fine.${suffix}@example.test`);
    await page5.getByLabel("Password", { exact: true }).fill("correct horse battery");
    await page5.getByTestId("submit").click();
    await page5.waitForURL(/\/onboarding/, { timeout: 60000 });
    check("expired token: the page refreshes it and carries on (asked twice, signed in)", meCalls >= 2, "calls=" + meCalls);
    await ctx5.close();
    check("no page errors in the browser", pageErrors.length === 0, pageErrors.join(" | "));
  } catch (error) {
    check("test ran to the end", false, (error as Error).message + "\n--- site log ---\n" + (site ? site.log().slice(-1500) : ""));
  } finally {
    if (site) await stopSite(site);
    await browser.close();
  }

  finish();
}

main();

