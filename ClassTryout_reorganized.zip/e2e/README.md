# Browser tests (optional)

These drive the app in Chromium. They are TypeScript, run with `tsx`, and they are not part of `yarn check`: run them
before a demo or a release. Set `CHROMIUM_PATH` if Playwright cannot find a browser (`yarn add -D playwright` once).

The shared set-up lives in `e2e/helpers/` so each test only contains the story it tells:

| Helper | What it does |
|---|---|
| `report.ts` | `check(name, ok)` prints PASS / FAIL; `finish()` prints the totals and sets the exit code |
| `authEmulator.ts` | creates, signs in and verifies accounts in the Firebase Auth emulator |
| `devServer.ts` | starts the app's own Next dev server wired to the emulator, a file store and the mock SMS outbox; `makeSuperAdmin` runs `scripts/setRole.ts` |
| `api.ts`, `onboarding.ts` | call our API with a token; finish onboarding without the form |
| `browser.ts` | opens Chromium, collects page errors, adds the `__name` shim that `tsx` needs for code sent into the page |
| `localChain.ts` | JSON-RPC to a local Ganache chain, with MetaMask-style gas estimation |

## Local chain tests (stand-in wallet, no MetaMask)

```
yarn chain                  # terminal 1: local chain on 7545 (chain id 1337)
yarn deploy:local           # terminal 2: deploy and record addresses
NEXT_PUBLIC_SHOW_LOCAL=true yarn build && npx next start -p 3100     # or: NEXT_PUBLIC_SHOW_LOCAL=true npx next dev -p 3100
yarn test:flow:e2e          # register, license, report, revoke, reinstate, history, admin, pause (33 steps)
```

`flow.e2e.ts` needs a fresh chain each run (vehicle names are reused). `multichain.e2e.ts` (`yarn test:multichain:e2e`) additionally
needs two more local chains (port 7546 with chain id 8453, port 7547 with chain id 42161) with the contracts deployed to 7546; it
exercises the network picker. **Because 8453 is Base, that deployment is recorded in `shared/deployments.json`; do not commit that
entry** (restore the file with `git checkout shared/deployments.json`).

## Email notifications

```
yarn test:notify             # needs the local chain + deployed contracts; starts its own mock mail server (port 2525)
```

Add the wallet-link API checks by starting a dev server with the same links file and passing its address:

```
NOTIFY_BACKEND=dev WALLET_LINK_SECRET=0123456789abcdef0123 DEV_LINKS_FILE=/tmp/links.json npx next dev -p 3100
BASE_URL=http://127.0.0.1:3100 DEV_LINKS_FILE=/tmp/links.json yarn test:notify
```

`yarn test:notify:ui` drives the "Email notifications" panel (start the dev server with `NEXT_PUBLIC_NOTIFY_BACKEND=dev` as
well). Use a fresh chain for each run of `yarn test:notify`; it expects exactly the emails it causes.

## Accounts (sign-in, onboarding, roles)

```
yarn firebase:emulators      # terminal 1 (or: npx firebase-tools emulators:start --only auth --project demo-classtryout)
yarn test:accounts:e2e       # terminal 2: starts its own Next dev server on 3200 (71 checks)
yarn test:navigation:e2e     # the page flow with screenshots, on port 3300 (32 checks)
```

They use the Auth emulator for real tokens and a local file store instead of Firestore, and a mock SMS provider whose outbox the
test reads (the API never returns the code). They need no chain.
