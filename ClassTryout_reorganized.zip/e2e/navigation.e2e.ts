// Browser test of the page flow: home -> sign in -> guided dashboard -> locked/unlocked pages -> admin screens, with screenshots.
// Needs the Auth emulator (see e2e/README.md). Starts its own Next dev server on port 3300.
//   yarn test:navigation:e2e

import path from 'path';
import type { Browser, Page } from 'playwright';
import {
  check, waitFor, finish, signUp, signIn, verifyEmail, emulatorIsRunning, EMULATOR_URL,
  startDevServer, makeSuperAdmin, makeCall, completeOnboarding, launchBrowser, collectErrors,
} from './helpers';

async function main(): Promise<void> {
  if (!(await emulatorIsRunning())) {
    console.error('Auth emulator not running at ' + EMULATOR_URL);
    process.exit(2);
  }

  const server = startDevServer('nav', '3300');
  const { base: BASE, dir } = server;
  const call = makeCall(BASE);

  const shot = (page: Page, name: string) => page.screenshot({ path: path.join(dir, name + '.png'), fullPage: true });
  const onboard = (token: string, phone: string) =>
    completeOnboarding(call, token, phone, { givenName: 'Ama', familyName: 'Mensah', dob: '1990-02-03', gender: 'female' });

  async function signInUi(page: Page, email: string, password: string): Promise<void> {
    await page.goto(BASE + '/signin');
    await page.fill('#email', email);
    await page.fill('#password', password);
    await page.getByTestId('submit').click();
  }

  const sfx = Date.now().toString(36);
  const PW = "correct horse battery";
  const citizen = `ama.${sfx}@example.test`, admin = `boss.${sfx}@example.test`;
  let browser: Browser | undefined;
  try {
    await waitFor(async () => (await fetch(BASE + "/api/me")).status === 401);
    // accounts made through the API so the browser steps below test the pages, not the sign-up form
    const c = await signUp(citizen, PW);
    const a = await signUp(admin, PW);
    await call(c.idToken, "GET", "/api/me"); await call(a.idToken, "GET", "/api/me");
    await verifyEmail(admin, a.idToken);
    await onboard(a.idToken, "0241111111");
    const promoted = makeSuperAdmin(server, admin);
    check("founding admin set up", promoted.ok, promoted.output);

    browser = await launchBrowser();
    const page = await browser.newPage({ viewport: { width: 1200, height: 900 } });
    const errs: string[] = [];
    collectErrors(page, errs);

    // ---- signed out
    await page.goto(BASE + "/");
    await page.getByRole("link", { name: /sign in/i }).first().waitFor({ timeout: 60000 });
    check("home (signed out) offers sign-in", true);
    const topLinks = await page.locator("header a").allInnerTexts();
    check("signed out: no Dashboard, Users or Contracts links", !topLinks.some((t) => /^(Dashboard|Users|ID review|Contracts)$/.test(t.trim())), topLinks.join("|"));
    await shot(page, "01-home-signed-out");

    // ---- citizen: sign in -> dashboard, guided
    await signInUi(page, citizen, PW);
    await page.waitForURL(/\/onboarding/, { timeout: 30000 });
    check("a new account is taken to set-up first", true);
    await shot(page, "02-onboarding");
    await onboard(c.idToken, "0242222222");
    await page.goto(BASE + "/dashboard");
    await page.getByTestId("next-step").waitFor({ timeout: 30000 });
    let next = await page.getByTestId("next-title").innerText();
    check("dashboard's next step is the email check", /email/i.test(next), next);
    await shot(page, "03-dashboard-step-email");
    await verifyEmail(citizen, c.idToken);
    await page.evaluate(() => window.dispatchEvent(new Event("focus"))); // coming back to the tab picks the change up by itself
    await page.waitForFunction(() => /ID/.test(document.querySelector('[data-testid="next-title"]')?.textContent || "") && !/email/i.test(document.querySelector('[data-testid="next-title"]')?.textContent || ""), null, { timeout: 15000 }).catch(() => {});
    next = await page.getByTestId("next-title").innerText();
    check("after the email is verified the next step is the ID", /\bID\b/i.test(next), next);
    const links = (await page.locator("header a").allInnerTexts()).map((t) => t.trim());
    check("citizen sees Vehicles, History, Notifications; not Licences, Revocations or Admin", ["Vehicles", "History", "Notifications"].every((x) => links.includes(x)) && !links.some((t) => /^(Licences|Revocations|Users|ID review|Contracts)$/.test(t)), links.join("|"));
    await page.goto(BASE + "/vehicles");
    await page.getByText(/is locked/).first().waitFor({ timeout: 20000 });
    check("vehicles is locked until the ID is confirmed, and says why", /confirmed ID/.test(await page.locator("main").innerText()));
    await shot(page, "04-vehicles-locked");

    const num = "GHA-" + String(Math.floor(Math.random() * 1e9)).padStart(9, "0") + "-" + Math.floor(Math.random() * 10);
    const idr = await call(c.idToken, "POST", "/api/identity", { type: "ghana_card", number: num });
    check("ID submitted", idr.status === 200 || idr.status === 201, JSON.stringify(idr));
    await page.goto(BASE + "/dashboard");
    await page.getByTestId("next-step").waitFor();
    check("dashboard now says the ID is waiting for a reviewer", /wait|review/i.test(await page.getByTestId("step-id").innerText()));
    await shot(page, "05-dashboard-waiting");

    // ---- admin
    const ctx2 = await browser.newContext({ viewport: { width: 1200, height: 900 } });
    const ap = await ctx2.newPage();
    collectErrors(ap, errs);
    await signInUi(ap, admin, PW);
    await ap.waitForURL(/\/dashboard/, { timeout: 30000 });
    check("admin lands on the dashboard", true);
    await ap.getByText("Admin", { exact: true }).first().click();
    const adminLinks = (await ap.locator("header a").allInnerTexts()).map((t) => t.trim());
    check("admin menu lists Users, ID review, Contracts", ["Users", "ID review", "Contracts"].every((x) => adminLinks.includes(x)), adminLinks.join("|"));
    await shot(ap, "06-admin-dashboard");

    await ap.goto(BASE + "/admin/ids");
    await ap.getByTestId("id-queue").waitFor({ timeout: 30000 });
    await ap.locator('[data-testid^="doc-"]').first().waitFor({ timeout: 15000 });
    check("ID review lists the waiting ID with only its last 4", /ending/.test(await ap.getByTestId("id-queue").innerText()) && !(await ap.getByTestId("id-queue").innerText()).includes(num.slice(4, 13)));
    await ap.getByRole("button", { name: "Show number" }).first().click();
    await ap.getByTestId("reveal-box").waitFor();
    check("reviewer can show the number", (await ap.getByTestId("reveal-box").innerText()).replace(/\D/g, "").includes(num.replace(/\D/g, "").slice(0, 9)));
    await shot(ap, "07-admin-ids-reveal");
    await ap.getByRole("button", { name: "Confirm", exact: true }).first().click();
    await ap.getByTestId("inline-confirm").waitFor();
    await ap.getByRole("button", { name: "Yes, confirm" }).click();
    await ap.getByText(/ID confirmed/).waitFor({ timeout: 15000 });
    check("reviewer confirms the ID from the page", true);

    await ap.goto(BASE + "/admin/users");
    await ap.getByTestId("users-table").waitFor({ timeout: 30000 });
    await ap.getByLabel("Role", { exact: true }).selectOption("citizen");
    await ap.locator('[data-testid^="user-"]').first().waitFor({ timeout: 15000 });
    check("users page lists citizens", (await ap.locator('[data-testid^="user-"]').count()) >= 1);
    await shot(ap, "08-admin-users");
    await ap.getByRole("button", { name: "Suspend" }).first().click();
    await ap.getByTestId("inline-confirm").waitFor();
    await ap.getByRole("button", { name: "Yes, suspend" }).click();
    await ap.getByText("Account suspended.").waitFor({ timeout: 15000 });
    check("admin suspends the citizen from the page", true);
    const sus = await call((await signIn(citizen, PW)).idToken, "GET", "/api/me");
    check("the suspended citizen is refused by the server", sus.status === 403, JSON.stringify(sus));
    await ap.getByLabel("Status", { exact: true }).selectOption("suspended");
    await ap.getByRole("button", { name: "Restore" }).first().waitFor({ timeout: 15000 });
    await ap.getByRole("button", { name: "Restore" }).first().click();
    await ap.getByRole("button", { name: "Yes, restore" }).click();
    await ap.getByText("Account restored.").waitFor({ timeout: 15000 });
    check("admin restores the citizen", true);
    await ap.getByLabel("Filter by").selectOption("email");
    await ap.getByLabel("Email", { exact: true }).fill(citizen);
    await ap.getByRole("button", { name: "Search" }).click();
    await ap.locator('[data-testid^="user-"]').first().waitFor({ timeout: 15000 });
    check("search by exact email finds the person", (await ap.locator('[data-testid^="user-"]').count()) === 1);
    await ap.getByRole("button", { name: "Change role" }).first().click();
    await ap.getByLabel("New role").selectOption("officer");
    await ap.getByRole("button", { name: "Save role" }).click();
    await ap.getByText("Role changed.").waitFor({ timeout: 15000 });
    check("super admin changes a role from the page", true);

    await ap.goto(BASE + "/admin/contracts");
    await ap.getByRole("heading", { name: /Contract|Admin/i }).first().waitFor({ timeout: 20000 });
    check("contracts page opens", true);
    await shot(ap, "09-admin-contracts");

    // ---- the citizen (now an officer with a confirmed ID) sees more of the bar and the unlocked pages
    await page.goto(BASE + "/signin");
    await page.goto(BASE + "/dashboard");
    await page.waitForTimeout(500);
    const c2 = await signIn(citizen, PW);
    check("citizen is now an officer", (await call(c2.idToken, "GET", "/api/me")).body.me.role === "officer");
    await page.goto(BASE + "/signin"); // old session was revoked by the role change: sign in again
    await page.waitForTimeout(800);
    if (!/\/dashboard/.test(page.url())) { await page.fill("#email", citizen).catch(() => {}); await page.fill("#password", PW).catch(() => {}); await page.getByTestId("submit").click().catch(() => {}); }
    await page.waitForURL(/\/dashboard/, { timeout: 30000 });
    const links2 = (await page.locator("header a").allInnerTexts()).map((t) => t.trim());
    check("officer now sees Licences and Revocations", ["Licences", "Revocations"].every((x) => links2.includes(x)), links2.join("|"));
    await shot(page, "10-dashboard-officer");
    for (const [p, h] of [["/vehicles", "Vehicle"], ["/licences", "icen"], ["/revocations", "evo"], ["/history", "istory"], ["/notifications", "otif"]]) {
      await page.goto(BASE + p);
      await page.locator("main h1, main h2").first().waitFor({ timeout: 30000 });
      check(`${p} opens`, new RegExp(h).test(await page.locator("main").innerText()));
    }
    await shot(page, "11-revocations");
    await page.goto(BASE + "/admin/users");
    await page.getByTestId("page-locked").waitFor({ timeout: 20000 });
    check("an officer opening an admin page is told it is locked", true);

    // ---- phone
    const m = await browser.newPage({ viewport: { width: 375, height: 800 } });
    await m.goto(BASE + "/");
    await m.waitForTimeout(1500);
    check("home has no horizontal scroll at 375px", !(await m.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1)));
    await m.getByRole("button", { name: "Menu" }).click().catch(() => {});
    await shot(m, "12-mobile-home");
    check("no page errors", errs.length === 0, errs.slice(0, 5).join(" || "));
  } catch (error) {
    check("test ran to the end", false, (error as Error).message.split("\n").slice(0, 4).join(" / "));
    console.log(server.log().slice(-1500));
  } finally {
    if (browser) await browser.close();
    server.stop();
  }

  finish(dir);
}

main();

