// Opens Chromium and collects the page errors a test should fail on.
import { chromium } from 'playwright';
import type { Browser, Page } from 'playwright';

export function launchBrowser(): Promise<Browser> {
  return chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
}

// Errors the test should NOT ignore. Network noise from favicons and blocked resources is left out.
export function collectErrors(page: Page, into: string[]): void {
  page.on('pageerror', (error) => into.push(error.message));

  page.on('console', (message) => {
    if (message.type() === 'error' && !/Failed to load resource|favicon|net::ERR/.test(message.text())) {
      into.push(message.text());
    }
  });
}

// tsx compiles with "keepNames", which wraps functions in a helper called __name. A function that is sent into the
// browser (page.evaluate, addInitScript) is serialised without that helper, so this defines a harmless stand-in on every page.
export async function newPage(browser: Browser, viewport: { width: number; height: number }): Promise<Page> {
  const page = await browser.newPage({ viewport });

  await page.addInitScript('window.__name = window.__name || function (target) { return target; };');

  return page;
}
