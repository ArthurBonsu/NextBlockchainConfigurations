// Starts the app's own Next dev server for a browser test, wired to the Auth emulator, a throwaway file store
// and the mock SMS outbox. Everything is stopped again when the test ends.
import { spawn, spawnSync } from 'child_process';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { EMULATOR_URL, PROJECT_ID } from './authEmulator';

export const ROOT = path.resolve(__dirname, '..', '..');

export interface DevServer {
  base: string;
  dir: string; // throwaway folder: store, SMS outbox, screenshots
  env: Record<string, string>;
  log: () => string;
  stop: () => void;
}

export interface DevServerOptions {
  extra?: Record<string, string>; // settings to add or change
  drop?: string[]; // settings to remove (to test a site that is set up wrongly)
  dir?: string; // reuse a folder (so several servers in one test share a store)
}

export function startDevServer(name: string, defaultPort: string, options: DevServerOptions = {}): DevServer {
  const port = process.env.E2E_PORT || defaultPort;
  const dir = options.dir || fs.mkdtempSync(path.join(os.tmpdir(), `ct-${name}-e2e-`));

  const env: Record<string, string> = {
    STORE_BACKEND: 'file',
    STORE_FILE: path.join(dir, 'store.json'),
    SMS_PROVIDER: 'mock',
    SMS_OUTBOX_FILE: path.join(dir, 'sms.jsonl'),
    NOTIFY_BACKEND: 'firebase',
    FIREBASE_PROJECT_ID: PROJECT_ID,
    FIREBASE_AUTH_EMULATOR_HOST: EMULATOR_URL.replace('http://', ''),
    WALLET_LINK_SECRET: 'e2e-secret-e2e-secret',
    NEXT_PUBLIC_FIREBASE_API_KEY: 'fake-key',
    NEXT_PUBLIC_FIREBASE_PROJECT_ID: PROJECT_ID,
    NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN: 'localhost',
    NEXT_PUBLIC_FIREBASE_APP_ID: '1:1:web:1',
    NEXT_PUBLIC_FIREBASE_AUTH_EMULATOR: EMULATOR_URL,
    NEXT_PUBLIC_REQUIRE_ACCOUNT: 'true',
    ID_HASH_PEPPER: 'e2e-pepper-e2e-pepper-e2e',
    OTP_SECRET: 'e2e-otp-secret-e2e-otp',
    TRUST_PROXY: 'true',
    ...options.extra,
  };

  // This process reads the mock SMS outbox too (to learn the codes), so it needs to know where it is.
  process.env.SMS_OUTBOX_FILE = env.SMS_OUTBOX_FILE;

  const childEnv: NodeJS.ProcessEnv = { ...process.env, ...env, NODE_ENV: 'development' };

  for (const key of options.drop || []) delete childEnv[key];

  const child = spawn('npx', ['next', 'dev', '-p', port, '-H', '127.0.0.1'], {
    cwd: ROOT,
    env: childEnv,
    stdio: ['ignore', 'pipe', 'pipe'],
    detached: true,
  });

  let log = '';
  child.stdout?.on('data', (chunk) => (log += chunk));
  child.stderr?.on('data', (chunk) => (log += chunk));

  const stop = () => {
    try {
      if (child.pid) process.kill(-child.pid);
    } catch {
      // already stopped
    }
  };

  process.on('exit', stop);

  return { base: `http://127.0.0.1:${port}`, dir, env, log: () => log, stop };
}

// Makes someone a super admin the way the real project does it: with the command-line script.
export function makeSuperAdmin(server: DevServer, email: string): { ok: boolean; output: string } {
  const result = spawnSync('npx', ['tsx', 'scripts/setRole.ts', '--email', email, '--role', 'super_admin', '--confirm-identity'], {
    cwd: ROOT,
    env: { ...process.env, ...server.env, NODE_ENV: 'development' },
    encoding: 'utf8',
  });

  return { ok: result.status === 0 && /super_admin/.test(result.stdout), output: result.stdout + result.stderr };
}
