// Calls the app's API like the browser does: JSON in, JSON out, optional bearer token.

export interface ApiResult {
  status: number;
  body: any;
}

export function makeCall(base: string) {
  return async function call(token: string | null, method: string, url: string, body?: object): Promise<ApiResult> {
    const response = await fetch(base + url, {
      method,
      headers: { ...(token ? { authorization: `Bearer ${token}` } : {}), 'content-type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    });

    let json: any = null;

    try {
      json = await response.json();
    } catch {
      // some replies have no body
    }

    return { status: response.status, body: json };
  };
}

export type ApiCall = ReturnType<typeof makeCall>;
