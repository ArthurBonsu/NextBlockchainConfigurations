// Talks to a local Ganache chain over JSON-RPC, the way a wallet would on the test page's behalf.

let nextId = 1;

export interface RpcReply {
  result?: any;
  error?: { code: number; message: string; data?: unknown };
}

export async function rpc(url: string, method: string, params: unknown[] = []): Promise<RpcReply> {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: nextId++, method, params }),
  });

  return response.json();
}

// Like MetaMask: when the page does not set a gas limit, estimate it and add 20%.
export async function withGasEstimate(url: string, method: string, params: any[]): Promise<RpcReply | null> {
  if (method !== 'eth_sendTransaction' || params[0].gas) return null;

  const estimate = await rpc(url, 'eth_estimateGas', [params[0]]);

  if (estimate.error) return estimate;

  params[0].gas = '0x' + Math.ceil(parseInt(estimate.result, 16) * 1.2).toString(16);

  return null;
}
