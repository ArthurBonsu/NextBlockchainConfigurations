// Prints PASS / FAIL lines and the final count, so every browser test reports the same way.

let passed = 0;
let failed = 0;

export function check(name: string, ok: boolean, detail = ''): void {
  if (ok) passed++;
  else failed++;

  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  ' + detail}`);
}

export const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

// Calls `isReady` again and again until it returns true (errors count as "not yet").
export async function waitFor(isReady: () => Promise<boolean>, ms = 90000): Promise<void> {
  const start = Date.now();

  for (;;) {
    try {
      if (await isReady()) return;
    } catch {
      // not ready yet
    }

    if (Date.now() - start > ms) throw new Error('timed out waiting for the dev server');

    await sleep(700);
  }
}

// Prints the totals and exits with a non-zero code when anything failed.
export function finish(screenshotDir?: string): never {
  console.log(`\n${passed} passed, ${failed} failed${screenshotDir ? `   (screenshots in ${screenshotDir})` : ''}`);
  process.exit(failed ? 1 : 0);
}
