// Finishes onboarding through the API, so a test can focus on the pages it is really checking.
import { lastTo } from '@/server/sms';
import type { ApiCall } from './api';

// The SMS code never leaves the server, so tests read it from the mock outbox.
export function lastCode(e164: string): string {
  const message = lastTo(e164);
  const match = message && /(\d{6}) is your/.exec(message.text);

  return match ? match[1] : '';
}

interface Person {
  givenName: string;
  familyName: string;
  dob: string;
  gender: string;
}

export async function completeOnboarding(call: ApiCall, token: string, phone: string, person: Person) {
  await call(token, 'POST', '/api/onboarding/consent', { terms: true, privacy: true, sms: true });
  await call(token, 'POST', '/api/onboarding/profile', { ...person, nationality: 'GH' });
  await call(token, 'POST', '/api/onboarding/phone/start', { phone });

  const confirmed = await call(token, 'POST', '/api/onboarding/phone/confirm', {
    code: lastCode('+233' + phone.replace(/^0/, '')),
  });

  await call(token, 'POST', '/api/onboarding/address', { regionCode: 'ASH', districtId: 'ASH-kumasi', city: 'Kumasi', suburb: 'Adum' });

  return confirmed;
}
