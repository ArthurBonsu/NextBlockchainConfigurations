// Talks to the Firebase Auth EMULATOR the way the browser SDK does, so tests can create and sign in accounts
// without going through the sign-up form.

export const EMULATOR_URL = process.env.AUTH_EMU || 'http://127.0.0.1:9099';
export const PROJECT_ID = 'demo-classtryout';

export interface EmulatorSession {
  idToken: string;
  localId: string;
  email: string;
}

async function post(pathname: string, body: object): Promise<any> {
  const response = await fetch(`${EMULATOR_URL}/identitytoolkit.googleapis.com/v1/${pathname}?key=fake-key`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });

  return response.json();
}

export const signUp = (email: string, password: string): Promise<EmulatorSession> =>
  post('accounts:signUp', { email, password, returnSecureToken: true });

export const signIn = (email: string, password: string): Promise<EmulatorSession> =>
  post('accounts:signInWithPassword', { email, password, returnSecureToken: true });

// Marks an email as verified: asks the emulator for the code it "sent", then redeems it.
export async function verifyEmail(email: string, idToken?: string): Promise<void> {
  if (idToken) await post('accounts:sendOobCode', { requestType: 'VERIFY_EMAIL', idToken });

  const response = await fetch(`${EMULATOR_URL}/emulator/v1/projects/${PROJECT_ID}/oobCodes`);
  const { oobCodes = [] } = await response.json();
  const code = oobCodes.filter((c: any) => c.email === email && c.requestType === 'VERIFY_EMAIL').pop();

  if (!code) throw new Error('no verification code in emulator for ' + email);

  await post('accounts:update', { oobCode: code.oobCode });
}

export async function emulatorIsRunning(): Promise<boolean> {
  try {
    await fetch(EMULATOR_URL);

    return true;
  } catch {
    return false;
  }
}
