# Project tree

Generated after the reorganisation. Folders have one job each; the notes after `—` say which. Component folders
(`components/<Group>/<Name>/`) each hold `<Name>.tsx`, an optional `<Name>.module.css` and an `index.ts`, and are not expanded here.
Where an old file went: `docs/REORGANIZATION.md`.

```
├── blockchain/   — everything about the chain
│   ├── contracts/   — one folder per contract: <Name>Contract.ts builds it, <Name>Actions.ts holds the calls its components make
│   │   ├── ContractControl/
│   │   │   ├── ContractControlActions.ts
│   │   │   └── index.ts
│   │   ├── LicenseRegistry/
│   │   │   ├── index.ts
│   │   │   ├── LicenseRegistryActions.ts
│   │   │   └── LicenseRegistryContract.ts
│   │   ├── RevocationManager/
│   │   │   ├── index.ts
│   │   │   ├── RevocationManagerActions.ts
│   │   │   └── RevocationManagerContract.ts
│   │   ├── VehicleRegistry/
│   │   │   ├── index.ts
│   │   │   ├── VehicleRegistryActions.ts
│   │   │   └── VehicleRegistryContract.ts
│   │   ├── deployments.ts
│   │   ├── index.ts
│   │   ├── openContracts.ts
│   │   └── sendTransaction.ts
│   ├── history/   — reading a vehicle's events from the chain
│   │   ├── getVehicleTimeline.ts
│   │   ├── index.ts
│   │   └── pastEvents.ts
│   ├── receipts/   — turning transactions into readable receipts
│   │   ├── buildReceipt.ts
│   │   └── index.ts
│   ├── types/   — TypeScript shapes for contracts, wallets and receipts
│   │   ├── contract.types.ts
│   │   ├── index.ts
│   │   ├── license.types.ts
│   │   ├── network.types.ts
│   │   ├── receipt.types.ts
│   │   ├── revocation.types.ts
│   │   ├── status.types.ts
│   │   ├── vehicle.types.ts
│   │   └── window.d.ts
│   ├── wallets/   — MetaMask connection and the network list
│   │   ├── connectWallet.ts
│   │   ├── index.ts
│   │   ├── linkedWallets.ts
│   │   ├── networks.ts
│   │   └── switchNetwork.ts
│   └── index.ts
├── components/   — one folder per component: Name/Name.tsx + Name.module.css (when needed) + index.ts
│   ├── Account/
│   │   ├── Account/
│   │   ├── AccountDetails/
│   │   ├── CapabilityList/
│   │   ├── NotificationSettings/
│   │   └── index.ts
│   ├── AdminTools/
│   │   ├── AdminPanel/
│   │   ├── IdReviewQueue/
│   │   ├── IdReviewRow/
│   │   ├── UserRow/
│   │   ├── UsersFilters/
│   │   ├── UsersTable/
│   │   └── index.ts
│   ├── AppLayout/
│   │   ├── Layout/
│   │   ├── NavBar/
│   │   ├── NetworkBanner/
│   │   └── index.ts
│   ├── Authentication/
│   │   ├── AccountBar/
│   │   ├── AccountProblem/
│   │   ├── AuthProvider/
│   │   ├── CapabilityGate/
│   │   ├── IdStep/
│   │   ├── SignInForm/
│   │   ├── SocialSignInButtons/
│   │   └── index.ts
│   ├── Common/
│   │   ├── FormField/
│   │   ├── Notice/
│   │   ├── StatusMessage/
│   │   └── index.ts
│   ├── DashboardPage/
│   │   ├── AccountSummary/
│   │   ├── ActionTiles/
│   │   ├── Dashboard/
│   │   ├── JourneyChecklist/
│   │   ├── NextStepHero/
│   │   ├── StepButton/
│   │   └── index.ts
│   ├── Home/
│   │   ├── Home/
│   │   ├── HowItWorks/
│   │   └── index.ts
│   ├── Licences/
│   │   ├── IssueLicenseForm/
│   │   ├── LicenseAdminActions/
│   │   ├── LicensePanel/
│   │   ├── LicenseResult/
│   │   └── index.ts
│   ├── Notifications/
│   │   ├── NotifyPanel/
│   │   └── index.ts
│   ├── Onboarding/
│   │   ├── AddressStep/
│   │   ├── ConsentStep/
│   │   ├── Onboarding/
│   │   ├── PhoneStep/
│   │   ├── ProfileStep/
│   │   ├── StepPills/
│   │   ├── VerifyEmailNotice/
│   │   ├── index.ts
│   │   └── StepProps.ts
│   ├── Receipts/
│   │   ├── ReceiptCard/
│   │   ├── TxLink/
│   │   └── index.ts
│   ├── Revocations/
│   │   ├── LookUpReport/
│   │   ├── ReportVehicleForm/
│   │   ├── RevocationAdminActions/
│   │   ├── RevocationPanel/
│   │   └── index.ts
│   ├── SetupCheck/
│   │   ├── CheckListItem/
│   │   ├── SetupCheck/
│   │   └── index.ts
│   ├── SignIn/
│   │   ├── SignIn/
│   │   └── index.ts
│   ├── Vehicles/
│   │   ├── LookUpVehicle/
│   │   ├── RegisterVehicleForm/
│   │   ├── VehicleHistory/
│   │   ├── VehicleRegistryPanel/
│   │   └── index.ts
│   ├── WalletConnection/
│   │   ├── WalletBar/
│   │   ├── WalletProvider/
│   │   └── index.ts
│   └── VehicleDemo.module.css.additions
├── constants/   — fixed values
│   ├── index.ts
│   └── lockedReasons.ts
├── contracts/   — Solidity
│   ├── 2_Owner.sol
│   ├── 3_Ballot.sol
│   ├── IRevocationManager.sol
│   ├── IVehicleRegistry.sol
│   ├── LicenseRegistry.sol
│   ├── RevocationManager.sol
│   ├── Storage.sol
│   └── VehicleRegistry.sol
├── e2e/   — browser tests; helpers/ holds the shared set-up
│   ├── helpers/
│   │   ├── api.ts
│   │   ├── authEmulator.ts
│   │   ├── browser.ts
│   │   ├── devServer.ts
│   │   ├── index.ts
│   │   ├── localChain.ts
│   │   ├── onboarding.ts
│   │   └── report.ts
│   ├── accounts.e2e.ts
│   ├── flow.e2e.ts
│   ├── multichain.e2e.ts
│   ├── navigation.e2e.ts
│   ├── notify-ui.e2e.ts
│   ├── notify.e2e.ts
│   ├── README.md
│   └── signinProblems.e2e.ts
├── firebase/   — Firestore rules, indexes and the console set-up guide
│   ├── firestore.indexes.json
│   ├── firestore.rules
│   └── README.md
├── hooks/   — React hooks, so components stay about layout
│   ├── index.ts
│   ├── useActionStatus.ts
│   ├── useFormSubmit.ts
│   ├── useIdReviewQueue.ts
│   ├── useLicenseLookup.ts
│   ├── useSignIn.ts
│   └── useUsersTable.ts
├── migrations/   — Truffle deploy scripts (JavaScript: Truffle requires it)
│   ├── 2_deploy_vehicle_registry.js
│   ├── 3_deploy_revocation_manager.js
│   └── 4_deploy_license_registry.js
├── notifier/   — the email watcher (TypeScript, run with tsx)
│   ├── deployments.ts
│   ├── index.ts
│   ├── mailer.ts
│   ├── resolve.ts
│   ├── state.ts
│   ├── templates.ts
│   ├── types.ts
│   └── watcher.ts
├── pages/   — one thin file per page; api/ holds the server routes
│   ├── admin/
│   │   ├── contracts.tsx
│   │   ├── ids.tsx
│   │   └── users.tsx
│   ├── api/
│   │   ├── admin/
│   │   │   ├── identity/
│   │   │   └── users/
│   │   ├── capability/
│   │   │   └── [name].ts
│   │   ├── identity/
│   │   │   └── index.ts
│   │   ├── locations/
│   │   │   └── suburbs.ts
│   │   ├── me/
│   │   │   ├── index.ts
│   │   │   └── notifications.ts
│   │   ├── onboarding/
│   │   │   ├── phone/
│   │   │   ├── address.ts
│   │   │   ├── consent.ts
│   │   │   └── profile.ts
│   │   ├── wallet-link/
│   │   │   ├── challenge.ts
│   │   │   ├── confirm.ts
│   │   │   └── index.ts
│   │   └── auth-check.ts
│   ├── _app.tsx
│   ├── account.tsx
│   ├── dashboard.tsx
│   ├── history.tsx
│   ├── index.tsx
│   ├── licences.tsx
│   ├── notifications.tsx
│   ├── onboarding.tsx
│   ├── revocations.tsx
│   ├── setup-check.tsx
│   ├── signin.tsx
│   ├── vehicle-demo.tsx
│   └── vehicles.tsx
├── scripts/   — command-line tools (TypeScript, run with tsx)
│   ├── helpers/
│   │   ├── commandLine.ts
│   │   └── sampleEnv.ts
│   ├── checkConsistency.ts
│   ├── cleanup-legacy.sh
│   ├── deployerWallet.ts   — which wallet signs which kind of network
│   ├── genRealStructure.ts
│   ├── idMaintenance.ts
│   ├── preflight.ts   — read-only check before a deployment
│   ├── recordDeployment.ts
│   ├── reviewId.ts
│   ├── setRole.ts
│   └── syncContracts.ts
├── server/   — code that runs only on the server; import each folder through its index.ts
│   ├── auth/   — verify the Firebase token, roles, sessions, set-up problem explanations
│   │   ├── authErrors.ts
│   │   ├── explainVerifyError.ts
│   │   ├── index.ts
│   │   ├── roles.ts
│   │   ├── session.ts
│   │   ├── setupCheck.ts
│   │   ├── setupErrors.ts
│   │   ├── verifyBearer.ts
│   │   └── withUser.ts
│   ├── config/   — environment variables and settings
│   │   ├── env.ts
│   │   ├── index.ts
│   │   └── settings.ts
│   ├── database/   — one interface, two backends (Firestore, and a file store for tests)
│   │   ├── fieldPaths.ts
│   │   ├── FileStore.ts
│   │   ├── FirestoreStore.ts
│   │   ├── index.ts
│   │   ├── indexCheck.ts
│   │   ├── store.ts
│   │   └── types.ts
│   ├── errors/   — HttpError
│   │   ├── HttpError.ts
│   │   └── index.ts
│   ├── firebase/   — Firebase Admin SDK
│   │   ├── firebaseAdmin.ts
│   │   └── index.ts
│   ├── identity/   — ID documents: submit, review, decide, purge, checkers
│   │   ├── checkers.ts
│   │   ├── checkWorker.ts
│   │   ├── decide.ts
│   │   ├── documentView.ts
│   │   ├── idRules.ts
│   │   ├── index.ts
│   │   ├── purgeExpired.ts
│   │   ├── reviewQueue.ts
│   │   └── submitDocument.ts
│   ├── locations/   — regions, districts, address validation
│   │   ├── index.ts
│   │   └── locations.ts
│   ├── phone/   — Ghana phone numbers and one-time codes
│   │   ├── index.ts
│   │   ├── otp.ts
│   │   └── phone.ts
│   ├── security/   — hashing, encryption, rate limits, audit log
│   │   ├── audit.ts
│   │   ├── crypto.ts
│   │   ├── index.ts
│   │   └── rateLimit.ts
│   ├── sms/   — SMS providers (Arkesel, Hubtel, console, mock)
│   │   ├── arkesel.ts
│   │   ├── consoleProvider.ts
│   │   ├── httpProvider.ts
│   │   ├── hubtel.ts
│   │   ├── index.ts
│   │   ├── mockProvider.ts
│   │   ├── sendSms.ts
│   │   └── smsTypes.ts
│   ├── users/   — user documents, onboarding steps, roles and status
│   │   ├── index.ts
│   │   ├── listUsers.ts
│   │   ├── loadUser.ts
│   │   ├── onboardingState.ts
│   │   ├── onboardingSteps.ts
│   │   ├── roleAndStatus.ts
│   │   ├── userTypes.ts
│   │   └── userView.ts
│   └── walletLinks/   — wallet to account links for email notices
│       ├── challenge.ts
│       ├── index.ts
│       └── links.ts
├── services/   — talking to the outside world
│   ├── api/   — calling our own /api routes with the Firebase token
│   │   ├── apiClient.ts
│   │   └── index.ts
│   ├── auth/   — sign-in, sign-up, Google / GitHub / X, friendly error messages
│   │   ├── authErrors.ts
│   │   ├── authToken.ts
│   │   ├── browserCheck.ts
│   │   ├── index.ts
│   │   ├── passwordRules.ts
│   │   └── signInService.ts
│   ├── firebase/   — the Firebase browser SDK (one app, one auth)
│   │   ├── firebaseClient.ts
│   │   └── index.ts
│   └── index.ts
├── shared/   — used by both the server and the browser: ABI, chains, roles, navigation, journey
│   ├── abi/
│   │   ├── LicenseRegistry.json
│   │   ├── LicenseRegistry.ts
│   │   ├── RevocationManager.json
│   │   ├── RevocationManager.ts
│   │   ├── VehicleRegistry.json
│   │   └── VehicleRegistry.ts
│   ├── locations/
│   │   ├── districts.json
│   │   └── regions.json
│   ├── chains.json
│   ├── contracts.json
│   ├── deployments.json
│   ├── deployments.local.json
│   ├── id-types.json
│   ├── journey.ts
│   ├── nav.json
│   ├── navigation.ts
│   ├── notifications.json
│   ├── onboarding.json
│   ├── roles.json
│   └── rpc.ts
├── styles/   — CSS modules shared by several components
│   ├── Account.module.css
│   ├── Layout.module.css
│   └── VehicleDemo.module.css
├── test/   — unit tests (accounts/) and the Truffle contract test
│   ├── accounts/
│   │   ├── accounts.test.ts
│   │   ├── deployer.test.ts
│   │   ├── helpers.ts
│   │   ├── journey.test.ts
│   │   ├── signinProblems.test.ts
│   │   └── testEnv.ts
│   └── registry.test.js
├── types/   — shared TypeScript types
│   ├── account.types.ts
│   ├── admin.types.ts
│   └── index.ts
├── utils/   — small pure helpers
│   ├── formatChainTime.ts
│   ├── friendlyError.ts
│   ├── index.ts
│   ├── safeNext.ts
│   └── shortAddress.ts
├── .env.local.example
├── .firebaserc
├── deployments.json
├── Dockerfile
├── firebase.json
├── firestore.indexes.json
├── firestore.rules
├── gitignore.additions.txt
├── LICENSE
├── move-old-files.ps1
├── next-env.d.ts
├── package.json
├── project-tree.md
├── README.md
├── truffle-config.js
├── truffle-config.sandbox.js
├── tsconfig.json
└── vehicledoc.md
```
