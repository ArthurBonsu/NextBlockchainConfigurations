# Project tree

The project tree now lives in [`docs/project-tree.md`](project-tree.md), regenerated for the reorganised folders.
Where each old file went: [`docs/REORGANIZATION.md`](REORGANIZATION.md).
