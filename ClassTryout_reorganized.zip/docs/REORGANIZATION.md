# Reorganisation: where every old file went

The project was reorganised so a student can find things: each folder has one job, components live in their own folders with
an `index.ts`, the server is split by topic, contract calls live in per-contract action files, and **everything except the three
Truffle files is TypeScript**. Nothing was deleted. Every file that was replaced is in `_legacy/before-reorganize/` with its old path,
so you can open the old and the new side by side. (`move-old-files.ps1` moves the old files there on your own disk.)

Files that were **not** replaced keep their path and only changed where needed (the three contracts, `firebase/`, `firestore.rules`, `styles/`,
the Solidity tests, `next-env.d.ts`, `Dockerfile`).

## What changed besides the folders

- **Sign-in and sign-up.** `services/auth/` and `hooks/useSignIn.ts` run the sign-in page; the buttons are email + password, **Google**, **GitHub** and **X**.
  A provider that fails (popup closed, provider not enabled, domain not authorised, network down) now shows a plain message; a server that cannot
  load a signed-in account shows `AccountProblem` on the sign-in page too (it only appeared on other pages before).
- **`shared/abi/*` regenerated.** The ABI files on disk were older than the Solidity: they lacked `owner()`, `pause()`, `paused()`,
  `transferOwnership()` and the `Paused` / `Unpaused` / `OwnershipTransferred` events and the custom errors that the contracts get from OpenZeppelin.
  They were regenerated from the compiled contracts (additions only; nothing was removed from the ABI).
- **Duplicate migrations.** `2_deploy_vehicle_registration.js` and `3_deploy_vehicle_manager.js` shared numbers with
  `2_deploy_vehicle_registry.js` and `3_deploy_revocation_manager.js`; they were moved to the archive.
- **Deploy wallets and preflight** were added: `scripts/deployerWallet.ts` (TESTNET_ vs MAINNET_ wallet rules), `scripts/preflight.ts`
  (`yarn deploy:preflight --network <key>`), `test/accounts/deployer.test.ts`, and `truffle-config.js` was rewritten to read
  local, then test networks, then real-money networks, with `CONFIRM_CHAIN_ID` and an optional `MAX_FEE_GWEI` ceiling.
- **`truffle-config.js`** loads TypeScript helpers with `require("tsx/cjs")`, and the migrations call `scripts/recordDeployment.ts`.
- **Component folders were renamed where a lower-case twin existed** (`admin` / `Admin`, `auth` / `Auth`, `dashboard` / `Dashboard`, `layout` /
  `Layout`, `wallet` / `Wallet`): Windows treats those as the same folder, and Linux hosts such as Vercel do not. The new folders are
  `AdminTools`, `Authentication`, `DashboardPage`, `AppLayout` and `WalletConnection`.

## Front end

| Old file | Now |
|---|---|
| `components/AdminPanel.tsx` | `components/AdminTools/AdminPanel/` |
| `components/LicensePanel.tsx` | `components/Licences/LicensePanel/` (+ `IssueLicenseForm`, `LicenseResult`, `LicenseAdminActions`) |
| `components/RevocationPanel.tsx` | `components/Revocations/RevocationPanel/` (+ `ReportVehicleForm`, `LookUpReport`, `RevocationAdminActions`) |
| `components/VehicleRegistryPanel.tsx` | `components/Vehicles/VehicleRegistryPanel/` (+ `RegisterVehicleForm`, `LookUpVehicle`) |
| `components/VehicleHistory.tsx` | `components/Vehicles/VehicleHistory/` |
| `components/NotifyPanel.tsx` | `components/Notifications/NotifyPanel/` |
| `components/ReceiptCard.tsx`, `TxLink.tsx` | `components/Receipts/ReceiptCard/`, `components/Receipts/TxLink/` |
| `components/NetworkBanner.tsx` | `components/AppLayout/NetworkBanner/` |
| `components/WalletBar.tsx` | `components/WalletConnection/WalletBar/` |
| `components/wallet/WalletProvider.tsx` | `components/WalletConnection/WalletProvider/` |
| `components/layout/Layout.tsx`, `NavBar.tsx` | `components/AppLayout/Layout/`, `components/AppLayout/NavBar/` |
| `components/dashboard/Dashboard.tsx` | `components/DashboardPage/` (`Dashboard`, `NextStepHero`, `JourneyChecklist`, `ActionTiles`, `AccountSummary`, `StepButton`) |
| `components/admin/IdReviewQueue.tsx` | `components/AdminTools/IdReviewQueue/` + `IdReviewRow/`, hook `hooks/useIdReviewQueue.ts` |
| `components/admin/UsersTable.tsx` | `components/AdminTools/UsersTable/` + `UsersFilters/`, `UserRow/`, hook `hooks/useUsersTable.ts` |
| `components/auth/AccountBar.tsx`, `AuthProvider.tsx`, `CapabilityGate.tsx`, `IdStep.tsx` | `components/Authentication/` (same names, one folder each) |
| `components/auth/ui.tsx` | split: `components/Common/` (`FormField`, `Notice`, `StatusMessage`) and `utils/safeNext.ts` |
| inline code in `pages/signin.tsx` | `components/SignIn/SignIn/`, `components/Authentication/SignInForm/`, `SocialSignInButtons/`, `AccountProblem/`, `hooks/useSignIn.ts`, `services/auth/` |
| inline code in `pages/onboarding.tsx` | `components/Onboarding/` (`ConsentStep`, `ProfileStep`, `PhoneStep`, `AddressStep`, `StepPills`, `VerifyEmailNotice`) |
| inline code in `pages/account.tsx`, `index.tsx`, `setup-check.tsx` | `components/Account/`, `components/Home/`, `components/SetupCheck/` |
| `pages/*.tsx` | the same URLs, now thin files that only choose a component |
| `utils/accountTypes.ts` | `types/account.types.ts` |
| `utils/api.ts` | `services/api/apiClient.ts` |
| `utils/auth.ts` | `services/auth/authToken.ts` |
| `utils/firebaseClient.ts` | `services/firebase/firebaseClient.ts` |
| `utils/errors.ts` | `utils/friendlyError.ts` |
| `utils/networks.ts` | `blockchain/wallets/networks.ts` (+ `switchNetwork.ts`) |
| `utils/walletLink.ts` | `blockchain/wallets/linkedWallets.ts` |
| `utils/receipts.ts` | `blockchain/receipts/buildReceipt.ts` and `blockchain/history/` (the timeline) |
| `utils/contracts.ts` | `blockchain/contracts/` : `deployments.ts`, `openContracts.ts`, `sendTransaction.ts`, `ContractControl/`, `blockchain/wallets/connectWallet.ts`; the typed contract builders are in `<Name>/<Name>Contract.ts` and the calls in `<Name>/<Name>Actions.ts` |
| `shared/journey.js`, `navigation.js`, `rpc.js` | `shared/journey.ts`, `navigation.ts`, `rpc.ts` |

## Server

| Old file | Now |
|---|---|
| `server/env.js`, `config.js` | `server/config/` |
| `server/httpError.js` | `server/errors/` |
| `server/firebaseAdmin.js` | `server/firebase/` |
| `server/store.js` | `server/database/` (`FileStore`, `FirestoreStore`, `types`, `indexCheck`, `fieldPaths`, `store`) |
| `server/crypto.js`, `audit.js`, `rateLimit.js` | `server/security/` |
| `server/auth.js`, `session.js`, `apiHelpers.js`, `roles.js`, `setupErrors.js`, `authCheck.js` | `server/auth/` (`verifyBearer`, `explainVerifyError`, `authErrors`, `session`, `withUser`, `roles`, `setupErrors`, `setupCheck`) |
| `server/users.js` | `server/users/` (`loadUser`, `onboardingSteps`, `onboardingState`, `roleAndStatus`, `userView`, `listUsers`) |
| `server/phone.js`, `otp.js` | `server/phone/` |
| `server/locations.js` | `server/locations/` |
| `server/links.js`, `challenge.js` | `server/walletLinks/` |
| `server/sms/{arkesel,hubtel,consoleProvider,http,mock,index}.js` | `server/sms/` (`arkesel`, `hubtel`, `consoleProvider`, `httpProvider`, `mockProvider`, `sendSms`, `smsTypes`) |
| `server/identity/{index,checkers,worker}.js` | `server/identity/` (`submitDocument`, `decide`, `reviewQueue`, `documentView`, `purgeExpired`, `idRules`, `checkers`, `checkWorker`) |
| `pages/api/**/*.ts` | same files and URLs; now `withSession(...)` routes that import from the `@/server/...` folders |

## Scripts, notifier, tests, migrations

| Old file | Now |
|---|---|
| `scripts/sync-contracts.js` | `scripts/syncContracts.ts` |
| `scripts/check-consistency.js` | `scripts/checkConsistency.ts` |
| `scripts/record-deployment.js` | `scripts/recordDeployment.ts` |
| `scripts/set-role.js`, `review-id.js`, `id-maintenance.js` | `scripts/setRole.ts`, `reviewId.ts`, `idMaintenance.ts` |
| `scripts/gen-real-structure.js` | `scripts/genRealStructure.ts` |
| (shared by the scripts) | `scripts/helpers/commandLine.ts`, `scripts/helpers/sampleEnv.ts` |
| `notifier/*.js` | `notifier/*.ts` (`index`, `watcher`, `resolve`, `mailer`, `templates`, `state`, `deployments`, `types`) |
| `test/accounts/helpers.js`, `accounts.test.js`, `journey.test.js` | `test/accounts/helpers.ts`, `testEnv.ts`, `accounts.test.ts`, `journey.test.ts` (+ new `signinProblems.test.ts`) |
| `e2e/*.e2e.js` | `e2e/*.e2e.ts` with shared set-up in `e2e/helpers/` (+ new `signinProblems.e2e.ts`) |
| `test/e2e.js` | archived: an older copy of `e2e/flow.e2e.ts` that still expected the removed `/vehicle-demo` page |
| `migrations/2_deploy_vehicle_registration.js`, `3_deploy_vehicle_manager.js` | archived (duplicate numbers) |
| `docs/PROJECT_TREE.md`, root `project-tree.md` | now pointers to `docs/project-tree.md`; the old text is archived |

## Commands

`npm run ...` in the old docs is now `yarn ...`. Scripts that were `node scripts/x.js` are `tsx scripts/x.ts` behind the same
`yarn` names (`yarn contracts:sync`, `yarn check`, `yarn accounts:set-role`, `yarn docs:structure`, `yarn notify`, ...). New:
`yarn test:accounts` (53 tests), `yarn test:navigation:e2e`, `yarn test:signin-problems:e2e`, `yarn test:flow:e2e`, `yarn test:multichain:e2e`.
