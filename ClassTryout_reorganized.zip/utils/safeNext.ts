// utils/safeNext.ts
// After sign-in we send people back to the page they came from (?next=/vehicles).
// Only addresses on this site are allowed, so nobody can be sent to another website.

export function safeNext(raw: unknown, fallback: string): string {
  const value = Array.isArray(raw) ? raw[0] : raw;

  if (typeof value !== 'string') return fallback;
  if (!value.startsWith('/')) return fallback;
  if (value.startsWith('//')) return fallback;
  if (value.includes('\\')) return fallback;

  return value;
}
