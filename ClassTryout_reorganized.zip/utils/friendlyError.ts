// utils/friendlyError.ts
// Wallet, web3 and contract errors come in many shapes.
// This turns any of them into one short sentence for the screen, and never shows raw JSON.
//
// OpenZeppelin 5 reports failures as custom errors, not require() strings.
// A wallet only hands back a 4-byte selector, so we recognise the error name and the selector.

interface CustomError {
  name: string;
  selector: string;
  message: string;
}

const CUSTOM_ERRORS: CustomError[] = [
  {
    name: 'OwnableUnauthorizedAccount',
    selector: '0x118cdaa7',
    message: 'Only the admin wallet can do this. You are connected with a different wallet.',
  },
  {
    name: 'OwnableInvalidOwner',
    selector: '0x1e4fbdf7',
    message: 'That is not a valid admin address.',
  },
  {
    name: 'EnforcedPause',
    selector: '0xd93c0665',
    message: 'This contract is paused by the admin. Please try again later.',
  },
  {
    name: 'ExpectedPause',
    selector: '0x8dfc202b',
    message: 'The contract is not paused.',
  },
];

function safeJson(value: unknown): string {
  try {
    return value === undefined ? '' : JSON.stringify(value);
  } catch {
    return '';
  }
}

function userRejected(err: any): boolean {
  if (err.code === 4001) return true;
  if (err.code === 'ACTION_REJECTED') return true;

  return /user (rejected|denied)/i.test(err.message || '');
}

function findCustomError(err: any, text: string): string | null {
  const payload = (text + ' ' + safeJson(err.data) + ' ' + safeJson(err.cause?.data) + ' ' + safeJson(err.cause)).toLowerCase();
  const decodedName: string | undefined = err.cause?.errorName || err.errorName || err.innerError?.errorName;

  for (const known of CUSTOM_ERRORS) {
    const sameName = decodedName === known.name;
    const nameInPayload = payload.includes(known.name.toLowerCase());
    const selectorInPayload = payload.includes(known.selector);

    if (sameName || nameInPayload || selectorInPayload) return known.message;
  }

  return null;
}

function findRevertReason(text: string): string | null {
  const match =
    text.match(/execution reverted:?\s*([^"|{}\n]+)/i) ||
    text.match(/reverted with reason string ['"]([^'"]+)['"]/i) ||
    text.match(/Reason given:\s*([^"|{}\n]+)/i) ||
    text.match(/revert\s+([A-Z][^"|{}\n]{3,})/);

  if (!match || !match[1].trim()) return null;

  return match[1].trim().replace(/\.$/, '') + '.';
}

export function friendlyError(err: any): string {
  if (!err) return 'Something went wrong.';

  if (userRejected(err)) return 'You rejected the request in your wallet.';

  const parts: string[] = [
    err.cause?.message,
    err.cause?.data?.message,
    err.data?.message,
    err.data?.reason,
    err.reason,
    err.message,
  ].filter(Boolean);
  const text = parts.join(' | ');

  const customMessage = findCustomError(err, text);
  if (customMessage) return customMessage;

  const revertReason = findRevertReason(text);
  if (revertReason) return revertReason;

  if (/out of gas/i.test(text)) {
    return 'The transaction ran out of gas. Try again and let the wallet set the gas limit.';
  }

  if (/insufficient funds/i.test(text)) {
    return "This wallet doesn't have enough ETH to pay for gas.";
  }

  if (/Transaction has been reverted by the EVM|Error happened while trying to execute a function inside a smart contract/i.test(text)) {
    return 'The contract rejected this transaction (it reverted). Check that the IDs exist, are not already used, and that you are using the admin wallet for admin actions.';
  }

  if (/nonce/i.test(text) && /too low|already/i.test(text)) {
    return 'Wallet nonce mismatch. If you reset Ganache, reset the account in MetaMask (Settings > Advanced > Clear activity tab data).';
  }

  // Last resort: remove any JSON blob and cap the length.
  const cleaned = (err.message || String(err)).replace(/\{[\s\S]*\}/g, '').replace(/\s+/g, ' ').trim();

  return (cleaned || 'Something went wrong.').slice(0, 240);
}
