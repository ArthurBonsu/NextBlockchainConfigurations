// utils/formatChainTime.ts
// The blockchain stores time as seconds. People read dates.

export function formatChainTime(seconds: number | string | bigint): string {
  const milliseconds = Number(seconds) * 1000;

  return new Date(milliseconds).toLocaleString();
}
