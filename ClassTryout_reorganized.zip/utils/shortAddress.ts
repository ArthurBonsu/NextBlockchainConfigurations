// utils/shortAddress.ts
// 0x1234567890abcdef... becomes 0x1234...cdef

export function shortAddress(address: string): string {
  const start = address.slice(0, 6);
  const end = address.slice(-4);

  return `${start}...${end}`;
}
