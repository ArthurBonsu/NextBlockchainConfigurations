// types/admin.types.ts
// Shapes used by the admin screens (users table and ID review queue).

// One line in the users table (GET /api/admin/users).
export interface UserRowData {
  uid: string;
  email: string | null;
  role: string;
  status: string;
  createdAt: string;
  name?: string | null;
  phone?: string | null;
  region?: string | null;
  district?: string | null;
  suburb?: string | null;
  level: number;
  onboardingComplete: boolean;
}

// The server allows ONE filter group at a time, and the screen does the same.
export type UserFilterGroup = 'role' | 'email' | 'level' | 'region';

export type PendingKind = 'suspend' | 'restore' | 'role';

// A change the admin has started but not confirmed yet.
export interface PendingUserChange {
  uid: string;
  kind: PendingKind;
  role?: string;
}

// One line in the ID review queue (GET /api/admin/identity).
export interface IdReviewDocument {
  id: string;
  uid: string;
  type: string;
  label: string;
  last4: string;
  country: string | null;
  expiry: string | null;
  status: string;
  createdAt: string;
  reviewedAt: string | null;
  note: string | null;
  checker?: any;
  attempts?: number;
}

// The full ID number, shown to a reviewer for a few seconds.
export interface RevealedId {
  number: string;
  type: string;
  country: string | null;
  expiry: string | null;
  holder: { name: string | null; dob: string | null };
}

export type ReviewDecision = 'verified' | 'rejected';

export interface PendingReview {
  id: string;
  decision: ReviewDecision;
}
