// types/account.types.ts
// What GET /api/me returns (see server/users/).
// It is kept by hand next to the server code. scripts/checkConsistency.ts compares the field names.

export interface Capability {
  allowed: boolean;
  reason?: string;
  need?: { roles?: string[]; level?: number; have?: number };
}

export interface IdDocument {
  id: string;
  type: string;
  label: string;
  last4: string;
  country: string | null;
  expiry: string | null;
  status: string;
  createdAt: string;
  note?: string | null;
}

export interface Address {
  regionCode: string;
  regionName: string;
  districtId: string;
  districtName: string;
  city: string;
  suburb: string;
  subarea?: string;
  street?: string;
  gpsAddress?: string;
  lat?: number;
  lng?: number;
}

export type Role = 'citizen' | 'officer' | 'admin' | 'super_admin';

export interface Profile {
  givenName?: string;
  familyName?: string;
  otherNames?: string;
  displayName?: string;
  dob?: string;
  gender?: string;
  nationality?: string;
}

export interface Onboarding {
  steps: string[];
  done: Record<string, boolean>;
  complete: boolean;
  next: string | null;
  required: string[];
  optional: string[];
}

export interface Me {
  uid: string;
  email: string | null;
  emailVerified: boolean;
  provider: string;
  role: Role;
  status: 'active' | 'suspended';
  profile: Profile;
  phone: { verified: boolean; masked?: string; verifiedAt?: string };
  address: Address | null;
  identity: { level: 0 | 1 | 2; types: string[] };
  consents: Record<string, { version: string; at: string }>;
  notifications: { email: boolean; sms: boolean };
  onboarding: Onboarding;
  capabilities: Record<string, Capability>;
  documents?: IdDocument[];
  pendingPhone?: { masked: string; resendAfter: string; expiresAt: string } | null;
  suggestedName?: string | null;
  createdAt: string;
}
