// constants/lockedReasons.ts
// When the server says a page or an action is locked, it sends a short reason code.
// These are the sentences we show for each code.

// A full sentence, for a page that is locked.
export const LOCKED_REASON_MESSAGES: Record<string, string> = {
  onboarding: 'Finish setting up your account first.',
  email_unverified: 'Verify your email address first (check your inbox).',
  level: 'This needs a confirmed ID. Add your ID on your account page; a reviewer confirms it.',
  role: 'Your account role does not allow this.',
  suspended: 'This account is suspended.',
};

// A few words, for a small tile on the dashboard.
export const LOCKED_REASON_SHORT: Record<string, string> = {
  onboarding: 'Finish setting up first',
  email_unverified: 'Verify your email first',
  level: 'Needs a confirmed ID',
  role: 'Not for your role',
  suspended: 'Account suspended',
};
