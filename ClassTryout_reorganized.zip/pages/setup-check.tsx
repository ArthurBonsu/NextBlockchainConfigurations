// pages/setup-check.tsx
import Head from 'next/head';
import { SetupCheck } from '@/components/SetupCheck';

export default function SetupCheckPage() {
  return (
    <>
      <Head>
        <title>Set-up check · ClassTryout</title>
      </Head>

      <SetupCheck />
    </>
  );
}
