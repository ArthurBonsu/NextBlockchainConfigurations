// pages/history.tsx
import { Layout } from '@/components/AppLayout';
import { VehicleHistory } from '@/components/Vehicles';

const INTRO = "Look up any vehicle's pseudonym to see every registration, licence and revocation event, read live from the chain.";

export default function HistoryPage() {
  return (
    <Layout title="History" intro={INTRO} width="normal" chain>
      <VehicleHistory />
    </Layout>
  );
}
