// pages/revocations.tsx
import { Layout } from '@/components/AppLayout';
import { CapabilityGate } from '@/components/Authentication';
import { RevocationPanel } from '@/components/Revocations';

const INTRO = "Report a vehicle, process reports, and reinstate vehicles. Processing and reinstating are done by the contract's admin wallet.";

export default function RevocationsPage() {
  return (
    <Layout title="Revocations" intro={INTRO} width="normal" chain>
      <CapabilityGate capability="license:revoke" title="Revocation">
        <RevocationPanel />
      </CapabilityGate>
    </Layout>
  );
}
