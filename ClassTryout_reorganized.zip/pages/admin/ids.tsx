// pages/admin/ids.tsx
import { Layout } from '@/components/AppLayout';
import { IdReviewQueue } from '@/components/AdminTools';

const INTRO = 'Compare each submitted ID number with the card, then confirm or reject it. You cannot review your own.';

export default function AdminIdsPage() {
  return (
    <Layout title="ID review" intro={INTRO} requireAccount capability="admin:ids:review">
      <IdReviewQueue />
    </Layout>
  );
}
