// pages/admin/contracts.tsx
// Contract ownership and pausing are decided by the connected WALLET (the contracts' owner), not by the account role.
// Anyone can look (it is public chain data). Only the owner wallet can press Pause / Resume.
// The menu link is shown to admin roles.

import { Layout } from '@/components/AppLayout';
import { AdminPanel } from '@/components/AdminTools';

const INTRO = 'Who controls each contract and whether it is paused. Only the owner wallet can pause or resume.';

export default function AdminContractsPage() {
  return (
    <Layout title="Contracts" intro={INTRO} width="normal" chain>
      <AdminPanel />
    </Layout>
  );
}
