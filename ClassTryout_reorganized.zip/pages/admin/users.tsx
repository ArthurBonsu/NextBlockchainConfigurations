// pages/admin/users.tsx
import { Layout } from '@/components/AppLayout';
import { UsersTable } from '@/components/AdminTools';

const INTRO = 'Find people, suspend or restore accounts, and (super administrators only) change roles.';

export default function AdminUsersPage() {
  return (
    <Layout title="Users" intro={INTRO} requireAccount capability="admin:users:read">
      <UsersTable />
    </Layout>
  );
}
