// pages/account.tsx
import Head from 'next/head';
import { Account } from '@/components/Account';

export default function AccountPage() {
  return (
    <>
      <Head>
        <title>Your account · ClassTryout</title>
      </Head>

      <Account />
    </>
  );
}
