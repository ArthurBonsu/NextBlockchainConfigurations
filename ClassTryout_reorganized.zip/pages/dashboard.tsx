// pages/dashboard.tsx
import { Layout } from '@/components/AppLayout';
import { Dashboard } from '@/components/DashboardPage';

export default function DashboardPage() {
  return (
    <Layout title="Dashboard" requireAccount chain>
      <Dashboard />
    </Layout>
  );
}
