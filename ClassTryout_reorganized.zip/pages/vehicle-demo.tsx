// pages/vehicle-demo.tsx
// The old single page is gone: its panels now live on their own pages
// (/vehicles, /licences, /revocations, /history, /notifications, /admin/contracts).
// This redirect keeps old bookmarks working.

import type { GetServerSideProps } from 'next';

export default function VehicleDemoMoved() {
  return null;
}

export const getServerSideProps: GetServerSideProps = async () => ({
  redirect: { destination: '/vehicles', permanent: false },
});
