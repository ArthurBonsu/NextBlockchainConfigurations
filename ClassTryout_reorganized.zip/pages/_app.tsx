// pages/_app.tsx
// Wraps every page: first the account (who is signed in), then the wallet (which network and address).

import type { AppProps } from 'next/app';
import { AuthProvider } from '@/components/Authentication';
import { WalletProvider } from '@/components/WalletConnection';

export default function App({ Component, pageProps }: AppProps) {
  return (
    <AuthProvider>
      <WalletProvider>
        <Component {...pageProps} />
      </WalletProvider>
    </AuthProvider>
  );
}
