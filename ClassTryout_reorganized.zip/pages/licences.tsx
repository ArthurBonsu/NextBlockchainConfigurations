// pages/licences.tsx
import { Layout } from '@/components/AppLayout';
import { CapabilityGate } from '@/components/Authentication';
import { LicensePanel } from '@/components/Licences';

const INTRO =
  'Issue a driving licence to a registered vehicle, look one up, or find the licence attached to a vehicle. Issuing leaves a receipt on the blockchain.';

export default function LicencesPage() {
  return (
    <Layout title="Licences" intro={INTRO} width="normal" chain>
      <CapabilityGate capability="license:issue" title="Licence issuing">
        <LicensePanel />
      </CapabilityGate>
    </Layout>
  );
}
