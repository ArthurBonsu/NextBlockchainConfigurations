// pages/api/me/notifications.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import type { SessionContext } from '@/server/auth';
import { saveNotificationPrefs, view } from '@/server/users';

// POST { email?: boolean, sms?: boolean } -> the updated notification choices
export default withSession(['POST'], async (req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => {
  const user = await saveNotificationPrefs(ctx.user.uid, req.body);

  return res.status(200).json({ me: view(user) });
});
