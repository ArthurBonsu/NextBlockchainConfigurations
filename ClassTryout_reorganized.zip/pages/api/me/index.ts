// pages/api/me/index.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import type { SessionContext } from '@/server/auth';
import { store } from '@/server/database';
import { listMyDocuments } from '@/server/identity';
import { mask } from '@/server/phone';
import { view } from '@/server/users';

// GET -> everything the app needs to draw the signed-in person: profile, role, set-up progress, what they may do,
//        their IDs (last 4 digits only) and a pending phone code, if any. Creates the profile on the first sign-in.
export default withSession(['GET'], async (_req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => {
  const uid = ctx.user.uid;

  const [documents, challenge] = await Promise.all([listMyDocuments(uid), store().get('phoneChallenges', uid)]);

  const codeIsWaiting = challenge && challenge.status === 'pending' && challenge.expireAt > new Date().toISOString();

  const pendingPhone = codeIsWaiting
    ? { masked: mask(challenge.phone), resendAfter: challenge.resendAfter, expiresAt: challenge.expireAt }
    : null;

  return res.status(200).json({
    me: view(ctx.user, { documents, pendingPhone, suggestedName: ctx.auth.name || null }),
  });
});
