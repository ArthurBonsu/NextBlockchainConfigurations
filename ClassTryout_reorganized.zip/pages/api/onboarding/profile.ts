// pages/api/onboarding/profile.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import type { SessionContext } from '@/server/auth';
import { saveProfile, view } from '@/server/users';

// POST { givenName, familyName, otherNames?, dob: "YYYY-MM-DD", gender, nationality? }
// The role, status, ID level and phone state are NEVER taken from the request body.
export default withSession(['POST'], async (req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => {
  const user = await saveProfile(ctx.user.uid, req.body);

  return res.status(200).json({ me: view(user) });
});
