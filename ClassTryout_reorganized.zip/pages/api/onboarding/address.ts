// pages/api/onboarding/address.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import type { SessionContext } from '@/server/auth';
import { saveAddress, view } from '@/server/users';

// POST { regionCode, districtId, city, suburb, subarea?, street?, gpsAddress?, lat?, lng?, placeId? }
export default withSession(['POST'], async (req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => {
  const user = await saveAddress(ctx.user.uid, req.body);

  return res.status(200).json({ me: view(user) });
});
