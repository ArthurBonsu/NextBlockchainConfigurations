// pages/api/onboarding/consent.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import type { SessionContext } from '@/server/auth';
import { saveConsents, view } from '@/server/users';

// POST { terms: true, privacy: true, sms: true } -> records which versions were accepted, and when
export default withSession(['POST'], async (req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => {
  const user = await saveConsents(ctx.user.uid, req.body, ctx.ip);

  return res.status(200).json({ me: view(user) });
});
