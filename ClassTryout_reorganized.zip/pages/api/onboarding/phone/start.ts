// pages/api/onboarding/phone/start.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import type { SessionContext } from '@/server/auth';
import { startPhoneVerification } from '@/server/phone';

// POST { phone } -> sends a one-time code by SMS. The code is never returned.
export default withSession(['POST'], async (req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => {
  const answer = await startPhoneVerification(ctx.user.uid, (req.body || {}).phone, ctx.ip);

  return res.status(200).json(answer);
});
