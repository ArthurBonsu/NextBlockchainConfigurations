// pages/api/onboarding/phone/confirm.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import type { SessionContext } from '@/server/auth';
import { confirmPhoneVerification } from '@/server/phone';
import { view } from '@/server/users';

// POST { code } -> marks the phone as verified
export default withSession(['POST'], async (req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => {
  const user = await confirmPhoneVerification(ctx.user.uid, (req.body || {}).code, ctx.ip);

  return res.status(200).json({ me: view(user) });
});
