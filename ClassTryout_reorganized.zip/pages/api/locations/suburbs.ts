// pages/api/locations/suburbs.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import { suburbSuggestions } from '@/server/users';

// GET ?districtId=GAR-accra-metropolitan -> suburbs other people have entered in that district (most used first)
export default withSession(['GET'], async (req: NextApiRequest, res: NextApiResponse) => {
  const suburbs = await suburbSuggestions(String(req.query.districtId || ''));

  return res.status(200).json({ suburbs });
});
