// pages/api/identity/index.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import type { SessionContext } from '@/server/auth';
import { listMyDocuments, submitDocument, withdrawDocument } from '@/server/identity';
import { view, requireUser } from '@/server/users';

// GET     -> my IDs (type, last 4 digits, status)
// POST    { type, number, country?, expiry? } -> adds an ID. Level 1 at once, level 2 when confirmed. Never waits for an outside service.
// DELETE  ?id=<docId> -> removes an unconfirmed ID (a typo, the wrong ID)
export default withSession(['GET', 'POST', 'DELETE'], async (req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => {
  const uid = ctx.user.uid;

  if (req.method === 'GET') {
    return res.status(200).json({ documents: await listMyDocuments(uid) });
  }

  if (req.method === 'POST') {
    const document = await submitDocument(uid, req.body, ctx.ip);
    const me = view(await requireUser(uid), { documents: await listMyDocuments(uid) });

    return res.status(201).json({ document, me });
  }

  await withdrawDocument(uid, String(req.query.id || ''));

  return res.status(200).json({ me: view(await requireUser(uid), { documents: await listMyDocuments(uid) }) });
});
