// pages/api/auth-check.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { runSetupCheck } from '@/server/auth';
import type { SetupCheckReport } from '@/server/auth';

// GET -> the sign-in set-up check (see /setup-check). It answers only yes or no and the public project id, never a secret.
// It is open while you develop. On a live site (NODE_ENV=production) it answers 404 unless you set SETUP_CHECK=on.
let lastAnswer: { at: number; body: SetupCheckReport } | null = null;

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  res.setHeader('Cache-Control', 'no-store');

  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed.' });

  if (process.env.NODE_ENV === 'production' && process.env.SETUP_CHECK !== 'on') {
    return res.status(404).json({ error: 'Not found.' });
  }

  // Do not let a refresh button hammer Firebase.
  if (lastAnswer && Date.now() - lastAnswer.at < 3000) return res.status(200).json(lastAnswer.body);

  const body = await runSetupCheck();

  lastAnswer = { at: Date.now(), body };

  return res.status(200).json(body);
}
