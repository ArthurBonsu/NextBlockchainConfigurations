// pages/api/admin/identity/[id]/reveal.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import type { SessionContext } from '@/server/auth';
import { revealNumber } from '@/server/identity';

// POST -> the decrypted ID number, for the reviewer to compare with the card. Every call is audit-logged and rate-limited.
export default withSession(
  ['POST'],
  async (req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => {
    const answer = await revealNumber({ uid: ctx.user.uid, role: ctx.user.role }, String(req.query.id), ctx.ip);

    return res.status(200).json(answer);
  },
  { capability: 'admin:ids:review' }
);
