// pages/api/admin/identity/[id]/review.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import type { SessionContext } from '@/server/auth';
import { decide } from '@/server/identity';

// POST { decision: "verified" | "rejected", note? } -> a human reviewer decides. You cannot review your own ID.
export default withSession(
  ['POST'],
  async (req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => {
    const body = req.body || {};

    const answer = await decide({
      docId: String(req.query.id),
      decision: body.decision,
      by: { uid: ctx.user.uid, role: ctx.user.role },
      note: body.note,
      checker: 'manual',
      ip: ctx.ip,
    });

    return res.status(200).json(answer);
  },
  { capability: 'admin:ids:review' }
);
