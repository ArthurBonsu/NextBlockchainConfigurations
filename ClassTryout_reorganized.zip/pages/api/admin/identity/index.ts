// pages/api/admin/identity/index.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import { reviewQueue } from '@/server/identity';

// GET ?status=pending_review (the default) | pending_check | verified | rejected   &before=<createdAt>&limit=
export default withSession(
  ['GET'],
  async (req: NextApiRequest, res: NextApiResponse) => {
    const { status, before, limit } = req.query as Record<string, string | undefined>;

    const documents = await reviewQueue({ status: status || 'pending_review', before, limit });

    return res.status(200).json({ documents });
  },
  { capability: 'admin:ids:review' }
);
