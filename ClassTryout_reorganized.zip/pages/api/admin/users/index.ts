// pages/api/admin/users/index.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import { listUsers } from '@/server/users';
import type { UserListFilters } from '@/server/users';

// GET ?role=&status=  |  ?regionCode=  |  ?districtId=  |  ?level=  |  ?email=    (one filter group at a time)  &before=<createdAt>&limit=
export default withSession(
  ['GET'],
  async (req: NextApiRequest, res: NextApiResponse) => {
    return res.status(200).json({ users: await listUsers(req.query as UserListFilters) });
  },
  { capability: 'admin:users:read' }
);
