// pages/api/admin/users/[uid]/status.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import type { SessionContext } from '@/server/auth';
import { setStatus } from '@/server/users';

// POST { status: "active" | "suspended", note? } -> suspends or restores an account. Audit-logged.
export default withSession(
  ['POST'],
  async (req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => {
    const body = req.body || {};
    const user = await setStatus(ctx.user, String(req.query.uid), body.status, body.note, ctx.ip);

    return res.status(200).json({ uid: user.uid, status: user.status });
  },
  { capability: 'admin:users:status' }
);
