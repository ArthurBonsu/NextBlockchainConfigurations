// pages/api/admin/users/[uid]/role.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession } from '@/server/auth';
import type { SessionContext } from '@/server/auth';
import { assignRole } from '@/server/users';

// POST { role } -> super administrators only. Ends the person's sessions so the change takes effect quickly. Audit-logged.
export default withSession(
  ['POST'],
  async (req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => {
    const user = await assignRole(ctx.user, String(req.query.uid), (req.body || {}).role, ctx.ip);

    return res.status(200).json({ uid: user.uid, role: user.role });
  },
  { capability: 'admin:roles:assign' }
);
