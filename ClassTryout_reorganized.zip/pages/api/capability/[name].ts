// pages/api/capability/[name].ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withSession, roles } from '@/server/auth';
import type { SessionContext } from '@/server/auth';
import { onboardingState } from '@/server/users';

// GET /api/capability/vehicle:register -> 200 { allowed: true } or 403 { allowed: false, code, error, need }
// Call this just before an action that matters (registering a vehicle, issuing a licence).
// The smart contract itself stays open, so this check is the application's gate, not the chain's.
export default withSession(['GET'], async (req: NextApiRequest, res: NextApiResponse, ctx: SessionContext) => {
  const name = String(req.query.name || '');
  const result = roles.check(ctx.user, name, { onboardingComplete: onboardingState(ctx.user).complete });

  if (result.allowed) return res.status(200).json({ allowed: true, capability: name });

  return res.status(403).json({
    allowed: false,
    capability: name,
    code: result.reason,
    error: roles.REASONS[result.reason as string] || 'Not allowed.',
    need: result.need || null,
  });
});
