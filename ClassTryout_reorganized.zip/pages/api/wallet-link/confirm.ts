// pages/api/wallet-link/confirm.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import Web3 from 'web3';
import { withUser } from '@/server/auth';
import type { AuthenticatedUser } from '@/server/auth';
import { checkChallenge, saveLink } from '@/server/walletLinks';

// POST { address, nonce, issuedAt, expiresAt, mac, signature }  ->  { linked: true, address }
// Checks that the signature over the challenge message came from `address`, then saves address -> uid.
export default withUser(['POST'], async (req: NextApiRequest, res: NextApiResponse, user: AuthenticatedUser) => {
  if (!user.emailVerified) {
    return res.status(403).json({ error: 'Verify your email address first.' });
  }

  const body = req.body || {};
  const message = checkChallenge(user.uid, body); // throws if forged, expired, or made for another account

  let signer: string;

  try {
    signer = new Web3().eth.accounts.recover(message, String(body.signature || ''));
  } catch {
    return res.status(400).json({ error: 'That signature could not be read. Sign the message again.' });
  }

  if (signer.toLowerCase() !== String(body.address).toLowerCase()) {
    return res.status(400).json({ error: 'The signature does not match that wallet. Sign with the wallet you are linking.' });
  }

  const link = await saveLink(body.address, user);

  return res.status(200).json({ linked: true, address: link.address });
});
