// pages/api/wallet-link/challenge.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withUser } from '@/server/auth';
import type { AuthenticatedUser } from '@/server/auth';
import { createChallenge } from '@/server/walletLinks';

// POST { address }  ->  { message, nonce, issuedAt, expiresAt, mac, address }
// The signed-in person asks for a message to sign with the wallet they want to link.
export default withUser(['POST'], async (req: NextApiRequest, res: NextApiResponse, user: AuthenticatedUser) => {
  if (!user.emailVerified) {
    return res.status(403).json({ error: 'Verify your email address first. We only send notifications to a verified email.' });
  }

  const { address } = req.body || {};

  return res.status(200).json(createChallenge(user.uid, address));
});
