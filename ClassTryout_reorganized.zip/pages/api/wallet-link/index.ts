// pages/api/wallet-link/index.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { withUser } from '@/server/auth';
import type { AuthenticatedUser } from '@/server/auth';
import { listLinks, removeLink } from '@/server/walletLinks';

// GET                 -> { wallets: [{ address, linkedAt }] }   the wallets linked to the signed-in account
// DELETE { address }  -> { removed: boolean }                   stop notifications for that wallet
export default withUser(['GET', 'DELETE'], async (req: NextApiRequest, res: NextApiResponse, user: AuthenticatedUser) => {
  if (req.method === 'GET') return res.status(200).json({ wallets: await listLinks(user.uid) });

  const removed = await removeLink((req.body || {}).address, user.uid);

  return res.status(200).json({ removed });
});
