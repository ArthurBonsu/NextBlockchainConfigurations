// pages/onboarding.tsx
import Head from 'next/head';
import { Onboarding } from '@/components/Onboarding';

export default function OnboardingPage() {
  return (
    <>
      <Head>
        <title>Set up your account · ClassTryout</title>
      </Head>

      <Onboarding />
    </>
  );
}
