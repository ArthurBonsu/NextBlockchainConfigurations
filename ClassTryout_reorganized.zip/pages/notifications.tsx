// pages/notifications.tsx
import { Layout } from '@/components/AppLayout';
import { NotifyPanel } from '@/components/Notifications';

const INTRO = 'Link your wallet to your account so registration, revocation and licence emails reach you.';

export default function NotificationsPage() {
  return (
    <Layout title="Notifications" intro={INTRO} width="normal" chain>
      <NotifyPanel />
    </Layout>
  );
}
