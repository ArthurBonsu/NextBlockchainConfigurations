// pages/vehicles.tsx
import { Layout } from '@/components/AppLayout';
import { CapabilityGate } from '@/components/Authentication';
import { VehicleRegistryPanel } from '@/components/Vehicles';

const INTRO = 'Register a vehicle under a pseudonym and look any vehicle up. Everything is written to and read from the blockchain.';

export default function VehiclesPage() {
  return (
    <Layout title="Vehicles" intro={INTRO} width="normal" chain>
      <CapabilityGate capability="vehicle:register" title="Vehicle registration">
        <VehicleRegistryPanel />
      </CapabilityGate>
    </Layout>
  );
}
