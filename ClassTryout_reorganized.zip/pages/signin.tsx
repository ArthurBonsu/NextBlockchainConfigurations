// pages/signin.tsx
import Head from 'next/head';
import { SignIn } from '@/components/SignIn';

export default function SignInPage() {
  return (
    <>
      <Head>
        <title>Sign in · ClassTryout</title>
      </Head>

      <SignIn />
    </>
  );
}
