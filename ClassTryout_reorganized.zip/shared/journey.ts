// shared/journey.ts
// What should this person do next?
//
// A pure function, so it is unit-tested (test/accounts/journey.test.ts) and the dashboard only has to draw the answer.
// The order is the order of the real journey:
//   verify email -> finish set-up -> confirmed ID -> wallet connected on a deployed network -> (optional) link wallet
//
// Nothing here is a permission: the server and the capability gates decide that. This only guides.

import type { Me } from '../types/account.types';

export type StepStatus = 'done' | 'current' | 'waiting' | 'todo';

export interface JourneyStep {
  id: string;
  title: string;
  detail: string;
  status: StepStatus;
  href?: string;
  action?: string;
  cta: string;
  optional?: boolean;
}

export interface WalletState {
  connected: boolean;
  deployed: boolean;
  networkName: string;
}

export interface JourneyInput {
  me: Me;
  wallet: WalletState;
  linked: boolean | null; // true / false, or null when it could not be read
}

export interface Journey {
  steps: JourneyStep[];
  next: JourneyStep | null; // the first step that is not done
}

function emailStep(me: Me): JourneyStep {
  return {
    id: 'email',
    title: 'Verify your email address',
    detail: me.emailVerified
      ? 'Verified.'
      : `We sent a link to ${me.email}. Vehicles and licences stay locked until you use it.`,
    status: me.emailVerified ? 'done' : 'todo',
    href: '/account',
    cta: 'Open my account',
  };
}

function setupStep(me: Me): JourneyStep {
  const done = !!me.onboarding.complete;

  return {
    id: 'setup',
    title: 'Finish setting up your account',
    detail: done ? 'Agreements, details, phone and address are saved.' : 'Agreements, your details, a phone code and your address.',
    status: done ? 'done' : 'todo',
    href: '/onboarding',
    cta: done ? 'Edit details' : 'Continue set-up',
  };
}

function idStep(me: Me): JourneyStep {
  const level = me.identity.level;

  let detail = 'Add your Ghana Card, passport or another ID. This unlocks registering vehicles and issuing licences.';
  if (level >= 2) detail = 'Your ID is confirmed.';
  else if (level === 1) detail = 'Your ID is added and waiting for a reviewer. You will be unlocked as soon as it is confirmed.';

  let status: StepStatus = 'todo';
  if (level >= 2) status = 'done';
  else if (level === 1) status = 'waiting';

  return {
    id: 'id',
    title: 'Get your ID confirmed',
    detail,
    status,
    href: '/account#id',
    cta: level === 1 ? 'View status' : 'Add my ID',
  };
}

function walletStep(wallet: WalletState): JourneyStep {
  const ready = !!(wallet && wallet.connected && wallet.deployed);

  let detail = 'Use MetaMask on a test network such as Sepolia. Blockchain actions are signed by your wallet.';
  if (ready) {
    detail = `Connected on ${wallet.networkName}.`;
  } else if (wallet && wallet.connected && !wallet.deployed) {
    detail = `${wallet.networkName} has no ClassTryout contracts yet. Switch to a network marked as deployed, such as Sepolia.`;
  }

  return {
    id: 'wallet',
    title: 'Connect your wallet',
    detail,
    status: ready ? 'done' : 'todo',
    action: 'connect',
    cta: wallet && wallet.connected ? 'Choose a network' : 'Connect wallet',
  };
}

function linkStep(linked: boolean | null): JourneyStep {
  return {
    id: 'link',
    title: 'Link your wallet for email notices',
    detail:
      linked === true
        ? 'Linked. You will be emailed about your vehicles and licences.'
        : 'Optional. Sign one free message so we know where to send registration and licence notices.',
    status: linked === true ? 'done' : 'todo',
    href: '/notifications',
    cta: 'Link my wallet',
    optional: true,
  };
}

export function buildJourney({ me, wallet, linked }: JourneyInput): Journey {
  const steps: JourneyStep[] = [];

  if (me.email) steps.push(emailStep(me));

  steps.push(setupStep(me));
  steps.push(idStep(me));
  steps.push(walletStep(wallet));
  steps.push(linkStep(linked));

  // Optional steps only count once the required ones are done.
  const required = steps.filter((step) => !step.optional);
  const firstOpen = required.find((step) => step.status !== 'done') || steps.find((step) => step.status !== 'done') || null;

  if (firstOpen) {
    firstOpen.status = firstOpen.status === 'waiting' ? 'waiting' : 'current';
  }

  return { steps, next: firstOpen };
}
