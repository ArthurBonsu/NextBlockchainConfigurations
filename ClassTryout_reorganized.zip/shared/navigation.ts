// shared/navigation.ts
// Which navigation items does this person see?
// A pure function (unit-tested in test/accounts/journey.test.ts).
//
// This is a convenience, never a permission: the server checks every action again, and the contracts are open.

import policy from './roles.json';

export interface NavItem {
  href: string;
  label: string;
  blurb?: string;
  group?: string;
  public?: boolean;
  needsAccount?: boolean;
  roles?: string[];
  capability?: string;
}

// The only two things about the signed-in person that decide what they see.
export interface NavViewer {
  status: string;
  role: string;
}

export interface VisibleItemsOptions {
  requireAccount?: boolean;
}

const capabilityPolicy = policy.capabilities as Record<string, { roles: string[] }>;

// What a signed-out visitor sees.
// When accounts are required, only public pages show.
// Otherwise (demo mode) the chain pages show too, but never anything that needs an account or an administrator.
function isVisibleSignedOut(item: NavItem, requireAccount: boolean): boolean {
  if (requireAccount) return false;

  const needsAdmin = String(item.capability || '').startsWith('admin:');

  return !item.needsAccount && !item.roles && !needsAdmin;
}

function isVisibleToUser(item: NavItem, viewer: NavViewer): boolean {
  if (item.roles) return item.roles.includes(viewer.role);

  if (item.capability) {
    const rule = capabilityPolicy[item.capability];

    return !!rule && rule.roles.includes(viewer.role);
  }

  return true;
}

export function visibleItems<T extends NavItem>(
  items: T[],
  viewer: NavViewer | null | undefined,
  options: VisibleItemsOptions = {}
): T[] {
  const requireAccount = options.requireAccount ?? false;

  return items.filter((item) => {
    if (item.public) return true;

    if (!viewer) return isVisibleSignedOut(item, requireAccount);

    if (viewer.status === 'suspended') return false;

    return isVisibleToUser(item, viewer);
  });
}
