# Firebase set-up (console steps)

You do these once. Nothing here needs code changes.

## 1. Project and sign-in
1. Firebase console > create (or open) the project. Add a **Web app**; copy its config into `.env.local` as the four `NEXT_PUBLIC_FIREBASE_*` values.
2. **Authentication > Sign-in method**: enable *Email/Password*, *Google*, *GitHub* and *X (Twitter)*. The sign-in page (`components/SignIn`, `components/Authentication/SocialSignInButtons`, `services/auth/`) has a button for each; a provider you leave off simply shows a clear "not enabled" message when clicked.
   - Email/Password: nothing else to do. New accounts are sent a verification email (a failure to send it never blocks sign-up).
   - Google: nothing else to do. Switch the provider on and choose a support email; no keys go in `.env.local`.
   - GitHub: create an **OAuth App** (not a GitHub App) at github.com > Settings > Developer settings. Set its *Authorization callback URL* to the one Firebase shows on the provider page (it looks like `https://<your-project-id>.firebaseapp.com/__/auth/handler`). Paste the app's Client ID and Client secret into Firebase.
   - X: create an app in the X developer portal and enable OAuth 1.0a / user authentication; add the same Firebase callback URL; paste the **API Key** and **API Key Secret** into Firebase. X often does not return an email; those accounts work but cannot receive email notices.
   - The GitHub / X / Google keys live in the Firebase console, **not** in `.env.local` (only the four `NEXT_PUBLIC_FIREBASE_*` web-config values are needed in the browser).
3. **Authentication > Settings > Authorized domains**: add your real domain (and `localhost` is already there).
4. Optional: **Authentication > Settings > User account linking**: keep *one account per email address* (default), so the same email cannot create two accounts through different providers.

## 2. Server credentials
**Project settings > Service accounts > Generate new private key.** Put `project_id`, `client_email`, `private_key` into `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY` in `.env.local` (server only; never commit; never `NEXT_PUBLIC_`).

Generate the three secrets (each different) and put them in `.env.local`:
```
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"   # ID_HASH_PEPPER, ID_ENC_KEY, OTP_SECRET, WALLET_LINK_SECRET
```
**Back up `ID_HASH_PEPPER`.** If you lose or change it, existing ID/phone hashes can no longer be matched.

## 3. Firestore
1. **Firestore Database > Create database** (production mode; pick a region close to Ghana's users, e.g. `europe-west1`).
2. Deploy rules and indexes (needs `npm i -g firebase-tools`, then `firebase login`):
   ```
   firebase use <your-project-id>
   firebase deploy --only firestore:rules,firestore:indexes
   ```
   Indexes take a few minutes to build. Until they finish, admin list screens return "index is building" errors.
3. **Time-to-live** so expired documents clean themselves up (Firestore console > TTL, or gcloud):
   ```
   gcloud firestore fields ttls update expireAt --collection-group=phoneChallenges --enable-ttl
   gcloud firestore fields ttls update expireAt --collection-group=rateLimits --enable-ttl
   ```
   Do **not** put a TTL on `identityDocuments`: that would delete the record, not just the number. `yarn accounts:id-maintenance` handles that collection.

## 4. First administrator
Sign up through the site once, then on a machine that has the server `.env.local`:
```
yarn accounts:set-role --email you@example.com --role super_admin --confirm-identity
```
`--confirm-identity` marks your ID confirmed (needed so you can review others' IDs). Use it only for the people whose ID you have seen in person; it is recorded in the audit log. Sign in again afterwards.

## 5. Run it locally against the emulator (no real Firebase needed)
```
npx firebase-tools emulators:start --only auth,firestore --project demo-classtryout
# .env.local for local work:
#   FIREBASE_PROJECT_ID=demo-classtryout   FIREBASE_AUTH_EMULATOR_HOST=127.0.0.1:9099
#   NEXT_PUBLIC_FIREBASE_AUTH_EMULATOR=http://127.0.0.1:9099   (+ the other NEXT_PUBLIC_FIREBASE_* with any text)
#   FIRESTORE_EMULATOR_HOST=127.0.0.1:8080                      (makes the Admin SDK use the Firestore emulator)
#   SMS_PROVIDER=console
```
The Firestore emulator is where to confirm the rules and indexes behave as the docs say. To run without any emulator, set `STORE_BACKEND=file` (local files only; refused in production).

## 6. Before going live: checklist
- [ ] `firebase deploy --only firestore:rules,firestore:indexes` done; indexes show *Enabled*
- [ ] TTL policies on `phoneChallenges.expireAt` and `rateLimits.expireAt`
- [ ] `NODE_ENV=production`; `STORE_BACKEND=firestore`; `SMS_PROVIDER` is a real provider (mock/console are refused)
- [ ] All secrets set; `ID_HASH_PEPPER` backed up somewhere other than the database
- [ ] SMS sender name registered; sample SMS received on an MTN, Telecel and AT number
- [ ] Privacy notice and terms texts written; bump the versions in `shared/onboarding.json` whenever they change
- [ ] First super administrator created; a second one created (the app refuses to remove the last)
- [ ] `yarn accounts:id-maintenance` scheduled hourly
- [ ] Firebase App Check and a reCAPTCHA/Turnstile on sign-up considered (stops bulk sign-ups)
